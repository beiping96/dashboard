package main

import (
	"fmt"
	"shared/csv"
	redis "shared/mfxredisutil"
	"shared/proto/server/mail"
	"time"

	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
)

// 邮箱
// 每个人有一个邮箱ID的种子
// 每个人有一个邮件ID列表，按照时间排序，使用ZSet来存储
// 每个人有一个邮件数据存储，使用Hash来存储
// 每个人有一个已读且无附件的邮件ID列表，使用ZSet来存储，按照时间排序
// 每个人有一个未读但无附件的邮件ID列表，使用ZSet来存储，按照时间排序
// 总结：每个人有三个List便于各种操作的索引，一个Hash用来存储邮件数据

func makeMailboxIncrKey(accountID string) string {
	return fmt.Sprintf("%s_incr_%s", mailPrefix, accountID)
}

func makeMailboxListKey(accountID string) string {
	return fmt.Sprintf("%s_list_%s", mailPrefix, accountID)
}

func makeMailboxDataKey(accountID string) string {
	return fmt.Sprintf("%s_data_%s", mailPrefix, accountID)
}

func makeMailboxEmptyListKey(accountID string) string {
	// 这个是已读且无附件
	return fmt.Sprintf("%s_empty_%s", mailPrefix, accountID)
}

func makeMailboxNoAttListKey(accountID string) string {
	// 这个是未读但无附件
	return fmt.Sprintf("%s_noatt_%s", mailPrefix, accountID)
}

// Mail的序列化和反序列化

func marshalMail(mail *mail.Mail) (string, error) {
	b, err := proto.Marshal(mail)
	if err != nil {
		return "", err
	}
	return string(b[:]), nil
}

func unmarshalMail(s string) (*mail.Mail, error) {
	b := []byte(s)
	o := &mail.Mail{}
	err := proto.Unmarshal(b, o)
	return o, err
}

// RPC接口的实际实现层，与Redis直接交互

func sendMail(r *redis.RedisUtil, accountID string, ml *mail.Mail) (uint32, error) {
	ts := uint32(time.Now().Unix())
	// 先获得mailID
	noKey := makeMailboxIncrKey(accountID)
	id, _ := r.Cmd("INCR", noKey).Int64()
	mailID := fmt.Sprintf("%d", id)
	// 填充Mail结构，然后序列化
	ml.MailId = uint64(id)
	ml.Type = mail.MailType_personal
	ml.Timestamp = ts
	ml.Read = false
	msg, err := marshalMail(ml)
	if err != nil {
		log.Error().Msgf("marshal failed: %s", err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	// 将这个msg放入Hash中
	hashKey := makeMailboxDataKey(accountID)
	_, err = r.Cmd("HSET", hashKey, mailID, msg).Int64()
	if err != nil {
		log.Error().Msgf("HSET key=%s field=%s failed: %s", hashKey, mailID, err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	// 再放入到自己的ZSet中
	listKey := makeMailboxListKey(accountID)
	_, err = r.Cmd("ZADD", listKey, ts, mailID).Int64()
	if err != nil {
		log.Error().Msgf("ZADD key=%s value=%s failed: %s", listKey, mailID, err.Error())
		r.Cmd("HDEL", hashKey, mailID)
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}

	// 个人邮箱有一个最大值设定，如果当前邮箱存储邮件达到最大值，则需要删掉一封已有邮件
	// 删除规则如下：
	// 1. 优先删除空邮件，即已读，且无附件
	// 2. 其次删除未读的，但无附件的邮件
	// 3. 如果1和2都没有找到，则按照时间顺序删除一份邮件即可
	checkAndDeleteMail(r, accountID)

	return csv.ERRCODE_SUCCESS, nil
}

func fetchMail(r *redis.RedisUtil, hashKey, mailID string) (*mail.Mail, error) {
	mailStr, err := r.Cmd("HGET", hashKey, mailID).Str()
	if err != nil {
		log.Error().Msgf("HGET key=%s mail=%s str=%s", hashKey, mailID, mailStr)
		return nil, err
	}
	o, err := unmarshalMail(mailStr)
	if err != nil {
		log.Error().Msgf("unmarshal str=%s failed: %s", mailStr, err.Error())
		return nil, err
	}
	return o, nil
}

func fetchMails(r *redis.RedisUtil, accountID string, startPos, endPos uint32) ([]*mail.Mail, error) {
	listKey := makeMailboxListKey(accountID)
	// 先删除一波过期的邮件
	now := time.Now().Unix()
	last := now - int64(cfg.ExpiredDays*24*60*60)
	array, err := r.Cmd("ZRANGEBYSCORE", listKey, 0, last).List()
	if err != nil {
		log.Error().Msgf("ZRANGEBYSCORE key=%s [0, %d] failed: %s", listKey, last, err.Error())
		return nil, err
	}
	hashKey := makeMailboxDataKey(accountID)
	emptyKey := makeMailboxEmptyListKey(accountID)
	noattKey := makeMailboxNoAttListKey(accountID)
	for i := 0; i < len(array); i++ {
		mailID := array[i]
		if mailID == "" {
			continue
		}
		deleteMail(r, listKey, noattKey, emptyKey, hashKey, mailID)
	}
	// 再拉取邮件ID
	var mails []*mail.Mail
	array, err = r.Cmd("ZREVRANGE", listKey, startPos, endPos).List()
	if err != nil {
		log.Error().Msgf("ZREVRANGE key=%s [%d, %d] failed: %s", listKey, startPos, endPos, err.Error())
		return nil, err
	}
	for i := 0; i < len(array); i++ {
		mailID := array[i]
		o, err := fetchMail(r, hashKey, mailID)
		if err == nil {
			mails = append(mails, o)
		}
	}
	return mails, nil
}

func setMailRead(r *redis.RedisUtil, accountID, mailID string, read bool) (uint32, error) {
	hashKey := makeMailboxDataKey(accountID)
	mailStr, err := r.Cmd("HGET", hashKey, mailID).Str()
	if err != nil {
		log.Error().Msgf("HGET key=%s mail=%s str=%s", hashKey, mailID, mailStr)
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	o, err := unmarshalMail(mailStr)
	if err != nil {
		log.Error().Msgf("unmarshal str=%s failed: %s", mailStr, err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	o.Read = read
	mailStr, err = marshalMail(o)
	if err != nil {
		log.Error().Msgf("marshal key=%s mail=%s failed: %s", hashKey, mailID, err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	_, err = r.Cmd("HSET", hashKey, mailID, mailStr).Int64()
	if err != nil {
		log.Error().Msgf("HSET key=%s mail=%s failed: %s", hashKey, mailID, err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	// 为删除而作的优化处理
	optzForDeleteMail(r, accountID, mailID, o)
	return csv.ERRCODE_SUCCESS, nil
}

func updateMailAttachment(r *redis.RedisUtil, accountID, mailID, newAttachment string) (uint32, error) {
	hashKey := makeMailboxDataKey(accountID)
	mailStr, err := r.Cmd("HGET", hashKey, mailID).Str()
	if err != nil {
		log.Error().Msgf("HGET key=%s mail=%s str=%s", hashKey, mailID, mailStr)
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	o, err := unmarshalMail(mailStr)
	if err != nil {
		log.Error().Msgf("unmarshal str=%s failed: %s", mailStr, err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	o.Attachment = newAttachment
	mailStr, err = marshalMail(o)
	if err != nil {
		log.Error().Msgf("marshal key=%s mail=%s failed: %s", hashKey, mailID, err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	_, err = r.Cmd("HSET", hashKey, mailID, mailStr).Int64()
	if err != nil {
		log.Error().Msgf("HSET key=%s mail=%s failed: %s", hashKey, mailID, err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	// 为删除而作的优化处理
	optzForDeleteMail(r, accountID, mailID, o)
	return csv.ERRCODE_SUCCESS, nil
}

func isEmpty(ml *mail.Mail) bool {
	return (ml.Attachment == "") && ml.Read
}

func isNoAtt(ml *mail.Mail) bool {
	return (ml.Attachment == "") && !ml.Read
}

func optzForDeleteMail(r *redis.RedisUtil, accountID, mailID string, ml *mail.Mail) {
	ts := ml.Timestamp
	emtpy := isEmpty(ml)
	noatt := isNoAtt(ml)
	emptyKey := makeMailboxEmptyListKey(accountID)
	noattKey := makeMailboxNoAttListKey(accountID)
	if emtpy {
		r.Cmd("ZADD", emptyKey, ts, mailID)
		r.Cmd("ZREM", noattKey, mailID)
		log.Debug().Msgf("account=%s mail=%s in empty list, delete from noatt list", accountID, mailID)
	} else if noatt {
		r.Cmd("ZREM", emptyKey, mailID)
		r.Cmd("ZADD", noattKey, ts, mailID)
		log.Debug().Msgf("account=%s mail=%s in noatt list, delete from empty list", accountID, mailID)
	}
}

func deleteMail(r *redis.RedisUtil, listKey, noattKey, emptyKey, hashKey, mailID string) {
	log.Debug().Msgf("delete mail=%s", mailID)
	r.Cmd("ZREM", listKey, mailID)
	r.Cmd("ZREM", emptyKey, mailID)
	r.Cmd("ZREM", noattKey, mailID)
	r.Cmd("HDEL", hashKey, mailID)
}

func deleteAccountMail(r *redis.RedisUtil, accountID, mailID string) (uint32, error) {
	listKey := makeMailboxListKey(accountID)
	emptyKey := makeMailboxEmptyListKey(accountID)
	noattKey := makeMailboxNoAttListKey(accountID)
	hashKey := makeMailboxDataKey(accountID)
	deleteMail(r, listKey, noattKey, emptyKey, hashKey, mailID)
	return csv.ERRCODE_SUCCESS, nil
}

func findMailIDForDelete(r *redis.RedisUtil, emptyKey, noattKey, listKey string) (string, bool) {
	array, err := r.Cmd("ZRANGE", emptyKey, 0, 0).List()
	if err == nil && len(array) > 0 {
		log.Debug().Msgf("find mail=%s delete in empty list", array[0])
		return array[0], true
	}

	array, err = r.Cmd("ZRANGE", noattKey, 0, 0).List()
	if err == nil && len(array) > 0 {
		log.Debug().Msgf("find mail=%s delete in noatt list", array[0])
		return array[0], true
	}

	array, err = r.Cmd("ZRANGE", listKey, 0, 0).List()
	if err == nil && len(array) > 0 {
		log.Debug().Msgf("find mail=%s delete in normal list", array[0])
		return array[0], true
	}

	return "", false
}

func checkAndDeleteMail(r *redis.RedisUtil, accountID string) {
	listKey := makeMailboxListKey(accountID)
	n, err := r.Cmd("ZCARD", listKey).Int64()
	if err != nil {
		log.Error().Msgf("ZCARD list=%s failed: %s", listKey, err.Error())
		return
	}
	if n <= int64(cfg.MaxNumber) {
		log.Debug().Msgf("account=%s mail count=%d, just return", accountID, n)
		return
	}
	delCount := n - int64(cfg.MaxNumber)
	log.Debug().Msgf("account=%s need to delete %d mails", accountID, delCount)
	emptyKey := makeMailboxEmptyListKey(accountID)
	noattKey := makeMailboxNoAttListKey(accountID)
	hashKey := makeMailboxDataKey(accountID)
	for i := int64(0); i < delCount; i++ {
		mailID, exist := findMailIDForDelete(r, emptyKey, noattKey, listKey)
		if exist {
			deleteMail(r, listKey, noattKey, emptyKey, hashKey, mailID)
		}
	}
}

// 全体邮件
// 全体邮件在一个独立的地方存储自己的数据，它不存在什么更新附件和设置已读
// 某个玩家领取了全体邮件的奖励，是在这个玩家身上设置标记的，可以是mailID

func makeMailboxGlobalIncrKey() string {
	return fmt.Sprintf("%s_global_incr", mailPrefix)
}

func makeMailboxGlobalListKey() string {
	return fmt.Sprintf("%s_global_list", mailPrefix)
}

func makeMailboxGlobalDataKey() string {
	return fmt.Sprintf("%s_global_data", mailPrefix)
}

func sendGlobalMail(r *redis.RedisUtil, ml *mail.Mail) (uint64, error) {
	ts := uint32(time.Now().Unix())
	incrKey := makeMailboxGlobalIncrKey()
	listKey := makeMailboxGlobalListKey()
	hashKey := makeMailboxGlobalDataKey()
	// 先获得mailID
	id, _ := r.Cmd("INCR", incrKey).Int64()
	mailID := fmt.Sprintf("%d", id)
	// 填充Mail结构，然后序列化
	ml.MailId = uint64(id)
	ml.Type = mail.MailType_global
	ml.Timestamp = ts
	ml.Read = false
	msg, err := marshalMail(ml)
	if err != nil {
		log.Error().Msgf("marshal global mail failed: %s", err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	// 放入Hash中存储
	_, err = r.Cmd("HSET", hashKey, mailID, msg).Int64()
	if err != nil {
		log.Error().Msgf("HSET key=%s field=%s failed: %s", hashKey, mailID, err.Error())
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	// 在放入自己的List中
	_, err = r.Cmd("ZADD", listKey, ts, mailID).Int64()
	if err != nil {
		log.Error().Msgf("ZADD key=%s value=%s failed: %s", listKey, mailID, err.Error())
		r.Cmd("HDEL", hashKey, mailID)
		return csv.ERRCODE_SYS_INTERNAL_ERROR, err
	}
	return csv.ERRCODE_SUCCESS, nil
}

func fetchGlobalMails(r *redis.RedisUtil, startPos, endPos uint32) ([]*mail.Mail, error) {
	var mails []*mail.Mail
	listKey := makeMailboxGlobalListKey()
	hashKey := makeMailboxGlobalDataKey()
	array, err := r.Cmd("ZREVRANGE", listKey, startPos, endPos).List()
	if err != nil {
		log.Error().Msgf("ZREVRANGE key=%s [%d, %d] failed: %s", listKey, startPos, endPos, err.Error())
		return nil, err
	}
	for i := 0; i < len(array); i++ {
		mailID := array[i]
		mailStr, err := r.Cmd("HGET", hashKey, mailID).Str()
		if err != nil {
			log.Error().Msgf("HGET key=%s field=%s failed: %s", hashKey, mailID, err.Error())
			continue
		}
		o, err := unmarshalMail(mailStr)
		if err != nil {
			log.Error().Msgf("unmarshal str=%s failed: %s", mailStr, err.Error())
			continue
		}
		mails = append(mails, o)
	}
	return mails, nil
}

func deleteGlobalMail(r *redis.RedisUtil, mailID uint64) (uint32, error) {
	listKey := makeMailboxGlobalListKey()
	hashKey := makeMailboxGlobalDataKey()
	r.Cmd("ZREM", listKey, mailID)
	r.Cmd("HDEL", hashKey, mailID)
	return csv.ERRCODE_SUCCESS, nil
}
