package main

import (
	"fmt"
	"golang.org/x/net/context"
	"shared/csv"
	cp "shared/mfxcoredump"
	"shared/proto/server/mail"
)

type myService struct{}

func (my *myService) SendMail(ctx context.Context, req *mail.SendMailReq) (*mail.SendMailRsp, error) {
	defer cp.CoredumpHandler()
	accountID := fmt.Sprintf("%d", req.AccountId)
	result, err := sendMail(getRedis(), accountID, req.MailCtx)
	rsp := &mail.SendMailRsp{
		Result:    result,
		AccountId: req.AccountId,
	}
	if err != nil {
		rsp.Result = csv.ERRCODE_SYS_INTERNAL_ERROR
	}
	return rsp, nil
}

func (my *myService) FetchMails(ctx context.Context, req *mail.FetchMailReq) (*mail.FetchMailRsp, error) {
	defer cp.CoredumpHandler()
	accountID := fmt.Sprintf("%d", req.AccountId)
	mails, err := fetchMails(getRedis(), accountID, req.StartPos, req.EndPos)
	if err == nil {
		rsp := &mail.FetchMailRsp{
			Result:    csv.ERRCODE_SUCCESS,
			AccountId: req.AccountId,
			StartPos:  req.StartPos,
			EndPos:    req.EndPos,
			Mails:     mails,
		}
		return rsp, nil
	}
	rsp := &mail.FetchMailRsp{Result: csv.ERRCODE_SYS_INTERNAL_ERROR}
	return rsp, nil
}

func (my *myService) SetMailRead(ctx context.Context, req *mail.SetMailReadReq) (*mail.SetMailReadRsp, error) {
	defer cp.CoredumpHandler()
	accountID := fmt.Sprintf("%d", req.AccountId)
	mailID := fmt.Sprintf("%d", req.MailId)
	result, err := setMailRead(getRedis(), accountID, mailID, true)
	rsp := &mail.SetMailReadRsp{
		Result:    result,
		AccountId: req.AccountId,
		MailId:    req.MailId,
		Read:      true,
	}
	if err != nil {
		rsp.Result = csv.ERRCODE_SYS_INTERNAL_ERROR
	}
	return rsp, nil
}

func (my *myService) UpdateMailAttachment(ctx context.Context, req *mail.UpdateMailAttachmentReq) (*mail.UpdateMailAttachmentRsp, error) {
	defer cp.CoredumpHandler()
	accountID := fmt.Sprintf("%d", req.AccountId)
	mailID := fmt.Sprintf("%d", req.MailId)
	result, err := updateMailAttachment(getRedis(), accountID, mailID, req.NewAttachment)
	rsp := &mail.UpdateMailAttachmentRsp{
		Result:        result,
		AccountId:     req.AccountId,
		MailId:        req.MailId,
		NewAttachment: req.NewAttachment,
	}
	if err != nil {
		rsp.Result = csv.ERRCODE_SYS_INTERNAL_ERROR
	}
	return rsp, nil
}

func (my *myService) DeleteMail(ctx context.Context, req *mail.DeleteMailReq) (*mail.DeleteMailRsp, error) {
	defer cp.CoredumpHandler()
	accountID := fmt.Sprintf("%d", req.AccountId)
	mailID := fmt.Sprintf("%d", req.MailId)
	result, err := deleteAccountMail(getRedis(), accountID, mailID)
	rsp := &mail.DeleteMailRsp{
		Result:    result,
		AccountId: req.AccountId,
		MailId:    req.MailId,
	}
	if err != nil {
		rsp.Result = csv.ERRCODE_SYS_INTERNAL_ERROR
	}
	return rsp, nil
}

func (my *myService) SendGlobalMail(ctx context.Context, req *mail.SendGlobalMailReq) (*mail.SendGlobalMailRsp, error) {
	defer cp.CoredumpHandler()
	mailID, err := sendGlobalMail(getRedis(), req.MailCtx)
	rsp := &mail.SendGlobalMailRsp{
		Result: csv.ERRCODE_SUCCESS,
		MailId: mailID,
	}
	if err != nil {
		rsp.Result = csv.ERRCODE_SYS_INTERNAL_ERROR
	}
	return rsp, nil
}

func (my *myService) FetchGlobalMails(ctx context.Context, req *mail.FetchGlobalMailReq) (*mail.FetchGlobalMailRsp, error) {
	defer cp.CoredumpHandler()
	mails, err := fetchGlobalMails(getRedis(), req.StartPos, req.EndPos)
	rsp := &mail.FetchGlobalMailRsp{
		Result:   csv.ERRCODE_SUCCESS,
		StartPos: req.StartPos,
		EndPos:   req.EndPos,
		Mails:    mails,
	}
	if err != nil {
		rsp.Result = csv.ERRCODE_SYS_INTERNAL_ERROR
	}
	return rsp, nil
}

func (my *myService) DeleteGlobalMail(ctx context.Context, req *mail.DeleteGlobalMailReq) (*mail.DeleteGlobalMailRsp, error) {
	defer cp.CoredumpHandler()
	result, err := deleteGlobalMail(getRedis(), req.MailId)
	rsp := &mail.DeleteGlobalMailRsp{
		Result: result,
		MailId: req.MailId,
	}
	if err != nil {
		rsp.Result = csv.ERRCODE_SYS_INTERNAL_ERROR
	}
	return rsp, nil
}
