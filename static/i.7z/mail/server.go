package main

import (
	"encoding/xml"
	"github.com/rs/zerolog/log"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"io/ioutil"
	"net"
	bd "shared/mfxbasedef"
	lr "shared/mfxlocalregistry"
	lu "shared/mfxlogutil"
	redis "shared/mfxredisutil"
	"shared/proto/server/mail"
)

type mailCfg struct {
	Division    string             `xml:"division"`
	RPC         bd.EndPoint        `xml:"rpc"`
	Loc         bd.Locator         `xml:"locator"`
	Redis       bd.RedisConnection `xml:"redis"`
	LogPath     string             `xml:"log_path"`
	LogLevel    string             `xml:"log_level"`
	ExpiredDays uint32             `xml:"mail_expired_days"`
	MaxNumber   uint32             `xml:"mail_max_number"`
}

var (
	cfg        mailCfg
	redisPool  *redis.RedisUtil
	mailPrefix string
)

func getRedis() *redis.RedisUtil {
	return redisPool
}

func initKeyPrefix(division string) bool {
	app, server, _, err := bd.ParseDivision(division)
	if err != nil {
		log.Error().Msgf("division format error: %s", err.Error())
		return false
	}
	mailPrefix = app + "_" + server + "_mailbox_"
	return true
}

func startRPC() bool {
	rpcAddr := cfg.RPC.Ip + ":" + cfg.RPC.Port
	ls, err := net.Listen("tcp", rpcAddr)
	if err != nil {
		log.Error().Msgf("rpc listen failed: %s", err.Error())
		return false
	}
	defer ls.Close()

	log.Info().Msgf("rpc listen addr=%s ok", rpcAddr)
	srv := grpc.NewServer()
	mail.RegisterMailServiceServer(srv, &myService{})
	reflection.Register(srv)
	srv.Serve(ls)

	log.Info().Msg("rpc exit")
	return true
}

func start(xmlFile string) bool {
	log.Info().Msgf("start with cfg: %s", xmlFile)

	fileData, err := ioutil.ReadFile(xmlFile)
	if err != nil {
		log.Error().Msgf("%s", err.Error())
		return false
	}

	if err := xml.Unmarshal(fileData, &cfg); err != nil {
		log.Error().Msgf("%s", err.Error())
		return false
	}

	log.Info().Msgf("log path=%s, level=%s", cfg.LogPath, cfg.LogLevel)

	// 设置日志输出和日志级别
	lu.SetupLogPath(cfg.LogPath)
	lu.SetupLogLevel(cfg.LogLevel)
	log.Info().Msgf("division=%s", cfg.Division)
	if cfg.ExpiredDays == 0 {
		cfg.ExpiredDays = 30
	}
	if cfg.MaxNumber == 0 {
		cfg.MaxNumber = 15
	}
	log.Info().Msgf("mail expired days=%d, max number=%d", cfg.ExpiredDays, cfg.MaxNumber)

	// 初始化key的前缀
	if !initKeyPrefix(cfg.Division) {
		log.Error().Msg("init key prefix failed")
		return false
	}

	// 设置registry，定时从服务器拉取，第一次失败就退出
	lr.SetLocator(cfg.Loc.Ep.Ip, cfg.Loc.Ep.Port)
	if err := lr.QueryRegistry(); err != nil {
		log.Error().Msgf("query registry from %s:%s failed: %s", cfg.Loc.Ep.Ip, cfg.Loc.Ep.Port, err.Error())
		return false
	}
	log.Info().Msgf("query registry ok")
	lr.StartQueryLoop(cfg.Loc.RefreshInterval)

	// 尝试连接Redis数据库
	if redisPool, err = redis.NewRedisUtil(cfg.Redis.Ep.Ip + ":" + cfg.Redis.Ep.Port); err != nil {
		log.Error().Msgf("redis init failed: %s", err.Error())
		return false
	}

	// 绑定RPC端口，以rpc的形式提供其他节点的状态上报服务
	return startRPC()
}
