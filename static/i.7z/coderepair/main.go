﻿package main

import (
	"database/sql"
	"encoding/json"
	"encoding/xml"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"os"
	logUtil "shared/mfxlogutil"
	"strconv"
	"sync"
	"time"
)

// CodeRepairConfig define for coderepairService config
type CodeRepairConfig struct {
	DbIP        string `xml:"db_ip"`
	DbPort      string `xml:"db_port"`
	DbUser      string `xml:"db_user"`
	DbPwd       string `xml:"db_pwd"`
	DbName      string `xml:"db_name"`
	ListenPort  string `xml:"listen_port"`
	RefreshTime string `xml:"refresh_second"`
	LogPath     string `xml:"log_path"`
	LogLevel    string `xml:"log_level"`
}

// ReadRsp - read content
type ReadRsp struct {
	Result  int    `json:"result"`
	Content string `json:"data"`
	Error   string `json:"error"`
}

// WriteRsp - write content
type WriteRsp struct {
	Result int    `json:"result"`
	Error  string `json:"error"`
}

type coderepairService struct {
	lock  sync.RWMutex
	code  *string
	dbStr string

	rDB *sql.DB
	wDB *sql.DB

	// IP白名单
	ipTable    map[string]int
	skipIPAuth bool
}

var globalCoderepairService *coderepairService

func getCode() *string {
	globalCoderepairService.lock.RLock()
	defer globalCoderepairService.lock.RUnlock()
	return globalCoderepairService.code
}

func setCode(s *string) {
	globalCoderepairService.lock.Lock()
	defer globalCoderepairService.lock.Unlock()
	globalCoderepairService.code = s
}

func skipIPAuth() bool {
	globalCoderepairService.lock.RLock()
	defer globalCoderepairService.lock.RUnlock()
	return globalCoderepairService.skipIPAuth
}

func ipTableContain(rip string) bool {
	globalCoderepairService.lock.RLock()
	defer globalCoderepairService.lock.RUnlock()
	_, ok := globalCoderepairService.ipTable[rip]
	return ok
}

func setIPTable(m map[string]int) {
	globalCoderepairService.lock.Lock()
	defer globalCoderepairService.lock.Unlock()
	globalCoderepairService.ipTable = m
	if len(globalCoderepairService.ipTable) > 0 {
		globalCoderepairService.skipIPAuth = false
	} else {
		globalCoderepairService.skipIPAuth = true
	}
}

func main() {
	if len(os.Args) < 2 {
		panic(fmt.Errorf("./coderepair coderepair.xml"))
	}

	fileData, err := ioutil.ReadFile(os.Args[1])
	if err != nil {
		panic(fmt.Errorf("read config failed: %s", err.Error()))
	}
	var config CodeRepairConfig
	err = xml.Unmarshal(fileData, &config)
	if err != nil {
		panic(fmt.Errorf("parse config failed: %s", err.Error()))
	}
	if config.LogPath == "" {
		config.LogPath = "./coderepair.log"
	}

	logUtil.SetupLogPath(config.LogPath)
	logUtil.SetupLogLevel(config.LogLevel)

	dbStr := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8",
		config.DbUser, config.DbPwd, config.DbIP, config.DbPort, config.DbName)

	globalCoderepairService = &coderepairService{}
	c := ""
	globalCoderepairService.code = &c

	globalCoderepairService.rDB, err = sql.Open("mysql", dbStr)
	if err != nil {
		panic(err.Error())
	}
	err = globalCoderepairService.rDB.Ping()
	if err != nil {
		panic(err.Error())
	}

	globalCoderepairService.wDB, err = sql.Open("mysql", dbStr)
	if err != nil {
		panic(err.Error())
	}
	err = globalCoderepairService.wDB.Ping()
	if err != nil {
		panic(err.Error())
	}
	globalCoderepairService.wDB.SetConnMaxLifetime(time.Duration(5) * time.Second)

	tick, err := strconv.ParseInt(config.RefreshTime, 10, 32)
	if err != nil {
		tick = 60
		log.Info().Msgf("refresh_time invalid, now set to %ds", tick)
	}
	go loadCodeTimer(uint32(tick))

	// start the http service
	http.HandleFunc("/setLuaStr", httpSetLuaStr)
	http.HandleFunc("/getLuaStr", httpGetLuaStr)
	server := &http.Server{Addr: config.ListenPort, Handler: nil}
	log.Info().Msg("start server success.")
	err = server.ListenAndServe()
	if err != nil {
		log.Panic().Msg(err.Error())
	}
}

func loadCodeTimer(t uint32) {
	ticker := time.Tick(time.Duration(t) * time.Second)
	for {
		<-ticker
		// 从数据库加载IP白名单
		m, err := loadIPTableFromDB()
		if err == nil {
			setIPTable(m)
			log.Info().Msgf("skipIPAuth: %t", skipIPAuth())
		}

		// 从数据库加载代码串
		s, err := loadCodeFromDB()
		if err != nil {
			log.Error().Msgf("load timer failed: %s", err.Error())
			continue
		}

		c := getCode()
		code := *c
		if code == s {
			log.Info().Msgf("code is equal between db and mem, %s", s)
			continue
		}

		// 不同，则修改之
		setCode(&s)
		log.Info().Msg("update code cache success...")
	}
}

func loadIPTableFromDB() (map[string]int, error) {
	m := make(map[string]int, 100)
	sqlStr := fmt.Sprintf("SELECT ip FROM ip_table LIMIT 100")
	log.Info().Msgf("load ip: %v", sqlStr)

	rows, err := globalCoderepairService.rDB.Query(sqlStr)
	if err != nil {
		log.Error().Msg(err.Error())
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var ip string
		err = rows.Scan(&ip)
		if err != nil {
			continue
		}
		m[ip] = 1
	}

	return m, nil
}

func loadCodeFromDB() (string, error) {
	err := globalCoderepairService.rDB.Ping()
	if err != nil {
		return "", err
	}

	sqlStr := fmt.Sprintf("SELECT code_cont FROM content ORDER BY id DESC LIMIT 1")
	log.Info().Msg(sqlStr)
	rows, err := globalCoderepairService.rDB.Query(sqlStr)
	if err != nil {
		return "", err
	}
	defer rows.Close()

	code := ""
	for rows.Next() {
		var codeStr string
		err = rows.Scan(&codeStr)
		if err == nil {
			log.Info().Msgf("code string: %s", codeStr)
			code = codeStr
			break
		}
	}

	return code, nil
}

func httpSetLuaStr(rsp http.ResponseWriter, req *http.Request) {
	rsp.Header().Add("Access-Control-Allow-Origin", "*")

	rip, _, _ := net.SplitHostPort(req.RemoteAddr)
	log.Info().Msgf("req from ip: %v method: %v", rip, req.Method)

	var result WriteRsp

	if !skipIPAuth() && !ipTableContain(rip) {
		log.Error().Msgf("error ip address %v", rip)
		result.Result = 1
		result.Error = "should in ip white-list"
		body, _ := json.Marshal(result)
		rsp.Write(body)
		return
	}

	if req.Method != "POST" {
		log.Error().Msgf("error Method %v", req.Method)
		result.Result = 1
		result.Error = "should use POST method"
		body, _ := json.Marshal(result)
		rsp.Write(body)
		return
	}

	req.ParseForm()
	log.Info().Msgf("form: %v", req.Form)

	luaStr := req.FormValue("luaStr")
	if luaStr == "" {
		log.Error().Msgf("error, luaStr field not exist")
		result.Result = 1
		result.Error = "should contain 'luaStr' field"
		body, _ := json.Marshal(result)
		rsp.Write(body)
		return
	}

	log.Info().Msgf("luaStr: %v", luaStr)

	saveLuaStrToDb(url.QueryEscape(luaStr))

	result.Result = 0
	result.Error = ""
	body, _ := json.Marshal(result)
	rsp.Write(body)
}

func httpGetLuaStr(rsp http.ResponseWriter, req *http.Request) {
	rip, _, _ := net.SplitHostPort(req.RemoteAddr)
	log.Info().Msgf("req from ip: %v method: %v", rip, req.Method)

	var result ReadRsp

	result.Result = 0
	result.Content = *getCode()
	result.Error = ""

	body, _ := json.Marshal(result)
	rsp.Header().Add("Access-Control-Allow-Origin", "*")
	rsp.Write(body)
}

func saveLuaStrToDb(luaStr string) error {
	err := globalCoderepairService.wDB.Ping()
	if err != nil {
		return err
	}

	sqlStr := fmt.Sprintf("INSERT INTO content (code_cont) VALUES ('%s')", luaStr)
	log.Info().Msgf("save luastr: %s", sqlStr)

	_, err = globalCoderepairService.wDB.Exec(sqlStr)
	if err != nil {
		log.Error().Msgf("save exec error: %v", err)
		return err
	}

	return err
}
