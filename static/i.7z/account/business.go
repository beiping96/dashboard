package main

import (
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"net"
	"os"
	"shared/csv"
	bd "shared/mfxbasedef"
	cd "shared/mfxconn"
	lr "shared/mfxlocalregistry"
	gs "shared/proto/client/portal"
	cmd "shared/proto/share/command"
	"time"
)

// 业务服务

var (
	AccountRedisPrefix string

	// 当前大区id
	ZoneId string = "0"

	// 当前推荐的大厅id
	LobbyId string = "0"
)

func makeAccountKey(key string) string {
	return AccountRedisPrefix + key
}

func makeUUIDKey(key string) string {
	return AccountRedisPrefix + "uuid_" + key
}

func initAccountConfig(config AccountConfig) (bool, string, string) {
	// 尝试初始化zone_id
	key := makeAccountKey("zone_id")
	value := config.ZoneInitID
	if b, err := redisPool.Cmd("SETNX", key, value).Int(); err != nil {
		log.Error().Msgf("SETNX key=%s failed: %s", key, err.Error())
		os.Exit(-1)
	} else {
		if b == 1 {
			log.Info().Msgf("key=%s init to: %s", key, value)
		} else {
			if s, err := redisPool.Cmd("GET", key).Str(); err != nil {
				log.Error().Msgf("GET key=%s failed: %s", key, err.Error())
				os.Exit(-1)
			} else {
				value = s
				log.Info().Msgf("key=%s exist: %s", key, s)
			}
		}
	}
	zoneID := value

	// 尝试初始化zone_no
	key = makeAccountKey("zone_no")
	value = config.ZoneInitNo
	if b, err := redisPool.Cmd("SETNX", key, value).Int(); err != nil {
		log.Error().Msgf("SETNX key=%s failed: %s", key, err.Error())
		os.Exit(-1)
	} else {
		if b == 1 {
			log.Info().Msgf("key=%s init to: %s", key, value)
		} else {
			if s, err := redisPool.Cmd("GET", key).Str(); err != nil {
				log.Error().Msgf("GET key=%s failed: %s", key, err.Error())
				os.Exit(-1)
			} else {
				log.Info().Msgf("key=%s exist: %s", key, s)
			}
		}
	}

	// 尝试初始化推荐lobby_id
	key = makeAccountKey("recommand_lobby")
	value = config.ZoneInitLobby
	if b, err := redisPool.Cmd("SETNX", key, value).Int(); err != nil {
		log.Error().Msgf("SETNX key=%s failed: %s", key, err.Error())
		os.Exit(-1)
	} else {
		if b == 1 {
			log.Info().Msgf("key=%s init to: %s", key, value)
		} else {
			if s, err := redisPool.Cmd("GET", key).Str(); err != nil {
				log.Error().Msgf("GET key=%s failed: %s", key, err.Error())
				os.Exit(-1)
			} else {
				log.Info().Msgf("key=%s exist: %s", key, s)
			}
		}
	}
	lobbyID := value

	return true, zoneID, lobbyID
}

func loadFromRedis(t uint32) {
	tick := time.NewTicker(time.Duration(t) * time.Second)
	for {
		select {
		case <-tick.C:
			log.Debug().Msg("load from redis active")
			key := makeAccountKey("recommand_lobby")
			lobbyID, _ := redisPool.Cmd("GET", key).Str()
			if lobbyID != "" && lobbyID != LobbyId {
				oldLobbyID := LobbyId
				LobbyId = lobbyID
				log.Info().Msgf("recommand lobby change from %s to %s", oldLobbyID, LobbyId)
			}
		}
	}
}

func handleClient(conn net.Conn) {
	defer conn.Close()
	cd.HandleStream(conn, func(conn net.Conn, hdr, body []byte) {
		dispatchAccountSignal(conn, hdr, body)
	})
}

func startBusiness(config AccountConfig, ch chan<- string) {
	// 尝试初始化account redis，如果已有初始化，则取得该值
	r, zoneId, lobbyId := initAccountConfig(config)
	if !r {
		ch <- "redis step failed"
		return
	}

	log.Info().Msgf("account run with zone=%s, recommand lobby=%s", zoneId, lobbyId)
	ZoneId = zoneId
	LobbyId = lobbyId

	// 初始化一个timer，它会定时从redis中拉取并更新配置，如推荐服
	go loadFromRedis(config.RedisRefreshInterval)

	// 初始化业务服务
	businessAddr := config.Business.Ip + ":" + config.Business.Port

	ls, err := net.Listen("tcp", businessAddr)
	if err != nil {
		log.Error().Msgf("business listen failed: %s", err.Error())
		ch <- "listen step failed"
		return
	}
	defer ls.Close()
	log.Info().Msgf("listen business addr=%s ok", businessAddr)
	ch <- "ready"

	for {
		conn, err := ls.Accept()
		if err != nil {
			log.Error().Msgf("business accept failed: %s", err.Error())
			continue
		}
		go handleClient(conn)
	}

	log.Info().Msg("business exit")
	ch <- "exit"
	return
}

// 辅助函数

func handleBindAccount(req *gs.BindAccountReq) *gs.BindAccountRsp {
	r := int32(0)
	rsp := &gs.BindAccountRsp{}
	accId, lobbyId, newbie, err := bindAccountWithCluster(*req.DeviceId)
	if err != nil {
		log.Debug().Msgf("bindAccountWithCluster err :%v", err)
		r = csv.ERRCODE_ACCOUNT_BIND_FAILED
		rsp.Result = &r
		return rsp
	}

	// 获得相应lobby的地址
	division := bd.MakeDivision(App, DispatchType, lobbyId)
	Sip, Sport, _, _, err := lr.QueryEndpoint(App, DispatchType, division)
	if err != nil {
		log.Debug().Msgf("Find lobby addr err :%v", err)
		r = csv.ERRCODE_ACCOUNT_LOBBY_NOTFOUND
		rsp.Result = &r
		return rsp
	}

	// 查找到了对应的lobby地址,需要把玩家信息同步到lobby上
	intToken := uint64(0)
	/*
		RpcAddr := fmt.Sprintf("%s:%d", Sip, RpcPort)
		intToken := token.Int64Token(accId)
		err = bindAccToken(accId, intToken, RpcAddr)
		if err != nil {
			log.Debug().Msgf("bindAccToken err :%v", err)
			r = 3
			rsp.Result = &r
			return rsp
		}*/

	r = csv.ERRCODE_SUCCESS
	rsp.Result = &r
	rsp.AccountId = &accId
	rsp.Token = &intToken
	rsp.LobbyAddr = &Sip
	rsp.LobbyPort = &Sport
	rsp.Newbie = &newbie
	return rsp
}

func dispatchAccountSignal(conn net.Conn, hdr []byte, body []byte) error {
	h := cd.ParseHeader(hdr)
	log.Debug().Msgf("account handler, header: body=%d, opcode=%d, seq=%d, timestamp=%d", h.BodyLen, h.CmdID, h.UserData, h.Timestamp)

	opcodeId := cmd.CLIENT_REQ_CMD(h.CmdID)
	switch opcodeId {
	case cmd.CLIENT_REQ_CMD_BIND_ACCOUNT_REQ:
		log.Debug().Msg("bind account req")
		req := &gs.BindAccountReq{}
		err := proto.Unmarshal(body, req)
		if err != nil {
			log.Error().Msgf("unmarshal failed, %s", err.Error())
		} else {
			log.Debug().Msgf("req: %s", req.String())
			rsp := handleBindAccount(req)
			log.Debug().Msgf("rsp: %s", rsp.String())
			w, err := proto.Marshal(rsp)
			if err != nil {
				log.Error().Msgf("marshal failed, %s", err.Error())
			} else {
				pkt := cd.MakeCommonPkt(uint16(cmd.CLIENT_RSP_CMD_BIND_ACCOUNT_RSP), h.UserData, h.Timestamp, w)
				conn.Write(pkt)
			}
		}
	default:
		log.Error().Msgf("unknown cmd=%d", h.CmdID)
	}

	return nil
}
