package main

import (
	"encoding/xml"
	"errors"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"math/rand"
	"net/http"
	"os"
	bd "shared/mfxbasedef"
	lr "shared/mfxlocalregistry"
	lu "shared/mfxlogutil"
	redis "shared/mfxredisutil"
	"shared/proto/server/account"
	"strconv"
	"time"
)

var (
	// redis连接池
	redisPool *redis.RedisUtil

	// 当前节点的域名信息
	App          string
	Server       string
	Division     string
	DispatchType string
)

type AccountConfig struct {
	// 节点域名
	Division string `xml:"division"`

	// Locator的地址
	Loc bd.Locator `xml:"locator"`

	Business bd.EndPoint `xml:"business"`
	Admin    bd.EndPoint `xml:"admin"`
	LogPath  string      `xml:"log_path"`
	LogLevel string      `xml:"log_level"`
	Threads  uint32      `xml:"threads"`

	// 专用配置
	Redis                bd.RedisConnection `xml:"redis"`
	RedisRefreshInterval uint32             `xml:"redis_refresh_interval"`
	ZoneInitID           string             `xml:"zone_init_id"`
	ZoneInitNo           string             `xml:"zone_init_no"`
	ZoneInitLobby        string             `xml:"zone_init_lobby"`
	DispatchType         string             `xml:"dispatch_type"`
}

/*
	开启本服务，会根据xml配置文件开启两个端口
	1 业务端口，可以使用socket+protobuf交互
	2 管理端口，可以利用http直接访问，比如动态修改日志等级

*/
func start(xmlFile string) bool {
	fmt.Printf("start with config: %s\n", xmlFile)
	rand.Seed(time.Now().UnixNano())

	fileData, err := ioutil.ReadFile(xmlFile)
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		return false
	}

	var config AccountConfig
	err = xml.Unmarshal(fileData, &config)
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		return false
	}

	fmt.Printf("log path=%s, level=%s\n", config.LogPath, config.LogLevel)

	// 设置日志输出与日志级别
	lu.SetupLogPath(config.LogPath)
	lu.SetupLogLevel(config.LogLevel)

	// 输出基础配置
	log.Info().Msgf("start with config: %s", xmlFile)
	log.Debug().Msgf("division=%s", config.Division)
	log.Debug().Msgf("locator protocol=%s, ip=%s, port=%s, refresh=%d", config.Loc.Protocol, config.Loc.Ep.Ip, config.Loc.Ep.Port, config.Loc.RefreshInterval)
	log.Debug().Msgf("business ip=%s, port=%s", config.Business.Ip, config.Business.Port)
	log.Debug().Msgf("admin ip=%s, port=%s", config.Admin.Ip, config.Admin.Port)
	log.Debug().Msgf("log path=%s, level=%s", config.LogPath, config.LogLevel)
	log.Debug().Msgf("threads=%d dispatch=%s", config.Threads, config.DispatchType)
	log.Debug().Msgf("redis=%v, redis refresh=%d, zone_init_id=%s", config.Redis, config.RedisRefreshInterval, config.ZoneInitID)

	if app, server, id, err := bd.ParseDivision(config.Division); err != nil {
		log.Error().Msgf("division error: %s", err.Error())
		return false
	} else {
		log.Debug().Msgf("app=%s, server=%s, id=%s", app, server, id)
		App, Server, Division = app, server, config.Division
		AccountRedisPrefix = App + "_" + Server + "_"
	}
	DispatchType = config.DispatchType

	// 先尝试拉取一次registry，如果失败则直接退出
	lr.SetLocator(config.Loc.Ep.Ip, config.Loc.Ep.Port)
	err = lr.QueryRegistry()
	if err != nil {
		log.Debug().Msgf("query registry from %s:%s failed, %s", config.Loc.Ep.Ip, config.Loc.Ep.Port, err.Error())
		return false
	}
	lr.StartQueryLoop(config.Loc.RefreshInterval)

	// 初始化redis连接池
	redisAddr := fmt.Sprintf("%s:%s", config.Redis.Ep.Ip, config.Redis.Ep.Port)
	redisPool, err = redis.NewRedisUtil(redisAddr)
	defer redisPool.Close()
	log.Info().Msg("account init the redis connection pool")

	// 绑定business端口，以socket+pb方式提供业务服务
	// 以另一个协程的方式运行初始化，与本协程以chan方式通信
	ch := make(chan string, 10)
	go startBusiness(config, ch)
	select {
	case s, _ := <-ch:
		if s == "ready" {
			log.Info().Msg("business is ready now")
			break
		} else {
			log.Error().Msgf("business send %s", s)
			log.Info().Msg("admin should exit by business exit or error")
			return false
		}
	}

	// 绑定admin端口，以web方式提供admin服务
	adminAddr := config.Admin.Ip + ":" + config.Admin.Port
	log.Info().Msgf("bind admin addr=%s", adminAddr)

	http.HandleFunc("/admin", adminWebHandler)
	admin := &http.Server{Addr: adminAddr, Handler: nil}
	err = admin.ListenAndServe()
	if err != nil {
		log.Fatal().Msgf("admin listen failed: %s", err.Error())
		return false
	}

	log.Info().Msg("admin exit")
	return true
}

func bindAccountWithoutTrans(deviceID string) (string, bool, error) {
	key1 := makeAccountKey("zone_no")
	key2 := makeUUIDKey(deviceID)

	// 检测zone_no是否存在，如果不存在则可能是有人把redis给清档了。。。
	s1, err := redisPool.Cmd("EXISTS", key1).Int()
	if s1 == 0 {
		log.Panic().Msgf("key=%s not exist, possible someone clean the redis...", key1)
		os.Exit(-1)
	}

	// 先检测这个deviceID是否存在
	s2, err := redisPool.Cmd("GET", key2).Str()
	if err == nil {
		// 这个设备已经绑定过了
		log.Debug().Msgf("device=%s s=%s", deviceID, s2)
		return s2, false, nil
	}

	// 这个设备没有被绑定过，我们尝试绑定它
	// 首先拿到ID
	n, err := redisPool.Cmd("INCR", key1).Int()
	if err != nil {
		log.Error().Msgf("INCR key=%s failed: %s", key1, err.Error())
		return "", false, err
	}
	// 然后构造玩家数据
	no := uint64(n) - 1
	lobbyID, _ := strconv.Atoi(LobbyId)
	info := &account.AccountInfoDb{
		AcctId:  no,
		LobbyId: int32(lobbyID),
	}
	t := proto.CompactTextString(info)
	log.Debug().Msgf("new account bind, marshal=%s", t)
	// 最后把这个数据写入
	b, err := redisPool.Cmd("SETNX", key2, t).Int()
	if err != nil {
		log.Error().Msgf("SETNX key=%s failed: %s", key2, err.Error())
		return "", false, err
	} else {
		if b == 1 {
			// 绑定成功
			log.Debug().Msgf("device=%s bind ok", deviceID)
			return t, true, nil
		} else {
			// 绑定时发生冲突，直接把这个no丢弃即可
			log.Info().Msgf("bind conflict detected, device=%s no=%d discard", deviceID, no)
			if s2, err = redisPool.Cmd("GET", key2).Str(); err != nil {
				return "", false, err
			} else {
				return s2, false, nil
			}
		}
	}
}

func bindAccountWithCluster(deviceID string) (uint64, int32, bool, error) {
	info, newbie, err := bindAccountWithoutTrans(deviceID)
	if err == nil {
		o := &account.AccountInfoDb{}
		proto.UnmarshalText(info, o)
		return o.AcctId, o.LobbyId, newbie, nil
	}
	return 0, 0, false, err
}

func unbindAccount(deviceID string) (string, error) {
	key := makeUUIDKey(deviceID)
	if n, err := redisPool.Cmd("DEL", key).Int(); err != nil {
		log.Error().Msgf("DEL failed: %s", err.Error())
		return "", err
	} else {
		if n > 0 {
			return "ok", nil
		} else {
			return "", errors.New("device not exist")
		}
	}
}

func chbindAccount(deviceID string, newLobbyID string) (string, error) {
	key := makeUUIDKey(deviceID)
	s, err := redisPool.Cmd("GET", key).Str()
	if s == "" {
		return "", errors.New("device not bind")
	}

	o := &account.AccountInfoDb{}
	if err = proto.UnmarshalText(s, o); err != nil {
		log.Error().Msgf("unmarshal failed: %s", err.Error())
		log.Error().Msgf("account deviceID=%s, dbtext=%s", deviceID, s)
		return "", err
	}

	i, _ := strconv.Atoi(newLobbyID)
	lobbyID := int32(i)
	if o.LobbyId == lobbyID {
		log.Debug().Msgf("account device=%s chbind no necessory, the same lobby", deviceID)
		return "", errors.New("same lobby, no need to change")
	} else {
		division := bd.MakeDivision(App, DispatchType, lobbyID)
		if _, _, _, _, err = lr.QueryEndpoint(App, DispatchType, division); err != nil {
			return "", errors.New(fmt.Sprintf("lobby %d not exist", lobbyID))
		}

		oldLobbyID := o.LobbyId
		o.LobbyId = lobbyID
		t := proto.CompactTextString(o)
		redisPool.Cmd("SET", key, t)

		log.Debug().Msgf("account chbind lobby, old=%d, new=%d", oldLobbyID, lobbyID)
		log.Debug().Msgf("account update, marshal=%s", t)
		return "ok", nil
	}
}

func setRecommandLobby(lobbyID string) (string, error) {
	key := makeAccountKey("recommand_lobby")
	oldLobbyID, _ := redisPool.Cmd("GET", key).Str()

	if oldLobbyID == lobbyID {
		return "", errors.New("same lobby, no need to change")
	} else {
		id, err := strconv.Atoi(lobbyID)
		if err != nil {
			return "", errors.New("lobby id must be a number")
		}

		division := bd.MakeDivision(App, DispatchType, int32(id))
		if _, _, _, _, err = lr.QueryEndpoint(App, DispatchType, division); err != nil {
			return "", errors.New(fmt.Sprintf("lobby %d not exist", id))
		}

		redisPool.Cmd("SET", key, lobbyID)

		log.Info().Msgf("account recommand lobby change from %s to %s", oldLobbyID, lobbyID)
		return "ok", nil
	}
}

func seeAccount(deviceID string) (string, error) {
	key := makeUUIDKey(deviceID)
	info, err := redisPool.Cmd("GET", key).Str()
	if err != nil {
		return "", err
	} else {
		if info == "" {
			return "", errors.New("device not exist")
		} else {
			return info, nil
		}
	}
}

func seeRecommandLobby() (string, error) {
	key := makeAccountKey("recommand_lobby")
	return redisPool.Cmd("GET", key).Str()
}
