package main

import (
	"encoding/json"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"net"
	"net/http"
	bd "shared/mfxbasedef"
	lr "shared/mfxlocalregistry"
	lu "shared/mfxlogutil"
	"shared/proto/server/account"
)

// Web 服务

type adminWebRsp struct {
	Result uint   `json:"result"`
	Error  string `json:"error"`
	Msg    string `json:"msg"`
}

func adminWebHandler(w http.ResponseWriter, r *http.Request) {
	var result adminWebRsp

	rip := r.Header.Get("X-Forwarded-For")
	if rip == "" {
		rip, _, _ = net.SplitHostPort(r.RemoteAddr)
	}
	if lr.IsRemoteAdminIPAllowed(rip) == false {
		result.Result = 1
		result.Error = "access denied"
		log.Info().Msgf("access denied, remote admin ip: %s", rip)
		return
	}

	r.ParseForm()
	log.Debug().Msgf("http request form: %v", r.Form)
	op := r.FormValue("op")
	switch op {
	case "":
		result.Result = 1
		result.Error = "invalid operation"
	case "log":
		newLevel := lu.SetupLogLevel(r.FormValue("level"))
		log.Info().Msgf("log level set to %s", newLevel)
		result.Result = 0
		result.Error = ""
	case "see":
		deviceId := r.FormValue("device_id")
		if deviceId == "" {
			result.Result = 1
			result.Error = "device id can't be null"
		} else {
			info, err := seeAccount(deviceId)
			if err != nil {
				result.Result = 1
				result.Error = err.Error()
			} else {
				o := &account.AccountInfoDb{}
				proto.UnmarshalText(info, o)
				result.Result = 0
				result.Msg = o.String()
			}
		}
	case "bind":
		deviceId := r.FormValue("device_id")
		if deviceId == "" {
			result.Result = 1
			result.Error = "device id can't be null"
		} else {
			info, newbie, err := bindAccountWithoutTrans(deviceId)
			log.Debug().Msgf("bind op, result=%v deviceId=%s, info=%s", err == nil, deviceId, info)
			if err == nil {
				o := &account.AccountInfoDb{}
				proto.UnmarshalText(info, o)

				result.Result = 0
				result.Msg = o.String()

				division := bd.MakeDivision(App, DispatchType, o.LobbyId)
				Sip, Sport, _, _, err := lr.QueryEndpoint(App, DispatchType, division)
				if err == nil {
					result.Msg += fmt.Sprintf("%s:%d", Sip, Sport)
				}
				if newbie {
					result.Msg += " newbie"
				}
			} else {
				result.Result = 1
				result.Msg = err.Error()
			}
		}
	case "unbind":
		deviceId := r.FormValue("device_id")
		if deviceId == "" {
			result.Result = 1
			result.Error = "device id can't be null"
		} else {
			info, err := unbindAccount(deviceId)
			log.Debug().Msgf("unbind op, result=%v deviceId=%s, info=%s", err == nil, deviceId, info)
			if err == nil {
				result.Result = 0
				result.Msg = info
			} else {
				result.Result = 1
				result.Error = err.Error()
			}
		}
	case "chbind":
		deviceId := r.FormValue("device_id")
		if deviceId == "" {
			result.Result = 1
			result.Error = "device id can't be null"
		} else {
			newLobbyId := r.FormValue("lobby_id")
			info, err := chbindAccount(deviceId, newLobbyId)
			log.Debug().Msgf("chbind op, result=%v deviceId=%s, info=%s", err == nil, deviceId, info)
			if err == nil {
				result.Result = 0
				result.Msg = info
			} else {
				result.Result = 1
				result.Error = err.Error()
			}
		}
	case "seerecomma":
		info, err := seeRecommandLobby()
		if err == nil {
			result.Result = 0
			result.Msg = info
		} else {
			result.Result = 1
			result.Error = err.Error()
		}
	case "recomma":
		lobbyId := r.FormValue("lobby_id")
		if lobbyId == "" {
			result.Result = 1
			result.Error = "lobby id can't be null"
		} else {
			info, err := setRecommandLobby(lobbyId)
			log.Debug().Msgf("recomma op, result=%v lobbyId=%s, info=%s", err == nil, lobbyId, info)
			if err == nil {
				result.Result = 0
				result.Msg = info
			} else {
				result.Result = 1
				result.Error = err.Error()
			}
		}
	default:
		result.Result = 1
		result.Error = "invalid operation"
	}

	w.Header().Add("Access-Control-Allow-Origin", "*")
	rsp, _ := json.Marshal(result)
	w.Write(rsp)
}
