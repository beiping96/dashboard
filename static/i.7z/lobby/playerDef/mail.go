package playerDef

import (
	"github.com/golang/protobuf/proto"
	pb "shared/proto/client/portal"
	mailService "shared/proto/server/mail"
)

// PlayerMail desc mail save in playerState
type PlayerMail struct {
	MailID uint64
	ItemS  map[uint32]*PlayerMailAttachment
}

// PlayerMailAttachment desc mail attachment
type PlayerMailAttachment struct {
	GoodsTypeID uint32
	GoodsNum    uint32
	IsExist     bool
}

// Mail2lobbyMail mailService converter
func Mail2lobbyMail(mails []*mailService.Mail) (lobbyMails []*pb.LobbyMail, playerMails []*PlayerMail) {
	for _, mailOne := range mails {
		if mailOne == nil {
			continue
		}
		mailID := mailOne.GetMailId()
		timestamp := mailOne.GetTimestamp()
		read := uint32(0)
		if mailOne.GetRead() {
			read = 1
		}
		subject := mailOne.GetSubject()
		content := mailOne.GetContent()
		attachmentIsExist := uint32(0)
		lobbyMail := &pb.LobbyMail{
			MailId:            &mailID,
			Timestamp:         &timestamp,
			Read:              &read,
			Subject:           &subject,
			Content:           &content,
			AttachmentIsExist: &attachmentIsExist,
		}
		lobbyMails = append(lobbyMails, lobbyMail)
		attachment := mailService.CardMailAttachment{}
		if err := proto.Unmarshal([]byte(mailOne.GetAttachment()), &attachment); err != nil {
			continue
		}
		if len(attachment.Items) == 0 {
			continue
		}
		if attachment.IsExist {
			attachmentIsExist = 1
		}
		playerMail := &PlayerMail{}
		playerMail.MailID = mailID
		playerMail.ItemS = make(map[uint32]*PlayerMailAttachment)
		for _, item := range attachment.Items {
			goodsTypeID := item.GetGoodsTypeID()
			goodsNum := item.GetGoodsNum()
			lobbyBackpack := pb.BackpackGoods{
				GoodsTypeId: &goodsTypeID,
				GoodsNum:    &goodsNum,
			}
			lobbyMail.Attachment = append(lobbyMail.Attachment, &lobbyBackpack)
			playerMail.ItemS[goodsTypeID] = &PlayerMailAttachment{
				GoodsTypeID: goodsTypeID,
				GoodsNum:    goodsNum,
				IsExist:     attachment.IsExist,
			}
		}
		playerMails = append(playerMails, playerMail)
	}
	return
}

// ToMailItems convert playerMailAttachment to serverMailAttachment
func (playerMail *PlayerMail) ToMailItems() (items []*mailService.CardMailAttachmentItem) {
	if playerMail == nil {
		return
	}
	for _, item := range playerMail.ItemS {
		if !item.IsExist {
			continue
		}
		serverItem := &mailService.CardMailAttachmentItem{
			GoodsTypeID: item.GoodsTypeID,
			GoodsNum:    item.GoodsNum,
		}
		items = append(items, serverItem)
	}
	return
}
