package playerDef

import (
	"errors"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"lobby/backpackDef"
	"lobby/box"
	"lobby/shop"
	cardD "shared/cardDef"
	heroD "shared/heroDef"
	portal "shared/proto/client/portal"
	db "shared/proto/server/lobby"
	"shared/table"
	"strconv"
)

const (
	CmdConnLeave        = 1
	CmdSessionData      = 11
	CmdSessionLeave     = 12
	CmdSessionReplace   = 13
	CmdPlayerData       = 21
	CmdPlayerSave       = 22
	CmdPlayerExit       = 23
	CmdPlayerForward    = 31
	CmdPlayerUpdateData = 32
	CmdGetPlayerData    = 41
)

type AdminRet struct {
	AccountID uint64
	Data      interface{}
	Result    error
}

type PlayerCmd struct {
	Cmd         uint32
	SessionID   uint64
	AccountID   uint64
	Hdr         []byte
	Body        []byte
	AdminSigRet chan *AdminRet
}

type PlayerData struct {
	playerID          uint64
	lobbyID           uint32
	icon              int32
	level             int32
	exp               int32
	name              string
	cards             map[cardD.TypeID]*cardD.Card
	heros             map[uint64]*heroD.Hero
	backpack          *backpackDef.Backpack
	shop              *shop.Shop
	singlePveStageUID uint64
	inBattleStageUID  uint64
	inBattleNodeID    uint32
	flagInEvent       bool
	box               *box.Box
	globalMail        map[uint64]bool
}

type PlayerState struct {
	Player    *PlayerData
	SessionID uint64
	SigPlayer chan *PlayerCmd
	IsDirty   bool
	DbDirty   bool
	Mail      map[uint64]*PlayerMail
}

func AccountID2PlayerID(accountID uint64) uint64 {
	return accountID
}

func PlayerID2AccountID(playerID uint64) uint64 {
	return playerID
}

func ToPlayerData(data []byte, player *PlayerData, lobbyID uint32) error {
	var db db.DbPlayerData
	if err := proto.Unmarshal(data, &db); err != nil {
		return err
	}
	player.playerID = db.GetPlayerId()
	player.lobbyID = lobbyID
	player.icon = db.GetIconId()
	player.level = db.GetLevel()
	player.exp = db.GetExp()
	player.name = db.GetName()
	cards := make(map[cardD.TypeID]*cardD.Card)
	for _, v := range db.Cards {
		card := cardD.FromDbProto(v)
		cards[card.GetTypeID()] = card
	}
	player.cards = cards
	heros := make(map[uint64]*heroD.Hero)
	for _, v := range db.Heros {
		hero := heroD.FromDbProto(v)
		heros[hero.GetUID()] = &hero
	}
	player.heros = heros
	player.backpack = backpackDef.FromDbProto(db.GetBackpack())
	player.shop = shop.FromDbProto(db.GetShop())
	player.singlePveStageUID = db.GetSinglePveStageUID()
	player.inBattleStageUID = db.GetInBattleStageUID()
	player.inBattleNodeID = db.GetInBattleNodeID()
	player.flagInEvent = db.GetFlagInEvent()
	player.box = box.FromDBProto(db.GetBox())
	globalMail := make(map[uint64]bool)
	for _, mailID := range db.GetGlobalMail() {
		globalMail[mailID] = true
	}
	player.globalMail = globalMail
	return nil
}

func NewPlayer(playerID uint64, name string, icon int32, lobbyID uint32) *PlayerData {
	player := &PlayerData{
		playerID:          playerID,
		lobbyID:           lobbyID,
		icon:              icon,
		level:             1,
		exp:               0,
		name:              name,
		cards:             make(map[cardD.TypeID]*cardD.Card),
		heros:             make(map[uint64]*heroD.Hero),
		backpack:          backpackDef.New(),
		shop:              shop.New(),
		singlePveStageUID: 0,
		inBattleStageUID:  0,
		inBattleNodeID:    0,
		flagInEvent:       false,
		box:               box.New(),
		globalMail:        make(map[uint64]bool),
	}
	// TODO
	// init player's hero
	player.NewHero(1)
	player.NewHero(2)
	// remark new card
	for _, cardOne := range player.cards {
		cardOne.CardShow()
	}
	return player
}

// NewHero - create new hero and unlock cards
func (player *PlayerData) NewHero(typeID uint32) error {
	initHero, err := heroD.New(typeID)
	if err != nil {
		return fmt.Errorf("player error new hero, %v", err)
	}
	// 获取表格中初始解锁卡牌
	cardMap := make(map[cardD.TypeID]*cardD.Card)
	for _, cardTypeID := range table.GetHeroInitUnlockCardsFromCsv(int64(typeID)) {
		cardTypeID := cardD.TypeID(cardTypeID)
		_, ok := player.cards[cardTypeID]
		if ok {
			continue
		}
		card, err := cardD.New(cardTypeID)
		if err != nil {
			return fmt.Errorf("player error new hero init card pool, %v", err)
		}
		cardMap[cardTypeID] = card
	}
	player.heros[initHero.GetUID()] = &initHero
	for cardTypeID, card := range cardMap {
		player.cards[cardTypeID] = card
	}
	return nil
}

func (player *PlayerData) GetPlayerID() uint64 {
	return player.playerID
}

func (player *PlayerData) GetLobbyID() uint32 {
	return player.lobbyID
}

func (player *PlayerData) GetPlayerName() string {
	return player.name
}

func (player *PlayerData) GetPlayerLevel() int32 {
	return player.level
}

func (player *PlayerData) GetPlayerIcon() int32 {
	return player.icon
}

func (player *PlayerData) GetPlayerExp() int32 {
	return player.exp
}

func (player *PlayerData) GetPlayerCards() map[cardD.TypeID]*cardD.Card {
	return player.cards
}

func (player *PlayerData) UnlockCard(cardTypeID cardD.TypeID) error {
	_, ok := player.cards[cardTypeID]
	if ok {
		return errors.New("card is exist")
	}
	card, err := cardD.New(cardTypeID)
	if err != nil {
		return err
	}
	player.cards[cardTypeID] = card
	return nil
}

func (player *PlayerData) GetPlayerHeros() map[uint64]*heroD.Hero {
	return player.heros
}

func (player *PlayerData) GetBackpack() *backpackDef.Backpack {
	return player.backpack
}

func (player *PlayerData) GetShop() *shop.Shop {
	return player.shop
}
func (player *PlayerData) GetSinglePveStageUID() uint64 {
	return player.singlePveStageUID
}

func (player *PlayerData) SetSinglePveStageUID(stageUID uint64) {
	player.singlePveStageUID = stageUID
}

func (player *PlayerData) GetInBattle() (uint64, uint32) {
	return player.inBattleStageUID, player.inBattleNodeID
}

func (player *PlayerData) SetInBattle(stageUID uint64, nodeID uint32) {
	player.inBattleStageUID = stageUID
	player.inBattleNodeID = nodeID
}

func (player *PlayerData) GetFlagInEvent() bool {
	return player.flagInEvent
}

func (player *PlayerData) SetFlagInEvent(flag bool) {
	player.flagInEvent = flag
}

func (player *PlayerData) GetBox() *box.Box {
	return player.box
}

func (player *PlayerData) GetGlobalMail(mailID uint64) bool {
	return player.globalMail[mailID]
}

func (player *PlayerData) SetGlobalMail(mailID uint64) {
	player.globalMail[mailID] = true
}

// OpExec - exec player data operation
func (player *PlayerData) OpExec(o *OP) error {
	// Deep copy playerData
	playerDb, err := player.ToDbPb()
	if err != nil {
		return err
	}
	copyPlayer := PlayerData{}
	err = ToPlayerData(playerDb, &copyPlayer, player.GetLobbyID())
	if err != nil {
		return err
	}
	// use copyPlayer to exec operation
	err = o.exec(&copyPlayer)
	if err != nil {
		// if err, return here, not save playerData
		return err
	}
	// if all operation execute success, reExec
	err = o.exec(player)
	if err != nil {
		log.Error().Msgf("player operation error first exec success second exec failed, need check:%v",
			err)
	}
	return err
}

func (player *PlayerData) ToClientProto() *portal.PlayerInfo {
	var heros []*portal.PlayerHero
	for _, v := range player.heros {
		heros = append(heros, v.ToClientProto())
	}
	log.Debug().Msgf("player info debug inBattle %v:%v", player.inBattleStageUID, player.inBattleNodeID)
	singlePveStageUIDStr := strconv.FormatUint(player.singlePveStageUID, 10)
	inBattleStageUIDStr := strconv.FormatUint(player.inBattleStageUID, 10)
	return &portal.PlayerInfo{
		Id:                &player.playerID,
		Name:              &player.name,
		Level:             &player.level,
		IconId:            &player.icon,
		Heros:             heros,
		SinglePveStageUid: &singlePveStageUIDStr,
		InBattleStageUid:  &inBattleStageUIDStr,
		InBattleNodeId:    &player.inBattleNodeID,
	}
}

func (player *PlayerData) ToDbProto() *db.DbPlayerData {
	var cards []*db.DbPlayerCard
	for _, v := range player.cards {
		cards = append(cards, v.ToDbProto())
	}
	var heros []*db.DbPlayerHero
	for _, v := range player.heros {
		heros = append(heros, v.ToDbProto())
	}
	var globalMail []uint64
	for mailID := range player.globalMail {
		globalMail = append(globalMail, mailID)
	}
	return &db.DbPlayerData{
		PlayerId:          player.playerID,
		IconId:            player.icon,
		Level:             player.level,
		Exp:               player.exp,
		Name:              player.name,
		Cards:             cards,
		Heros:             heros,
		Backpack:          player.backpack.ToDbProto(),
		Shop:              player.shop.ToDbProto(),
		SinglePveStageUID: player.singlePveStageUID,
		InBattleStageUID:  player.inBattleStageUID,
		InBattleNodeID:    player.inBattleNodeID,
		FlagInEvent:       player.flagInEvent,
		Box:               player.box.ToDBProto(),
		GlobalMail:        globalMail,
	}
}

func (player *PlayerData) ToDbPb() ([]byte, error) {
	msg := player.ToDbProto()
	return proto.Marshal(msg)
}
