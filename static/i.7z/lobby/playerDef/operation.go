package playerDef

import (
	"fmt"
	"runtime/debug"
	"shared/battle.etc/stageDef"
	db "shared/proto/server/lobby"
)

// OP - desc player data operation
type OP struct {
	opS []*op
}

type op struct {
	method         db.PlayerDataOpEnum
	goodsTypeID    uint32
	goodsNum       uint32
	stageOperation *stageDef.PlayerOperation
}

// NewOP - create new player data operation
func NewOP() *OP {
	return &OP{}
}

// JoinAddGoods - join addGoods operation into player data operation
func (o *OP) JoinAddGoods(goodsTypeID uint32, goodsNum uint32) error {
	newOpOne := op{
		method:      db.PlayerDataOpEnum_ADD_GOODS,
		goodsTypeID: goodsTypeID,
		goodsNum:    goodsNum,
	}
	o.opS = append(o.opS, &newOpOne)
	return nil
}

// JoinDelGoods - join delGoods operation into player data operation
func (o *OP) JoinDelGoods(goodsTypeID uint32, goodsNum uint32) error {
	newOpOne := op{
		method:      db.PlayerDataOpEnum_DEL_GOODS,
		goodsTypeID: goodsTypeID,
		goodsNum:    goodsNum,
	}
	o.opS = append(o.opS, &newOpOne)
	return nil
}

// JoinAddStageOperation - join addStageOperation into player data operation
func (o *OP) JoinAddStageOperation(stageOperation *stageDef.PlayerOperation) error {
	newOpOne := op{
		method:         db.PlayerDataOpEnum_STAGE_OPERATION,
		stageOperation: stageOperation,
	}
	o.opS = append(o.opS, &newOpOne)
	return nil
}

// ToDbProto - convert OP to *db.DbShadowMail
func (o *OP) ToDbProto() *db.DbShadowMail {
	ans := []*db.PlayerDataOp{}
	for _, opLocal := range o.opS {
		ansOne := db.PlayerDataOp{}
		ansOne.Method = opLocal.method
		ansOne.GoodsTypeID = opLocal.goodsTypeID
		ansOne.GoodsNum = opLocal.goodsNum
		ansOne.StageOperation = opLocal.stageOperation.ToDbProto()
		ans = append(ans, &ansOne)
	}
	return &db.DbShadowMail{OpS: ans}
}

// OpFromDbProto - convert *db.DbShadowMail to *OP
func OpFromDbProto(opDb *db.DbShadowMail) *OP {
	ans := []*op{}
	for _, opDbOne := range opDb.GetOpS() {
		ansOne := op{
			method:         opDbOne.GetMethod(),
			goodsTypeID:    opDbOne.GetGoodsTypeID(),
			goodsNum:       opDbOne.GetGoodsNum(),
			stageOperation: stageDef.FromDbStageOperation(opDbOne.GetStageOperation()),
		}
		ans = append(ans, &ansOne)
	}
	return &OP{opS: ans}
}

// exec - exec player data operation
func (o *OP) exec(player *PlayerData) (err error) {
	defer func() {
		if localErr := recover(); localErr != nil {
			err = fmt.Errorf("player operation panic error source:%v panicError:%v stack:%v",
				err, localErr, string(debug.Stack()))
		}
	}()
	for _, opOne := range o.opS {
		switch opOne.method {
		case db.PlayerDataOpEnum_ADD_GOODS:
			goodsTypeID, goodsNum := opOne.goodsTypeID, opOne.goodsNum
			err = player.GetBackpack().AddGoods(goodsTypeID, goodsNum)
			if err != nil {
				return
			}
		case db.PlayerDataOpEnum_DEL_GOODS:
			goodsTypeID, goodsNum := opOne.goodsTypeID, opOne.goodsNum
			err = player.GetBackpack().DelGoods(goodsTypeID, goodsNum)
			if err != nil {
				return
			}
		case db.PlayerDataOpEnum_STAGE_OPERATION:
			switch opOne.stageOperation.Type {
			case stageDef.PlayerOperationEnumWriteInBattle:
				player.SetInBattle(opOne.stageOperation.Param1, opOne.stageOperation.Param2)
			case stageDef.PlayerOperationEnumCleanSinglePve:
				player.SetSinglePveStageUID(0)
			case stageDef.PlayerOperationEnumAddRewardGoods:
				err = player.GetBox().AddTypeID(opOne.stageOperation.Param2)
				if err != nil {
					return
				}
			default:
				err = fmt.Errorf("player operation exec error unknown stageOperation type %v",
					opOne.stageOperation)
				return
			}
		default:
			err = fmt.Errorf("player data operation error : op enum not exist : %v",
				opOne.method)
			return
		}
	}
	return nil
}

// String - achieve String interface
func (o OP) String() string {
	s := "player data operation <"
	for index, opOne := range o.opS {
		s += fmt.Sprintf("index:%v,", index)
		s += fmt.Sprintf("enum:%v,", opOne.method)
		s += fmt.Sprintf("goodsTypeID:%v,", opOne.goodsTypeID)
		s += fmt.Sprintf("goodsNum:%v,", opOne.goodsNum)
		s += fmt.Sprintf("stageOperation:%v,", opOne.stageOperation)
	}
	s += ">"
	return s
}
