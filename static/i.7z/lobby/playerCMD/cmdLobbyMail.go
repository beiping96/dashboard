package playerCMD

import (
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"lobby/mail"
	pd "lobby/playerDef"
	"shared/csv"
	pb "shared/proto/client/portal"
	mailService "shared/proto/server/mail"
	"strconv"
)

// CmdLobbyMailGet CMD: lobby_mail_get_req
func CmdLobbyMailGet(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.LobbyMailGetRsp{Result: &result}
	// Unmarshal
	req := pb.LobbyMailGetReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	mails, err := mail.FetchMails(state)
	if err != nil {
		log.Error().Msgf("lobby get mails from mailService error %v", err)
		result = csv.ERRCODE_FAILED
		return rsp
	}
	rsp.Mails = mails
	globalMails, err := mail.FetchGlobalMails(state)
	if err != nil {
		log.Error().Msgf("lobby get global mails error %v", err)
		result = csv.ERRCODE_FAILED
		return rsp
	}
	rsp.GlobalMails = globalMails
	return rsp
}

// CmdLobbyMailRead CMD: lobby_mail_read_req
func CmdLobbyMailRead(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.LobbyMailReadRsp{Result: &result}
	// Unmarshal
	req := pb.LobbyMailReadReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	mailID, err := strconv.ParseUint(req.GetMailId(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	rsp.MailId = &mailID
	if mailID == 0 {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	result = mail.SetMailRead(state, mailID)
	return rsp
}

// CmdLobbyMailAttachment CMD: lobby_mail_attachment_req
func CmdLobbyMailAttachment(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.LobbyMailAttachmentRsp{Result: &result}
	// Unmarshal
	req := pb.LobbyMailAttachmentReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	mailID, err := strconv.ParseUint(req.GetMailId(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	rsp.MailId = &mailID
	if mailID == 0 {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	log.Debug().Msgf("mail debug update attachment mailID:%v stateMail:%v", mailID, state.Mail)
	// check attachment is exist
	playerMail, ok := state.Mail[mailID]
	if !ok {
		result = csv.ERRCODE_LOBBY_ATTACHMENT_NOT_EXIST
		return rsp
	}
	attachment := &mailService.CardMailAttachment{
		IsExist: false,
		Items:   playerMail.ToMailItems(),
	}
	newAttachment, err := proto.Marshal(attachment)
	if err != nil {
		result = csv.ERRCODE_FAILED
		return rsp
	}
	// update mail attachment
	err = mail.UpdateMailAttachment(state, mailID, string(newAttachment))
	if err != nil {
		result = csv.ERRCODE_FAILED
		return rsp
	}
	// add goods
	for _, playerMailItem := range playerMail.ItemS {
		if !playerMailItem.IsExist {
			continue
		}
		state.Player.GetBackpack().AddGoods(playerMailItem.GoodsTypeID, playerMailItem.GoodsNum)
	}
	state.IsDirty = true
	// delete local attachment
	delete(state.Mail, mailID)
	return rsp
}

// CmdLobbyMailDel CMD: lobby_mail_del_req
func CmdLobbyMailDel(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.LobbyMailDelRsp{Result: &result}
	// Unmarshal
	req := pb.LobbyMailDelReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	mailID, err := strconv.ParseUint(req.GetMailId(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	rsp.MailId = &mailID
	if mailID == 0 {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	result = mail.DeleteMail(state, mailID)
	return rsp
}

// CmdLobbyGlobalMailAttachment CMD: lobby_global_mail_attachment_req
func CmdLobbyGlobalMailAttachment(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.LobbyGlobalMailAttachmentRsp{Result: &result}
	// Unmarshal
	req := pb.LobbyGlobalMailAttachmentReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	mailID, err := strconv.ParseUint(req.GetMailId(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	rsp.MailId = &mailID
	if mailID == 0 {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	log.Debug().Msgf("global mail debug update attachment mailID:%v stateMail:%v", mailID, state.Mail)
	// check attachment
	if state.Player.GetGlobalMail(mailID) {
		result = csv.ERRCODE_LOBBY_ATTACHMENT_NOT_EXIST
		return rsp
	}
	rewardGoods, ok := mail.GetGlobalMailAttachment(mailID)
	if !ok {
		result = csv.ERRCODE_FAILED
		return rsp
	}
	// write has reward flag
	state.Player.SetGlobalMail(mailID)
	state.IsDirty = true
	for _, goods := range rewardGoods {
		state.Player.GetBackpack().AddGoods(*goods.GoodsTypeId, *goods.GoodsNum)
	}
	return rsp
}
