package playerCMD

import (
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	pd "lobby/playerDef"
	"shared/csv"
	pp "shared/proto/client/portal"
)

// CmdLobbyGetBackpackReq get all backpack
func CmdLobbyGetBackpackReq(state *pd.PlayerState, body []byte) proto.Message {
	log.Debug().Msgf("player=%d get backpack req", state.Player.GetPlayerID())
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pp.LobbyGetBackpackRsp{Result: &result}
	backpack := state.Player.GetBackpack()
	rsp.Goods = backpack.ToClientProto()
	return rsp
}

// CmdLobbyConvertGoldsReq money convert
func CmdLobbyConvertGoldsReq(state *pd.PlayerState, body []byte) proto.Message {
	log.Debug().Msgf("player=%d convert golds req", state.Player.GetPlayerID())
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pp.LobbyConvertGoldsRsp{Result: &result}
	req := pp.LobbyConvertGoldsReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	gemstoneNum := req.GetGemstoneNum()
	backpack := state.Player.GetBackpack()
	bpGmestone := backpack.GetGemstoneNum()
	if bpGmestone < gemstoneNum {
		result = csv.ERRCODE_BATTLE_SHOP_MONEY_NOT_ENOUGH
		return rsp
	}
	err = backpack.AddGolds(gemstoneNum * 15)
	if err != nil {
		result = csv.ERRCODE_DEL_GOODS_ERR
		return rsp
	}
	err = backpack.DelGemstone(gemstoneNum)
	if err != nil {
		result = csv.ERRCODE_DEL_GOODS_ERR
		return rsp
	}
	state.IsDirty = true
	return rsp
}
