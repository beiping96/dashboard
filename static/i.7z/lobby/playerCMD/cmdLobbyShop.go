package playerCMD

import (
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	pd "lobby/playerDef"
	ps "lobby/shop"
	cardD "shared/cardDef"
	"shared/csv"
	pp "shared/proto/client/portal"
	"shared/table"
)

// CmdLobbyGetShop 拉取外围商店数据
func CmdLobbyGetShop(state *pd.PlayerState, body []byte) proto.Message {
	log.Debug().Msgf("player=%d get dayshop req", state.Player.GetPlayerID())
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pp.LobbyGetShopRsp{Result: &result}
	shop := state.Player.GetShop()
	cards := state.Player.GetPlayerCards()
	backpack := state.Player.GetBackpack()
	err := shop.GetDayShop().FormDayShop(cards, backpack)
	if err != nil {
		log.Debug().Msgf("get dayShop error: %v", err)
		result = csv.ERRCODE_PLAN_FORM_ERR
		return rsp
	}
	rsp.DailyShopInfo = shop.DayShopToClientProto()
	rsp.CardbagItem = shop.CardBagToClientProto()
	state.IsDirty = true
	return rsp
}

// CmdLobbyShop 购买商店商品
func CmdLobbyShop(state *pd.PlayerState, body []byte) proto.Message {
	log.Debug().Msgf("player=%d shop req", state.Player.GetPlayerID())
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pp.LobbyShopRsp{Result: &result}
	req := pp.LobbyShopReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("unmarshal failed")
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	backpack := state.Player.GetBackpack()
	shop := state.Player.GetShop()
	cards := state.Player.GetPlayerCards()
	shoptype := req.GetType()
	if shoptype == csv.SHOP_TYPE_COIN_CONVERT {
		//金币转换
		convertInfo := table.GetCoinConvertByID(int(req.GetTypeId()))
		if convertInfo == nil {
			result = csv.ERRCODE_PLAN_FORM_ERR
			return rsp
		}
		err = backpack.DelGemstone(uint32(convertInfo.NeedGem) * req.GetNum())
		if err != nil {
			result = csv.ERRCODE_BATTLE_SHOP_MONEY_NOT_ENOUGH
			return rsp
		}
		backpack.AddGolds(uint32(convertInfo.ConvertCoinNum) * req.GetNum())
	} else if shoptype == csv.SHOP_TYPE_DAILY_SHOP {
		//每日商店
		goodslist := shop.GetDayShop().GetGoodsList()
		goods, ok := goodslist[req.GetTypeId()]
		if !ok {
			//商品下标错误
			result = csv.ERRCODE_PLAN_FORM_ERR
			return rsp
		}
		if (1 - goods.GetLimitNum()) < req.GetNum() {
			//限购次数已达到上限
			result = csv.ERRCODE_PLAN_FORM_ERR
			return rsp
		}
		//消耗金钱
		if goods.GetGoodsConvertType() == csv.GOLDTYPE_TYPE_GEMSTONE {
			err := backpack.DelGemstone(goods.GetGoodsPrice() * req.GetNum())
			if err != nil {
				result = csv.ERRCODE_BATTLE_SHOP_MONEY_NOT_ENOUGH
				return rsp
			}
		} else if goods.GetGoodsConvertType() == csv.GOLDTYPE_TYPE_GOLD {
			err := backpack.DelGolds(goods.GetGoodsPrice() * req.GetNum())
			if err != nil {
				result = csv.ERRCODE_BATTLE_SHOP_MONEY_NOT_ENOUGH
				return rsp
			}
		} else {
			//货币类型错误
			result = csv.ERRCODE_BATTLE_SHOP_MONEY_NOT_ENOUGH
			return rsp
		}
		//增加货物
		backpack.AddGoods(goods.GetGoodsType(), goods.GetGoodsCardPieceNum()*req.GetNum())
		//添加购买的次数
		goods.AddLimitNum(req.GetNum())
		//修改每日商店碎片数量
		goods.SetcardPieceSumNum(goods.GetGoodsCardPieceNum() * req.GetNum())
		//构造回包
		rsp.DailyShopInfo = shop.DayShopToClientProto()
	} else if shoptype == csv.SHOP_TYPE_CARD_BOX {
		//卡包
		cardBagTrade := table.GetCardBagTradeByID(int(req.GetTypeId()))
		if cardBagTrade == nil {
			//贩售表中不存在此ID的卡包
			result = csv.ERRCODE_PLAN_FORM_ERR
			return rsp
		}
		//限购次数
		if cardBagTrade.IsLimit == 1 {
			limitnum, err := shop.GetCardBag().GetBuyNum(req.GetTypeId())
			if err != nil {
				result = csv.ERRCODE_PLAN_FORM_ERR
				return rsp
			}
			if uint32(cardBagTrade.LimitNum) < (limitnum + req.GetNum()) {
				result = csv.ERRCODE_PLAN_FORM_ERR
				return rsp
			}
		}
		//金钱是否足够
		err := backpack.DelGemstone(uint32(cardBagTrade.ConvertNum) * req.GetNum())
		if err != nil {
			result = csv.ERRCODE_BATTLE_SHOP_MONEY_NOT_ENOUGH
			return rsp
		}
		//购买次数增加
		err = shop.GetCardBag().SetBuyNum(req.GetTypeId(), req.GetNum())
		if err != nil {
			//贩售表中不存在此ID的卡包
			result = csv.ERRCODE_PLAN_FORM_ERR
			return rsp
		}
		//开宝箱
		var rewarditem []*pp.BagItemInfo
		cardbaglist := ps.OpenCardBag(req.GetTypeId(), cards, backpack)
		for i, v := range cardbaglist {
			var ans pp.BagItemInfo
			typeID := i
			num := v
			cardTypeID := uint32(0)
			cardstar := uint32(0)
			cardexp := uint32(0)
			convertNum := uint32(0)
			if typeID != csv.GOLDTYPE_TYPE_GEMSTONE && typeID != csv.GOLDTYPE_TYPE_GOLD {
				cardTypeID = uint32(table.GetCardTypeIDByPieceID(int(typeID)))
				card, ok := cards[cardD.TypeID(cardTypeID)]
				if !ok {
					//解锁卡牌
					err := state.Player.UnlockCard(cardD.TypeID(cardTypeID))
					if err != nil {
						log.Error().Msgf("open reward box error unlock card %v error %v", cardTypeID, err)
					} else {
						state.IsDirty = true
						cards = state.Player.GetPlayerCards()
						card = cards[cardD.TypeID(cardTypeID)]
					}
				}
				cardstar = card.GetCardStarLevel()
				//获取上限
				cardgrowinfo := table.GetCardGrowFromCsv(int64(cardTypeID*100 + cardstar))
				limitNum := cardgrowinfo.LimitCount
				//获取转换比率
				propInfo := table.GetPropInfoByID(int(typeID))
				rate := propInfo.RecyclingPrice
				sumNum := backpack.GetGoodsNum(typeID)
				newConvertNum, needsAddNum := ps.GetLimitGoodsInfo(sumNum, num, uint32(limitNum), uint32(rate))
				convertNum = newConvertNum
				backpack.AddGolds(newConvertNum)
				backpack.AddGoods(typeID, needsAddNum)
				cardexp = backpack.GetGoodsNum(typeID)
			} else {
				backpack.AddGoods(typeID, num)
			}
			ans.CardGroupId = &cardTypeID
			ans.CardStar = &cardstar
			ans.CardExp = &cardexp
			ans.ConvertNum = &convertNum
			ans.TypeId = &typeID
			ans.Num = &num
			rewarditem = append(rewarditem, &ans)
		}
		var cardbagItem []*pp.CardbagItem
		cardbagItem = shop.CardBagToClientProto()
		cardBagInfo := pp.CardBagInfo{
			CardbagItem: cardbagItem,
			RewardItem:  rewarditem,
		}
		rsp.CardBagInfo = &cardBagInfo
	} else {
		result = csv.ERRCODE_PLAN_FORM_ERR
		return rsp
	}
	state.IsDirty = true
	return rsp
}
