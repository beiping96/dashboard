package playerCMD

import (
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	pd "lobby/playerDef"
	"lobby/shop"
	"shared/cardDef"
	"shared/csv"
	pb "shared/proto/client/portal"
	"shared/table"
)

// CmdLobbyBoxGet CMD :: lobby_box_get_req
func CmdLobbyBoxGet(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.LobbyBoxGetRsp{Result: &result}
	hasRefresh := state.Player.GetBox().Refresh()
	if hasRefresh {
		state.IsDirty = true
	}
	rsp.Box = state.Player.GetBox().ToClientProto()
	return rsp
}

// CmdLobbyBoxOpen CMD :: lobby_box_open_req
func CmdLobbyBoxOpen(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.LobbyBoxOpenRsp{Result: &result}
	// Unmarshal
	req := pb.LobbyBoxOpenReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	goodsTypeID := req.GetTypeID()
	// refresh box
	hasRefresh := state.Player.GetBox().Refresh()
	if hasRefresh {
		state.IsDirty = true
	}
	// check item is exist
	isExist := state.Player.GetBox().IsExist(goodsTypeID)
	if !isExist {
		result = csv.ERRCODE_LOBBY_BOX_NOT_EXIST
		return rsp
	}
	// check config is exist
	cardBagConfig, ok := csv.TableCardBagMap[int64(goodsTypeID)]
	if !ok {
		result = csv.ERRCODE_FAILED
		log.Error().Msgf("lobby box config error %v is exist in playerData but can't found its config",
			goodsTypeID)
		return rsp
	}
	// check key is enough
	keyNum := state.Player.GetBox().GetKeyNum()
	needKeyNum := uint32(cardBagConfig.NeedKey)
	if keyNum < needKeyNum {
		needGemstoneNum := (needKeyNum - keyNum) * 10
		gemstoneNum := state.Player.GetBackpack().GetGemstoneNum()
		if gemstoneNum < needGemstoneNum {
			result = csv.ERRCODE_LOBBY_GEMSTONE_NOT_ENOUGH
			return rsp
		}
		err := state.Player.GetBox().DelKey(keyNum)
		if err != nil {
			log.Error().Msgf("lobby box error del key %v", err)
			result = csv.ERRCODE_FAILED
			return rsp
		}
		err = state.Player.GetBackpack().DelGemstone(needGemstoneNum)
		if err != nil {
			log.Error().Msgf("lobby box error del gemstone %v", err)
			result = csv.ERRCODE_FAILED
			return rsp
		}
	} else {
		err := state.Player.GetBox().DelKey(needKeyNum)
		if err != nil {
			log.Error().Msgf("lobby box error del key %v", err)
			result = csv.ERRCODE_FAILED
			return rsp
		}
	}
	// ensure change playerData
	state.IsDirty = true
	// del box item
	delSuccess := state.Player.GetBox().DelTypeID(goodsTypeID)
	if !delSuccess {
		log.Error().Msgf("lobby box error del item %v", err)
		result = csv.ERRCODE_FAILED
		return rsp
	}
	// re refresh
	state.Player.GetBox().Refresh()
	rsp.Box = state.Player.GetBox().ToClientProto()
	// Open
	rewardGoodsMap := shop.OpenCardBag(goodsTypeID, state.Player.GetPlayerCards(), state.Player.GetBackpack())
	for goodsTypeID, goodsNum := range rewardGoodsMap {
		localGoodsTypeID, localGoodsNum := goodsTypeID, goodsNum
		var (
			cardTypeID uint32
			cardStar   uint32
			cardExp    uint32
			convertNum uint32
		)
		rewardItem := &pb.BagItemInfo{
			CardGroupId: &cardTypeID,
			CardStar:    &cardStar,
			CardExp:     &cardExp,
			ConvertNum:  &convertNum,
			TypeId:      &localGoodsTypeID,
			Num:         &localGoodsNum,
		}
		// skip money
		if localGoodsTypeID == csv.GOLDTYPE_TYPE_GEMSTONE ||
			localGoodsTypeID == csv.GOLDTYPE_TYPE_GOLD {
			state.Player.GetBackpack().AddGoods(localGoodsTypeID, localGoodsNum)
			rsp.RewardGoods = append(rsp.RewardGoods, rewardItem)
			continue
		}
		cardTypeID = uint32(table.GetCardTypeIDByPieceID(int(localGoodsTypeID)))
		card, ok := state.Player.GetPlayerCards()[cardDef.TypeID(cardTypeID)]
		if !ok {
			// card unlock
			err := state.Player.UnlockCard(cardDef.TypeID(cardTypeID))
			if err != nil {
				log.Error().Msgf("open reward box error unlock card %v error %v", cardTypeID, err)
			} else {
				card = state.Player.GetPlayerCards()[cardDef.TypeID(cardTypeID)]
			}
		}
		cardStar = card.GetCardStarLevel()
		// 获取上限
		cardgrowinfo := table.GetCardGrowFromCsv(int64(cardTypeID*100 + cardStar))
		limitNum := cardgrowinfo.LimitCount
		// 获取转换比率
		propInfo := table.GetPropInfoByID(int(localGoodsTypeID))
		rate := propInfo.RecyclingPrice
		sumNum := state.Player.GetBackpack().GetGoodsNum(localGoodsTypeID)
		newConvertNum, needsAddNum := shop.GetLimitGoodsInfo(sumNum, localGoodsNum, uint32(limitNum), uint32(rate))
		convertNum = newConvertNum
		state.Player.GetBackpack().AddGolds(newConvertNum)
		state.Player.GetBackpack().AddGoods(localGoodsTypeID, needsAddNum)
		cardExp = state.Player.GetBackpack().GetGoodsNum(localGoodsTypeID)
		rsp.RewardGoods = append(rsp.RewardGoods, rewardItem)
	}
	return rsp
}
