package playerCMD

import (
	"errors"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	pd "lobby/playerDef"
	"shared/csv"
	pp "shared/proto/client/portal"
	"shared/table"
)

func CmdLobbyGetAllHeroes(state *pd.PlayerState, body []byte) proto.Message {
	log.Debug().Msgf("player=%d get all heros req", state.Player.GetPlayerID())
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pp.LobbyGetAllHerosRsp{Result: &result}
	heroesList, err := GetAllHeroes(state)
	if err != nil {
		log.Debug().Msgf("get all hero error: %v", err)
		result = csv.ERRCODE_PLAN_FORM_ERR
		return rsp
	}
	rsp.Heros = heroesList
	state.IsDirty = true
	return rsp
}

func CmdLobbyUpgradeHero(state *pd.PlayerState, body []byte) proto.Message {
	log.Debug().Msgf("player=%d hero upgrade req", state.Player.GetPlayerID())
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pp.LobbyUpgradeHeroRsp{Result: &result}
	req := pp.LobbyUpgradeHeroReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("Unmarshal failed")
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	heroTypeID := req.GetHeroTypeId()
	heroes := state.Player.GetPlayerHeros()
	//判断英雄是否在英雄池中，在，升星，不在，则解锁
	for k, hero := range heroes {
		if hero.GetTypeID() == heroTypeID {
			heroInfo, errCode := UpgradeHero(state, k)
			if errCode != 0 {
				result = errCode
				return rsp
			}
			rsp.Heros = heroInfo
			state.IsDirty = true
			return rsp
		}
	}
	//解锁英雄
	heroInfo, errCode := UnlockHero(state, heroTypeID)
	if errCode != 0 {
		result = errCode
		return rsp
	}
	rsp.Heros = heroInfo
	state.IsDirty = true
	return rsp
}

func GetAllHeroes(state *pd.PlayerState) ([]*pp.LobbyHeroInfo, error) {
	allHero := make(map[uint64]*pp.LobbyHeroInfo)
	heroes := state.Player.GetPlayerHeros()
	backpack := state.Player.GetBackpack()
	for _, v := range csv.TableCareerInitialValueMap {
		heroUid := uint64(0)
		heroId := uint32(v.HeroId)
		starLevel := uint32(0)
		exp := uint32(0)
		for _, hero := range heroes {
			typeID := hero.GetTypeID()
			if typeID == heroId {
				starLevel = hero.GetStarLevel()
				heroUid = hero.GetUID()
			}
		}
		id := int64(heroId*100 + 1)
		heroGrow := table.GetHeroGrowFromCsv(id)
		if heroGrow == nil {
			return nil, errors.New("hero maxstar config not exist")
		}
		star := heroGrow.MaxStar
		if starLevel < uint32(star) {
			id = int64(heroId*100 + starLevel + 1)
			heroPiecesID := heroGrow.HeroPropID
			exp = uint32(backpack.GetGoodsNum(uint32(heroPiecesID)))
		}
		allHero[uint64(v.HeroId)] = &pp.LobbyHeroInfo{
			HeroUid:    &heroUid,
			HeroTypeId: &heroId,
			StarLevel:  &starLevel,
			Exp:        &exp,
		}
	}
	heroesList := make([]*pp.LobbyHeroInfo, len(allHero))
	i := 0
	for _, hero := range allHero {
		heroesList[i] = hero
		i++
	}
	return heroesList, nil
}

//英雄升星
func UpgradeHero(state *pd.PlayerState, uid uint64) (*pp.LobbyHeroInfo, int32) {
	result := int32(csv.ERRCODE_SUCCESS)
	backpack := state.Player.GetBackpack()
	heros := state.Player.GetPlayerHeros()
	hero, _ := heros[uid]
	//判断英雄星级是否达到最大
	heroStar := hero.GetStarLevel()
	heroTypeID := hero.GetTypeID()
	id := int64(heroTypeID*100 + heroStar)
	heroGrow := table.GetHeroGrowFromCsv(id)
	if heroGrow == nil {
		log.Error().Msgf("plan hero grow config not exist")
		result = csv.ERRCODE_PLAN_FORM_ERR
		return nil, result
	}
	maxStar := heroGrow.MaxStar
	if heroStar >= uint32(maxStar) {
		result = csv.ERRCODE_HERO_ALWAYS_MAX_STAR
		return nil, result
	}
	heroStar++
	id++
	//判断英雄碎片是否足够
	heroPieces := heroGrow.HeroPropID
	heroPiecesNum := heroGrow.HeroPropNum
	piecesNum := backpack.GetGoodsNum(uint32(heroPieces))
	if piecesNum < uint32(heroPiecesNum) {
		result = csv.ERRCODE_UPGRADE_GOODS_NOT_ENOUGH
		return nil, result
	}
	//判断金币是否足够
	coin := heroGrow.HeroUpgradeCoin
	bpCoin := backpack.GetGoldsNum()
	if bpCoin < uint32(coin) {
		result = csv.ERRCODE_UPGRADE_GOLDS_NOT_ENOUGH
		return nil, result
	}
	//英雄升星
	err := backpack.DelGoods(uint32(heroPieces), uint32(heroPiecesNum))
	if err != nil {
		log.Error().Msgf("Del goods failed")
		result = csv.ERRCODE_DEL_GOODS_ERR
		return nil, result
	}
	err = backpack.DelGolds(uint32(coin))
	if err != nil {
		log.Error().Msgf("Del golds failed")
		result = csv.ERRCODE_DEL_GOODS_ERR
		return nil, result
	}
	hero.SetStarLevel(heroStar)
	heros[uid] = hero
	heroInfo := GetOneHeroInfo(state, uid)
	if heroInfo == nil {
		result = csv.ERRCODE_GET_HERO_ERR
		return nil, result
	}
	return heroInfo, result
}

func GetOneHeroInfo(state *pd.PlayerState, uid uint64) *pp.LobbyHeroInfo {
	heroes := state.Player.GetPlayerHeros()
	backpack := state.Player.GetBackpack()
	exp := uint32(0)
	heroID := heroes[uid].GetTypeID()
	star := heroes[uid].GetStarLevel()
	id := int64(heroID*100 + 1)
	heroGrow := table.GetHeroGrowFromCsv(id)
	if heroGrow == nil {
		return nil
	}
	maxStar := heroGrow.MaxStar
	if star < uint32(maxStar) {
		id = int64(heroID*100 + star + 1)
		heroPiecesID := heroGrow.HeroPropID
		exp = uint32(backpack.GetGoodsNum(uint32(heroPiecesID)))
	}
	return &pp.LobbyHeroInfo{
		HeroUid:    &uid,
		HeroTypeId: &heroID,
		StarLevel:  &star,
		Exp:        &exp,
	}
}

//英雄解锁
func UnlockHero(state *pd.PlayerState, heroTypeID uint32) (*pp.LobbyHeroInfo, int32) {
	result := int32(csv.ERRCODE_SUCCESS)
	backpack := state.Player.GetBackpack()
	//职业表中是否存在此职业
	_, ok := csv.TableCareerInitialValueMap[int64(heroTypeID)]
	if !ok {
		log.Error().Msgf("TableCareerInitial config err")
		result = csv.ERRCODE_PLAN_FORM_ERR
		return nil, result
	}
	//养成表中是否存在解锁条件
	//判断英雄碎片是否足够
	id := int64(heroTypeID*100 + 1)
	heroGrow := table.GetHeroGrowFromCsv(id)
	if heroGrow == nil {
		log.Error().Msgf("hero pieces config not exist")
		result = csv.ERRCODE_PLAN_FORM_ERR
		return nil, result
	}
	heroPieces := heroGrow.HeroPropID
	heroPiecesNum := heroGrow.HeroPropNum
	piecesNum := backpack.GetGoodsNum(uint32(heroPieces))
	if piecesNum < uint32(heroPiecesNum) {
		result = csv.ERRCODE_UPGRADE_GOODS_NOT_ENOUGH
		return nil, result
	}
	//判断金币是否足够
	coin := heroGrow.HeroUpgradeCoin
	bpCoin := backpack.GetGoldsNum()
	if bpCoin < uint32(coin) {
		result = csv.ERRCODE_UPGRADE_GOLDS_NOT_ENOUGH
		return nil, result
	}
	//英雄解锁
	err := state.Player.NewHero(heroTypeID)
	if err != nil {
		log.Error().Msgf("new hero failed, err: %v", err)
		result = csv.ERRCODE_UNLOCK_HERO_ERR
		return nil, result
	}
	err = backpack.DelGoods(uint32(heroPieces), uint32(heroPiecesNum))
	if err != nil {
		log.Error().Msgf("Del golds failed")
		result = csv.ERRCODE_DEL_GOODS_ERR
		return nil, result
	}
	err = backpack.DelGolds(uint32(coin))
	if err != nil {
		log.Error().Msgf("Del golds failed")
		result = csv.ERRCODE_DEL_GOODS_ERR
		return nil, result
	}
	newHeroes := state.Player.GetPlayerHeros()
	for k, v := range newHeroes {
		if heroTypeID == v.GetTypeID() {
			heroInfo := GetOneHeroInfo(state, k)
			if heroInfo == nil {
				result = csv.ERRCODE_GET_HERO_ERR
				return nil, result
			}
			return heroInfo, result
		}
	}
	result = csv.ERRCODE_UNLOCK_HERO_ERR
	return nil, result
}
