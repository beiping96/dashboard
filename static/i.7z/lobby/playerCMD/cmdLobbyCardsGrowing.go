package playerCMD

import (
	"errors"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	pd "lobby/playerDef"
	cd "shared/cardDef"
	"shared/csv"
	pp "shared/proto/client/portal"
	"shared/table"
)

func CmdLobbyGetAllCards(state *pd.PlayerState, body []byte) proto.Message {
	log.Debug().Msgf("player=%d get all cards req", state.Player.GetPlayerID())
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pp.LobbyGetAllCardsRsp{Result: &result}
	cardslist, err := GetAllCards(state)
	if err != nil {
		result = csv.ERRCODE_GET_CARDS_ERR
		return rsp
	}
	rsp.Cards = cardslist
	return rsp
}

func CmdLobbyUpgradeCard(state *pd.PlayerState, body []byte) proto.Message {
	log.Debug().Msgf("player=%d upgrade cards req", state.Player.GetPlayerID())
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pp.LobbyUpgradeCardRsp{Result: &result}
	req := pp.LobbyUpgradeCardReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("unmarshal failed")
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	cardTypeID := req.GetTypeId()
	cardT := cd.TypeID(cardTypeID)
	//判断卡牌是否存在玩家卡牌池中
	cards := state.Player.GetPlayerCards()
	backpack := state.Player.GetBackpack()
	crd, ok := cards[cardT]
	if !ok {
		log.Error().Msgf("%v card not exist", cardTypeID)
		result = csv.ERRCODE_CARD_NOT_EXIST
		return rsp
	}
	//判断卡片星级是否达到最大
	star := crd.GetCardStarLevel()
	id := int64(cardTypeID*100 + star)
	cardGrow := table.GetCardGrowFromCsv(id)
	if cardGrow == nil {
		log.Error().Msgf("%v card config form err", cardTypeID)
		result = csv.ERRCODE_PLAN_FORM_ERR
		return rsp
	}
	maxstar := cardGrow.MaxStar
	if star >= uint32(maxstar) {
		result = csv.ERRCODE_CARD_ALWAYS_MAX_STAR
		return rsp
	}
	//判断升星道具是否足够
	propNum := cardGrow.CardPropNum
	cardPropID := cardGrow.CardPropID
	goodsnum := backpack.GetGoodsNum(uint32(cardPropID))
	if goodsnum < uint32(propNum) {
		result = csv.ERRCODE_UPGRADE_GOODS_NOT_ENOUGH
		return rsp
	}
	//判断升星金币是否足够
	upgradeIcon := cardGrow.CardUpgradeCoin
	coin := backpack.GetGoldsNum()
	if coin < uint32(upgradeIcon) {
		result = csv.ERRCODE_UPGRADE_GOLDS_NOT_ENOUGH
		return rsp
	}
	//升星，消耗道具，消耗金币
	star += 1
	crd.SetCardStarLevel(star)
	cards[cardT] = crd
	err = backpack.DelGoods(uint32(cardPropID), uint32(propNum))
	if err != nil {
		log.Debug().Msgf("Del goods failed")
		result = csv.ERRCODE_DEL_GOODS_ERR
		return rsp
	}
	err = backpack.DelGolds(uint32(upgradeIcon))
	if err != nil {
		log.Debug().Msgf("Del golds failed")
		result = csv.ERRCODE_DEL_GOODS_ERR
		return rsp
	}
	//获取所有卡牌的最新数据
	cardslist, err := GetAllCards(state)
	if err != nil {
		log.Error().Msgf("card upgrade goods not exist")
		result = csv.ERRCODE_GET_CARDS_ERR
		return rsp
	}
	rsp.Cards = cardslist
	state.IsDirty = true
	return rsp
}

//获取玩家所有卡牌数据
func GetAllCards(state *pd.PlayerState) ([]*pp.LobbyCardInfo, error) {
	cardslist := []*pp.LobbyCardInfo{}
	for _, card := range state.Player.GetPlayerCards() {
		typeID := uint32(card.GetTypeID())
		star := uint32(card.GetCardStarLevel())
		id := int64(typeID*100 + star)
		cardGrow := table.GetCardGrowFromCsv(id)
		if cardGrow == nil {
			log.Error().Msgf("card grow config not exist error table.GetCardGrowFromCsv %v", id)
			return nil, errors.New("card grow config not exist")
		}
		cardPropID := cardGrow.CardPropID
		exp := uint32(state.Player.GetBackpack().GetGoodsNum(uint32(cardPropID)))
		isNewUnlock := uint32(0)
		if card.GetIsNewUnlock() {
			card.CardShow()
			state.IsDirty = true
			isNewUnlock = 1
		}
		cardInfo := &pp.LobbyCardInfo{
			TypeId:      &typeID,
			StarLevel:   &star,
			Exp:         &exp,
			IsNewUnlock: &isNewUnlock,
		}
		cardslist = append(cardslist, cardInfo)
	}
	log.Debug().Msgf("debug output all cardsLen %v  LobbyCardInfoLen %v", len(state.Player.GetPlayerCards()), len(cardslist))
	return cardslist, nil
}
