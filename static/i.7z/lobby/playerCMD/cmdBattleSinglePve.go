package playerCMD

import (
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	pd "lobby/playerDef"
	"lobby/singlePVE"
	"shared/csv"
	pb "shared/proto/client/battle"
	"strconv"
)

// CmdBattleSinglePveCreate CMD: battle_single_pve_create_req
func CmdBattleSinglePveCreate(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleSinglePveCreateRsp{Result: &result}

	// Unmarshal
	req := pb.BattleSinglePveCreateReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	heroID, err := strconv.ParseUint(req.GetHeroUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageMode := uint32(1)
	stageDifficulty := req.GetDifficulty()
	// Check hero
	myHero, ok := state.Player.GetPlayerHeros()[heroID]
	if !ok {
		result = csv.ERRCODE_NO_HERO
		return rsp
	}

	// if player has unFinish singlePve, shouldn't create new one
	if state.Player.GetSinglePveStageUID() > 0 {
		result = csv.ERRCODE_SINGLEPVE_IS_EXIST
		return rsp
	}
	resultLocal, battleStage, err := singlePVE.CreateStage(state.Player, *myHero, stageMode, stageDifficulty)
	result = resultLocal
	if err != nil {
		log.Error().Msgf("failed to create stage:%s", err.Error())
		return rsp
	}
	// save singlePve flag
	state.Player.SetSinglePveStageUID(battleStage.UID)
	state.IsDirty = true
	rsp.Info = battleStage.ToClientProto(state.Player.GetPlayerID())
	return rsp
}

// CmdBattleSinglePveTouch CMD: battle_single_pve_touch_req
func CmdBattleSinglePveTouch(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleSinglePveTouchRsp{Result: &result}

	req := pb.BattleSinglePveTouchReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		log.Error().Msgf("fail unmarshal proto:%s", err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	reqStageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	reqStageNodeID := req.GetStageNodeId()
	playerID := state.Player.GetPlayerID()
	stageUID := state.Player.GetSinglePveStageUID()
	log.Debug().Msgf("singlePVE touch up, stageUID:%v, reqStageUID:%v",
		stageUID, reqStageUID)

	if stageUID != reqStageUID || stageUID <= 0 {
		result = csv.ERRCODE_NO_STAGE
		return rsp
	}
	err = singlePVE.Touch(state, stageUID, reqStageNodeID, rsp)
	if err != nil {
		log.Info().Msgf("hero can't touch node in stage, playerID:%v, stageID:%v, nodeID:%v, error: %s",
			playerID, reqStageUID, reqStageNodeID, err.Error())
		return rsp
	}
	log.Debug().Msgf("singlePVE touch down result:%v status:%v, reward, %v, rest_status: %v, all:%v",
		rsp.GetResult(), rsp.GetStatus(), rsp.GetTreasure(), rsp.GetRestStatus(), rsp)
	return rsp
}

// CmdBattleOperation CMD: battle_operation_req
func CmdBattleOperation(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleOperationRsp{Result: &result}

	req := pb.BattleOperationReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	o := req.GetOperation()
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageNodeID := req.GetStageNodeId()
	resultLocal, newO := singlePVE.BattleOperation(state.Player.GetPlayerID(), stageUID, stageNodeID, o)
	log.Debug().Msgf("battle %v:%v operation %v get the result:%v", stageUID, stageNodeID, o, result)
	rsp.Result = &resultLocal
	rsp.Operation = newO
	return rsp
}

// CmdBattleChooseCard CMD: battle_choose_card_req
func CmdBattleChooseCard(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleChooseCardRsp{Result: &result}

	req := pb.BattleChooseCardReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageNodeID := req.GetNodeId()
	cardUIDs := req.GetCardUids()

	resultLocal := singlePVE.BattleChooseCardOperation(state.Player.GetPlayerID(), stageUID, stageNodeID, cardUIDs)
	rsp.Result = &resultLocal
	return rsp
}

// CmdBattleLeave CMD: battle_leave_battle_req
func CmdBattleLeave(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleLeaveBattleRsp{Result: &result}

	req := pb.BattleLeaveBattleReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageNodeID := req.GetStageNodeId()
	resultLocal := singlePVE.BattlePlayerLeave(state.Player.GetPlayerID(), stageUID, stageNodeID)
	rsp.Result = &resultLocal
	return rsp
}

// CmdBattleCardLevelUp CMD: battle_card_level_up_req
func CmdBattleCardLevelUp(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleCardLevelUpRsp{Result: &result}

	req := pb.BattleCardLevelUpReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageNodeID := req.GetStageNodeId()
	cardID := req.GetCardId()
	resultLocal, newResID := singlePVE.RestCardLevelUp(stageUID, stageNodeID, state.Player.GetPlayerID(), cardID)
	rsp.Result = &resultLocal
	rsp.CardTypeId = &newResID
	rsp.CardId = &cardID
	return rsp
}

// CmdBattleRecover CMD: battle_recover_req
func CmdBattleRecover(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleRecoverRsp{Result: &result}

	req := pb.BattleRecoverReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageNodeID := req.GetStageNodeId()
	resultLocal, newHP, stageRelicsInfo := singlePVE.RestRecover(stageUID, stageNodeID, state.Player.GetPlayerID())
	rsp.Result = &resultLocal
	rsp.NewHP = &newHP
	rsp.RelicInStage = append(rsp.RelicInStage, stageRelicsInfo...)
	return rsp
}

// CmdBattleRewardOpen CMD: battle_reward_open_req
func CmdBattleRewardOpen(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleRewardOpenRsp{Result: &result}

	req := pb.BattleRewardOpenReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageNodeID := req.GetStageNodeId()
	resultLocal, relicInStage := singlePVE.OpenReward(stageUID, stageNodeID, state.Player.GetPlayerID())
	rsp.RelicInStage = relicInStage
	rsp.Result = &resultLocal
	return rsp
}

// CmdBattleRewardClose CMD: battle_reward_close_req
func CmdBattleRewardClose(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleRewardCloseRsp{Result: &result}

	req := pb.BattleRewardCloseReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageNodeID := req.GetStageNodeId()
	resultLocal := singlePVE.CloseReward(stageUID, stageNodeID, state.Player.GetPlayerID())
	rsp.Result = &resultLocal
	return rsp
}

// CmdBattleChoiceReward CMD: battle_choice_reward_req
func CmdBattleChoiceReward(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleChoiceRewardRsp{Result: &result}

	req := pb.BattleChoiceRewardReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageNodeID := req.GetStageNodeId()
	rewardBagUID := req.GetRewardBagInsId()
	rewardType := req.GetType()
	itemID := req.GetItemId()
	resultLocal, relicInStage, goldNum := singlePVE.ChooseReward(stageUID, stageNodeID, state.Player.GetPlayerID(), rewardBagUID, rewardType, itemID)
	rsp.Result = &resultLocal
	rsp.RelicInStage = relicInStage
	rsp.GoldNum = &goldNum
	return rsp
}

// CmdBattleSinglePveDestroy CMD: battle_single_pve_destroy_req
func CmdBattleSinglePveDestroy(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleSinglePveDestroyRsp{Result: &result}

	req := pb.BattleSinglePveDestroyReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	if stageUID == 0 {
		result = int32(csv.ERRCODE_FAILED)
		return rsp
	}
	stage := singlePVE.Get(state.Player.GetSinglePveStageUID())
	if stage == nil || stageUID != stage.UID {
		result = int32(csv.ERRCODE_NO_STAGE)
		return rsp
	}
	resultLocal := singlePVE.Destroy(stageUID, state.Player.GetPlayerID())
	rsp.Result = &resultLocal
	if csv.ERRCODE_SUCCESS == resultLocal {
		state.Player.SetSinglePveStageUID(0)
		state.IsDirty = true
	}
	return rsp
}

// CmdBattleDropPotion CMD: battle_drop_potion_req
func CmdBattleDropPotion(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleDropPotionRsp{Result: &result}

	req := pb.BattleDropPotionReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	if stageUID == 0 {
		result = int32(csv.ERRCODE_FAILED)
		return rsp
	}
	saveStageUID := state.Player.GetSinglePveStageUID()
	if stageUID != saveStageUID {
		result = int32(csv.ERRCODE_NO_STAGE)
		return rsp
	}
	resultLocal, newPotion := singlePVE.DropPotion(stageUID, state.Player.GetPlayerID(), req.GetPotionTypeID())
	rsp.Potions = newPotion
	rsp.Result = &resultLocal
	return rsp
}

// CmdBattleSinglePveGet CMD: battle_get_single_pve_req
func CmdBattleSinglePveGet(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleGetSinglePveRsp{Result: &result}

	req := pb.BattleGetSinglePveReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	if stageUID == 0 {
		result = int32(csv.ERRCODE_FAILED)
		return rsp
	}
	saveStageUID := state.Player.GetSinglePveStageUID()
	if stageUID != saveStageUID {
		result = int32(csv.ERRCODE_NO_STAGE)
		return rsp
	}
	myStage := singlePVE.Get(stageUID)
	if myStage == nil {
		result = int32(csv.ERRCODE_NO_STAGE)
		return rsp
	}

	// 原样返回 param
	param := req.GetParam()
	rsp.Param = &param
	rsp.Info = myStage.ToClientProto(state.Player.GetPlayerID())
	return rsp
}

// CmdBattleShopPurchase stage shop
func CmdBattleShopPurchase(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.BattleShopPurchaseRsp{Result: &result}

	req := pb.BattleShopPurchaseReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	//myStage, err := stage.Stage{UID: stageUID}, errors.New("")
	//if err != nil {
	//	result = csv.ERRCODE_NO_STAGE
	//	return rsp
	//}
	nodeID := req.GetNodeId()
	//_, ok := myStage.Nodes[nodeID]
	//if !ok {
	//	result = csv.ERRCODE_BATTLE_NODE_NOT_EXIST
	//	return rsp
	//}
	//heroInStage := false
	//var myHero hero.InStage
	playerID := state.Player.GetPlayerID()
	//for _, h := range myStage.Heros {
	//	if h.PlayerID == playerID {
	//		myHero = h
	//		heroInStage = true
	//		break
	//	}
	//}
	//if !heroInStage {
	//	result = csv.ERRCODE_NO_HERO_IN_STAGE
	//	return rsp
	//}
	//if myHero.FlagInBattle {
	//	result = csv.ERRCODE_FAILED // in battle
	//	return rsp
	//}
	//if myHero.FlagQuit {
	//	result = csv.ERRCODE_NO_HERO_IN_STAGE
	//	return rsp
	//}
	itemIndex := req.GetItemIndex()
	itemType := req.GetItemType()
	itemID := req.GetItemId()
	rsp.ItemType = &itemType
	rsp.ItemId = &itemID
	//result = myStage.ShopPurchase(&myHero, nodeID, itemID, uint32(itemType), itemIndex, rsp)
	result = singlePVE.ShopPurchase(playerID, stageUID, nodeID, itemID, uint32(itemType), itemIndex, rsp)

	return rsp
}

// CmdBattleChooseEvent stage event
func CmdBattleChooseEvent(state *pd.PlayerState, body []byte) proto.Message {
	rsp := &pb.BattleChooseEventRsp{}
	result := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &result

	req := pb.BattleChooseEventReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}

	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	nodeID := req.GetNodeId()
	optionIndex := req.GetOptionIndex()
	playerID := state.Player.GetPlayerID()
	cardIds := req.CardIds
	eventResult, linkageEventID, stop, result := singlePVE.ChooseEvent(playerID, stageUID, nodeID, optionIndex, cardIds)
	rsp.EventId = &linkageEventID
	rsp.EventResult = &eventResult
	rsp.OptionIndex = &optionIndex
	eventStop := uint32(csv.GENERAL_FALSE)
	if stop {
		eventStop = csv.GENERAL_TRUE
		state.Player.SetFlagInEvent(false)
		state.IsDirty = true
	}
	rsp.Stop = &eventStop
	log.Debug().Msgf("choose event, rsp.EventResult: %v, linkageEventId: %d, stop: %v",
		rsp.EventResult, linkageEventID, stop)
	return rsp
}

// CmdBattleChooseInitEvent stage init event
func CmdBattleChooseInitEvent(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.StageChooseInitEventRsp{Result: &result}
	req := pb.StageChooseInitEventReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	eventID := req.GetEventId()
	param := req.GetParam()
	playerID := state.Player.GetPlayerID()
	eventResult, result := singlePVE.StageChooseInitEvent(stageUID, playerID, eventID, param)
	rsp.EventResult = &eventResult
	return rsp
}

// CmdBattleReconnection CMD: battle_reconnection_req
func CmdBattleReconnection(state *pd.PlayerState, body []byte) proto.Message {
	rsp := &pb.BattleReconnectionRsp{}
	result := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &result

	req := pb.BattleReconnectionReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	nodeID := req.GetNodeId()
	typeLocal, resultLocal := singlePVE.Reconnection(stageUID, nodeID, state.Player.GetPlayerID())
	rsp.Result = &resultLocal
	rsp.Type = &typeLocal
	return rsp
}

// CmdBattleResurgence CMD: battle_resurgence_req
func CmdBattleResurgence(state *pd.PlayerState, body []byte) proto.Message {
	rsp := &pb.BattleResurgenceRsp{}
	result := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &result

	req := pb.BattleResurgenceReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	resurgenceType := req.GetType()
	if resurgenceType == 0 {
		singlePVE.Resurgence(stageUID, resurgenceType, state, rsp)
		return rsp
	}
	singlePVE.ResurgencePlus(stageUID, resurgenceType, state, rsp)
	return rsp
}

// CmdBattleRelicInStageChoose CMD: battle_relic_in_stage_choose_req
func CmdBattleRelicInStageChoose(state *pd.PlayerState, body []byte) proto.Message {
	rsp := &pb.BattleRelicInStageChooseRsp{}
	result := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &result

	req := pb.BattleRelicInStageChooseReq{}
	err := proto.Unmarshal(body, &req)
	if err != nil {
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	stageUID, err := strconv.ParseUint(req.GetStageUid(), 0, 64)
	if err != nil {
		log.Error().Msgf("failed unmarshal proto:byte(%v), len(%v), %s", body, len(body), err.Error())
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return rsp
	}
	relicTypeID := req.GetRelicTypeId()
	cardID := req.GetCardId()
	potionID := req.GetPotionTypeID()
	resultLocal, newCard, allPotion := singlePVE.RelicInStageChoose(state.Player.GetPlayerID(), stageUID, relicTypeID, cardID, potionID)
	result = resultLocal
	rsp.NewCard = newCard
	rsp.Potions = allPotion
	return rsp
}
