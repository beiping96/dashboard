package playerCMD

import (
	"fmt"
	"github.com/golang/protobuf/proto"
	pd "lobby/playerDef"
	cd "shared/mfxconn"
	cmd "shared/proto/share/command"
)

type cmdHandlerFunc func(*pd.PlayerState, []byte) proto.Message

type playerHandler struct {
	opcode cmd.CLIENT_RSP_CMD
	fun    cmdHandlerFunc
}

var handlerMap = map[cmd.CLIENT_REQ_CMD]playerHandler{
	cmd.CLIENT_REQ_CMD_LOBBY_CODE_REPAIR_REQ: {cmd.CLIENT_RSP_CMD_LOBBY_CODE_REPAIR_RSP, CmdLobbyCodeRepair},
	// Mail
	cmd.CLIENT_REQ_CMD_LOBBY_MAIL_GET_REQ:               {cmd.CLIENT_RSP_CMD_LOBBY_MAIL_GET_RSP, CmdLobbyMailGet},
	cmd.CLIENT_REQ_CMD_LOBBY_MAIL_READ_REQ:              {cmd.CLIENT_RSP_CMD_LOBBY_MAIL_READ_RSP, CmdLobbyMailRead},
	cmd.CLIENT_REQ_CMD_LOBBY_MAIL_ATTACHMENT_REQ:        {cmd.CLIENT_RSP_CMD_LOBBY_MAIL_ATTACHMENT_RSP, CmdLobbyMailAttachment},
	cmd.CLIENT_REQ_CMD_LOBBY_MAIL_DEL_REQ:               {cmd.CLIENT_RSP_CMD_LOBBY_MAIL_DEL_RSP, CmdLobbyMailDel},
	cmd.CLIENT_REQ_CMD_LOBBY_GLOBAL_MAIL_ATTACHMENT_REQ: {cmd.CLIENT_RSP_CMD_LOBBY_GLOBAL_MAIL_ATTACHMENT_RSP, CmdLobbyGlobalMailAttachment},
	// Lobby
	cmd.CLIENT_REQ_CMD_LOBBY_GET_ALL_CARDS_REQ: {cmd.CLIENT_RSP_CMD_LOBBY_GET_ALL_CARDS_RSP, CmdLobbyGetAllCards},
	cmd.CLIENT_REQ_CMD_LOBBY_UPGRADE_CARD_REQ:  {cmd.CLIENT_RSP_CMD_LOBBY_UPGRADE_CARD_RSP, CmdLobbyUpgradeCard},
	cmd.CLIENT_REQ_CMD_LOBBY_GET_ALL_HEROS_REQ: {cmd.CLIENT_RSP_CMD_LOBBY_GET_ALL_HEROS_RSP, CmdLobbyGetAllHeroes},
	cmd.CLIENT_REQ_CMD_LOBBY_UPGRADE_HERO_REQ:  {cmd.CLIENT_RSP_CMD_LOBBY_UPGRADE_HERO_RSP, CmdLobbyUpgradeHero},
	cmd.CLIENT_REQ_CMD_LOBBY_GET_BACKPACK_REQ:  {cmd.CLIENT_RSP_CMD_LOBBY_GET_BACKPACK_RSP, CmdLobbyGetBackpackReq},
	cmd.CLIENT_REQ_CMD_LOBBY_CONVERT_GOLDS_REQ: {cmd.CLIENT_RSP_CMD_LOBBY_CONVERT_GOLDS_RSP, CmdLobbyConvertGoldsReq},
	cmd.CLIENT_REQ_CMD_LOBBY_GET_SHOP_REQ:      {cmd.CLIENT_RSP_CMD_LOBBY_GET_SHOP_RSP, CmdLobbyGetShop},
	cmd.CLIENT_REQ_CMD_LOBBY_SHOP_REQ:          {cmd.CLIENT_RSP_CMD_LOBBY_SHOP_RSP, CmdLobbyShop},
	cmd.CLIENT_REQ_CMD_LOBBY_BOX_GET_REQ:       {cmd.CLIENT_RSP_CMD_LOBBY_BOX_GET_RSP, CmdLobbyBoxGet},
	cmd.CLIENT_REQ_CMD_LOBBY_BOX_OPEN_REQ:      {cmd.CLIENT_RSP_CMD_LOBBY_BOX_OPEN_RSP, CmdLobbyBoxOpen},
	// Single PVE
	cmd.CLIENT_REQ_CMD_BATTLE_SINGLE_PVE_CREATE_REQ:     {cmd.CLIENT_RSP_CMD_BATTLE_SINGLE_PVE_CREATE_RSP, CmdBattleSinglePveCreate},
	cmd.CLIENT_REQ_CMD_BATTLE_SINGLE_PVE_TOUCH_REQ:      {cmd.CLIENT_RSP_CMD_BATTLE_SINGLE_PVE_TOUCH_RSP, CmdBattleSinglePveTouch},
	cmd.CLIENT_REQ_CMD_BATTLE_OPERATION_REQ:             {cmd.CLIENT_RSP_CMD_BATTLE_OPERATION_RSP, CmdBattleOperation},
	cmd.CLIENT_REQ_CMD_BATTLE_LEAVE_BATTLE_REQ:          {cmd.CLIENT_RSP_CMD_BATTLE_LEAVE_BATTLE_RSP, CmdBattleLeave},
	cmd.CLIENT_REQ_CMD_BATTLE_CARD_LEVEL_UP_REQ:         {cmd.CLIENT_RSP_CMD_BATTLE_CARD_LEVEL_UP_RSP, CmdBattleCardLevelUp},
	cmd.CLIENT_REQ_CMD_BATTLE_RECOVER_REQ:               {cmd.CLIENT_RSP_CMD_BATTLE_RECOVER_RSP, CmdBattleRecover},
	cmd.CLIENT_REQ_CMD_BATTLE_CHOICE_REWARD_REQ:         {cmd.CLIENT_RSP_CMD_BATTLE_CHOICE_REWARD_RSP, CmdBattleChoiceReward},
	cmd.CLIENT_REQ_CMD_BATTLE_SINGLE_PVE_DESTROY_REQ:    {cmd.CLIENT_RSP_CMD_BATTLE_SINGLE_PVE_DESTROY_RSP, CmdBattleSinglePveDestroy},
	cmd.CLIENT_REQ_CMD_BATTLE_GET_SINGLE_PVE_REQ:        {cmd.CLIENT_RSP_CMD_BATTLE_GET_SINGLE_PVE_RSP, CmdBattleSinglePveGet},
	cmd.CLIENT_REQ_CMD_BATTLE_CHOOSE_CARD_REQ:           {cmd.CLIENT_RSP_CMD_BATTLE_CHOOSE_CARD_RSP, CmdBattleChooseCard},
	cmd.CLIENT_REQ_CMD_BATTLE_SHOP_PURCHASE_REQ:         {cmd.CLIENT_RSP_CMD_BATTLE_SHOP_PURCHASE_RSP, CmdBattleShopPurchase},
	cmd.CLIENT_REQ_CMD_BATTLE_REWARD_OPEN_REQ:           {cmd.CLIENT_RSP_CMD_BATTLE_REWARD_OPEN_RSP, CmdBattleRewardOpen},
	cmd.CLIENT_REQ_CMD_BATTLE_REWARD_CLOSE_REQ:          {cmd.CLIENT_RSP_CMD_BATTLE_REWARD_CLOSE_RSP, CmdBattleRewardClose},
	cmd.CLIENT_REQ_CMD_BATTLE_CHOOSE_EVENT_REQ:          {cmd.CLIENT_RSP_CMD_BATTLE_CHOOSE_EVENT_RSP, CmdBattleChooseEvent},
	cmd.CLIENT_REQ_CMD_BATTLE_DROP_POTION_REQ:           {cmd.CLIENT_RSP_CMD_BATTLE_DROP_POTION_RSP, CmdBattleDropPotion},
	cmd.CLIENT_REQ_CMD_BATTLE_RECONNECTION_REQ:          {cmd.CLIENT_RSP_CMD_BATTLE_RECONNECTION_RSP, CmdBattleReconnection},
	cmd.CLIENT_REQ_CMD_BATTLE_RESURGENCE_REQ:            {cmd.CLIENT_RSP_CMD_BATTLE_RESURGENCE_RSP, CmdBattleResurgence},
	cmd.CLIENT_REQ_CMD_STAGE_CHOOSE_INIT_EVENT_REQ:      {cmd.CLIENT_RSP_CMD_STAGE_CHOOSE_INIT_EVENT_RSP, CmdBattleChooseInitEvent},
	cmd.CLIENT_REQ_CMD_BATTLE_RELIC_IN_STAGE_CHOOSE_REQ: {cmd.CLIENT_RSP_CMD_BATTLE_RELIC_IN_STAGE_CHOOSE_RSP, CmdBattleRelicInStageChoose},
}

func execute(opcode cmd.CLIENT_REQ_CMD, actorState *pd.PlayerState, body []byte) (proto.Message, cmd.CLIENT_RSP_CMD, error) {
	handler, ok := handlerMap[opcode]
	//不存在cmd
	if ok == false {
		return nil, cmd.CLIENT_RSP_CMD_TEST_RSP, fmt.Errorf("unknown opcode:%d", opcode)
	}

	//包处理
	return handler.fun(actorState, body), handler.opcode, nil
}

// CmdHandler hander player up
func CmdHandler(opcode cmd.CLIENT_REQ_CMD, state *pd.PlayerState, bodyWithSession []byte) ([]byte, cmd.CLIENT_RSP_CMD, error) {
	_, _, body := cd.ParseSessionBody(bodyWithSession)
	rsp, rspCmdID, err := execute(opcode, state, body)
	if err != nil {
		return nil, 0, err
	}

	newBody, err := proto.Marshal(rsp)
	return newBody, rspCmdID, err
}
