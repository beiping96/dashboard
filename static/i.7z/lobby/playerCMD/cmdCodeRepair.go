package playerCMD

import (
	"github.com/golang/protobuf/proto"
	"lobby/codeRepair"
	pd "lobby/playerDef"
	"shared/csv"
	pb "shared/proto/client/portal"
)

// CmdLobbyCodeRepair CMD :: lobby_code_repair_req
func CmdLobbyCodeRepair(state *pd.PlayerState, body []byte) proto.Message {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp := &pb.LobbyCodeRepairRsp{Result: &result}
	luaStr := codeRepair.GetLuaStr()
	rsp.LuaStr = &luaStr
	return rsp
}
