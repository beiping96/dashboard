package codeRepair

import (
	"encoding/json"
	"fmt"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"net/http"
	"net/url"
	"shared/mfxlocalregistry"
	"sync"
	"time"
)

type codeRepairMgr struct {
	codeRepairService string
	lock              sync.RWMutex
	luaStr            *string
}

var (
	globalMgr *codeRepairMgr
)

// Init codeRepairService
func Init(codeRepairService string) {
	luaStr := ""
	globalMgr = &codeRepairMgr{
		codeRepairService: codeRepairService,
		luaStr:            &luaStr,
	}
	// try update Once
	err := updateLuaStr()
	if err != nil {
		panic(fmt.Errorf("codeRepair Init error %v", err))
	}
	// go tick update
	go tickUpdateLuaStr()
}

// GetLuaStr call by player login lobby
func GetLuaStr() string {
	globalMgr.lock.RLock()
	defer globalMgr.lock.RUnlock()
	return *globalMgr.luaStr
}

func tickUpdateLuaStr() {
	ticker := time.Tick(time.Duration(10) * time.Second)
	for {
		<-ticker
		err := updateLuaStr()
		if err != nil {
			log.Error().Msgf("codeRepair update error %v", err)
		}
	}
}

// ReadRsp - read luaStr
type ReadRsp struct {
	Result  int    `json:"result"`
	Content string `json:"data"`
	Error   string `json:"error"`
}

func updateLuaStr() error {
	ip, _, port, err := mfxlocalregistry.SelectEndpoint(globalMgr.codeRepairService)
	if err != nil {
		return err
	}
	serviceURL := fmt.Sprintf("http://%s:%d/getLuaStr", ip, port)
	readRsp, err := http.Get(serviceURL)
	if err != nil {
		return err
	}
	defer readRsp.Body.Close()
	jsonByte, err := ioutil.ReadAll(readRsp.Body)
	if err != nil {
		return err
	}
	rsp := ReadRsp{}
	err = json.Unmarshal(jsonByte, &rsp)
	if err != nil {
		return nil
	}
	if rsp.Result != 0 {
		return fmt.Errorf(rsp.Error)
	}
	luaStr := ""
	if len(rsp.Content) != 0 {
		luaStr, err = url.QueryUnescape(rsp.Content)
		if err != nil {
			return err
		}
	}
	globalMgr.lock.Lock()
	defer globalMgr.lock.Unlock()
	globalMgr.luaStr = &luaStr
	return nil
}
