package main

import (
	"database/sql"
	"encoding/xml"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	cfg "lobby/config"
	"net"
	"net/http"
	_ "net/http/pprof"
	bd "shared/mfxbasedef"
	lr "shared/mfxlocalregistry"
	lu "shared/mfxlogutil"
	redis "shared/mfxredisutil"
	"strconv"
	"time"
)

func start(xmlFile string, isResume bool) bool {
	fmt.Printf("start with config: %s\n", xmlFile)
	fileData, err := ioutil.ReadFile(xmlFile)
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		return false
	}

	var config cfg.LobbyConfig
	err = xml.Unmarshal(fileData, &config)
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		return false
	}

	// 设置日志
	fmt.Printf("log path=%s, level=%s\n", config.LogPath, config.LogLevel)
	lu.SetupLogPath(config.LogPath)
	lu.SetupLogLevel(config.LogLevel)

	// 基本的服务器配置
	if isResume {
		log.Info().Msgf("resume with config: %s", xmlFile)
	} else {
		log.Info().Msgf("start with config: %s", xmlFile)
	}

	log.Debug().Msgf("division:%s", config.Division)
	log.Debug().Msgf("locator:%v", config.Loc)
	log.Debug().Msgf("mysql connection: %s:%s, database=%s, username=%s, password=%s", config.Mysql.Ep.Ip, config.Mysql.Ep.Port, config.Mysql.Database, config.Mysql.Username, config.Mysql.Password)
	log.Debug().Msgf("redis connection: %v", config.Redis)
	log.Debug().Msgf("business ip=%s, port=%s", config.Business.Ip, config.Business.Port)
	log.Debug().Msgf("admin ip=%s, port=%s", config.Admin.Ip, config.Admin.Port)
	log.Debug().Msgf("rpc ip=%s, port=%s", config.RPC.Ip, config.RPC.Port)
	log.Debug().Msgf("shm pool data_size=%d, data_count=%d", config.Shmpool.DataSize, config.Shmpool.DataCount)
	log.Debug().Msgf("log path=%s, level=%s", config.LogPath, config.LogLevel)

	// 节点相关，获得division
	var app, server, id string
	var lobbyID int
	if app, server, id, err = bd.ParseDivision(config.Division); err != nil {
		log.Error().Msgf("division error: %s", err.Error())
		return false
	} else {
		log.Debug().Msgf("app=%s, server=%s, id=%s", app, server, id)
		cfg.App, cfg.Server, cfg.Division = app, server, config.Division
	}

	// 先尝试拉取一次registry，如果失败则直接退出
	lr.SetLocator(config.Loc.Ep.Ip, config.Loc.Ep.Port)
	err = lr.QueryRegistry()
	if err != nil {
		log.Error().Msgf("query registry from %s:%s failed, %s", config.Loc.Ep.Ip, config.Loc.Ep.Port, err.Error())
		return false
	}
	lr.StartQueryLoop(config.Loc.RefreshInterval)

	// 初始化redis连接池
	redisAddr := fmt.Sprintf("%s:%s", config.Redis.Ep.Ip, config.Redis.Ep.Port)
	redisPool, err := redis.NewRedisUtil(redisAddr)
	if err != nil {
		// redis initialization failed
		log.Error().Msgf("lobby id=%s redis initialization error: %s", id, err.Error())
		return false
	}
	cfg.RedisPool = redisPool

	// 查询是否有对应自己id的conn进程，如果没有也直接退出
	var connAddr string
	if lobbyID, err = strconv.Atoi(id); err != nil {
		log.Error().Msgf("lobby id=%s error: %s", id, err.Error())
		return false
	} else {
		connDivision := bd.MakeDivision(app, "conn", int32(lobbyID))
		_, _, _, rpcPort, err := lr.QueryEndpoint(app, "conn", connDivision)
		if err != nil {
			log.Error().Msgf("conn id=%s query failed: %s", id, err.Error())
			return false
		} else {
			ip := "127.0.0.1"
			connAddr = fmt.Sprintf("%s:%d", ip, rpcPort)
			log.Info().Msgf("conn id=%s ip=%s rpc_port=%d addr=%s", id, ip, rpcPort, connAddr)
		}
	}

	// 有conn进程，连接上去，如果连接失败，也要直接退出
	conn, err := net.Dial("tcp", connAddr)
	if err != nil {
		log.Error().Msgf("connect to conn=%s failed: %s", connAddr, err.Error())
		return false
	}

	// 尝试连接数据库，创建连接池，如果失败也要直接退出
	dbstr := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8", config.Mysql.Username, config.Mysql.Password, config.Mysql.Ep.Ip, config.Mysql.Ep.Port, config.Mysql.Database)
	log.Debug().Msgf("mysql connstr=%s", dbstr)
	dbPool, err = sql.Open("mysql", dbstr)
	if err != nil {
		log.Error().Msgf("connect to mysql failed: %s", err.Error())
		return false
	}
	dbPool.SetMaxOpenConns(10)
	dbPool.SetMaxIdleConns(5)
	dbPool.SetConnMaxLifetime(time.Duration(30) * time.Minute)

	for i := 0; i < 5; i++ {
		if err = dbPool.Ping(); err != nil {
			log.Error().Msgf("ping to mysql failed: %s", err.Error())
			return false
		}
	}

	// 初始化共享内存
	dbCache = NewDbCache(uint64(lobbyID), config.Shmpool.DataSize, config.Shmpool.DataCount)
	if dbCache == nil {
		log.Error().Msg("new dbcache failed")
		return false
	}

	if isResume {
		if dbCache.Resume() {
			log.Info().Msg("dbcache resume ok")
		} else {
			log.Error().Msg("dbcache resume from shm failed")
			return false
		}
	} else {
		dbCache.Start()
		log.Info().Msg("dbcache start ok")
	}

	// 开启主协程，它负责玩家登录统筹、数据存盘以及conn过来的包转发
	ch := make(chan string)
	go startBusiness(lobbyID, config, conn, ch)

	select {
	case s, _ := <-ch:
		if s == "ready" {
			log.Info().Msg("lobby business is ready now")
			break
		} else {
			log.Error().Msgf("lobby business send %s", s)
			log.Info().Msg("admin should exit by business exit or error")
			return false
		}
	}

	// 绑定admin端口，以web形式提供admin服务
	go func() {
		adminAddr := config.Admin.Ip + ":" + config.Admin.Port
		log.Info().Msgf("bind admin addr=%s", adminAddr)
		http.HandleFunc("/admin", adminWebHandler)
		admin := &http.Server{Addr: adminAddr, Handler: nil}
		err = admin.ListenAndServe()
		if err != nil {
			panic(fmt.Sprintf("admin listen failed: %s", err.Error()))
		}
	}()

	<-ch

	return true
}
