package main

import (
	"encoding/json"
	//"errors"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	pd "lobby/playerDef"
	"net"
	"net/http"
	lr "shared/mfxlocalregistry"
	lu "shared/mfxlogutil"
	"shared/proto/server/lobby"
	"strconv"
)

// Web 服务

type adminRet struct {
	AccountID uint64
	Data      interface{}
	Result    error
}

type adminEnum uint32

const (
	_ adminEnum = iota
	adminAddGoods
	adminShowPlayerData
)

type adminCmd struct {
	AccountID uint64
	AdminEnum adminEnum
	OpType    uint32
	Param1    uint32
	Param2    uint64
	SigRet    chan *pd.AdminRet
}

type adminWebRsp struct {
	Result uint   `json:"result"`
	Error  string `json:"error"`
	Msg    string `json:"msg"`
}

func adminWebHandler(w http.ResponseWriter, r *http.Request) {
	var result adminWebRsp

	rip := r.Header.Get("X-Forwarded-For")
	if rip == "" {
		rip, _, _ = net.SplitHostPort(r.RemoteAddr)
	}
	if lr.IsRemoteAdminIPAllowed(rip) == false {
		result.Result = 1
		result.Error = "access denied"
		log.Info().Msgf("access denied, remote admin ip: %s", rip)
		return
	}

	r.ParseForm()
	log.Debug().Msgf("http request form: %v", r.Form)
	op := r.FormValue("op")
	switch op {
	case "":
		result.Result = 1
		result.Error = "invalid operation"
	case "log":
		newLevel := lu.SetupLogLevel(r.FormValue("level"))
		log.Info().Msgf("log level set to %s", newLevel)
		result.Result = 0
		result.Error = ""
	case "addgoods":
		a, _ := strconv.ParseInt(r.FormValue("goods_type"), 10, 32)
		b, _ := strconv.ParseInt(r.FormValue("goods_count"), 10, 64)
		c, _ := strconv.ParseInt(r.FormValue("account_id"), 10, 64)
		goodsType := uint32(a)
		goodsCount := uint64(b)
		accountID := uint64(c)
		log.Debug().Msgf("account=%d add goods: type=%d count=%d", accountID, goodsType, goodsCount)
		ch := make(chan *pd.AdminRet, 1)
		sigAdmin <- &adminCmd{
			AccountID: accountID,
			AdminEnum: adminAddGoods,
			OpType:    uint32(lobby.PlayerDataOpEnum_ADD_GOODS),
			Param1:    goodsType,
			Param2:    goodsCount,
			SigRet:    ch,
		}
		ret := <-ch
		if ret.Result == nil {
			result.Result = 0
			result.Error = ""
		} else {
			result.Result = 1
			result.Error = ret.Result.Error()
		}
	case "see_acc":
		a, _ := strconv.ParseUint(r.FormValue("acc_id"), 10, 64)
		accountID := uint64(a)
		ch := make(chan *pd.AdminRet, 1)
		sigAdmin <- &adminCmd{
			AccountID: accountID,
			AdminEnum: adminShowPlayerData,
			//OpType:    uint32(lobby.PlayerDataOpEnum_SEE_ACCOUNT),
			SigRet: ch,
		}
		ret := <-ch
		if ret.Result == nil {
			account := lobby.DbPlayerData{}
			err := proto.Unmarshal(ret.Data.([]byte), &account)
			if err != nil {
				result.Result = 1
				result.Error = err.Error()
				return
			}
			result.Result = 0
			data, err := json.Marshal(account)
			if err != nil {
				result.Result = 1
				result.Error = err.Error()
				return
			}
			result.Msg = string(data)
			result.Error = ""
		} else {
			result.Result = 1
			result.Error = ret.Result.Error()
		}
		log.Debug().Msgf("accountID=%d", accountID)
	default:
		result.Result = 1
		result.Error = "invalid operation"
	}

	w.Header().Add("Access-Control-Allow-Origin", "*")
	rsp, _ := json.Marshal(result)
	w.Write(rsp)
}

// 暗邮箱执行协程

func shadowMailRoutine(c *adminCmd) {
	log.Debug().Msgf("account=%d shadow mail routine begin", c.AccountID)
	defer func() {
		log.Debug().Msgf("account=%d shadow mail routine end", c.AccountID)
	}()

	opType := lobby.PlayerDataOpEnum(c.OpType)
	switch opType {
	case lobby.PlayerDataOpEnum_ADD_GOODS:
		log.Debug().Msgf("account=%d add goods %v", c.AccountID, c)
		// TODO 加上accountID的检查
		// TODO 加上goodsType的检查
		// TODO 加上goodsCount的检查
		op := pd.NewOP()
		op.JoinAddGoods(c.Param1, uint32(c.Param2))
		msg := op.ToDbProto()
		ret := &pd.AdminRet{AccountID: c.AccountID, Result: nil}
		if bin1, err := proto.Marshal(msg); err == nil {
			trx, _ := dbPool.Begin()
			trx.Exec("INSERT INTO shadow_mailbox (account_id, binary1) VALUES (?, ?)", c.AccountID, bin1)
			if err := trx.Commit(); err != nil {
				log.Error().Msgf("account=%d save shadow mail failed: %s", c.AccountID, err.Error())
				ret.Result = err
			} else {
				log.Debug().Msgf("account=%d save shadow mail ok", c.AccountID)
			}
		} else {
			log.Error().Msgf("account=%d save shadow mail marshal failed: %s", c.AccountID, err.Error())
			ret.Result = err
		}
		c.SigRet <- ret
	}
}
