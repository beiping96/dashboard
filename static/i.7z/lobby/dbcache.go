package main

import (
	"container/list"
	"github.com/rs/zerolog/log"
	su "shared/mfxshmutil"
)

// dbcache 使用共享内存作为玩家数据的存储方式
// 为了加速索引，额外使用一个map来映射accountID和共享内存槽位
// 为了加速申请，额外使用一个list来保存当前空闲的内存槽位

type DbCache struct {
	shmChunk      *su.ShmChunk
	account2Index map[uint64]int32
	freeList      *list.List
	dataSize      uint32
	dataCount     uint32
}

func NewDbCache(key uint64, dataSize, dataCount uint32) *DbCache {
	sc, err := su.NewShmChunk(key, dataSize, dataCount)
	if err != nil {
		log.Error().Msgf("dbcache create failed: %s", err.Error())
		return nil
	}
	err = sc.Attach()
	if err != nil {
		log.Error().Msgf("dbcache attach shm failed: %s", err.Error())
		return nil
	}
	log.Info().Msgf("dbcache attach shm ok")
	return &DbCache{
		shmChunk:      sc,
		account2Index: make(map[uint64]int32, dataCount),
		freeList:      list.New(),
		dataSize:      dataSize,
		dataCount:     dataCount,
	}
}

func (dc *DbCache) Start() {
	dc.shmChunk.Start(dc.dataSize, dc.dataCount, func(index int32, prefix *su.ShmUnitPrefix) {
		dc.freeList.PushBack(index)
	})
	log.Debug().Msgf("freelist lenght=%d", dc.freeList.Len())
}

func (dc *DbCache) Resume() bool {
	err := dc.shmChunk.Resume(func(index int32, prefix *su.ShmUnitPrefix) {
		if prefix.UnitInUse == 0 {
			dc.freeList.PushBack(index)
		} else {
			log.Debug().Msgf("account=%d cached in index=%d length=%d", prefix.UserData, index, prefix.DataLen)
			dc.account2Index[prefix.UserData] = index
		}
	})
	if err != nil {
		log.Error().Msgf("dbcache resume from shm failed: %s", err.Error())
		return false
	} else {
		log.Info().Msg("dbcache resume from shm ok")
		log.Info().Msgf("account data cache count=%d", len(dc.account2Index))
		log.Debug().Msgf("freelist lenght=%d", dc.freeList.Len())
		return true
	}
}

func (dc *DbCache) Find(accountID uint64) bool {
	_, ok := dc.account2Index[accountID]
	return ok
}

func (dc *DbCache) Load(accountID uint64) ([]byte, bool) {
	index, ok := dc.account2Index[accountID]
	if ok {
		_, data, err := dc.shmChunk.Load(index)
		if err != nil {
			log.Error().Msgf("dbcache load account=%d from index=%d failed: %s", accountID, index, err.Error())
			return nil, false
		} else {
			log.Debug().Msgf("dbcache load account=%d from index=%d ok", accountID, index)
			return data, true
		}
	} else {
		return nil, false
	}
}

func (dc *DbCache) Save(accountID uint64, data []byte) bool {
	// 检查data的长度是否已经超过了pool定义的最大长度
	// 如果超过了，则需要将这个账号的数据从cache中删掉
	// 让这个账号直接使用mysql来进行存取
	index, ok := dc.account2Index[accountID]
	dataLen := uint32(len(data))
	if dataLen > dc.dataSize {
		log.Error().Msgf("account=%d data len=%d above max=%d, delete from cache", accountID, dataLen, dc.dataSize)
		if ok {
			// 需要将这个账号从cache中删掉，因为cache无法保证账号数据的一致性
			dc.shmChunk.Free(index)
			delete(dc.account2Index, accountID)
		}
		return false
	}

	// 已经有槽位，直接存储即可
	if ok {
		err := dc.shmChunk.Save(index, accountID, data)
		if err != nil {
			log.Error().Msgf("dbcache save account=%d to index=%d failed: %s", accountID, index, err.Error())
			return false
		} else {
			log.Debug().Msgf("dbcache save account=%d to index=%d ok", accountID, index)
			return true
		}
	}

	// 从freelist中找一个空闲的槽位
	count := dc.freeList.Len()
	if count <= 0 {
		log.Info().Msg("dbcache has no shm unit to use, pool is full")
		return false
	}

	e := dc.freeList.Front()
	index = e.Value.(int32)
	dc.freeList.Remove(e)

	// 锁定这个空闲槽位，并将数据存进去
	if !dc.shmChunk.Lock(index) {
		log.Error().Msgf("dbcache error: index=%d in freelist, but unit is in use", index)
		return false
	}

	if err := dc.shmChunk.Save(index, accountID, data); err == nil {
		dc.account2Index[accountID] = index
		log.Debug().Msgf("dbcache save account=%d to index=%d ok", accountID, index)
		return true
	} else {
		return false
	}
}
