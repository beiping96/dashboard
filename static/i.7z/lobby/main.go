package main

import (
	"fmt"
	"os"
)

func printHelp() {
	fmt.Println("Exiled Card lobby help")
}

func main() {
	if len(os.Args) < 2 {
		printHelp()
		return
	}

	switch os.Args[1] {
	case "start":
		if len(os.Args) < 3 {
			printHelp()
			return
		}
		isResume := false
		r := start(os.Args[2], isResume)
		if !r {
			fmt.Printf("start failed, find the error in log")
			return
		}
	case "resume":
		if len(os.Args) < 3 {
			printHelp()
			return
		}
		isResume := true
		r := start(os.Args[2], isResume)
		if !r {
			fmt.Printf("resume failed, find the error in log")
			return
		}
	default:
		printHelp()
	}
}
