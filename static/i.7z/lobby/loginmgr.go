package main

import (
	"container/list"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	pd "lobby/playerDef"
	"shared/csv"
	cd "shared/mfxconn"
	portal "shared/proto/client/portal"
	db "shared/proto/server/lobby"
	cmd "shared/proto/share/command"
	"strconv"
)

// 登录事务过程

type loginCmd struct {
	AccountID  uint64
	SessionID  uint64
	Result     int32
	PlayerData *pd.PlayerData
}

type LoginMgr struct {
	Account2Queue map[uint64]uint64
}

type ShadowMail struct {
	MailID uint64
	Data   []byte
}

func NewLoginMgr() *LoginMgr {
	return &LoginMgr{
		Account2Queue: make(map[uint64]uint64, 3000),
	}
}

func (lm *LoginMgr) IsInLoginState(accountID uint64) bool {
	_, ok := lm.Account2Queue[accountID]
	return ok
}

func (lm *LoginMgr) NewLoginTrans(sessionID, accountID uint64, accountData []byte, ch chan *loginCmd) bool {
	_, ok := lm.Account2Queue[accountID]
	if ok {
		return true
	} else {
		lm.Account2Queue[accountID] = sessionID
		go loginRoutine(sessionID, accountID, accountData, ch)
		return true
	}
}

func (lm *LoginMgr) DelLoginTrans(accountID uint64) {
	delete(lm.Account2Queue, accountID)
}

func loadAccountFromDb(accountID uint64) ([]byte, bool, error) {
	log.Debug().Msgf("account=%d load from db begin", accountID)
	defer func() {
		log.Debug().Msgf("account=%d load from db end", accountID)
	}()

	str := fmt.Sprintf("SELECT binary1 FROM actor WHERE actor_id=%d", accountID)
	if rows, err := dbPool.Query(str); err != nil {
		log.Error().Msgf("account=%d load from db failed: %s", accountID, err.Error())
		return nil, false, err
	} else {
		defer rows.Close()
		for rows.Next() {
			var data []byte
			if err = rows.Scan(&data); err != nil {
				return nil, false, err
			} else {
				return data, true, nil
			}
		}
		return nil, false, nil
	}
}

func loadAccountShadowMailboxFromDb(accountID uint64) (*list.List, error) {
	log.Debug().Msgf("account=%d load shadow mailbox from db begin", accountID)
	defer func() {
		log.Debug().Msgf("account=%d load shadow mailbox from db end", accountID)
	}()

	str := fmt.Sprintf("SELECT mail_id, binary1 FROM shadow_mailbox WHERE account_id=%d ORDER BY mail_id", accountID)
	if rows, err := dbPool.Query(str); err != nil {
		return nil, err
	} else {
		defer rows.Close()
		l := list.New()
		for rows.Next() {
			var mailID uint64
			var data []byte
			if err := rows.Scan(&mailID, &data); err == nil {
				l.PushBack(&ShadowMail{MailID: mailID, Data: data})
			}
		}
		return l, nil
	}
}

func applyAccountShadowMailbox(playerData *pd.PlayerData, mails *list.List) {
	accountID := pd.PlayerID2AccountID(playerData.GetPlayerID())
	log.Debug().Msgf("account=%d merge data with shadow mailbox, mail count=%d", accountID, mails.Len())
	for e := mails.Front(); e != nil; e = e.Next() {
		c, ok := e.Value.(*ShadowMail)
		log.Debug().Msgf("cont=%v status:%v", c, ok)
		if !ok {
			log.Error().Msgf("account=%d mail=%d reflect failed", accountID, c.MailID)
			continue
		}
		var msg db.DbShadowMail
		if err := proto.Unmarshal(c.Data, &msg); err != nil {
			log.Error().Msgf("account=%d mail=%d unmarshal failed: %s", accountID, c.MailID, err.Error())
			continue
		}
		// 合并暗邮箱数据到玩家身上
		op := pd.OpFromDbProto(&msg)
		log.Debug().Msgf("account=%d mail=%d merge op=%v", accountID, c.MailID, op)
		if err := playerData.OpExec(op); err == nil {
			// 从数据库中删掉这封mail
			str := fmt.Sprintf("DELETE FROM shadow_mailbox WHERE account_id=%d AND mail_id=%d", accountID, c.MailID)
			dbPool.Exec(str)
		}
	}
}

func saveAccountToDb(playerData *pd.PlayerData) error {
	data, _ := playerData.ToDbPb()
	accountID := pd.PlayerID2AccountID(playerData.GetPlayerID())
	log.Debug().Msgf("account=%d save to db begin, length=%d", accountID, len(data))

	// 下面actor的概念等同于account
	trx, _ := dbPool.Begin()
	trx.Exec("DELETE FROM actor WHERE actor_id=?", accountID)
	trx.Exec("INSERT INTO actor (actor_id, name, level, exp, icon, binary1) VALUES (?, ?, ?, ?, ?, ?)", accountID, playerData.GetPlayerName(), playerData.GetPlayerLevel(), playerData.GetPlayerExp(), playerData.GetPlayerIcon(), data)
	if err := trx.Commit(); err != nil {
		log.Error().Msgf("account=%d save to db failed: %s", accountID, err.Error())
		return err
	} else {
		log.Debug().Msgf("account=%d save to db ok", accountID)
		return nil
	}
}

func loginRoutine(sessionID, accountID uint64, accountData []byte, ch chan *loginCmd) {
	log.Debug().Msgf("login trans begin: account=%d session=%d", accountID, sessionID)
	defer func() {
		log.Debug().Msgf("login trans end: account=%d session=%d", accountID, sessionID)
	}()

	if accountData != nil {
		verifyToken(accountID, "abc")

		playerData := &pd.PlayerData{}
		if err := pd.ToPlayerData(accountData, playerData, globalLobbyID); err != nil {
			log.Error().Msgf("account=%d in cache unmarshal failed: %s", accountID, err.Error())
			ch <- &loginCmd{
				AccountID:  accountID,
				SessionID:  sessionID,
				Result:     csv.ERRCODE_SYS_INTERNAL_ERROR,
				PlayerData: nil,
			}
		} else {
			if mails, err := loadAccountShadowMailboxFromDb(accountID); err == nil {
				applyAccountShadowMailbox(playerData, mails)
			}
			ch <- &loginCmd{
				AccountID:  accountID,
				SessionID:  sessionID,
				Result:     csv.ERRCODE_SUCCESS,
				PlayerData: playerData,
			}
		}
		return
	}

	verifyToken(accountID, "abc")

	// 先检查是否存在这个账号的数据，在mysql中
	data, exist, err := loadAccountFromDb(accountID)
	if err != nil {
		log.Error().Msgf("account=%d load from db failed: %s", accountID, err.Error())
		ch <- &loginCmd{
			AccountID: accountID,
			SessionID: sessionID,
			Result:    csv.ERRCODE_SYS_INTERNAL_ERROR,
		}
		return
	}

	if exist {
		// 存在，直接把data给丢出去即可
		log.Debug().Msgf("account=%d data exist in db", accountID)
		playerData := &pd.PlayerData{}
		if err := pd.ToPlayerData(data, playerData, globalLobbyID); err != nil {
			log.Error().Msgf("account=%d login unmarshal failed: %s", accountID, err.Error())
			ch <- &loginCmd{
				AccountID:  accountID,
				SessionID:  sessionID,
				Result:     csv.ERRCODE_SYS_INTERNAL_ERROR,
				PlayerData: nil,
			}
		} else {
			if mails, err := loadAccountShadowMailboxFromDb(accountID); err == nil {
				applyAccountShadowMailbox(playerData, mails)
			}
			ch <- &loginCmd{
				AccountID:  accountID,
				SessionID:  sessionID,
				Result:     csv.ERRCODE_SUCCESS,
				PlayerData: playerData,
			}
		}
	} else {
		// 不存在，需要创角
		log.Debug().Msgf("account=%d data not exist in db, need new", accountID)
		name := fmt.Sprintf("%d", accountID)
		playerData := pd.NewPlayer(pd.AccountID2PlayerID(accountID), name, int32(1), globalLobbyID)

		// 存入DB
		saveAccountToDb(playerData)

		ch <- &loginCmd{
			AccountID:  accountID,
			SessionID:  sessionID,
			Result:     csv.ERRCODE_SUCCESS,
			PlayerData: playerData,
		}
	}
}

func verifyToken(accountID uint64, token string) bool {
	// TODO 实现token验证
	return true
}

func parseLoginReq(body []byte) (accountID uint64, token string, err error) {
	var req portal.LobbyLoginReq
	err = proto.Unmarshal(body, &req)
	if err != nil {
		return
	}
	accountID, err = strconv.ParseUint(req.GetAccount(), 0, 64)
	if err != nil {
		return
	}
	token = req.GetToken()
	return
}

func makeLoginRsp(sessionID uint64, result int32, playerData *pd.PlayerData) []byte {
	rsp := &portal.LobbyLoginRsp{}
	if playerData == nil {
		rsp.Result = &result
	} else {
		rsp.Result = &result
		rsp.Player = playerData.ToClientProto()
	}
	body, err := proto.Marshal(rsp)
	if err != nil {
		log.Error().Msgf("login rsp marshal error: %s", err.Error())
		return nil
	}
	sessions := make([]uint64, 1)
	sessions[0] = sessionID
	return cd.MakeSessionPkt(sessions, uint16(cmd.CLIENT_RSP_CMD_LOBBY_LOGIN_RSP), 0, 0, body)
}

func makeKickPkt(sessionID uint64) []byte {
	sessions := make([]uint64, 1)
	sessions[0] = sessionID
	return cd.MakeSessionPkt(sessions, uint16(cd.CmdSessionKick), 0, 0, nil)
}
