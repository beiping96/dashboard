package main

import (
	"os"
	"os/signal"
	"syscall"
)

func signalNotify(c chan<- os.Signal) {
	signal.Notify(c, syscall.SIGINT, syscall.SIGTERM,
		syscall.SIGABRT, syscall.SIGSEGV, syscall.SIGUSR1)
}

func isSigUsr1(sig os.Signal) bool {
	if sig == syscall.SIGUSR1 {
		return true
	}
	return false
}
