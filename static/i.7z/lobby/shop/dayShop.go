package shop

import (
	"errors"
	"lobby/backpackDef"
	"math/rand"
	cardD "shared/cardDef"
	"shared/csv"
	pp "shared/proto/client/portal"
	db "shared/proto/server/lobby"
	"shared/table"
	"time"
	"github.com/rs/zerolog/log"
)

type DayShop struct {
	goodsList           map[uint32]*Goods
	timeZero            uint64
	weekdayGoodsGroupID uint32
	sundayGoodsGroupID  uint32
	legendCardNum       uint32
}

type Goods struct {
	goodsSortId     uint32
	goodsType       uint32
	cardPieceNum    uint32
	convertType     uint32
	price           uint32
	limitNum        uint32
	cardTypeID      uint32
	cardStar        uint32
	cardPieceSumNum uint32
}

func DayShopFromDbProto(dayShop *db.DbPlayerDayShop) *DayShop {
	var shop DayShop
	goodslist := make(map[uint32]*Goods, 6)
	shop.timeZero = dayShop.GetTimeZero()
	shop.weekdayGoodsGroupID = dayShop.GetWeekdayGoodsGroupID()
	shop.sundayGoodsGroupID = dayShop.GetSundayGoodsGroupID()
	shop.legendCardNum = dayShop.GetLegendCardNum()
	goodsList := dayShop.GetGoodsList()
	for k, good := range goodsList {
		goods := Goods{}
		goodsInfo := good
		goods.goodsSortId = goodsInfo.GetGoodsSortId()
		goods.goodsType = goodsInfo.GetGoodsTypeID()
		goods.cardPieceNum = goodsInfo.GetGoodsNum()
		goods.convertType = goodsInfo.GetConvertType()
		goods.price = goodsInfo.GetPrice()
		goods.limitNum = goodsInfo.GetLimitNum()
		goods.cardPieceSumNum = goodsInfo.GetCardPieceSumNum()
		goods.cardTypeID = goodsInfo.GetCardTypeID()
		goods.cardStar = goodsInfo.GetCardStar()
		goodslist[uint32(k)] = &goods
	}
	shop.goodsList = goodslist
	return &shop
}

func (dayShop *DayShop) ToDbProto() *db.DbPlayerDayShop {
	ans := db.DbPlayerDayShop{}
	ans.TimeZero = uint64(dayShop.timeZero)
	for _, goods := range dayShop.goodsList {
		ansOne := db.DbPlayerDayShopGoods{}
		good := goods
		ansOne.GoodsTypeID = good.goodsType
		ansOne.GoodsNum = good.cardPieceNum
		ansOne.ConvertType = good.convertType
		ansOne.Price = good.price
		ansOne.LimitNum = good.limitNum
		ansOne.GoodsSortId = good.goodsSortId
		ansOne.CardStar = good.cardStar
		ansOne.CardPieceSumNum = good.cardPieceSumNum
		ansOne.CardTypeID = good.cardTypeID
		ans.GoodsList = append(ans.GoodsList, &ansOne)
	}
	ans.SundayGoodsGroupID = dayShop.sundayGoodsGroupID
	ans.WeekdayGoodsGroupID = dayShop.weekdayGoodsGroupID
	ans.LegendCardNum = dayShop.legendCardNum
	return &ans

}

//新建一个每日商店
func NewDayShop() DayShop {
	return DayShop{
		goodsList:           make(map[uint32]*Goods),
		timeZero:            0,
		weekdayGoodsGroupID: 1,
		sundayGoodsGroupID:  uint32(len(table.GetWeekdayCardShopMap())),
		legendCardNum:       1,
	}
}

//随机生成一个普通或者稀有品质的卡牌碎片ID
func FormCardPieceID(cards []cardD.Card) ([]cardD.Card, uint32, uint32, uint32, error) {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	if len(cards) > 0 {
		randNum := r.Intn(len(cards))
		card := cards[uint32(randNum)]
		cardGrowSortID := uint32(card.GetTypeID())*100 + card.GetCardStarLevel()
		cardGrow := table.GetCardGrowFromCsv(int64(cardGrowSortID))
		if cardGrow == nil {
			log.Error().Msgf("cardGrowSortID %v not exist in cardGrow form",cardGrowSortID)
			return nil, 0, 0, 0, errors.New("plan config not exist")
		}
		pieceID := cardGrow.CardPropID
		goodTypeID := uint32(pieceID)
		// 3.将这个卡牌从数组中删除
		cards = append(cards[:randNum], cards[randNum+1:]...)
		return cards, goodTypeID, uint32(card.GetTypeID()), card.GetCardStarLevel(), nil
	}
	return nil, 0, 0, 0, errors.New("plan config not exist")
}

//从传奇卡牌碎片配表中获取一个卡牌碎片ID
func FormLegendCardPieceID(cards []cardD.Card, legendCardNum uint32) (uint32, uint32, bool, error) {
	cardInfo, ok := csv.TableCardLegendQualityMap[int64(legendCardNum)]
	if !ok {
		log.Error().Msgf("legendCardNum %v not in TableCardLegendQualityMap",legendCardNum)
		return 0, 0, false, errors.New("plan config not exist")
	}
	//玩家卡池中有传奇品质的卡牌
	for _, card := range cards {
		if int(card.GetTypeID()) == cardInfo.CardGroupID {
			id := uint32(card.GetTypeID())*100 + card.GetCardStarLevel()
			cardGrow := table.GetCardGrowFromCsv(int64(id))
			if cardGrow == nil {
				log.Error().Msgf("cardGrow %v not in CardGrow",id)
				return 0, 0, false, errors.New("plan config not exist")
			}
			pieceID := cardGrow.CardPropID
			legendCardNum++
			return uint32(pieceID), legendCardNum, true, nil
		}
	}
	return 0, 0, false, nil
}

//将卡牌按品质分类
func SortCardsByQuality(cards map[cardD.TypeID]*cardD.Card) ([]cardD.Card, []cardD.Card, []cardD.Card, error) {
	var commonCardsArry []cardD.Card
	var rareCardsArry []cardD.Card
	var legendCardsArry []cardD.Card
	for typeId, card := range cards {
		sortID := uint32(typeId)*10 + card.GetCardStarLevel()
		cardOne, ok := csv.TableCardsMap[int64(sortID)]
		if !ok {
			log.Error().Msgf("sortID %v card config not exist",sortID)
			return nil, nil, nil, errors.New("card config not exist")
		}
		quality := cardOne.Rarity
		if quality == csv.CARD_QUALITY_NORMAL {
			commonCardsArry = append(commonCardsArry, *card)
		} else if quality == csv.CARD_QUALITY_RARE {
			rareCardsArry = append(rareCardsArry, *card)
		} else if quality == csv.CARD_QUALITY_LEGEND {
			legendCardsArry = append(legendCardsArry, *card)
		} else {
			log.Error().Msgf("sortID %v card quality config error",sortID)
			return nil, nil, nil, errors.New("card quality config error")
		}
	}
	return commonCardsArry, rareCardsArry, legendCardsArry, nil
}

//根据索引ID返回每日商店商品组货物索引
func GetCardShopProductByID(cardShop *csv.TableCardShop, ID int) int {
	switch ID {
	case 1:
		return cardShop.Product1
	case 2:
		return cardShop.Product2
	case 3:
		return cardShop.Product3
	case 4:
		return cardShop.Product4
	case 5:
		return cardShop.Product5
	case 6:
		return cardShop.Product6
	case 7:
		return cardShop.SubProduct1
	case 8:
		return cardShop.SubProduct2
	case 9:
		return cardShop.SubProduct3
	default:
		return 0
	}
}

//获取本地当前时间0点时间戳
func GetTimeZreo() int64 {
	timeNow := time.Now()
	unixTimeZero := time.Date(timeNow.Year(), timeNow.Month(), timeNow.Day(), 0, 0, 0, 0, timeNow.Location()).Unix()
	return unixTimeZero
}

//根据每日商店参数生成新的每日商店
func (dayShop *DayShop) FormDayShop(cards map[cardD.TypeID]*cardD.Card, backpack *backpackDef.Backpack) error {
	goodsGroupID := uint32(1)
	lastTimeZero := uint64(GetTimeZreo())
	whichDay := time.Now().Weekday()
	goodsList := make(map[uint32]*Goods)
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	if dayShop.timeZero == 0 {
		if whichDay == 7 {
			goodsGroupID = uint32(r.Intn(len(table.GetWeekendCardShopMap())) + 1 + len(table.GetWeekdayCardShopMap()))
			dayShop.sundayGoodsGroupID = goodsGroupID
		} else {
			goodsGroupID = uint32(r.Intn(len(table.GetWeekdayCardShopMap())) + 1)
			dayShop.weekdayGoodsGroupID = goodsGroupID
		}
	} else {
		if lastTimeZero == dayShop.timeZero {
			//同一天，直接返回玩家身上的每日商店数据
			return nil
		}
		if whichDay == 7 {
			goodsGroupID = dayShop.sundayGoodsGroupID
			if goodsGroupID == uint32(len(table.GetWeekdayCardShopMap())+len(table.GetWeekendCardShopMap())) {
				goodsGroupID = uint32(len(table.GetWeekdayCardShopMap()) + 1)
			} else {
				goodsGroupID++
			}
			dayShop.sundayGoodsGroupID = goodsGroupID
		} else {
			goodsGroupID = dayShop.weekdayGoodsGroupID
			if goodsGroupID == uint32(len(table.GetWeekdayCardShopMap())) {
				goodsGroupID = 1
			} else {
				goodsGroupID++
			}
			dayShop.weekdayGoodsGroupID = goodsGroupID
		}
	}
	normal, rare, legend, err := SortCardsByQuality(cards)
	if err != nil {
		return err
	}
	//从对应ID商品组中确定商品属性
	cardShop, ok := csv.TableCardShopMap[int64(goodsGroupID)]
	if !ok {
		log.Error().Msgf("goodsGroupID %v cardShop not exist",goodsGroupID)
		return errors.New("cardShop not exist")
	}
	//生成6个商品
	for i := 0; i < 6; i++ {
		//获取商品组中单个商品的索引ID
		cardGoodsID := GetCardShopProductByID(cardShop, i+1)
		if cardGoodsID == 0 {
			log.Error().Msgf("product %v cardShop not exist",i+1)
			return errors.New("product config not exist")
		}
		//根据索引ID获取对应的商品属性
		cardGoods, ok := csv.TableCardGoodsMap[int64(cardGoodsID)]
		if !ok {
			log.Error().Msgf("cardShop product sortID %v not exist",cardGoodsID)
			return errors.New("product sortID config not exist")
		}
		//获取商品的品质
		goodTypeID := uint32(0)
		cardTypeID := uint32(0)
		cardStar := uint32(0)
		goodsType := cardGoods.CommodityType
		if goodsType == csv.COMMODITY_TYPE_CARD {
			if cardGoods.ConvertNum == 0 {
				goodTypeID = 3
			} else {
				goodType := cardGoods.Type
				//根据品质随机生成对应的物品ID
				if goodType == csv.CARD_QUALITY_NORMAL {
					temcards, cardPieceID, cardtypeID, cardstar, err := FormCardPieceID(normal)
					if err != nil {
						log.Error().Msgf("normal %v error",normal)
						return errors.New("plan config not exist")
					}
					normal = temcards
					goodTypeID = cardPieceID
					cardTypeID = cardtypeID
					cardStar = cardstar
				} else if goodType == csv.CARD_QUALITY_RARE {
					temcards, cardPieceID, cardtypeID, cardstar, err := FormCardPieceID(rare)
					if err != nil {
						log.Error().Msgf("rare %v error",rare)
						return errors.New("plan config not exist")
					}
					rare = temcards
					goodTypeID = cardPieceID
					cardTypeID = cardtypeID
					cardStar = cardstar
				} else if goodType == csv.CARD_QUALITY_LEGEND {
					cardPieceID, legendNum, ok, err := FormLegendCardPieceID(legend, dayShop.legendCardNum)
					if err != nil {
						log.Error().Msgf("legend %v card piece find error",dayShop.legendCardNum)
						return errors.New("plan config not exist")
					}
					if ok {
						goodTypeID = cardPieceID
						legendNum++
						dayShop.legendCardNum = legendNum
					} else {
						randGoodsID := r.Intn(3) + 7
						cardGoodsID = GetCardShopProductByID(cardShop, randGoodsID)
						if cardGoodsID == 0 {
							log.Error().Msgf("legend product %v error",randGoodsID)
							return errors.New("plan config not exist")
						}
						cardGoods, ok = csv.TableCardGoodsMap[int64(cardGoodsID)]
						if !ok {
							log.Error().Msgf("legend cardGoodsID %v error",cardGoodsID)
							return errors.New("plan config not exist")
						}
						temcards, cardPieceID, cardtypeID, cardstar, err := FormCardPieceID(rare)
						if err != nil {
							log.Error().Msgf("legend rare %v error",rare)
							return errors.New("plan config not exist")
						}
						rare = temcards
						goodTypeID = cardPieceID
						cardTypeID = cardtypeID
						cardStar = cardstar
					}
				} else {
					return errors.New("plan config not exist")
				}
			}

		} else if goodsType == csv.COMMODITY_TYPE_FREE_GOLD {
			goodTypeID = csv.GOLDTYPE_TYPE_GOLD
		} else {
			log.Error().Msgf("goodsType %v error",goodsType)
			return errors.New("plan config not exist")
		}
		cardPieceSumNum := backpack.GetGoodsNum(goodTypeID)
		goodsList[uint32(i)] = &Goods{
			goodsSortId:     uint32(cardGoodsID),
			goodsType:       goodTypeID,
			cardTypeID:      cardTypeID,
			cardStar:        cardStar,
			cardPieceSumNum: cardPieceSumNum,
			cardPieceNum:    uint32(cardGoods.Number),
			convertType:     uint32(cardGoods.ConvertType),
			price:           uint32(cardGoods.ConvertNum),
			limitNum:        0,
		}
	}
	dayShop.goodsList = goodsList
	dayShop.timeZero = lastTimeZero
	return nil
}

func (dayShop *DayShop) ToClientProto() *pp.DayshopGoodsInfo {
	dayshop := pp.DayshopGoodsInfo{}
	zerotime := dayShop.timeZero + 86400
	dayshop.Zerotime = &zerotime
	dayShopGoods := make([]*pp.DayshopGoods, 6)
	for i, goods := range dayShop.goodsList {
		index := i
		good := goods
		goodsOne := pp.DayshopGoods{}
		goodsOne.Index = &index
		goodsOne.GoodsSortId = &good.goodsSortId
		goodsOne.GoodsTypeId = &good.goodsType
		goodsOne.GoodsLimit = &good.limitNum
		goodsOne.CardGroupId = &good.cardTypeID
		goodsOne.CardStar = &good.cardStar
		goodsOne.CardExp = &good.cardPieceSumNum
		dayShopGoods[i] = &goodsOne
	}
	dayshop.Goods = dayShopGoods
	return &dayshop
}

func (dayShop *DayShop) GetTimeZero() uint64 {
	return dayShop.timeZero
}

func (dayShop *DayShop) GetGoodsList() map[uint32]*Goods {
	return dayShop.goodsList
}

func (goods *Goods) GetGoodsType() uint32 {
	return goods.goodsType
}

func (goods *Goods) GetLimitNum() uint32 {
	return goods.limitNum
}

func (goods *Goods) AddLimitNum(reduceNum uint32) {
	goods.limitNum += reduceNum

}

func (goods *Goods) GetGoodsSortId() uint32 {
	return goods.goodsSortId
}

func (goods *Goods) GetGoodsCardPieceNum() uint32 {
	return goods.cardPieceNum
}

func (goods *Goods) GetGoodsConvertType() uint32 {
	return goods.convertType
}

func (goods *Goods) GetGoodsPrice() uint32 {
	return goods.price
}

func (goods *Goods) SetcardPieceSumNum(addNum uint32) {
	goods.cardPieceSumNum += addNum
}
