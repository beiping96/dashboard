package shop

import (
	db "shared/proto/server/lobby"
	pp "shared/proto/client/portal"
)

type Shop struct {
	dayShop *DayShop
	cardBag *CardBag
}

func New() *Shop{
	dayShop := NewDayShop()
	cardBag := NewCardBag()
	return &Shop{dayShop: &dayShop,cardBag: &cardBag}
}

func (shop *Shop) GetDayShop() *DayShop {
	return shop.dayShop
}

func (shop *Shop) GetCardBag() *CardBag {
	return shop.cardBag
}

func (shop Shop) ToDbProto() *db.DbPlayerShop {
	shopDb := db.DbPlayerShop{}
	shopDb.DayShop = shop.dayShop.ToDbProto()
	shopDb.Cardbag = shop.cardBag.ToDbProto()
	return &shopDb
}

func FromDbProto(shopDb *db.DbPlayerShop) *Shop {
	var shop Shop
	shop.dayShop = DayShopFromDbProto(shopDb.GetDayShop())
	shop.cardBag = CardBagFromDbProto(shopDb.GetCardbag())
	return &shop
}

func (shop Shop) DayShopToClientProto() *pp.DayshopGoodsInfo {
	return shop.dayShop.ToClientProto()
}

func (shop Shop) CardBagToClientProto() []*pp.CardbagItem {
	return shop.cardBag.ToClientProto()
}


