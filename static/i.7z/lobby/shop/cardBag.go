package shop

import (
	"errors"
	"github.com/rs/zerolog/log"
	"lobby/backpackDef"
	"math/rand"
	cardD "shared/cardDef"
	"shared/csv"
	pp "shared/proto/client/portal"
	db "shared/proto/server/lobby"
	"shared/table"
	"time"
)

//卡包
type CardBag struct {
	moneyCardBag map[uint32]*moneyCardBag //k为卡包ID
}

//氪金卡包
type moneyCardBag struct {
	cardBagId uint32 //礼包ID
	buyNum    uint32 //购买次数
}

//开宝箱商品列表
type CardBagList struct {
	goodsList map[uint32]uint32 //货物列表
}

//概率结构
type PercentAssist struct {
	minPercent uint32
	maxPercent uint32
}

//初始化卡包数据
func NewCardBag() CardBag {
	cardBag := make(map[uint32]*moneyCardBag, len(csv.TableCardBagTraderMap))
	for _, v := range csv.TableCardBagTraderMap {
		meneyCardBag := moneyCardBag{}
		meneyCardBag.cardBagId = uint32(v.ShopPam)
		meneyCardBag.buyNum = 0
		cardBag[uint32(v.ShopPam)] = &meneyCardBag
	}
	return CardBag{moneyCardBag: cardBag}
}

func CardBagFromDbProto(cardShop *db.DbPlayerCardbag) *CardBag {
	cardbag := make(map[uint32]*moneyCardBag)
	for k, v := range cardShop.GetCardbags() {
		cardBag := moneyCardBag{}
		ans := v
		cardBag.cardBagId = ans.GetCardbagTypeID()
		cardBag.buyNum = ans.GetCardbagBugnum()
		cardbag[uint32(k)] = &cardBag
	}
	return &CardBag{cardbag}
}

func (CardBag *CardBag) ToDbProto() *db.DbPlayerCardbag {
	cardbag := db.DbPlayerCardbag{}
	for _, v := range CardBag.moneyCardBag {
		ans := db.DbPlayerMenoryCardbag{}
		cardBag := v
		ans.CardbagTypeID = cardBag.cardBagId
		ans.CardbagBugnum = cardBag.buyNum
		cardbag.Cardbags = append(cardbag.Cardbags, &ans)
	}
	return &cardbag
}

func (CardBag *CardBag) GetBuyNum(cardBagID uint32) (uint32, error) {
	for _, v := range CardBag.moneyCardBag {
		if v.cardBagId == cardBagID {
			return v.buyNum, nil
		}
	}
	return 0, errors.New("cardbag bot exist")
}

func (CardBag *CardBag) SetBuyNum(cardBagID uint32, buyNum uint32) error {
	for _, v := range CardBag.moneyCardBag {
		if v.cardBagId == cardBagID {
			v.buyNum += buyNum
			return nil
		}
	}
	return errors.New("cardbag bot exist")
}

func (CardBag *CardBag) ToClientProto() []*pp.CardbagItem {
	var cardbags []*pp.CardbagItem
	for _, v := range CardBag.moneyCardBag {
		cardBag := pp.CardbagItem{}
		ans := v
		cardBag.TypeId = &ans.cardBagId
		cardBag.LimitNum = &ans.buyNum
		cardbags = append(cardbags, &cardBag)
	}
	return cardbags
}

//开礼包
func OpenCardBag(cardBagId uint32, cards map[cardD.TypeID]*cardD.Card, backpack *backpackDef.Backpack) map[uint32]uint32 {
	goodsList := make(map[uint32]uint32)
	//根据卡包ID获取开卡包规则
	cardBag := table.GetCardBag(cardBagId)
	if cardBag == nil {
		return nil
	}
	//确定货币数量
	resourceType := cardBag.ResourceType
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	resourceNum := r.Intn((cardBag.MaxResource - cardBag.MinResource + 1)) + cardBag.MinResource
	goodsList[uint32(resourceType)] = uint32(resourceNum)
	//确定碎片总数和总堆数
	pieceSum := cardBag.PieceSum
	debrisSum := cardBag.DebrisSum
	//优先级A货物ID和数量
	aDebrisSum, apieceSum := FormGoodsData(uint32(cardBag.GoodsA), uint32(debrisSum), uint32(pieceSum), cards, backpack, goodsList, false)
	pieceSum -= int(apieceSum)
	debrisSum -= int(aDebrisSum)
	//优先级B货物ID和数量
	bDebrisSum, bpieceSum := FormGoodsData(uint32(cardBag.GoodsB), uint32(debrisSum), uint32(pieceSum), cards, backpack, goodsList, false)
	pieceSum -= int(bpieceSum)
	debrisSum -= int(bDebrisSum)
	//优先级C货物ID和数量
	cDebrisSum, cpieceSum := FormGoodsData(uint32(cardBag.GoodsC), uint32(debrisSum), uint32(pieceSum), cards, backpack, goodsList, false)
	pieceSum -= int(cpieceSum)
	debrisSum -= int(cDebrisSum)
	//优先级D货物ID和数量
	FormGoodsData(uint32(cardBag.GoodsD), uint32(debrisSum), uint32(pieceSum), cards, backpack, goodsList, true)
	return goodsList
}

//根据物品索引ID确定货物ID和数量
func FormGoodsData(goodsID uint32, debrisNum uint32, pieceNum uint32, cards map[cardD.TypeID]*cardD.Card, backpack *backpackDef.Backpack, goodsList map[uint32]uint32, flag bool) (uint32, uint32) {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	cardBagDrop := table.GetCardBagDrop(uint32(goodsID))
	//情况一：掉落概率为0，直接跳过
	if cardBagDrop.DropPercent == 0 {
		return 0, 0
	}
	//情况二：根据掉落概率判定是否掉落
	if (r.Intn(10000) + 1) > cardBagDrop.DropPercent {
		return 0, 0
	}
	randDebrisNum := int(debrisNum)
	randPieceNum := int(pieceNum)
	if !flag {
		//随机货物数
		randDebrisNum = r.Intn(cardBagDrop.MaxDebrisNum-cardBagDrop.MinDebrisNum+1) + cardBagDrop.MinDebrisNum
		//随机件数
		randPieceNum = r.Intn(cardBagDrop.MaxPieceNum-cardBagDrop.MinPieceNum+1) + cardBagDrop.MinPieceNum
	}
	//剩余牌数>最大随机牌数
	if debrisNum > uint32(cardBagDrop.MaxDebrisNum) {
		//情况三：剩余件数==1或者0，直接跳过
		if pieceNum <= 1 {
			return 0, 0
		}
		//情况四：随机件数满足<=剩余件数-1
		if uint32(randPieceNum) >= pieceNum {
			randPieceNum = int(pieceNum - 1)
		}
	}
	//情况五：随机掉落牌数<随机掉落件数，件数=牌数
	if randDebrisNum < randPieceNum {
		randPieceNum = randDebrisNum
	}
	//返回货物数量和堆数
	backDebrisNum := uint32(randDebrisNum)
	backPieceNum := uint32(randPieceNum)
	//挑出掉落组数据
	aDropGroup := table.GetCardBagGroup(uint32(cardBagDrop.DropGroup))
	if cardBagDrop.MaxPieceNum > len(aDropGroup) {
		log.Error().Msgf("plan config error")
		return 0, 0
	}
	//算出新的权重表
	lastWeight := make(map[uint32]uint32)
	for _, dropGrop := range aDropGroup {
		dropWeight := dropGrop.Weight0
		//1.确定碎片对应的卡牌的ID
		cardTypeID := table.GetCardTypeIDByPieceID(dropGrop.GoodsID)
		if cardTypeID == 0 {
			log.Error().Msgf("plan config error")
			return 0, 0
		}
		//2.根据卡牌ID确定玩家卡牌星级,计算最新权重
		card, ok := cards[cardD.TypeID(cardTypeID)]
		if ok {
			cardStar := card.GetCardStarLevel()
			if cardStar == 2 {
				dropWeight -= dropGrop.Weight1
			}
			if cardStar == 3 {
				dropWeight -= dropGrop.Weight2
			}
		}
		//3.根据玩家背包中碎片数量计算最新权重
		pieceNum := backpack.GetGoodsNum(uint32(dropGrop.GoodsID))
		dropWeight -= int(pieceNum * uint32(dropGrop.Weight3))
		if dropWeight <= 0 {
			dropWeight = 1
		}
		//4.记录新的权重数据
		lastWeight[uint32(dropGrop.GoodsID)] = uint32(dropWeight)
	}
	//确定货物ID和数量
	for i := 1; i <= randPieceNum; i++ {
		//算出总权重
		sumWeight := uint32(0)
		for _, v := range lastWeight {
			sumWeight += v
		}
		//算出每个碎片的权重范围
		percentList := make(map[uint32]*PercentAssist)
		minNum := uint32(0)
		maxNum := uint32(0)
		for k, v := range lastWeight {
			perAs := PercentAssist{}
			perAs.minPercent = minNum
			perAs.maxPercent = uint32(maxNum) + v
			percentList[k] = &perAs
			minNum = perAs.maxPercent
			maxNum = minNum
		}
		//随机权重
		randWeight := r.Intn(int(sumWeight))
		//根据随机权重确定物品ID
		for k, v := range percentList {
			if uint32(randWeight) >= v.minPercent && uint32(randWeight) < v.maxPercent {
				if i == randPieceNum {
					num := randDebrisNum
					goodsList[k] += uint32(num)
				} else {
					randNum := randDebrisNum - randPieceNum + 1
					if randNum <= 0 {
						randNum = 1
					}
					num := 1 + r.Intn(randNum)
					goodsList[k] += uint32(num)
					randDebrisNum -= num
					delete(lastWeight, k)
				}
			}
		}
	}
	return backDebrisNum, backPieceNum
}

func GetLimitGoodsInfo(sumNum uint32, goodsNum uint32, goodsLimit uint32, convertNum uint32) (uint32, uint32) {
	//获取物品数量
	if goodsLimit <= sumNum {
		//直接转换成古币
		return convertNum * goodsNum, 0
	} else {
		if goodsLimit >= (sumNum + goodsNum) {
			//直接添加
			return 0, goodsNum
		} else {
			//部分转换
			return convertNum * (sumNum + goodsNum - goodsLimit), (goodsLimit - sumNum)
		}
	}
}
