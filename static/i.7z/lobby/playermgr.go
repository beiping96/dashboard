package main

import (
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"lobby/playerCMD"
	pd "lobby/playerDef"
	"lobby/singlePVE"
	cd "shared/mfxconn"
	cp "shared/mfxcoredump"
	db "shared/proto/server/lobby"
	cmd "shared/proto/share/command"
	"time"
)

type playerSession struct {
	AccountID uint64
	Chan      chan *pd.PlayerCmd
}

type PlayerMgr struct {
	// 这两个map需要保证强一致性
	session2Player  map[uint64]*playerSession
	account2Session map[uint64]uint64
}

func NewPlayerMgr() *PlayerMgr {
	return &PlayerMgr{
		session2Player:  make(map[uint64]*playerSession, 3000),
		account2Session: make(map[uint64]uint64, 3000),
	}
}

func (pm *PlayerMgr) IsInPlayStateBySession(sessionID uint64) bool {
	_, ok := pm.session2Player[sessionID]
	return ok
}

func (pm *PlayerMgr) IsInPlayStateByAccount(accountID uint64) bool {
	_, ok := pm.account2Session[accountID]
	return ok
}

func (pm *PlayerMgr) ReplaceSession(sessionID, accountID uint64) uint64 {
	oldSessionID, _ := pm.account2Session[accountID]
	ps, _ := pm.session2Player[oldSessionID]

	ps.AccountID = accountID
	delete(pm.session2Player, oldSessionID)
	delete(pm.account2Session, accountID)

	ps.Chan <- &pd.PlayerCmd{
		Cmd:       pd.CmdSessionReplace,
		SessionID: sessionID,
	}

	pm.session2Player[sessionID] = ps
	pm.account2Session[accountID] = sessionID
	return oldSessionID
}

func (pm *PlayerMgr) NewPlayerCtx(sessionID, accountID uint64, playerData *pd.PlayerData, sigMain chan *pd.PlayerCmd) bool {
	_, ok := pm.session2Player[sessionID]
	if ok {
		return true
	} else {
		log.Debug().Msgf("player enter play state, account=%d session=%d", accountID, sessionID)
		ps := &playerSession{
			AccountID: accountID,
			Chan:      make(chan *pd.PlayerCmd, 100),
		}
		pm.session2Player[sessionID] = ps
		pm.account2Session[accountID] = sessionID
		go playerRoutine(sessionID, accountID, playerData, ps.Chan, sigMain)
		return true
	}
}

func (pm *PlayerMgr) GetPlayerCount() uint32 {
	return uint32(len(pm.session2Player))
}

func (pm *PlayerMgr) DelPlayerCtx(sessionID uint64) {
	ps, ok := pm.session2Player[sessionID]
	if !ok {
		return
	}

	ps.Chan <- &pd.PlayerCmd{
		Cmd: pd.CmdSessionLeave,
	}
	accountID := ps.AccountID
	delete(pm.account2Session, accountID)
	delete(pm.session2Player, sessionID)
}

func (pm *PlayerMgr) ForwardToPlayerBySession(sessionID uint64, c *pd.PlayerCmd) {
	ps, ok := pm.session2Player[sessionID]
	if !ok {
		return
	}

	log.Debug().Msgf("player cmd incoming: session=%d", sessionID)
	ps.Chan <- c
}

func (pm *PlayerMgr) ForwardToPlayerByAccount(accountID uint64, c *pd.PlayerCmd) {
	sessionID, ok := pm.account2Session[accountID]
	if !ok {
		return
	}

	log.Debug().Msgf("player cmd forward: session=%d", sessionID)
	pm.ForwardToPlayerBySession(sessionID, c)
}

func saveAccountToCache(state *pd.PlayerState, sigOut chan *pd.PlayerCmd) bool {
	playerID := state.Player.GetPlayerID()
	log.Debug().Msgf("perform player=%d save...", playerID)
	if b, err := state.Player.ToDbPb(); err != nil {
		log.Error().Msgf("marshal player=%d for save failed: %s", playerID, err.Error())
		return false
	} else {
		sigOut <- &pd.PlayerCmd{
			Cmd:       pd.CmdPlayerSave,
			AccountID: pd.PlayerID2AccountID(playerID),
			Body:      b,
		}
		return true
	}
}

func dispatchPlayerUp(c *pd.PlayerCmd, state *pd.PlayerState, sigOut chan *pd.PlayerCmd) {
	defer cp.CoredumpHandler()

	state.SessionID = c.SessionID
	header := cd.ParseHeader(c.Hdr)
	opcode := cmd.CLIENT_REQ_CMD(header.CmdID)
	body, rspCmdID, err := playerCMD.CmdHandler(opcode, state, c.Body)
	if err != nil {
		log.Error().Msgf("player handler %v failed: %v", opcode, err)
		return
	}

	if state.IsDirty {
		// 同步到dbcache中
		if saveAccountToCache(state, sigOut) {
			state.IsDirty = false
		}

		// 是否需要同步到数据库
		state.DbDirty = true
	}

	sessions := make([]uint64, 1)
	sessions[0] = c.SessionID
	pkt := cd.MakeSessionPkt(sessions, uint16(rspCmdID), header.UserData, header.Timestamp, body)
	sigOut <- &pd.PlayerCmd{
		Cmd:  pd.CmdPlayerData,
		Body: pkt,
	}
}

func dispatchPlayerForward(c *pd.PlayerCmd, state *pd.PlayerState, sigOut chan *pd.PlayerCmd) {
	log.Debug().Msgf("player=%d recv a cmd=%v", state.Player.GetPlayerID(), *c)
	if c.Cmd == pd.CmdPlayerForward {
		rspCmdID := uint16(c.SessionID)
		body := c.Body
		sessions := make([]uint64, 1)
		sessions[0] = state.SessionID
		pkt := cd.MakeSessionPkt(sessions, rspCmdID, 0, 0, body)
		sigOut <- &pd.PlayerCmd{
			Cmd:  pd.CmdPlayerData,
			Body: pkt,
		}
	}
}

func playerRoutine(sessionID, accountID uint64, playerData *pd.PlayerData, sigMainIn chan *pd.PlayerCmd, sigMainOut chan *pd.PlayerCmd) {
	log.Debug().Msgf("player routine begin: account=%d, data=%v", accountID, *playerData)

	state := &pd.PlayerState{
		Player:    playerData,
		SessionID: sessionID,
		SigPlayer: sigMainOut,
		IsDirty:   false,
		DbDirty:   false,
		Mail:      make(map[uint64]*pd.PlayerMail),
	}
	playerID := state.Player.GetPlayerID()

	// 战斗中标志位检查
	singlePVE.Login(state)

	// 需要创建一个定时存盘的timer
	t := time.NewTimer(time.Minute * 5)

	for {
		exit := false
		select {
		case c, _ := <-sigMainIn:
			if c.Cmd == pd.CmdSessionLeave {
				singlePVE.ControlPlayerOffline(state)
				exit = true
				break
			} else if c.Cmd == pd.CmdSessionReplace {
				oldSessionID := state.SessionID
				log.Debug().Msgf("player=%d change session from %d to %d", playerID, oldSessionID, c.SessionID)
				state.SessionID = c.SessionID
			} else if c.Cmd == pd.CmdPlayerForward {
				dispatchPlayerForward(c, state, sigMainOut)
			} else if c.Cmd == pd.CmdPlayerUpdateData {
				// 因为玩家在线，所以直接合并数据
				log.Debug().Msgf("player=%v receive cmdPlayerUpdateData", playerID)
				shadowMail := &db.DbShadowMail{}
				err := proto.Unmarshal(c.Body, shadowMail)
				if err != nil {
					log.Error().Msgf("player=%v unmarshal playerUpdateData error ",
						playerID)
				} else {
					op := pd.OpFromDbProto(shadowMail)
					err = state.Player.OpExec(op)
					if err != nil {
						log.Error().Msgf("player=%v playerUpdateData operation exec error %v",
							playerID, err)
					} else {
						saveAccountToCache(state, sigMainOut)
						state.DbDirty = true
					}
				}
			} else if c.Cmd == pd.CmdGetPlayerData {
				log.Debug().Msgf("account=%d get playerData", accountID)
				data, err := proto.Marshal(playerData.ToDbProto())
				if err != nil {
					c.AdminSigRet <- &pd.AdminRet{
						AccountID: accountID,
						Result:    err,
					}
					return
				}
				c.AdminSigRet <- &pd.AdminRet{
					AccountID: accountID,
					Data:      data,
					Result:    nil,
				}
			} else {
				dispatchPlayerUp(c, state, sigMainOut)
			}
		case <-t.C:
			if state.DbDirty {
				log.Debug().Msgf("player=%d save to cache & db", playerID)
				saveAccountToCache(state, sigMainOut)
				saveAccountToDb(state.Player)
				state.DbDirty = false
			} else {
				log.Debug().Msgf("player=%d no need to save, wait next time", playerID)
			}
			t.Reset(time.Minute * 5)
		}

		if exit {
			break
		}
	}

	// 更新缓存
	if state.IsDirty {
		saveAccountToCache(state, sigMainOut)
		state.IsDirty = false
	}

	// 更新磁盘
	saveAccountToDb(state.Player)

	sigMainOut <- &pd.PlayerCmd{
		Cmd:       pd.CmdPlayerExit,
		AccountID: pd.PlayerID2AccountID(playerID),
	}
	log.Debug().Msgf("player routine end: account=%d", accountID)
}

func (pm *PlayerMgr) killAll() {
	tmpSessions := make(map[uint64]uint64)
	for k, v := range pm.account2Session {
		tmpSessions[k] = v
	}

	for index := range tmpSessions {
		log.Debug().Msgf("KillAll kill session = [%v]", tmpSessions[index])
		pm.DelPlayerCtx(tmpSessions[index])
	}
}
