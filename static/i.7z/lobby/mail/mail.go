package mail

import (
	"context"
	"fmt"
	"github.com/rs/zerolog/log"
	"lobby/playerDef"
	"shared/csv"
	grpcPool "shared/mfxgrpcpool"
	"shared/mfxlocalregistry"
	pb "shared/proto/client/portal"
	mailServicePb "shared/proto/server/mail"
	"time"
)

const (
	constRPCTimeout              = time.Duration(3) * time.Second
	constGRPCPoolMaxSize         = 5
	constGRPCPoolIdleTimeOut     = time.Duration(0)
	constGRPCPoolMaxLifeDuration = time.Duration(10) * time.Second
)

var (
	constMailService    string
	personalMailService *grpcPool.GRPCPool
)

// Init mailService
func Init(mailService string) {
	constMailService = mailService
	personalMailService = grpcPool.New(constGRPCPoolMaxSize, constGRPCPoolIdleTimeOut, constGRPCPoolMaxLifeDuration)

	// Try once
	if _, err := getMailRPCAddr(); err != nil {
		panic(fmt.Errorf("lobby start fail can't get mail service RPC addr from %v",
			constMailService))
	}
	// init global mail mgr
	initGlobalMailLoader()
}

func getMailRPCAddr() (string, error) {
	ip, _, port, err := mfxlocalregistry.SelectEndpoint(constMailService)
	if err != nil {
		log.Error().Msgf("mail error can't get mail service RPC addr from %v",
			constMailService)
		return "", err
	}
	return fmt.Sprintf("%s:%d", ip, port), nil
}

// FetchMails get mails from mailService and rewrite playerState.Mails
func FetchMails(state *playerDef.PlayerState) ([]*pb.LobbyMail, error) {
	allMail := []*mailServicePb.Mail{}
	result := uint32(0)
	accountID := playerDef.PlayerID2AccountID(state.Player.GetPlayerID())
	fn := func(cli mailServicePb.MailServiceClient, ctx context.Context) error {
		req := &mailServicePb.FetchMailReq{
			AccountId: accountID,
			StartPos:  0,
			EndPos:    14,
		}
		rsp, err := cli.FetchMails(ctx, req)
		if err != nil {
			log.Error().Msgf("mailService error FetchMails : %v", err)
			return err
		}
		result = rsp.GetResult()
		allMail = rsp.GetMails()
		return nil
	}
	if err := personalMailCallRPC(fn); err != nil || result != 0 {
		return nil, err
	}
	lobbyMails, playerMails := playerDef.Mail2lobbyMail(allMail)
	for _, playerMail := range playerMails {
		if playerMail == nil {
			continue
		}
		if playerMail.MailID == 0 {
			continue
		}
		state.Mail[playerMail.MailID] = playerMail
	}
	return lobbyMails, nil
}

// SetMailRead mark mail read
func SetMailRead(state *playerDef.PlayerState, mailID uint64) (result int32) {
	result = csv.ERRCODE_SUCCESS
	accountID := playerDef.PlayerID2AccountID(state.Player.GetPlayerID())
	fn := func(cli mailServicePb.MailServiceClient, ctx context.Context) error {
		req := &mailServicePb.SetMailReadReq{
			AccountId: accountID,
			MailId:    mailID,
		}
		rsp, err := cli.SetMailRead(ctx, req)
		if err != nil {
			log.Error().Msgf("mailService error SetMailRead : %v", err)
			return err
		}
		result = int32(rsp.GetResult())
		return nil
	}
	if err := personalMailCallRPC(fn); err != nil {
		result = csv.ERRCODE_FAILED
		return
	}
	return
}

// UpdateMailAttachment reward attachment in mail
func UpdateMailAttachment(state *playerDef.PlayerState, mailID uint64, NewAttachment string) error {
	accountID := playerDef.PlayerID2AccountID(state.Player.GetPlayerID())
	fn := func(cli mailServicePb.MailServiceClient, ctx context.Context) error {
		req := &mailServicePb.UpdateMailAttachmentReq{
			AccountId:     accountID,
			MailId:        mailID,
			NewAttachment: NewAttachment,
		}
		rsp, err := cli.UpdateMailAttachment(ctx, req)
		if err != nil || rsp.GetResult() != 0 {
			log.Error().Msgf("mailService error UpdateMailAttachment : %v : %v",
				err, rsp.GetResult())
			return err
		}
		return nil
	}
	if err := personalMailCallRPC(fn); err != nil {
		return err
	}
	return nil
}

// DeleteMail del mail
func DeleteMail(state *playerDef.PlayerState, mailID uint64) (result int32) {
	result = csv.ERRCODE_SUCCESS
	accountID := playerDef.PlayerID2AccountID(state.Player.GetPlayerID())
	fn := func(cli mailServicePb.MailServiceClient, ctx context.Context) error {
		req := &mailServicePb.DeleteMailReq{
			AccountId: accountID,
			MailId:    mailID,
		}
		rsp, err := cli.DeleteMail(ctx, req)
		if err != nil {
			log.Error().Msgf("mailService error DeleteMail : %v", err)
			return err
		}
		result = int32(rsp.GetResult())
		return nil
	}
	if err := personalMailCallRPC(fn); err != nil {
		result = csv.ERRCODE_FAILED
		return
	}
	return
}

func personalMailCallRPC(proc func(mailServicePb.MailServiceClient, context.Context) error) error {
	mailAddr, err := getMailRPCAddr()
	if err != nil {
		log.Error().Msgf("get mailService addr error failed: %v", err)
		return err
	}
	log.Debug().Msgf("use mailService rpc addr=%s", mailAddr)
	ctx, cancel := context.WithTimeout(context.Background(), constRPCTimeout)
	defer cancel()
	conn, err := personalMailService.GetConn(ctx, mailAddr)
	if err != nil {
		log.Error().Msgf("mailService error gRPC dial failed: %s", err.Error())
		return err
	}
	defer conn.Close()
	c := mailServicePb.NewMailServiceClient(conn.ClientConn)
	return proc(c, ctx)
}
