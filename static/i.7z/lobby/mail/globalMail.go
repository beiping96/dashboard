package mail

import (
	"context"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"google.golang.org/grpc"
	pd "lobby/playerDef"
	pb "shared/proto/client/portal"
	mailServicePb "shared/proto/server/mail"
	"sync"
	"time"
)

const (
	constLoadDuration       = time.Duration(10) * time.Second
	constGlobalMailStartPos = uint32(0)
	constGlobalMailEndPos   = uint32(2)
)

type globalMailCache struct {
	lock  sync.RWMutex
	mails [][]byte
}

var (
	globalMail *globalMailCache
)

func initGlobalMailLoader() {
	globalMail = &globalMailCache{
		mails: getGlobalMail(),
	}
	go globalMailLoader()
}

func globalMailLoader() {
	ticker := time.Tick(constLoadDuration)
	for {
		<-ticker
		newMail := getGlobalMail()
		if newMail == nil {
			// if rpc error
			// do not change this cache
			continue
		}
		globalMail.lock.Lock()
		globalMail.mails = newMail
		globalMail.lock.Unlock()
	}
}

func getGlobalMail() [][]byte {
	allMail := []*mailServicePb.Mail{}
	result := uint32(0)
	fn := func(cli mailServicePb.MailServiceClient, ctx context.Context) error {
		req := &mailServicePb.FetchGlobalMailReq{
			StartPos: constGlobalMailStartPos,
			EndPos:   constGlobalMailEndPos,
		}
		rsp, err := cli.FetchGlobalMails(ctx, req)
		if err != nil {
			log.Error().Msgf("mailService error FetchMails : %v", err)
			return err
		}
		result = rsp.GetResult()
		allMail = rsp.GetMails()
		return nil
	}
	if err := globalMailCallRPC(fn); err != nil || result != 0 {
		log.Error().Msgf("mailService error get global mail error %v", err)
		return nil
	}
	lobbyMails, _ := pd.Mail2lobbyMail(allMail)
	ans := [][]byte{}
	for _, pbMail := range lobbyMails {
		mailData, err := proto.Marshal(pbMail)
		if err != nil {
			log.Error().Msgf("lobby global mail error getGlobalMail Marshal %v", err)
			continue
		}
		ans = append(ans, mailData)
	}
	return ans
}

// FetchGlobalMails get global mails from localCache
func FetchGlobalMails(state *pd.PlayerState) ([]*pb.LobbyMail, error) {
	globalMail.lock.RLock()
	defer globalMail.lock.RUnlock()
	ans := []*pb.LobbyMail{}
	for _, mailData := range globalMail.mails {
		localMail := &pb.LobbyMail{}
		err := proto.Unmarshal(mailData, localMail)
		if err != nil {
			log.Error().Msgf("lobby global mail error FetchGlobalMails Unmarshal %v", err)
			continue
		}
		mailID := localMail.GetMailId()
		var (
			read              uint32
			attachmentIsExist uint32
		)
		if state.Player.GetGlobalMail(mailID) {
			read = 1
			attachmentIsExist = 0
		} else {
			read = 0
			attachmentIsExist = 1
		}
		localMail.Read = &read
		localMail.AttachmentIsExist = &attachmentIsExist
		ans = append(ans, localMail)
	}
	return ans, nil
}

// GetGlobalMailAttachment get global mail attachment from localCache
func GetGlobalMailAttachment(mailID uint64) ([]*pb.BackpackGoods, bool) {
	globalMail.lock.RLock()
	defer globalMail.lock.RUnlock()
	for _, mailData := range globalMail.mails {
		pbMail := &pb.LobbyMail{}
		err := proto.Unmarshal(mailData, pbMail)
		if err != nil {
			log.Error().Msgf("lobby global mail error GetGlobalMailAttachment Unmarshal %v", err)
			continue
		}
		if *pbMail.MailId != mailID {
			continue
		}
		return pbMail.GetAttachment(), true
	}
	return nil, false
}

func globalMailCallRPC(proc func(mailServicePb.MailServiceClient, context.Context) error) error {
	mailAddr, err := getMailRPCAddr()
	if err != nil {
		log.Error().Msgf("get mailService addr error failed: %v", err)
		return err
	}
	log.Debug().Msgf("use mailService rpc addr=%s", mailAddr)
	conn, err := grpc.Dial(mailAddr, grpc.WithInsecure())
	if err != nil {
		log.Error().Msgf("mailService error gRPC dial failed: %s", err.Error())
		return err
	}
	defer conn.Close()
	c := mailServicePb.NewMailServiceClient(conn)
	ctx, cancel := context.WithTimeout(context.Background(), constRPCTimeout)
	defer cancel()
	return proc(c, ctx)
}
