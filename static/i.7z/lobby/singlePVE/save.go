package singlePVE

import (
	"github.com/gogo/protobuf/proto"
	"github.com/rs/zerolog/log"
	"shared/battle.etc/stage"
	redis "shared/mfxredisutil"
	battle "shared/proto/server/battle"
	"strconv"
)

func key(uid uint64) string {
	return "GLOBAL&SINGLEPVE&STAGE&SAVESTAGE&UID&" + strconv.FormatUint(uid, 10)
}

// Get just use for stageGet CMD
func Get(stageUID uint64) *stage.Stage {
	return mainMgr.Get(stageUID)
}

func (singlePveMgr singlePveStageMgr) Get(stageUID uint64) *stage.Stage {
	redisPool, err := redis.NewRedisUtil(singlePveMgr.redisAddr)
	if err != nil {
		log.Error().Msgf("singlePVE get error redis %v init error, %v",
			singlePveMgr.redisAddr, err)
		return nil
	}
	defer redisPool.Close()
	rsp, err := redisPool.Cmd("GET", key(stageUID)).Str()
	if err != nil {
		return nil
	}
	basic := []byte(rsp)
	var stg battle.RdsStage
	if proto.Unmarshal(basic, &stg) != nil {
		return nil
	}
	stage := stage.FromRdsStageProto(&stg)
	return &stage
}

func (singlePveMgr singlePveStageMgr) Save(stageSource *stage.Stage) {
	if stageSource.UID == 0 {
		log.Error().Msg("ERROR stage save error  uid is zero")
		return
	}
	redisPool, err := redis.NewRedisUtil(singlePveMgr.redisAddr)
	if err != nil {
		log.Error().Msgf("singlePVE save error redis %v init error, %v",
			singlePveMgr.redisAddr, err)
		return
	}
	defer redisPool.Close()

	stage := stageSource.ToRdsStageProto()
	data, err := proto.Marshal(stage)
	if err != nil {
		log.Error().Msgf("marshal stage data failed, err: &v", err)
		return
	}
	rsp := redisPool.Cmd("SET", key(stageSource.UID), string(data))
	if rsp.Err != nil {
		log.Error().Msgf("save stage data failed, err: %v", rsp.Err)
	}
}

func (singlePveMgr singlePveStageMgr) del(stageUID uint64) {
	redisPool, err := redis.NewRedisUtil(singlePveMgr.redisAddr)
	if err != nil {
		log.Error().Msgf("singlePVE delete error redis %v init error, %v",
			singlePveMgr.redisAddr, err)
		return
	}
	defer redisPool.Close()
	redisPool.Cmd("DEL", key(stageUID))
}
