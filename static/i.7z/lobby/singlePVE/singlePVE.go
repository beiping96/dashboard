package singlePVE

import (
	"errors"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	cfg "lobby/config"
	"lobby/playerDef"
	"shared/battle.etc/stageDef"
	"shared/battle.etc/stageServer"
	cp "shared/mfxcoredump"
	redis "shared/mfxredisutil"
	"time"
)

var mainMgr singlePve

type singlePve struct {
	singlePveStageMgr
	upChan chan<- *stageDef.In
}

type singlePveStageMgr struct {
	redisAddr        string
	lobbyMainSigChan chan<- *playerDef.PlayerCmd
}

// Init singlePVE mgr
func Init(lobbyID uint16, config cfg.LobbyConfig, mainSigChan chan<- *playerDef.PlayerCmd) {
	redisAddr := fmt.Sprintf("%s:%s", config.Redis.Ep.Ip, config.Redis.Ep.Port)
	// check connection
	redisPool, err := redis.NewRedisUtil(redisAddr)
	if err != nil {
		panic(fmt.Errorf("lobby start singlePVE mgr error, connect %v redis cluster err %v",
			redisAddr, err))
	}
	defer redisPool.Close()

	// init
	mainMgr.redisAddr = redisAddr
	mainMgr.lobbyMainSigChan = mainSigChan
	upChan := make(chan *stageDef.In, 5000)
	mainMgr.upChan = upChan

	// start stageMgr
	err = stageServer.Run(mainMgr, upChan, lobbyID)
	if err != nil {
		panic(fmt.Errorf("lobby start singlePVE mgr error, stageServer start error :%v", err))
	}
}

// Login called by player login
func Login(state *playerDef.PlayerState) {
	cleanBattle(state)
	cleanEvent(state)
}

// cleanEvent
func cleanEvent(state *playerDef.PlayerState) {
	if !state.Player.GetFlagInEvent() {
		return
	}
	stageUID := state.Player.GetSinglePveStageUID()
	if stageUID == 0 {
		return
	}
	defer cp.CoredumpHandler()
	log.Debug().Msgf("singlePVE login debug check event status stageUID:%v playerID: %v",
		stageUID, state.Player.GetPlayerID())
	in := stageDef.In{
		Type:     stageDef.CheckEvent,
		StageUID: stageUID,
		PlayerID: state.Player.GetPlayerID(),
	}
	_, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("singlePVE login error cannot connect with stageMgr check event status, stageUID: %d, playerID: %v",
			stageUID, state.Player.GetPlayerID())
		return
	}

}

// cleanBattle
func cleanBattle(state *playerDef.PlayerState) {
	stageUID, nodeID := state.Player.GetInBattle()
	if stageUID == 0 {
		return
	}
	defer cp.CoredumpHandler()
	log.Debug().Msgf("singlePVE login debug check battle status %v:%v playerID:%v",
		stageUID, nodeID, state.Player.GetPlayerID())
	in := stageDef.In{
		Type:     stageDef.CheckBattle,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: state.Player.GetPlayerID(),
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("singlePVE login error can not connect with stageMgr check battle status %v:%v playerID:%v",
			stageUID, nodeID, state.Player.GetPlayerID())
		return
	}
	if reply.Param.(bool) {
		return
	}
	// clean player flag in battle
	state.Player.SetInBattle(0, 0)
	state.IsDirty = true
}

func (singlePveMgr singlePveStageMgr) NoticeDown(notice stageDef.Notice) {
	playerID := notice.PlayerID
	accountID := playerDef.PlayerID2AccountID(playerID)
	playerCMD := playerDef.PlayerCmd{
		Cmd:       playerDef.CmdPlayerForward,
		SessionID: uint64(notice.CmdCode),
		AccountID: accountID,
		Body:      notice.Data,
	}
	singlePveMgr.lobbyMainSigChan <- &playerCMD
}

func (singlePveMgr singlePveStageMgr) OperationDown(operation stageDef.Operation) {
	playerID := operation.PlayerID
	accountID := playerDef.PlayerID2AccountID(playerID)
	op := playerDef.NewOP()
	err := op.JoinAddStageOperation(&operation.Op)
	if err != nil {
		log.Error().Msgf("singlePve error interface operationDown can't join playerOperation %v", err)
		return
	}
	data, err := proto.Marshal(op.ToDbProto())
	if err != nil {
		log.Error().Msgf("singlePve error interface operationDown can't Marshal playerOperation %v", err)
		return
	}
	playerOperation := playerDef.PlayerCmd{
		Cmd:       playerDef.CmdPlayerUpdateData,
		AccountID: accountID,
		Body:      data,
	}
	singlePveMgr.lobbyMainSigChan <- &playerOperation
}

func (singlePveMgr singlePveStageMgr) StageOver(stageUID uint64, playerIDs []uint64) {
	singlePveMgr.del(stageUID)
	op := playerDef.NewOP()
	opWriteSinglePveUID := stageDef.PlayerOperation{
		Type: stageDef.PlayerOperationEnumCleanSinglePve,
	}
	err := op.JoinAddStageOperation(&opWriteSinglePveUID)
	if err != nil {
		log.Error().Msgf("singlePve error interface stageOver operationDown can't join playerOperation %v", err)
		return
	}
	data, err := proto.Marshal(op.ToDbProto())
	if err != nil {
		log.Error().Msgf("singlePve error interface stageOver operationDown can't Marshal playerOperation %v", err)
		return
	}
	for _, playerID := range playerIDs {
		singlePveMgr.lobbyMainSigChan <- &playerDef.PlayerCmd{
			Cmd:       playerDef.CmdPlayerUpdateData,
			AccountID: playerDef.PlayerID2AccountID(playerID),
			Body:      data,
		}
	}
}

func send2stage(stageIn *stageDef.In) (*stageDef.InReply, error) {
	replyChan := make(chan stageDef.InReply, 1)
	stageIn.ReplyChan = replyChan

	timer := time.After(time.Duration(2) * time.Second)
	select {
	case mainMgr.upChan <- stageIn:
	case <-timer:
		return nil, errors.New("error send2Stage error can't join stageMgr in chan")
	}
	select {
	case reply := <-replyChan:
		return &reply, nil
	case <-timer:
		return nil, fmt.Errorf("error send2Stage error timeout not got the reply %v", stageIn)
	}
}
