package singlePVE

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"lobby/playerDef"
	"shared/battle.etc/battle"
	"shared/battle.etc/stage"
	"shared/battle.etc/stageDef"
	"shared/battle.etc/stagePlayer"
	"shared/csv"
	"shared/heroDef"
	pb "shared/proto/client/battle"
	"strconv"
	"time"
)

// CreateStage battle_single_pve_create_req
func CreateStage(player *playerDef.PlayerData, myHero heroDef.Hero,
	stageMode uint32, stageDifficulty uint32) (int32, stage.Stage, error) {
	stgPlayer := stagePlayer.New(player.GetPlayerID(), player.GetPlayerName(),
		player.GetLobbyID(), player.GetPlayerCards(), player.GetPlayerHeros())
	createStage := stageDef.CreateStageParam{
		StagePlayer:     *stgPlayer,
		Hero:            myHero,
		StageMode:       stageMode,
		StageDifficulty: stageDifficulty,
	}
	createStageIn := stageDef.In{
		Type:  stageDef.CreateStage,
		Param: createStage,
	}
	reply, err := send2stage(&createStageIn)
	if err != nil {
		return csv.ERRCODE_FAILED, stage.Stage{}, fmt.Errorf("singlePVE create stage error %v:%v",
			reply, err)
	}
	stage, _ := reply.Param.(stage.Stage)
	return reply.Result, stage, nil
}

// Touch battle_single_pve_touch_req
func Touch(state *playerDef.PlayerState, stageUID uint64, stageNodeID uint32, rsp *pb.BattleSinglePveTouchRsp) error {
	rsp.StageNodeId = &stageNodeID
	nodeTouchMethod := stageDef.Method{
		Type: stageDef.TouchNode,
	}
	nodeTouchIn := stageDef.In{
		Type:     stageDef.PlayerUp,
		Param:    nodeTouchMethod,
		StageUID: stageUID,
		NodeID:   stageNodeID,
		PlayerID: state.Player.GetPlayerID(),
	}
	reply, err := send2stage(&nodeTouchIn)
	if err != nil {
		log.Error().Msgf("stage touch error %v:%v error :%v",
			stageUID, stageNodeID, err)
		return err
	}
	rsp.Result = &reply.Result
	touchNodeReply, ok := reply.Param.(stageDef.TouchNodeReply)
	if ok {
		rsp.Status = &touchNodeReply.Status
		rsp.Data = &touchNodeReply.BattleData
		rsp.ShopItems = &touchNodeReply.ShopItem
		for _, restStatus := range touchNodeReply.RestStatus {
			rsp.RestStatus = append(rsp.RestStatus, restStatus)
		}
		rsp.Treasure = &touchNodeReply.Treasure
		rsp.MeetId = &touchNodeReply.MeetID
		if touchNodeReply.InBattle {
			state.Player.SetInBattle(stageUID, stageNodeID)
			state.IsDirty = true
		} else if touchNodeReply.MeetID > 0 {
			state.Player.SetFlagInEvent(true)
			state.IsDirty = true
		}
	}
	return nil
}

// BattleOperation battle_operation_req
func BattleOperation(playerID uint64, stageUID uint64, nodeID uint32,
	o *pb.BattleOperation) (int32, *pb.BattleOperation) {
	battleOperationParam := stageDef.Method{
		Type: stageDef.BattleOperation,
	}
	battleOperationIn := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    battleOperationParam,
	}
	reply, err := send2stage(&battleOperationIn)
	if err != nil {
		log.Error().Msgf("stage up battle operation error %v", err)
		return csv.ERRCODE_FAILED, o
	}
	if reply.Result != csv.ERRCODE_SUCCESS {
		return reply.Result, o
	}
	battleChan, ok := reply.Param.(chan interface{})
	if !ok {
		log.Error().Msgf("stage %v up battle operation error can't catch battle chan", stageUID)
		return csv.ERRCODE_FAILED, o
	}
	opInterface, replyChan := battle.NewOperationUP(o)
	battleChan <- opInterface

	timer := time.After(time.Duration(2) * time.Second)
	select {
	case battleRe := <-replyChan:
		p3 := strconv.Itoa(int(battleRe.CardRoundTimes))
		o.Param3 = &p3
		return battleRe.Result, o
	case <-timer:
		return csv.ERRCODE_BATTLE_TIMEOUT, o
	}
}

// BattleChooseCardOperation battle_choose_card_req
func BattleChooseCardOperation(playerID uint64, stageUID uint64, nodeID uint32,
	cardIDs []uint32) int32 {

	battleOperationParam := stageDef.Method{
		Type: stageDef.BattleChooseCard,
	}
	battleOperationIn := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    battleOperationParam,
	}
	reply, err := send2stage(&battleOperationIn)
	if err != nil {
		log.Error().Msgf("stage up battle operation choose card error %v", err)
		return csv.ERRCODE_FAILED
	}
	if reply.Result != csv.ERRCODE_SUCCESS {
		return reply.Result
	}
	battleChan, ok := reply.Param.(chan interface{})
	if !ok {
		log.Error().Msgf("stage %v up battle operation choose card error can't catch battle chan", stageUID)
		return csv.ERRCODE_FAILED
	}
	opInterface, replyChan := battle.NewChooseCardOperationUP(cardIDs)
	battleChan <- opInterface

	timer := time.After(time.Duration(2) * time.Second)
	select {
	case battleRe := <-replyChan:
		return battleRe.Result
	case <-timer:
		return csv.ERRCODE_BATTLE_TIMEOUT
	}
}

// BattlePlayerLeave battle_leave_battle_req
func BattlePlayerLeave(playerID uint64, stageUID uint64, nodeID uint32) int32 {
	battleOperationParam := stageDef.Method{
		Type: stageDef.BattleLeave,
	}
	battleOperationIn := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    battleOperationParam,
	}
	reply, err := send2stage(&battleOperationIn)
	if err != nil {
		log.Error().Msgf("stage up battle leave error %v", err)
		return csv.ERRCODE_FAILED
	}
	return reply.Result
}

// ControlPlayerOffline called by playerMgr after player cut the connection
func ControlPlayerOffline(state *playerDef.PlayerState) {
	stageUID, nodeID := state.Player.GetInBattle()
	if stageUID == 0 || stageUID != state.Player.GetSinglePveStageUID() {
		return
	}
	battleOperationIn := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: state.Player.GetPlayerID(),
		Param: stageDef.Method{
			Type: stageDef.BattleOffline,
		},
	}
	_, err := send2stage(&battleOperationIn)
	if err != nil {
		log.Error().Msgf("stage up battle offline error %v", err)
		return
	}
	return
}

// DropPotion battle_drop_potion_req
func DropPotion(stageUID uint64, playerID uint64, potionTypeID uint32) (int32, []uint32) {
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		PlayerID: playerID,
		Param: stageDef.Method{
			Type:  stageDef.DropPotion,
			Param: potionTypeID,
		},
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage up drop potion error %v", err)
		return csv.ERRCODE_FAILED, nil
	}
	potionAll, _ := reply.Param.([]uint32)
	return reply.Result, potionAll
}

// ShopPurchase shop
func ShopPurchase(playerID uint64, stageUID uint64, nodeID, itemID, itemType, itemIndex uint32, rsp *pb.BattleShopPurchaseRsp) (result int32) {
	methodParam := stageDef.ShopBuyParam{
		ItemID:    itemID,
		ItemType:  itemType,
		ItemIndex: itemIndex,
		Rsp:       rsp,
	}
	method := stageDef.Method{
		Type:  stageDef.ShopBuy,
		Param: methodParam,
	}

	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    method,
	}

	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("shop buy error: %v", err)
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return
	}

	return reply.Result
}

// ChooseEvent battle_choose_event_req
func ChooseEvent(playerID uint64, stageUID uint64, nodeID uint32, operationIndex uint32, cardIDs []uint32) (eventResult pb.BattleEventResult,
	linkageEventID uint32, eventStop bool, result int32) {
	method := stageDef.Method{
		Type: stageDef.ChooseEvent,
		Param: stageDef.ChooseEventParam{
			OperationIndex: operationIndex,
			CardIDs:        cardIDs,
		},
	}
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    method,
	}

	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("choose event error: %v", err)
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return
	}
	result = reply.Result
	rep, ok := reply.Param.(stageDef.ChooseEventReply)
	if ok {
		eventResult = rep.EventResult
		linkageEventID = rep.LinkageEventID
		eventStop = rep.EventStop
	}

	return
}

// StageChooseInitEvent init event
func StageChooseInitEvent(stageUID uint64, playerID uint64, eventID uint32, param uint32) (eventResult pb.BattleEventResult, result int32) {
	method := stageDef.Method{
		Type: stageDef.ChooseInitEvent,
		Param: stageDef.ChooseInitEventParam{
			EventID: eventID,
			Param:   param,
		},
	}
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		PlayerID: playerID,
		Param:    method,
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage choose init event failed: %v", err)
		result = csv.ERRCODE_FAILED
		return
	}
	result = reply.Result
	eventResult, ok := reply.Param.(pb.BattleEventResult)
	if !ok {
		log.Debug().Msgf("single pve choose init event: reply.eventResult: %+v", eventResult)
		return pb.BattleEventResult{}, result
	}
	return
}

// RestCardLevelUp battle_card_level_up_req
func RestCardLevelUp(stageUID uint64, nodeID uint32, playerID uint64, cardID uint32) (int32, uint32) {
	method := stageDef.Method{
		Type:  stageDef.RestCardLevelUp,
		Param: cardID,
	}
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    method,
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage rest card level up error :%v", err)
		return csv.ERRCODE_FAILED, 0
	}
	newCardResID, _ := reply.Param.(uint32)
	return reply.Result, newCardResID
}

// RestRecover battle_recover_req
func RestRecover(stageUID uint64, nodeID uint32, playerID uint64) (int32, uint32, []*pb.BattleRelicInStage) {
	method := stageDef.Method{
		Type: stageDef.RestRecover,
	}
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    method,
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage rest recover error :%v", err)
		return csv.ERRCODE_FAILED, 0, nil
	}
	recoverReply, ok := reply.Param.(stageDef.RestRecoverReply)
	if ok {
		ansRelicInStage := []*pb.BattleRelicInStage{}
		for _, relicInStage := range recoverReply.RelicInStage {
			ansRelicInStage = append(ansRelicInStage, &relicInStage)
		}
		return reply.Result, recoverReply.NewHP, ansRelicInStage
	}
	return reply.Result, 0, nil
}

// OpenReward battle_reward_open_req
func OpenReward(stageUID uint64, nodeID uint32, playerID uint64) (int32, *pb.BattleRelicInStage) {
	method := stageDef.Method{
		Type: stageDef.OpenReward,
	}
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    method,
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage open reward error :%v", err)
		return csv.ERRCODE_FAILED, nil
	}
	ansRelicInStage, ok := reply.Param.(pb.BattleRelicInStage)
	if !ok {
		return reply.Result, nil
	}
	return reply.Result, &ansRelicInStage
}

// CloseReward battle_reward_close_req
func CloseReward(stageUID uint64, nodeID uint32, playerID uint64) int32 {
	method := stageDef.Method{
		Type: stageDef.CloseReward,
	}
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    method,
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage close reward error :%v", err)
		return csv.ERRCODE_FAILED
	}
	return reply.Result
}

// ChooseReward battle_choice_reward_req
func ChooseReward(stageUID uint64, nodeID uint32, playerID uint64,
	rewardBagUID uint32, rewardType pb.BattleRewardEnum,
	itemID uint32) (int32, []*pb.BattleRelicInStage, uint32) {
	method := stageDef.Method{
		Type: stageDef.ChooseReward,
		Param: stageDef.ChooseRewardParam{
			RewardBagUID: rewardBagUID,
			RewardType:   rewardType,
			ItemID:       itemID,
		},
	}
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		NodeID:   nodeID,
		PlayerID: playerID,
		Param:    method,
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage choose reward error : %v", err)
		return csv.ERRCODE_FAILED, nil, 0
	}
	chooseRewardReply, ok := reply.Param.(stageDef.ChooseRewardReply)
	if ok {
		ansRelicInStage := []*pb.BattleRelicInStage{}
		for _, relicInStage := range chooseRewardReply.RelicInStage {
			ansRelicInStage = append(ansRelicInStage, &relicInStage)
		}
		return reply.Result, ansRelicInStage, chooseRewardReply.NewGold
	}
	return reply.Result, nil, 0
}

// Destroy battle_single_pve_destroy_req
func Destroy(stageUID uint64, playerID uint64) int32 {
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		PlayerID: playerID,
		Param: stageDef.Method{
			Type: stageDef.DestroyStage,
		},
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage destroy error : %v", err)
		return csv.ERRCODE_FAILED
	}
	return reply.Result
}

// Reconnection battle_reconnection_req
func Reconnection(stageUID uint64, nodeID uint32, playerID uint64) (uint32, int32) {
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		PlayerID: playerID,
		NodeID:   nodeID,
		Param: stageDef.Method{
			Type: stageDef.Reconnection,
		},
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage reconnection error : %v", err)
		return 0, csv.ERRCODE_FAILED
	}
	typeLocal, ok := reply.Param.(uint32)
	if !ok {
		return 0, csv.ERRCODE_FAILED
	}
	return typeLocal, reply.Result
}

// Resurgence battle_resurgence_req
func Resurgence(stageUID uint64, resurgenceType uint32, state *playerDef.PlayerState, rsp *pb.BattleResurgenceRsp) {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &result
	gold := state.Player.GetBackpack().GetGoldsNum()
	rsp.NewOutsideGold = &gold
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		PlayerID: state.Player.GetPlayerID(),
		Param: stageDef.Method{
			Type:  stageDef.Resurgence,
			Param: resurgenceType,
		},
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage resurgence error : %v", err)
		result = csv.ERRCODE_FAILED
		return
	}
	result = reply.Result
	if result != csv.ERRCODE_SUCCESS {
		return
	}
	resurgenceReply, ok := reply.Param.(stageDef.ResurgenceReply)
	if !ok {
		return
	}
	rsp.CardLvUp = resurgenceReply.CardLvUp
	rsp.Potions = resurgenceReply.Potions
	rsp.RelicTypeId = &resurgenceReply.RelicTypeID
	rsp.RelicInStage = resurgenceReply.RelicInStage
	return
}

// ResurgencePlus battle_resurgence_req
func ResurgencePlus(stageUID uint64, resurgenceType uint32, state *playerDef.PlayerState, rsp *pb.BattleResurgenceRsp) {
	result := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &result
	gold := state.Player.GetBackpack().GetGoldsNum()
	rsp.NewOutsideGold = &gold
	recoverConfig, ok := csv.RecoverOptionMap[int64(resurgenceType)]
	if !ok {
		result = csv.ERRCODE_FAILED
		return
	}
	needGold := uint32(recoverConfig.Cost)
	if needGold > gold {
		result = csv.ERRCODE_NO_GOLD
		return
	}
	in := stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		PlayerID: state.Player.GetPlayerID(),
		Param: stageDef.Method{
			Type:  stageDef.Resurgence,
			Param: resurgenceType,
		},
	}
	reply, err := send2stage(&in)
	if err != nil {
		log.Error().Msgf("stage resurgence error : %v", err)
		result = csv.ERRCODE_FAILED
		return
	}
	result = reply.Result
	if reply.Result != csv.ERRCODE_SUCCESS {
		return
	}
	err = state.Player.GetBackpack().DelGolds(needGold)
	if err != nil {
		log.Error().Msgf("stage resurgence error cost gold not enough : %v", err)
		result = csv.ERRCODE_FAILED
		return
	}
	state.IsDirty = true
	gold = state.Player.GetBackpack().GetGoldsNum()
	resurgenceReply, ok := reply.Param.(stageDef.ResurgenceReply)
	if !ok {
		return
	}
	rsp.CardLvUp = resurgenceReply.CardLvUp
	rsp.Potions = resurgenceReply.Potions
	rsp.RelicTypeId = &resurgenceReply.RelicTypeID
	rsp.RelicInStage = resurgenceReply.RelicInStage
	return
}

// RelicInStageChoose battle_relic_in_stage_choose_req
func RelicInStageChoose(playerID uint64, stageUID uint64, relicID uint32, cardID uint32, potionID uint32) (int32, *pb.BattleCard, []uint32) {
	in := &stageDef.In{
		Type:     stageDef.PlayerUp,
		StageUID: stageUID,
		PlayerID: playerID,
		Param: stageDef.Method{
			Type: stageDef.RelicInStageChoose,
			Param: stageDef.RelicInStageChooseParam{
				RelicTypeID: relicID,
				CardID:      cardID,
				PotionID:    potionID,
			},
		},
	}
	reply, err := send2stage(in)
	if err != nil {
		log.Error().Msgf("stage RelicInStageChoose error : %v", err)
		return csv.ERRCODE_FAILED, nil, nil
	}
	result := reply.Result
	relicInStageChooseReply, ok := reply.Param.(stageDef.RelicInStageChooseReply)
	if !ok {
		return result, nil, nil
	}
	return result, relicInStageChooseReply.Card, relicInStageChooseReply.Potions
}
