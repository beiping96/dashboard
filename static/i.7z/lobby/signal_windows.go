package main

import (
	"os"
)

func signalNotify(c chan<- os.Signal) {

}

func isSigUsr1(sig os.Signal) bool {
	return false
}
