package main

import (
	"database/sql"
	"errors"
	_ "github.com/go-sql-driver/mysql"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"lobby/codeRepair"
	cfg "lobby/config"
	"lobby/mail"
	pd "lobby/playerDef"
	"lobby/singlePVE"
	"net"
	"os"
	"os/signal"
	"shared/csv"
	cd "shared/mfxconn"
	"shared/proto/server/lobby"
	cmd "shared/proto/share/command"
	"syscall"
	"time"
)

var (
	loginMgr      *LoginMgr
	playerMgr     *PlayerMgr
	dbCache       *DbCache
	dbPool        *sql.DB
	globalLobbyID uint32
	sigAdmin      chan *adminCmd
)

func handleConn(conn net.Conn, sig chan<- *pd.PlayerCmd) {
	defer conn.Close()

	err := cd.HandleStream(conn, func(conn net.Conn, hdr, body []byte) {
		header := cd.ParseHeader(hdr)
		if cd.IsInnerCmd(header.CmdID) {
			switch header.CmdID {
			case cd.CmdMasterYou:
				log.Info().Msgf("I'm Master now")
				return
			case cd.CmdMasterNot:
				log.Info().Msgf("I'm not Master, just exit")
				os.Exit(-1)
			}
		}
		dupHdr := make([]byte, len(hdr))
		dupBody := make([]byte, len(body))
		copy(dupHdr, hdr)
		copy(dupBody, body)
		sig <- &pd.PlayerCmd{
			Cmd:  pd.CmdSessionData,
			Hdr:  dupHdr,
			Body: dupBody,
		}
	})
	if err != nil {
		log.Error().Msgf("conn leave: %s", err.Error())
	} else {
		log.Info().Msgf("conn leave")
	}
	sig <- &pd.PlayerCmd{
		Cmd: pd.CmdConnLeave,
	}
}

func dispatchConnSignal(c *pd.PlayerCmd, conn net.Conn, sigLogin chan *loginCmd) {
	header := cd.ParseHeader(c.Hdr)
	log.Debug().Msgf("conn signal: cmd=%d", header.CmdID)
	if header.CmdID == cd.CmdSessionEnter {
		_, sessions, _ := cd.ParseSessionBody(c.Body)
		log.Debug().Msgf("session=%d enter", sessions[0])
	} else if header.CmdID == cd.CmdSessionLeave {
		_, sessions, _ := cd.ParseSessionBody(c.Body)
		sessionID := sessions[0]
		log.Debug().Msgf("session=%d leave", sessionID)
		playerMgr.DelPlayerCtx(sessionID)
	} else {
		_, sessions, body := cd.ParseSessionBody(c.Body)
		sessionID := sessions[0]
		c.SessionID = sessionID
		log.Debug().Msgf("session=%d cmd=%d bodylen=%d", sessionID, header.CmdID, len(body))

		// 首先检查这个session是否已经通过login了，如果是则直接转发给对应协程处理
		if playerMgr.IsInPlayStateBySession(sessionID) {
			playerMgr.ForwardToPlayerBySession(sessionID, c)
			return
		}

		// 然后看是否是login协议
		if header.CmdID != uint16(cmd.CLIENT_REQ_CMD_LOBBY_LOGIN_REQ) {
			log.Debug().Msgf("session=%d cmd=%d discard, shoud be login req at first", sessionID, header.CmdID)
			return
		}

		// 最后看这个accountID是否有正在执行的login事务
		// 首先要解包拿到accountID
		accountID, _, err := parseLoginReq(body)
		if err != nil {
			log.Error().Msgf("session=%d login unmarshal failed: %s", sessionID, err.Error())
			return
		}
		log.Debug().Msgf("session=%d account=%d incoming login req", sessionID, accountID)
		if loginMgr.IsInLoginState(accountID) {
			// login事务具备原子性，所以直接拒绝掉，错误码应该是类似"一会儿再重试"这种
			log.Debug().Msgf("account=%d has login trans now, just refuse", accountID)
			if pkt := makeLoginRsp(sessionID, csv.ERRCODE_LOBBY_LOGIN_PENDING, nil); pkt != nil {
				conn.Write(pkt)
			}
			return
		}

		// 看这个accountID对应的数据是否已经在dbcache中
		// 为这个account产生一个login的事务
		data, ok := dbCache.Load(accountID)
		if ok {
			log.Debug().Msgf("account=%d in dbcache", accountID)
			loginMgr.NewLoginTrans(sessionID, accountID, data, sigLogin)
		} else {
			loginMgr.NewLoginTrans(sessionID, accountID, nil, sigLogin)
		}
	}
}

func dispatchLoginSignal(c *loginCmd, conn net.Conn, sigMain chan *pd.PlayerCmd) {
	// 删除一个login事务登记
	loginMgr.DelLoginTrans(c.AccountID)

	log.Debug().Msgf("login trans complete: session=%d account=%d result=%d", c.SessionID, c.AccountID, c.Result)
	if c.Result != 0 {
		if pkt := makeLoginRsp(c.SessionID, c.Result, nil); pkt != nil {
			conn.Write(pkt)
		}
		return
	}

	// 有一个session的login事务成功完成了，我们需要先检查
	// 是否有相同accountID的session存在，如果有则踢掉这个session，并复用之前的这个协程
	// 然后新建一个player的协程给这个session用
	result := c.Result
	if playerMgr.IsInPlayStateByAccount(c.AccountID) {
		oldSessionID := playerMgr.ReplaceSession(c.SessionID, c.AccountID)
		log.Info().Msgf("session=%d account=%d kick the same account session=%d", c.SessionID, c.AccountID, oldSessionID)
		pkt := makeKickPkt(oldSessionID)
		conn.Write(pkt)
	} else {
		data, _ := c.PlayerData.ToDbPb()
		dbCache.Save(c.AccountID, data)
		playerMgr.NewPlayerCtx(c.SessionID, c.AccountID, c.PlayerData, sigMain)
	}
	log.Debug().Msgf("player in play state total count=%d", playerMgr.GetPlayerCount())

	// 给对应客户端发login rsp
	if pkt := makeLoginRsp(c.SessionID, result, c.PlayerData); pkt != nil {
		conn.Write(pkt)
	}
}

func dispatchMainSignal(c *pd.PlayerCmd, conn net.Conn) {
	switch c.Cmd {
	case pd.CmdPlayerData:
		pkt := c.Body
		conn.Write(pkt)
	case pd.CmdPlayerSave:
		data := c.Body
		log.Debug().Msgf("account=%d save data, data len=%d", c.AccountID, len(data))
		dbCache.Save(c.AccountID, data)
	case pd.CmdPlayerForward:
		// 这个是battle发过来的包，或是其他进程通过RPC调用过来的包
		// 这种包需要派发到player协程中去处理
		log.Debug().Msgf("account=%d has a forward request, data len=%d", c.AccountID, len(c.Body))
		if playerMgr.IsInPlayStateByAccount(c.AccountID) {
			playerMgr.ForwardToPlayerByAccount(c.AccountID, c)
		}
	case pd.CmdPlayerUpdateData:
		// 这个需要修改player数据，所以player不在线需要写入暗邮箱中
		// 待这个player再次login时强制执行
		log.Debug().Msgf("account=%d has a get reward op to deal, data len=%d", c.AccountID, len(c.Body))
		if playerMgr.IsInPlayStateByAccount(c.AccountID) {
			playerMgr.ForwardToPlayerByAccount(c.AccountID, c)
		} else {
			trx, _ := dbPool.Begin()
			trx.Exec("INSERT INTO shadow_mailbox (account_id, binary1) VALUES (?, ?)", c.AccountID, c.Body)
			if err := trx.Commit(); err != nil {
				log.Error().Msgf("account=%d save shadow mail failed: %s", c.AccountID, err.Error())
			} else {
				log.Debug().Msgf("account=%d save shadow mail ok", c.AccountID)
			}
		}
	case pd.CmdPlayerExit:
		log.Debug().Msgf("account=%d exit", c.AccountID)
	}
}

func dispatchAdminSignal(c *adminCmd) {
	log.Debug().Msgf("account=%d admin request %v", c.AccountID, c)
	switch c.AdminEnum {
	case adminAddGoods:
		if playerMgr.IsInPlayStateByAccount(c.AccountID) {
			// 直接转发给player协程
			op := pd.NewOP()
			switch lobby.PlayerDataOpEnum(c.OpType) {
			case lobby.PlayerDataOpEnum_ADD_GOODS:
				op.JoinAddGoods(c.Param1, uint32(c.Param2))
			default:
				c.SigRet <- &pd.AdminRet{
					AccountID: c.AccountID,
					Result:    errors.New("unknown operation enum"),
				}
				return
			}
			data, err := proto.Marshal(op.ToDbProto())
			if err != nil {
				c.SigRet <- &pd.AdminRet{
					AccountID: c.AccountID,
					Result:    err,
				}
				return
			}
			playerCMD := &pd.PlayerCmd{
				Cmd:       pd.CmdPlayerUpdateData,
				AccountID: c.AccountID,
				Body:      data,
			}
			playerMgr.ForwardToPlayerByAccount(c.AccountID, playerCMD)
		} else {
			// 开启一个协程，将请求封装好，然后放入暗邮箱中
			go shadowMailRoutine(c)
		}
		c.SigRet <- &pd.AdminRet{
			AccountID: c.AccountID,
			Result:    nil,
		}
	case adminShowPlayerData:
		if playerMgr.IsInPlayStateByAccount(c.AccountID) {
			playerCmd := &pd.PlayerCmd{
				Cmd:         pd.CmdGetPlayerData,
				AccountID:   c.AccountID,
				AdminSigRet: c.SigRet,
			}
			playerMgr.ForwardToPlayerByAccount(c.AccountID, playerCmd)
		} else {
			go getPlayerData(c)
		}
	default:
		c.SigRet <- &pd.AdminRet{
			AccountID: c.AccountID,
			Result:    errors.New("unknown admin enum"),
		}
	}
}

func getPlayerData(c *adminCmd) {
	log.Debug().Msgf("accountID:%d getPlayerData routine begin", c.AccountID)
	defer func() {
		log.Debug().Msgf("accountID:%d getPlayerData routine end", c.AccountID)
	}()
	data, ok := dbCache.Load(c.AccountID)
	if ok {
		c.SigRet <- &pd.AdminRet{
			AccountID: c.AccountID,
			Data:      data,
			Result:    nil,
		}
	} else {
		data, exist, err := loadAccountFromDb(c.AccountID)
		if err != nil {
			log.Error().Msgf("load account from db failed, accountID: %d, err: %v", c.AccountID, err.Error())
			c.SigRet <- &pd.AdminRet{
				AccountID: c.AccountID,
				Result:    err,
			}
			return
		}
		if exist {
			c.SigRet <- &pd.AdminRet{
				AccountID: c.AccountID,
				Data:      data,
				Result:    nil,
			}
		} else {
			c.SigRet <- &pd.AdminRet{
				AccountID: c.AccountID,
				Result:    errors.New("account data not exist"),
			}
		}
	}
}

func startBusiness(lobbyID int, config cfg.LobbyConfig, conn net.Conn, ch chan<- string) {
	cd.SendMasterSet(conn)
	ch <- "ready"

	//信号相关处理
	isExit := false
	exitCount, lastCount, cycleCount := 0, 0, 0
	t := time.NewTimer(time.Millisecond * 200)
	sigC := make(chan os.Signal, 1)
	signal.Ignore(syscall.SIGPIPE)
	signalNotify(sigC)

	globalLobbyID = uint32(lobbyID)
	loginMgr = NewLoginMgr()
	playerMgr = NewPlayerMgr()
	sigConn := make(chan *pd.PlayerCmd, 3000)
	sigLogin := make(chan *loginCmd, 3000)
	sigMain := make(chan *pd.PlayerCmd, 3000)
	sigAdmin = make(chan *adminCmd, 10)
	go handleConn(conn, sigConn)

	singlePVE.Init(uint16(lobbyID), config, sigMain)
	mail.Init(config.MailService)
	codeRepair.Init(config.CodeRepairService)

	for {
		select {
		case c, _ := <-sigConn:
			if c.Cmd == pd.CmdConnLeave {
				ch <- "exit"
				return
			}
			dispatchConnSignal(c, conn, sigLogin)
		case c, _ := <-sigLogin:
			dispatchLoginSignal(c, conn, sigMain)
		case c, _ := <-sigMain:
			dispatchMainSignal(c, conn)
		case c, _ := <-sigAdmin:
			dispatchAdminSignal(c)
		case sig, _ := <-sigC:
			log.Debug().Msgf("handle signal = [%d] [%s]", sig, sig)
			if isSigUsr1(sig) {
				ch <- "exit"
				return
			}
			t.Reset(time.Millisecond * 200)
			playerMgr.killAll()
			signal.Stop(sigC)
			isExit = true
		case <-t.C:
			if isExit {
				t.Reset(time.Millisecond * 200)
			}

			if cycleCount > 5 && lastCount == exitCount {
				ch <- "exit"
				return
			}

			cycleCount++
			lastCount = exitCount
		}
	}
}
