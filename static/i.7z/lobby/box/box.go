package box

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"shared/csv"
	pb "shared/proto/client/portal"
	db "shared/proto/server/lobby"
	"time"
)

const (
	constMaxBoxNum       = 3
	constMaxKeyNum       = 8
	constIncrKeyDuration = time.Duration(30) * time.Minute
)

// Box define for player reward box info
type Box struct {
	keyNum         uint32
	refreshTime    time.Time
	otherBoxTypeID uint32
	boxTypeIDs     []uint32
}

// New player reward box
func New() *Box {
	return &Box{
		keyNum:      constMaxKeyNum,
		refreshTime: time.Now(),
	}
}

// Refresh box
func (boxSelf *Box) Refresh() (hasRefresh bool) {
	// refresh key
	now := time.Now()
	if boxSelf.keyNum < constMaxKeyNum && now.Sub(boxSelf.refreshTime).Minutes() >= 30 {
		hasRefresh = true
		for {
			boxSelf.keyNum++
			boxSelf.refreshTime = boxSelf.refreshTime.Add(constIncrKeyDuration)
			if boxSelf.keyNum >= constMaxKeyNum {
				boxSelf.refreshTime = now
				break
			}
			if now.Sub(boxSelf.refreshTime).Minutes() < 30 {
				break
			}
		}
	}
	// refresh item array
	if len(boxSelf.boxTypeIDs) < constMaxBoxNum && boxSelf.otherBoxTypeID > 0 {
		boxSelf.boxTypeIDs = append(boxSelf.boxTypeIDs, boxSelf.otherBoxTypeID)
		boxSelf.otherBoxTypeID = 0
		hasRefresh = true
	}
	return
}

// AddTypeID add one item into box
func (boxSelf *Box) AddTypeID(typeID uint32) error {
	_, ok := csv.TableCardBagMap[int64(typeID)]
	if !ok {
		err := fmt.Errorf("lobby box add item error %v not exist in csv.TableCardBagMap",
			typeID)
		log.Error().Msgf(err.Error())
		return err
	}
	boxSelf.otherBoxTypeID = typeID
	boxSelf.Refresh()
	return nil
}

// DelTypeID delete one item from box
func (boxSelf *Box) DelTypeID(typeID uint32) bool {
	if boxSelf.otherBoxTypeID == typeID {
		boxSelf.otherBoxTypeID = 0
		return true
	}
	index := -1
	for indexLocal, boxTypeID := range boxSelf.boxTypeIDs {
		if boxTypeID == typeID {
			index = indexLocal
			break
		}
	}
	if index < 0 {
		return false
	}
	boxSelf.boxTypeIDs = append(boxSelf.boxTypeIDs[:index], boxSelf.boxTypeIDs[index+1:]...)
	return true
}

// IsExist check item is exist in box
func (boxSelf *Box) IsExist(typeID uint32) bool {
	if typeID == 0 {
		return false
	}
	if boxSelf.otherBoxTypeID == typeID {
		return true
	}
	for _, one := range boxSelf.boxTypeIDs {
		if one == typeID {
			return true
		}
	}
	return false
}

// GetKeyNum ensure has refresh before
func (boxSelf *Box) GetKeyNum() uint32 {
	return boxSelf.keyNum
}

// DelKey and remark refresh time
func (boxSelf *Box) DelKey(num uint32) error {
	if num > boxSelf.GetKeyNum() {
		return fmt.Errorf("lobby box del key do not has enough keyNum has:%v want:%v",
			boxSelf.GetKeyNum(), num)
	}
	if boxSelf.GetKeyNum() == constMaxKeyNum {
		boxSelf.refreshTime = time.Now()
	}
	boxSelf.keyNum -= num
	return nil
}

// ToClientProto convert box struct to pb.LobbyBox
func (boxSelf *Box) ToClientProto() *pb.LobbyBox {
	refreshTimestamp := uint32(boxSelf.refreshTime.Unix())
	return &pb.LobbyBox{
		BoxTypeIDs:       boxSelf.boxTypeIDs,
		KeyNum:           &boxSelf.keyNum,
		OtherBoxTypeID:   &boxSelf.otherBoxTypeID,
		RefreshTimestamp: &refreshTimestamp,
	}
}

// ToDBProto convert box struct to db.DbPlayerBox
func (boxSelf *Box) ToDBProto() *db.DbPlayerBox {
	timeByte, err := boxSelf.refreshTime.MarshalText()
	if err != nil {
		log.Error().Msgf("lobby player box error marshall time error %v", err)
	}
	return &db.DbPlayerBox{
		KeyNum:      boxSelf.keyNum,
		Time:        string(timeByte),
		OtherTypeID: boxSelf.otherBoxTypeID,
		TypeIDs:     boxSelf.boxTypeIDs,
	}
}

// FromDBProto covert db.DbPlayerBox to box struct
func FromDBProto(boxDB *db.DbPlayerBox) *Box {
	refreshTime := time.Now()
	err := refreshTime.UnmarshalText([]byte(boxDB.GetTime()))
	if err != nil {
		log.Error().Msgf("lobby player box error unmarshal time error %v", err)
	}
	return &Box{
		keyNum:         boxDB.GetKeyNum(),
		otherBoxTypeID: boxDB.GetOtherTypeID(),
		boxTypeIDs:     boxDB.GetTypeIDs(),
		refreshTime:    refreshTime,
	}
}
