package config

import (
	bd "shared/mfxbasedef"
	redis "shared/mfxredisutil"
)

var (
	// 当前节点的域名信息
	App      string
	Server   string
	Division string
	// Redis连接池
	RedisPool *redis.RedisUtil
)

type LobbyConfig struct {
	Division          string             `xml:"division"`
	Loc               bd.Locator         `xml:"locator"`
	Mysql             bd.MysqlConnection `xml:"mysql"`
	Business          bd.EndPoint        `xml:"business"`
	Admin             bd.EndPoint        `xml:"admin"`
	RPC               bd.EndPoint        `xml:"rpc"`
	Shmpool           bd.ShmPoolConfig   `xml:"shmpool"`
	LogPath           string             `xml:"log_path"`
	LogLevel          string             `xml:"log_level"`
	Redis             bd.RedisConnection `xml:"redis"`
	MailService       string             `xml:"mail_service"`
	CodeRepairService string             `xml:"coderepair_service"`
}
