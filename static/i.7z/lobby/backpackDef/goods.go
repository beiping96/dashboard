package backpackDef

import (
	"errors"
	"fmt"
	csv "shared/csv"
	pb "shared/proto/client/portal"
	db "shared/proto/server/lobby"
)

// GoodsList desc some goods
type GoodsList struct {
	goodsList map[uint32]uint32
}

// ToClientProto proto convert
func (goodsList *GoodsList) ToClientProto() []*pb.BackpackGoods {
	var ans []*pb.BackpackGoods
	for i, v := range goodsList.goodsList {
		goodsTypeID := i
		goodsNum := v
		ansOne := &pb.BackpackGoods{
			GoodsTypeId: &goodsTypeID,
			GoodsNum:    &goodsNum,
		}
		ans = append(ans, ansOne)
	}
	return ans
}

// ToDbProto - convert GoodsList to []*db.DbPlayerGoods
func (goodsList GoodsList) ToDbProto() []*db.DbPlayerGoods {
	var ans []*db.DbPlayerGoods
	for goodsTypeID, goodsNum := range goodsList.goodsList {
		ansOne := db.DbPlayerGoods{}
		ansOne.GoodsTypeID = goodsTypeID
		ansOne.GoodsNum = goodsNum
		ans = append(ans, &ansOne)
	}
	return ans
}

// GoodsListFromDbProto - convert []*db.DbPlayerGoods to *GoodsList
func GoodsListFromDbProto(goodsListDb []*db.DbPlayerGoods) *GoodsList {
	goodsList := GoodsList{goodsList: make(map[uint32]uint32)}
	for _, goodsDb := range goodsListDb {
		goodsList.AddGoods(goodsDb.GetGoodsTypeID(), goodsDb.GetGoodsNum())
	}
	return &goodsList
}

// GetGoodsNum - get goodsNum from goodsTypeID
func (goodsList *GoodsList) GetGoodsNum(goodsTypeID uint32) uint32 {
	goodsNum, ok := goodsList.goodsList[goodsTypeID]
	if !ok {
		return 0
	}
	return goodsNum
}

// GetGoldsNum - get golds
func (goodsList *GoodsList) GetGoldsNum() uint32 {
	goldsNum, ok := goodsList.goodsList[csv.GOLDTYPE_TYPE_GOLD]
	if !ok {
		return 0
	}
	return goldsNum
}

// GetGemstoneNum - get gemstone
func (goodsList *GoodsList) GetGemstoneNum() uint32 {
	gemstoneNum, ok := goodsList.goodsList[csv.GOLDTYPE_TYPE_GEMSTONE]
	if !ok {
		return 0
	}
	return gemstoneNum
}

// DelGoods - del goods from GoodsList
func (goodsList *GoodsList) DelGoods(goodsTypeID uint32, goodsNum uint32) error {
	if goodsList.GetGoodsNum(goodsTypeID) < goodsNum {
		return errors.New("delGoods error, don't have enough goods")
	}
	goodsList.goodsList[goodsTypeID] -= goodsNum
	return nil
}

// DelGolds - del golds
func (goodsList *GoodsList) DelGolds(goldsNum uint32) error {
	if goodsList.GetGoldsNum() < goldsNum {
		return errors.New("delGolds error, don't have enough golds")
	}
	goodsList.goodsList[csv.GOLDTYPE_TYPE_GOLD] -= goldsNum
	return nil
}

// DelGemstone - del gemstone
func (goodsList *GoodsList) DelGemstone(GemstoneNum uint32) error {
	if goodsList.GetGemstoneNum() < GemstoneNum {
		return errors.New("delGolds error, don't have enough golds")
	}
	goodsList.goodsList[csv.GOLDTYPE_TYPE_GEMSTONE] -= GemstoneNum
	return nil
}

// AddGoods - add goods into GoodsList
func (goodsList *GoodsList) AddGoods(goodsTypeID uint32, goodsNum uint32) error {
	goodsList.goodsList[goodsTypeID] += goodsNum
	return nil
}

// AddGolds - add golds
func (goodsList *GoodsList) AddGolds(goldsNum uint32) error {
	goodsList.goodsList[csv.GOLDTYPE_TYPE_GOLD] += goldsNum
	return nil
}

// AddGemstone add gemstone
func (goodsList *GoodsList) AddGemstone(GemstoneNum uint32) error {
	goodsList.goodsList[csv.GOLDTYPE_TYPE_GEMSTONE] += GemstoneNum
	return nil
}

// String - achieve String interface
func (goodsList GoodsList) String() string {
	ans := "GoodsList:<"
	for goodsTypeID, goodsNum := range goodsList.goodsList {
		ans += fmt.Sprintf(" %v:%v ",
			goodsTypeID, goodsNum)
	}
	ans += ">"
	return ans
}
