package backpackDef

import (
	"fmt"
	pb "shared/proto/client/portal"
	db "shared/proto/server/lobby"
)

// Backpack - desc goodsList in playerData
type Backpack struct {
	goodsList *GoodsList
}

// ToClientProto proto convert
func (backpack *Backpack) ToClientProto() []*pb.BackpackGoods {
	return backpack.goodsList.ToClientProto()
}

// FromDbProto - convert *db.DbPlayerBackpack to *Backpack
func FromDbProto(backpackDb *db.DbPlayerBackpack) *Backpack {
	backpack := New()
	backpack.goodsList = GoodsListFromDbProto(backpackDb.GetGoodsList())
	return backpack
}

// ToDbProto - convert Backpack to *db.DbPlayerBackpack
func (backpack *Backpack) ToDbProto() *db.DbPlayerBackpack {
	backpackDb := db.DbPlayerBackpack{}
	backpackDb.GoodsList = backpack.goodsList.ToDbProto()
	return &backpackDb
}

// New create one empty backpack
func New() *Backpack {
	goodsList := GoodsList{goodsList: make(map[uint32]uint32)}
	goodsList.AddGolds(0)
	goodsList.AddGemstone(10000)
	goodsList.AddGoods(3001, 100)
	goodsList.AddGoods(3003, 600)
	goodsList.AddGoods(5001, 1000)
	goodsList.AddGoods(5002, 1000)
	goodsList.AddGoods(5003, 1000)
	goodsList.AddGoods(5051, 1000)
	goodsList.AddGoods(5052, 1000)
	goodsList.AddGoods(5053, 1000)
	return &Backpack{
		goodsList: &goodsList,
	}
}

// GetGoodsNum - get goodsNum from goodsTypeID
func (backpack Backpack) GetGoodsNum(goodsTypeID uint32) uint32 {
	return backpack.goodsList.GetGoodsNum(goodsTypeID)
}

// GetGoldsNum - get golds num
func (backpack Backpack) GetGoldsNum() uint32 {
	return backpack.goodsList.GetGoldsNum()
}

// GetGemstoneNum - get gemstone num
func (backpack Backpack) GetGemstoneNum() uint32 {
	return backpack.goodsList.GetGemstoneNum()
}

// DelGoods - del goods from backpack
func (backpack *Backpack) DelGoods(goodsTypeID uint32, goodsNum uint32) error {
	return backpack.goodsList.DelGoods(goodsTypeID, goodsNum)
}

// DelGolds - del golds
func (backpack *Backpack) DelGolds(goldsNum uint32) error {
	return backpack.goodsList.DelGolds(goldsNum)
}

// DelGemstone - del gemstones
func (backpack *Backpack) DelGemstone(GemstoneNum uint32) error {
	return backpack.goodsList.DelGemstone(GemstoneNum)
}

// AddGoods - add goods into backpack
func (backpack *Backpack) AddGoods(goodsTypeID uint32, goodsNum uint32) error {
	return backpack.goodsList.AddGoods(goodsTypeID, goodsNum)
}

// AddGolds - add golds
func (backpack *Backpack) AddGolds(goldsNum uint32) error {
	return backpack.goodsList.AddGolds(goldsNum)
}

// AddGemstone - add gemstone
func (backpack *Backpack) AddGemstone(GemstoneNum uint32) error {
	return backpack.goodsList.AddGemstone(GemstoneNum)
}

// String - achieve String interface
func (backpack Backpack) String() string {
	ans := "Backpack:<"
	ans += fmt.Sprintln(backpack.goodsList)
	ans += ">"
	return ans
}
