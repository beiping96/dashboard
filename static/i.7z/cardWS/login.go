package main

import (
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/gorilla/websocket"
	"github.com/rs/zerolog/log"
	"net"
	"shared/mfxconn"
	"shared/mfxlocalregistry"
	pb "shared/proto/client/portal"
	cmd "shared/proto/share/command"
	"time"
)

const loginWait = time.Duration(10) * time.Second

var accountServiceAddr string

func accountServiceAddrInit(accountService string) {
	accountIP, port, _, err := mfxlocalregistry.SelectEndpoint(accountService)
	if err != nil {
		panic(fmt.Sprintf("load %v account service error %v", accountService, err))
	}
	accountServiceAddr = fmt.Sprintf("%s:%d", accountIP, port)
}

func accountServiceAddrUpdate(accountService string) {
	ticker := time.Tick(time.Duration(30) * time.Second)
	for {
		log.Debug().Msgf("use account service %v", accountServiceAddr)
		<-ticker
		accountIP, port, _, err := mfxlocalregistry.SelectEndpoint(accountService)
		if err != nil {
			log.Error().Msgf("load %v account service error %v", accountService, err)
			continue
		}
		accountServiceAddr = fmt.Sprintf("%s:%d", accountIP, port)
	}
}

func login(wsConn *websocket.Conn) (tcpConn net.Conn, loginSuccess bool) {
	// read bind account req
	wsConn.SetReadDeadline(time.Now().Add(loginWait))
	messageType, message, err := wsConn.ReadMessage()
	if err != nil {
		log.Debug().Msgf("wsConn readMessage bind account %v", err)
		return
	}
	if messageType != websocket.BinaryMessage {
		log.Debug().Msgf("wsConn readMessage bind account messageType %v", messageType)
		return
	}
	if len(message) < mfxconn.LengthOfHeader {
		log.Debug().Msgf("wsConn readMessage bind account size %v", len(message))
		return
	}
	// ensure is bind account
	hdr := mfxconn.ParseHeader(message[:mfxconn.LengthOfHeader])
	if hdr.CmdID != uint16(cmd.CLIENT_REQ_CMD_BIND_ACCOUNT_REQ) {
		log.Debug().Msgf("wsConn readMessage bind account cmdID %v", hdr.CmdID)
		return
	}
	// connect to account server
	accountTCPConn, err := net.Dial("tcp", accountServiceAddr)
	if err != nil {
		log.Error().Msgf("webSocket try to connect account service %v error %v",
			accountServiceAddr, err)
		return
	}
	defer accountTCPConn.Close()
	// send bind account to account service
	accountTCPConn.SetWriteDeadline(time.Now().Add(loginWait))
	_, err = accountTCPConn.Write(message)
	if err != nil {
		log.Error().Msgf("webSocket try send message to account service %v error %v",
			accountServiceAddr, err)
		return
	}
	// wait account service reply
	message = make([]byte, mfxconn.LengthOfMaxPacket)
	accountTCPConn.SetReadDeadline(time.Now().Add(loginWait))
	_, err = accountTCPConn.Read(message)
	if err != nil {
		log.Error().Msgf("webSocket try read message from account service %v error %v",
			accountServiceAddr, err)
		return
	}
	// parse account service reply
	hdr = mfxconn.ParseHeader(message[:mfxconn.LengthOfHeader])
	message = message[:mfxconn.LengthOfHeader+hdr.BodyLen]
	// write account service reply to webSocket
	wsConn.SetWriteDeadline(time.Now().Add(writeWait))
	err = wsConn.WriteMessage(websocket.BinaryMessage, message)
	if err != nil {
		log.Error().Msgf("webSocket write account service reply to webSocket error %v",
			err)
		return
	}
	// ensure account service has the success reply
	if hdr.CmdID != uint16(cmd.CLIENT_RSP_CMD_BIND_ACCOUNT_RSP) {
		log.Error().Msgf("webSocket got the reply from account service is unknown %v",
			hdr)
		return
	}
	body := message[mfxconn.LengthOfHeader:]
	accountRsp := pb.BindAccountRsp{}
	err = proto.Unmarshal(body, &accountRsp)
	if err != nil {
		log.Error().Msgf("webSocket got the reply from account service unmarshal error %v",
			err)
		return
	}
	if accountRsp.GetResult() != 0 {
		log.Debug().Msgf("wsConn readMessage bind account result %v", accountRsp.GetResult())
		return
	}
	lobbyAddr := fmt.Sprintf("%s:%d",
		accountRsp.GetLobbyAddr(), accountRsp.GetLobbyPort())
	// read login lobby req
	wsConn.SetReadDeadline(time.Now().Add(loginWait))
	messageType, message, err = wsConn.ReadMessage()
	if err != nil {
		log.Debug().Msgf("wsConn readMessage lobby login %v", err)
		return
	}
	if messageType != websocket.BinaryMessage {
		log.Debug().Msgf("wsConn readMessage lobby login messageType %v", messageType)
		return
	}
	if len(message) < mfxconn.LengthOfHeader {
		log.Debug().Msgf("wsConn readMessage lobby login size %v", len(message))
		return
	}
	// ensure is lobby login
	hdr = mfxconn.ParseHeader(message[:mfxconn.LengthOfHeader])
	if hdr.CmdID != uint16(cmd.CLIENT_REQ_CMD_LOBBY_LOGIN_REQ) {
		log.Debug().Msgf("wsConn readMessage lobby login cmdID %v", hdr.CmdID)
		return
	}
	// connect to lobby server
	tcpConn, err = net.Dial("tcp", lobbyAddr)
	if err != nil {
		log.Error().Msgf("webSocket try to connect lobby service %v error %v",
			lobbyAddr, err)
		return
	}
	// send login req to lobby
	tcpConn.SetWriteDeadline(time.Now().Add(loginWait))
	_, err = tcpConn.Write(message)
	if err != nil {
		log.Error().Msgf("webSocket try send message to lobby service %v error %v",
			lobbyAddr, err)
		return
	}
	// wait lobby reply
	tcpConn.SetReadDeadline(time.Now().Add(loginWait))
	message = make([]byte, mfxconn.LengthOfMaxPacket)
	_, err = tcpConn.Read(message)
	if err != nil {
		log.Error().Msgf("webSocket try read message from lobby service %v error %v",
			lobbyAddr, err)
		return
	}
	// parse lobby reply
	hdr = mfxconn.ParseHeader(message[:mfxconn.LengthOfHeader])
	message = message[:mfxconn.LengthOfHeader+hdr.BodyLen]
	// write lobby reply to webSocket
	wsConn.SetWriteDeadline(time.Now().Add(writeWait))
	err = wsConn.WriteMessage(websocket.BinaryMessage, message)
	if err != nil {
		log.Error().Msgf("webSocket write lobby service reply to webSocket error %v",
			err)
		return
	}
	// ensure lobby service has success reply
	if hdr.CmdID != uint16(cmd.CLIENT_RSP_CMD_LOBBY_LOGIN_RSP) {
		log.Error().Msgf("webSocket got the reply from lobby service is unknown %v",
			hdr)
		return
	}
	body = message[mfxconn.LengthOfHeader:]
	lobbyRsp := pb.LobbyLoginRsp{}
	err = proto.Unmarshal(body, &lobbyRsp)
	if err != nil {
		log.Error().Msgf("webSocket got the reply from lobby service unmarshal error %v",
			err)
		return
	}
	if lobbyRsp.GetResult() != 0 {
		log.Debug().Msgf("wsConn readMessage lobby login result %v", lobbyRsp.GetResult())
		return
	}
	loginSuccess = true
	return
}
