package main

import (
	"github.com/gorilla/websocket"
	"net"
	"time"
)

func joinSession(wsConn *websocket.Conn) (tcpConn net.Conn, joinSuccess bool) {
	time.Sleep(time.Duration(10) * time.Second)
	return
}
