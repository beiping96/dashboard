package main

import (
	"fmt"
	"os"
)

func printHelp() {
	fmt.Println("cardWebSocket")
	fmt.Println("    cardWS start cardWS.xml")
}

func main() {
	if len(os.Args) < 2 {
		printHelp()
		return
	}
	switch os.Args[1] {
	case "start":
		if len(os.Args) < 3 {
			printHelp()
			return
		}
		err := start(os.Args[2])
		if err != nil {
			panic(fmt.Sprintf("start failed %v", err))
		}
	default:
		printHelp()
	}
}
