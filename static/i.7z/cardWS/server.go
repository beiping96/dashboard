package main

import (
	"encoding/xml"
	"fmt"
	"github.com/gorilla/websocket"
	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
	echoLog "github.com/labstack/gommon/log"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"net/http"
	"net/url"
	bd "shared/mfxbasedef"
	"shared/mfxconn"
	lr "shared/mfxlocalregistry"
	lu "shared/mfxlogutil"
)

// Config desc cardWS.xml
type Config struct {
	Division       string     `xml:"division"`
	Loc            bd.Locator `xml:"locator"`
	ListenPort     string     `xml:"listen_port"`
	LogPath        string     `xml:"log_path"`
	LogLevel       string     `xml:"log_level"`
	AccountService string     `xml:"account_service"`
}

func start(configFile string) error {
	// config
	configSource, err := ioutil.ReadFile(configFile)
	if err != nil {
		return fmt.Errorf("read config file error file:%v",
			configFile)
	}
	config := &Config{}
	err = xml.Unmarshal(configSource, config)
	if err != nil {
		return fmt.Errorf("unmarshal config file error file:%v, error:%v",
			configFile, err)
	}
	// locator
	lr.SetLocator(config.Loc.Ep.Ip, config.Loc.Ep.Port)
	err = lr.QueryRegistry()
	if err != nil {
		return fmt.Errorf("query registry from %s:%s failed, %v",
			config.Loc.Ep.Ip, config.Loc.Ep.Port, err)
	}
	err = lr.StartQueryLoop(config.Loc.RefreshInterval)
	if err != nil {
		return fmt.Errorf("query registry from %s:%s failed, %v",
			config.Loc.Ep.Ip, config.Loc.Ep.Port, err)
	}
	// log
	fmt.Printf("log path=%s, level=%s\n",
		config.LogPath, config.LogLevel)
	lu.SetupLogPath(config.LogPath)
	lu.SetupLogLevel(config.LogLevel)
	// search account service
	accountServiceAddrInit(config.AccountService)
	go accountServiceAddrUpdate(config.AccountService)
	// echo
	e := echo.New()
	e.Use(middleware.Logger())
	switch config.LogLevel {
	case "debug":
		e.Logger.SetLevel(echoLog.DEBUG)
	case "info":
		e.Logger.SetLevel(echoLog.INFO)
	case "warn":
		e.Logger.SetLevel(echoLog.WARN)
	default:
		e.Logger.SetLevel(echoLog.ERROR)
	}
	e.Use(middleware.Recover())
	e.GET("/wsCardLobby", wsCardLobby)
	e.GET("/wsCardSession", wsCardSession)
	err = e.Start(config.ListenPort)
	if err != nil {
		return fmt.Errorf("server %v start error %v",
			config.ListenPort, err)
	}
	return nil
}

var upgrader = websocket.Upgrader{
	ReadBufferSize:  mfxconn.LengthOfMaxPacket,
	WriteBufferSize: mfxconn.LengthOfMaxPacket,
	CheckOrigin: func(req *http.Request) bool {
		origin := req.Header["Origin"]
		if len(origin) == 0 {
			return true
		}
		u, err := url.Parse(origin[0])
		if err != nil {
			return false
		}
		return u.Hostname() == req.Host
	},
}

func wsCardLobby(c echo.Context) error {
	// ensure webSocket
	wsConn, err := upgrader.Upgrade(c.Response(), c.Request(), nil)
	if err != nil {
		log.Error().Msgf("ws handle ip:%v origin:%v host:%v error %v",
			c.Request().RemoteAddr, c.Request().Header["Origin"], c.Request().Host, err)
		return err
	}
	log.Debug().Msgf("wsCardLobbyUp %v", c.Request().RemoteAddr)
	// deal login
	tcpConn, ok := login(wsConn)
	if !ok {
		log.Debug().Msgf("wsCardLobby closed %v", c.Request().RemoteAddr)
		wsConn.Close()
		return nil
	}
	// register client
	newClient := &client{
		wsConn:  wsConn,
		tcpConn: tcpConn,
	}
	// running write webSocket
	go newClient.writeWS()
	// read webSocket in this goroutine
	newClient.readWS()
	return nil
}

func wsCardSession(c echo.Context) error {
	// ensure webSocket
	wsConn, err := upgrader.Upgrade(c.Response(), c.Request(), nil)
	if err != nil {
		log.Error().Msgf("ws handle ip:%v origin:%v host:%v error %v",
			c.Request().RemoteAddr, c.Request().Header["Origin"], c.Request().Host, err)
		return err
	}
	log.Debug().Msgf("wsCardSession %v", c.Request().RemoteAddr)
	// deal join
	tcpConn, ok := joinSession(wsConn)
	if !ok {
		log.Debug().Msgf("wsCardSession closed %v", c.Request().RemoteAddr)
		wsConn.Close()
		return nil
	}
	// register client
	newClient := &client{
		wsConn:  wsConn,
		tcpConn: tcpConn,
	}
	// running write webSocket
	go newClient.writeWS()
	// read webSocket in this goroutine
	newClient.readWS()
	return nil
}
