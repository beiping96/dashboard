package main

import (
	"github.com/gorilla/websocket"
	"github.com/rs/zerolog/log"
	"net"
	"shared/mfxconn"
	"time"
)

const writeWait = 10 * time.Second

type client struct {
	// The websocket connection.
	wsConn *websocket.Conn
	// The server connection.
	tcpConn net.Conn
}

func (c *client) readWS() {
	log.Debug().Msgf("readWS start %v", c.wsConn.RemoteAddr())
	// defer close
	defer func() {
		log.Debug().Msgf("readWS stop %v", c.wsConn.RemoteAddr())
		c.wsConn.Close()
		c.tcpConn.Close()
	}()
	// service
	for {
		messageType, message, err := c.wsConn.ReadMessage()
		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				log.Debug().Msgf("readWS webSocket is closed: %v", err)
				break
			}
			log.Error().Msgf("readWS webSocket error: %v", err)
			break
		}
		if messageType != websocket.BinaryMessage {
			log.Error().Msgf("readWS webSocket error, messageType not binaryMessage %v",
				c.wsConn.RemoteAddr())
			break
		}
		if len(message) < mfxconn.LengthOfHeader {
			log.Error().Msgf("readWS webSocket error, binary size not allowed %v", len(message))
			break
		}
		_, err = c.tcpConn.Write(message)
		if err != nil {
			log.Error().Msgf("readWS webSocket error, tcpConn write error %v", err)
			break
		}
	}
}

func (c *client) writeWS() {
	log.Debug().Msgf("writeWS start %v", c.wsConn.RemoteAddr())
	defer func() {
		log.Debug().Msgf("writeWS stop %v", c.wsConn.RemoteAddr())
		c.wsConn.Close()
		c.tcpConn.Close()
	}()
	handler := func(conn net.Conn, hdr []byte, body []byte) {
		log.Debug().Msgf("writeWS catch %v hdrLen:%v, bodyLen:%v",
			c.wsConn.RemoteAddr(), len(hdr), len(body))
		binaryMessage := append(hdr, body...)
		if len(body) == 0 {
			binaryMessage = make([]byte, len(hdr))
			copy(binaryMessage, hdr)
		}
		c.wsConn.SetWriteDeadline(time.Now().Add(writeWait))
		err := c.wsConn.WriteMessage(websocket.BinaryMessage, binaryMessage)
		if err != nil {
			log.Error().Msgf("writeWS WriteMessage error %v", err)
		}
	}
	err := mfxconn.HandleStream(c.tcpConn, handler)
	if err != nil {
		log.Error().Msgf("writeWS read tcpConn error %v", err)
	}
}
