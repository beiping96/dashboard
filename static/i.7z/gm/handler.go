package main

import (
	"encoding/json"
	"errors"
	"github.com/labstack/echo"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"net/http"
	bd "shared/mfxbasedef"
	"shared/mfxlocalregistry"
	"shared/proto/server/lobby"
	"strconv"
	"strings"
)

type adminWebRsp struct {
	Result uint   `json:"result"`
	Error  string `json:"error"`
	Msg    string `json:"msg"`
}

const (
	postContentType = "application/x-www-form-urlencoded"
)

func getAllRegistryServers(c echo.Context) error {
	rsp, err := http.Post(registryAdminAddr, postContentType, strings.NewReader("op=query_from_db"))
	if err != nil {
		return err
	}
	defer rsp.Body.Close()
	body, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return err
	}

	var rspData adminWebRsp

	err = json.Unmarshal(body, &rspData)
	if err != nil {
		return err
	}

	if rspData.Result != 0 {
		return errors.New(rspData.Error)
	}

	msg := strings.Split(rspData.Msg, "|")

	var obj json.RawMessage
	var servers []bd.RegistryServerConfig
	var services []bd.RegistryServiceConfig
	err1 := json.Unmarshal([]byte(msg[0]), &obj)
	err2 := json.Unmarshal(obj, &servers)
	err3 := json.Unmarshal([]byte(msg[1]), &obj)
	err4 := json.Unmarshal(obj, &services)
	if err1 != nil || err2 != nil || err3 != nil || err4 != nil {
		return errors.New("unmarshal failed")
	}

	//var servers

	return c.JSON(http.StatusOK, map[string]interface{}{
		"result": rspData.Result,
		"error":  rspData.Error,
		"msg": map[string]interface{}{
			"servers":  servers,
			"services": services,
		},
	})
}

func queryDeviceBindInfo(c echo.Context) error {
	deviceId := c.QueryParam("device_id")
	rsp, err := http.Post(accountAdminAddr, postContentType, strings.NewReader("op=see&device_id="+deviceId))
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	defer rsp.Body.Close()
	body, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}

	log.Debug().Msg(string(body))

	return c.String(http.StatusOK, string(body))
}

func bindLobby(c echo.Context) error {
	deviceId := c.QueryParam("device_id")
	rsp, err := http.Post(accountAdminAddr, postContentType, strings.NewReader("op=bind&device_id="+deviceId))
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	defer rsp.Body.Close()
	body, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	return c.String(http.StatusOK, string(body))
}

func unbindLobby(c echo.Context) error {
	deviceId := c.FormValue("device_id")
	rsp, err := http.Post(accountAdminAddr, postContentType, strings.NewReader("op=unbind&device_id="+deviceId))
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	defer rsp.Body.Close()
	body, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	return c.String(http.StatusOK, string(body))
}

func queryRecommendLobby(c echo.Context) error {
	rsp, err := http.Post(accountAdminAddr, postContentType, strings.NewReader("op=seerecomma"))
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	defer rsp.Body.Close()
	body, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	log.Debug().Msgf("recommend: %v", body)
	return c.String(http.StatusOK, string(body))
}

func changeRecommendLobby(c echo.Context) error {
	lobbyId := c.FormValue("lobby_id")
	rsp, err := http.Post(accountAdminAddr, postContentType, strings.NewReader("op=recomma&lobby_id="+lobbyId))
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	defer rsp.Body.Close()
	body, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	return c.String(http.StatusOK, string(body))
}

func accountChangeBindLobby(c echo.Context) error {
	deviceId := c.FormValue("device_id")
	newLobbyId := c.FormValue("lobby_id")
	rsp, err := http.Post(accountAdminAddr, postContentType, strings.NewReader("op=chbind&device_id="+deviceId+"&lobby_id="+newLobbyId))

	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	defer rsp.Body.Close()
	body, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	return c.String(http.StatusOK, string(body))
}

func addRegistryServer(c echo.Context) error {
	useAgent, err1 := strconv.ParseUint(c.FormValue("use_agent"), 10, 32)
	nodeStatus, err2 := strconv.ParseUint(c.FormValue("node_status"), 10, 32)
	serviceStatus, err3 := strconv.ParseUint(c.FormValue("service_status"), 10, 32)
	if err1 != nil || err2 != nil || err3 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}

	rsc := &bd.RegistryServerConfig{
		App:           c.FormValue("app"),
		Server:        c.FormValue("server"),
		Division:      c.FormValue("division"),
		Node:          c.FormValue("node"),
		UseAgent:      uint32(useAgent),
		NodeStatus:    uint32(nodeStatus),
		ServiceStatus: uint32(serviceStatus),
	}
	content, err1 := json.Marshal(rsc)
	if err1 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}
	rsp, err1 := http.Post(registryAdminAddr, postContentType, strings.NewReader("op=add&type=server"+"&content="+string(content)))
	if err1 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}
	defer rsp.Body.Close()
	body, _ := ioutil.ReadAll(rsp.Body)
	return c.String(http.StatusOK, string(body))
}

func addRegistryService(c echo.Context) error {
	servicePort, err1 := strconv.Atoi(c.FormValue("service_port"))
	rpcPort, err2 := strconv.Atoi(c.FormValue("rpc_port"))
	adminPort, err3 := strconv.Atoi(c.FormValue("admin_port"))
	if err1 != nil || err2 != nil || err3 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}

	rsc := &bd.RegistryServiceConfig{
		App:         c.FormValue("app"),
		Server:      c.FormValue("server"),
		Division:    c.FormValue("division"),
		Node:        c.FormValue("node"),
		Service:     c.FormValue("service"),
		ServiceIp:   c.FormValue("service_ip"),
		ServicePort: int32(servicePort),
		AdminPort:   int32(adminPort),
		RpcPort:     int32(rpcPort),
	}
	content, err1 := json.Marshal(rsc)
	if err1 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}
	rsp, err1 := http.Post(registryAdminAddr, postContentType, strings.NewReader("op=add&type=service&content="+string(content)))
	if err1 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}
	defer rsp.Body.Close()
	body, _ := ioutil.ReadAll(rsp.Body)
	return c.String(http.StatusOK, string(body))
}

func editRegistryServer(c echo.Context) error {
	useAgent, err1 := strconv.ParseUint(c.FormValue("use_agent"), 10, 32)
	nodeStatus, err2 := strconv.ParseUint(c.FormValue("node_status"), 10, 32)
	serviceStatus, err3 := strconv.ParseUint(c.FormValue("service_status"), 10, 32)
	if err1 != nil || err2 != nil || err3 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}

	rsc := &bd.RegistryServerConfig{
		App:           c.FormValue("app"),
		Server:        c.FormValue("server"),
		Division:      c.FormValue("division"),
		Node:          c.FormValue("node"),
		UseAgent:      uint32(useAgent),
		NodeStatus:    uint32(nodeStatus),
		ServiceStatus: uint32(serviceStatus),
	}
	content, err1 := json.Marshal(rsc)
	if err1 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}
	rsp, err1 := http.Post(registryAdminAddr, postContentType, strings.NewReader("op=edit&type=server"+"&content="+string(content)))
	if err1 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}
	defer rsp.Body.Close()
	body, _ := ioutil.ReadAll(rsp.Body)
	return c.String(http.StatusOK, string(body))
}

func editRegistryService(c echo.Context) error {
	servicePort, err1 := strconv.Atoi(c.FormValue("service_port"))
	rpcPort, err2 := strconv.Atoi(c.FormValue("rpc_port"))
	adminPort, err3 := strconv.Atoi(c.FormValue("admin_port"))
	if err1 != nil || err2 != nil || err3 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}

	rsc := &bd.RegistryServiceConfig{
		App:         c.FormValue("app"),
		Server:      c.FormValue("server"),
		Division:    c.FormValue("division"),
		Node:        c.FormValue("node"),
		Service:     c.FormValue("service"),
		ServiceIp:   c.FormValue("service_ip"),
		ServicePort: int32(servicePort),
		AdminPort:   int32(adminPort),
		RpcPort:     int32(rpcPort),
	}
	content, err1 := json.Marshal(rsc)
	if err1 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}
	rsp, err1 := http.Post(registryAdminAddr, postContentType, strings.NewReader("op=edit&type=service&content="+string(content)))
	if err1 != nil {
		return c.JSON(http.StatusInternalServerError, err1)
	}
	defer rsp.Body.Close()
	body, _ := ioutil.ReadAll(rsp.Body)
	return c.String(http.StatusOK, string(body))
}

func deleteRegistry(c echo.Context) error {
	t := c.FormValue("type")
	app := c.FormValue("app")
	server := c.FormValue("server")
	div := c.FormValue("division")
	node := c.FormValue("node")
	service := c.FormValue("service")
	str := "op=del&type=" + t + "&app=" + app + "&server=" + server + "&division=" + div + "&node=" + node + "&service=" + service
	rsp, err := http.Post(registryAdminAddr, postContentType, strings.NewReader(str))
	if err != nil {
		return c.JSON(http.StatusInternalServerError, err)
	}
	defer rsp.Body.Close()
	body, _ := ioutil.ReadAll(rsp.Body)

	return c.String(http.StatusOK, string(body))
}

func getAccountInfo(c echo.Context) error {
	lobbyID := c.QueryParam("lobby_id")
	accountID := c.QueryParam("acc_id")
	ip, _, adminPort, _, err := mfxlocalregistry.QueryEndpoint("card", "lobby", "card.lobby."+lobbyID)
	if err != nil {
		return c.String(http.StatusOK, `{"result": 1, "error": "lobby not found"}`)
	}
	lobbyAdminAddr := "http://" + ip + ":" + strconv.FormatInt(int64(adminPort), 10) + "/admin"
	rsp, err := http.Post(lobbyAdminAddr, postContentType, strings.NewReader("op=see_acc&acc_id="+accountID))
	if err != nil {
		return err
	}
	defer rsp.Body.Close()
	body, _ := ioutil.ReadAll(rsp.Body)
	adminRsp := adminWebRsp{}
	err = json.Unmarshal(body, &adminRsp)
	if err != nil {
		return err
	}
	if adminRsp.Result != 0 {
		return c.String(http.StatusInternalServerError, "")
	}
	data := lobby.DbPlayerData{}
	err = json.Unmarshal([]byte(adminRsp.Msg), &data)
	if err != nil {
		return err
	}

	//log.Debug().Msgf("rsp is : %v", adminRsp)
	return c.JSON(http.StatusOK, map[string]interface{}{
		"result": 0,
		"msg":    data,
	})
}
