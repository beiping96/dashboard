package main

import (
	"encoding/json"
	"fmt"
	"github.com/labstack/echo"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"math/rand"
	"net/http"
	"net/url"
	"shared/mfxlocalregistry"
	"strconv"
	"strings"
)

func testNotice(c echo.Context) error {
	content := "公告测试 ===== "
	content += fmt.Sprintf("随机数 : %v", rand.Intn(999999))
	err := writeNotice(content)
	result := "all content "
	for _, content := range readNotice() {
		result += fmt.Sprintf("[id:%v ,info:%v, timestamp:%v]", content.UID, content.Info, content.Timestamp)
	}
	return c.String(http.StatusOK, fmt.Sprintf("%v err : %v", result, err))
}

func getNotice(c echo.Context) error {
	contents := readNotice()
	var notices = make([]AdminContentInfo, len(contents))
	for i, content := range contents {
		notices[i] = *content
	}

	data := map[string]interface{}{
		"result": 0,
		"msg":    notices,
	}
	return c.JSON(http.StatusOK, data)
}

func updateNotice(c echo.Context) error {
	content := c.FormValue("content")
	err := writeNotice(content)
	data := map[string]interface{}{
		"result": 0,
		"error":  "0",
		"msg":    "",
	}
	if err != nil {
		data["result"] = 1
		data["error"] = err.Error()
	}
	return c.JSON(http.StatusOK, data)
}

func deleteContent(c echo.Context) error {
	id := c.FormValue("id")
	uid, err := strconv.Atoi(id)
	if err != nil {
		return c.String(http.StatusInternalServerError, err.Error())
	}
	err = deleteNotice(uid)
	if err != nil {
		return c.String(http.StatusInternalServerError, err.Error())
	}
	return c.JSON(http.StatusOK, map[string]interface{}{
		"result": 0,
	})
}

// AdminReadRsp Admin read all content
type AdminReadRsp struct {
	Result  int                `json:"result"`
	Error   string             `json:"error"`
	Content []AdminContentInfo `json:"admin_content"`
}

// AdminContentInfo define for admin content info
type AdminContentInfo struct {
	UID       int    `json:"id"`
	Timestamp int    `json:"timestamp"`
	Info      string `json:"info"`
}

func readNotice() []*AdminContentInfo {
	noticeURL := getNoticeURL()
	if noticeURL == "" {
		return nil
	}
	rsp, err := http.Get(noticeURL + "/admin_read_notice")
	if err != nil {
		log.Error().Msgf("notice read notice error : %v", err)
		return nil
	}
	defer rsp.Body.Close()
	jsonByte, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		log.Error().Msgf("notice read notice readBody error : %v", err)
		return nil
	}
	readRsp := AdminReadRsp{}
	err = json.Unmarshal(jsonByte, &readRsp)
	if err != nil {
		log.Error().Msgf("notice read notice jsonUnmarshal error : %v", err)
		return nil
	}
	if readRsp.Result != 0 {
		log.Error().Msgf("notice read notice result!=0 err : %v", readRsp.Error)
		return nil
	}
	result := []*AdminContentInfo{}
	for _, contentInfo := range readRsp.Content {
		localContentInfo := contentInfo
		localInfo, err := url.QueryUnescape(contentInfo.Info)
		if err != nil {
			log.Error().Msgf("notice read notice url decode %v error %v",
				contentInfo, err)
		}
		localContentInfo.Info = localInfo
		result = append(result, &localContentInfo)
	}
	return result
}

// AdminDeleteRsp Admin delete notice rsp
type AdminDeleteRsp struct {
	Result int    `json:"result"`
	Error  string `json:"error"`
}

func deleteNotice(contentUID int) error {
	noticeURL := getNoticeURL()
	if noticeURL == "" {
		return nil
	}
	rsp, err := http.Post(noticeURL+"/admin_delete_notice", "application/x-www-form-urlencoded",
		strings.NewReader(fmt.Sprintf("contentUID=%v", contentUID)))
	if err != nil {
		return fmt.Errorf("notice delete notice post error %v", err)
	}
	defer rsp.Body.Close()
	jsonByte, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return fmt.Errorf("notice delete notice read rsp error %v", err)
	}
	deleteRsp := AdminDeleteRsp{}
	err = json.Unmarshal(jsonByte, &deleteRsp)
	if err != nil {
		return fmt.Errorf("notice delete notice jsonUnmarshal error : %v", err)

	}
	if deleteRsp.Result != 0 {
		return fmt.Errorf("notice delete notice result!=0 err : %v", deleteRsp.Error)
	}
	return nil
}

// AdminWriteRsp Admin write notice rsp
type AdminWriteRsp struct {
	Result int    `json:"result"`
	Error  string `json:"error"`
}

func writeNotice(content string) error {
	noticeURL := getNoticeURL()
	if noticeURL == "" {
		return nil
	}
	rsp, err := http.Post(noticeURL+"/admin_write_notice", "application/x-www-form-urlencoded",
		strings.NewReader(fmt.Sprintf("content=%v", url.QueryEscape(content))))
	if err != nil {
		return fmt.Errorf("notice write notice post error %v", err)
	}
	defer rsp.Body.Close()
	jsonByte, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return fmt.Errorf("notice write notice read rsp error %v", err)
	}
	writeRsp := AdminWriteRsp{}
	err = json.Unmarshal(jsonByte, &writeRsp)
	if err != nil {
		return fmt.Errorf("notice write notice jsonUnmarshal error : %v", err)

	}
	if writeRsp.Result != 0 {
		return fmt.Errorf("notice write notice result!=0 err : %v", writeRsp.Error)
	}
	return nil
}

func getNoticeURL() string {
	ip, _, port, err := mfxlocalregistry.SelectEndpoint(config.NoticeService)
	if err != nil {
		log.Error().Msgf("notice error can't get notice service addr from %v : %v",
			config.NoticeService, err)
		return ""
	}
	return fmt.Sprintf("http://%s:%d", ip, port)
}
