
var Local = Local || {};

Local.account = new AccountInfo();
Local.server = "127.0.0.1:8080";

function CheckMobileStyle() {
    if ($(".navbar").height() > 150) {
        $("#toggle-button").click();
    }
}

function Nav_Block(i) {
    Utils.Cookies.set("navblockid", i);
    $(".nav-class").removeClass("active");
    $(".nav-block").hide();
    //$($(".nav-class")[i]).addClass("active");
    //$($(".nav-block")[i]).show();
    $("#nav_menu_" + i).addClass("active");
    $("#nav_block_" + i).show();
    Local.nav = i;
    CheckMobileStyle();
}

function AdjustWindow() {
    let height = $(".navbar").height();
    height -= 50;
    $(".container").css("margin-top", height + "px");
}

function ScroolTop() {
    //window.scroll(0, 0);
}

$(window).resize(function () {
    AdjustWindow();
});

function PageInit() {
    AdjustWindow();
    CheckMobileStyle();
    //ServerListInit();
    //MailInitTimer();
    // var server = Utils.Cookies.get("serverid");
    // Utils.SelectByIdAndValue("server_selector", server);
    // ServerIDChanged();
    let i = parseInt(Utils.Cookies.get("navblockid")) || 0;
    Nav_Block(i);
    Local.server = window.location.host;
    console.log(Local.server);
    lobbyList();
}

function lobbyList() {
    let html = "";
    for (let i = 1; i <= 20; ++i) {
        html = `${html}<option>${i}</option>>`;
    }
    $("#server_selector").html(html);
}

function queryRegistry() {
    $("#registry_service_add_div").hide();
    $("#registry_server_add_div").hide();

    let isShowService = true;
    if (!$("#is_show_service").prop("checked")) {
        isShowService = false;
    }
    let filterType = $("#query_filter").val();  // 0-all, 1-server, 2-node
    let filterTxt = $("#query_filter_txt").val();

    Utils.queryWithoutUin("get_all_registry", {}, function (data) {
        if (!data) {
            Utils.alert("data error!");
            return false;
        }
        console.log(data);
        let servers = data.servers == null ? [] : data.servers, services = data.services == null ? [] : data.services;
        let html = "";
        for (let i = 0; i < servers.length; ++i) {
            let server = servers[i];
            //let serverArr = server.split(",");

            let app =  server.App, //serverArr[0].split("=")[1],
                srv = server.Server, //serverArr[1].split("=")[1],
                div = server.Division, //serverArr[2].split("=")[1],
                node = server.Node, //serverArr[3].split("=")[1],
                useAgent = server.UseAgent, //server.useserverArr[4].split("=")[1],
                nodeStat = server.NodeStatus, //serverArr[5].split("=")[1],
                serviceStat = server.ServiceStatus; //serverArr[6].split("=")[1];
            if (filterType == 1 && srv !== filterTxt || filterType == 2 && node !== filterTxt) {
                continue;
            }

            html = `${html}<tr>
                <td><input type="text" class="form-control" value="${app}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${srv}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${div}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${node}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${useAgent}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${nodeStat}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${serviceStat}" readonly="readonly"/></td>
                <td><span class="input-group-btn"><button class="btn btn-info" type="button" onclick="editRegistry($(this), 0)" style="min-width: 60px;">编辑</button></span>
                <span class="input-group-btn"><button class="btn btn-danger" type="button" onclick="deleteRegistry($(this), 0)" style="min-width: 60px;">删除</button></span>
                <span class="input-group-btn" style="display: none;"><button class="btn btn-info" type="button" onclick="editServerSubmit($(this))" style="min-width: 60px;">确定</button></span>
                <span class="input-group-btn" style="display: none;"><button class="btn btn-info" type="button" onclick="editRegistryCancel($(this))" style="min-width: 60px;">取消</button></span>
                </td>></tr>`;
        }
        //console.log(html);
        $("#registry_server_div").show();
        $("#registry_server_data").html(html);

        if (!isShowService) {
            $("#registry_service_div").hide();
            $("#registry_service_data").html("");
            return;
        }
        html = "";
        for (let i = 0; i < services.length; ++i) {
            let service = services[i];
            //let servicesArr = service.split(",");

            let app = service.App, //servicesArr[0].split("=")[1],
                server = service.Server, //servicesArr[1].split("=")[1],
                division = service.Division, //servicesArr[2].split("=")[1],
                node = service.Node, //servicesArr[3].split("=")[1],
                srvc = service.Service, //servicesArr[4].split("=")[1],
                serviceIp = service.ServiceIp, //servicesArr[5].split("=")[1],
                servicePort = service.ServicePort, //servicesArr[6].split("=")[1],
                adminPort = service.AdminPort,
                rpcPort = service.RpcPort; //servicesArr[7].split("=")[1];

            if (filterType == 1 && server !== filterTxt || filterType == 2 && node !== filterTxt) {
                continue;
            }

            html = `${html}<tr>
                <td style="max-width: 40px;"><input type="text" class="form-control" value="${app}" readonly="readonly"/></td>
                <td style="max-width: 100px;"><input type="text" class="form-control" value="${server}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${division}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${node}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${srvc}" readonly="readonly"/></td>
                <td><input type="text" class="form-control" value="${serviceIp}" readonly="readonly"/></td>
                <td style="max-width: 100px;"><input type="text" class="form-control" value="${servicePort}" readonly="readonly"/></td>
                <td style="max-width: 100px;"><input type="text" class="form-control" value="${adminPort}" readonly="readonly"/></td>
                <td style="max-width: 100px;"><input type="text" class="form-control" value="${rpcPort}" readonly="readonly"/></td>
                <td><span class="input-group-btn"><button class="btn btn-info" type="button" onclick="editRegistry($(this), 1)" style="min-width: 60px;">编辑</button></span>
                <span class="input-group-btn"><button class="btn btn-danger" type="button" onclick="deleteRegistry($(this), 1)" style="min-width: 60px;">删除</button></span>
                <span class="input-group-btn" style="display: none;"><button class="btn btn-info" type="button" onclick="editServiceSubmit($(this))" style="min-width: 60px;">确定</button></span>
                <span class="input-group-btn" style="display: none;"><button class="btn btn-info" type="button" onclick="editRegistryCancel($(this))" style="min-width: 60px;">取消</button></span>
                </td>></tr>`
        }
        $("#registry_service_div").show();
        $("#registry_service_data").html(html);
    });
}

function editRegistry(e, type) {
    let tr = e.parent().parent().parent();
    let begin = (type === 1 ? 5 : 4) ;
    let arr = [];
    tr.find("td").slice(begin).each(function () {
        //console.log($(this));
        $(this).children("input").removeAttr("readonly");
        let v = $(this).children("input").val();
        if (v) {
            arr.push(v);
        }
    });
    tr.attr("oldval", arr.reverse().join(","));
    //tr.find("td").eq(4, 3);

    e.parent().hide();
    e.parent().next().hide();
    e.parent().siblings("span").eq(1).show();
    e.parent().siblings("span").eq(2).show();
}

function editRegistryCancel(e) {
    let tr = e.parent().parent().parent();
    tr.find("td").each(function () {
        $(this).children("input").attr("readonly", "readonly");
    });

    let oldval = tr.attr("oldval");
    let arr = oldval.split(",");
    for (let i = 0; i < arr.length; ++i) {
        tr.find("td").eq(-2-i).children("input").val(arr[i]);
    }
    e.parent().hide();
    e.parent().prev().hide();
    e.parent().siblings("span").eq(0).show();
    e.parent().siblings("span").eq(1).show();
}

function editServerSubmit(e) {
    let arr = [];
    let tr = e.parent().parent().parent();
    tr.find("td").each(function () {
        arr.push($(this).children("input").val());
    });
    let app = arr[0], server = arr[1], division = arr[2], node = arr[3],
        useAgent = arr[4], nodeStat = arr[5], serviceStat = arr[6];
    Utils.confirmWithKey("确定要修改吗？请输入超级密码.", function () {
        Utils.actionPostWithKey("gm/edit_registry_server", {
            app: app,
            server: server,
            division: division,
            node: node,
            use_agent: useAgent,
            node_status: nodeStat,
            service_status: serviceStat,
        }, function (data) {
            e.parent().hide();
            e.parent().next().hide();
            e.parent().prevAll().show();
            tr.find("td").each(function () {
                $(this).children("input").attr("readonly", "readonly")
            });
            Utils.success("编辑成功");
        });
    }, function () {
        Utils.success("您取消了修改");
    });

}

function editServiceSubmit(e) {
    let arr = [];
    let tr = e.parent().parent().parent();
    tr.find("td").each(function () {
        arr.push($(this).children("input").val());
    });
    let app = arr[0], server = arr[1], division = arr[2], node = arr[3], service = arr[4],
        serviceIp = arr[5], servicePort = arr[6], adminPort = arr[7], rpcPort = arr[8];
    Utils.confirmWithKey("确定要修改吗？请输入超级密码.", function () {
        Utils.actionPostWithKey("gm/edit_registry_service", {
            app: app,
            server: server,
            division: division,
            node: node,
            service: service,
            service_ip: serviceIp,
            service_port: servicePort,
            admin_port: adminPort,
            rpc_port: rpcPort
        }, function (data) {
            e.parent().hide();
            e.parent().next().hide();
            e.parent().prevAll().show();
            tr.find("td").each(function () {
                $(this).children("input").attr("readonly", "readonly")
            });
            Utils.success("编辑成功");
        });
    }, function () {
        Utils.success("您取消了修改");
    });
}

function deleteRegistry(e, type) {
    Utils.confirmWithKey("确定删除？请输入超级密码", function() {
        let t = "server";
        if (type === 1) {
            t = "service"
        }
        let arr = [];
        let tr = e.parent().parent().parent();
        tr.find("td").each(function () {
            arr.push($(this).children("input").val());
        });
        Utils.actionPostWithKey("gm/delete_registry", {
            type: t,
            app: arr[0],
            server: arr[1],
            division: arr[2],
            node: arr[3],
            service: arr[4]
        }, function (data) {
            Utils.success("删除成功");
            tr.hide();
            //queryRegistry();
        });
    }, function() {
        //$.alert("no");
    });
}

function clickAddRegistryServer() {
    $("#registry_server_div").hide();
    $("#registry_service_div").hide();
    $("#registry_service_add_div").hide();
    $("#registry_server_add_div").show();
}

function clickAddRegistryService() {
    $("#registry_server_div").hide();
    $("#registry_service_div").hide();
    $("#registry_server_add_div").hide();
    $("#registry_service_add_div").show();
}

function addRegistryServer() {
    let app = $("#registry_server_add_app").val(),
        server = $("#registry_server_add_server").val(),
        division = $("#registry_server_add_division").val(),
        node = $("#registry_server_add_node").val(),
        useAgent = $("#registry_server_add_use_agent").val(),
        nodeStatus = $("#registry_server_add_node_status").val(),
        serviceStatus = $("#registry_server_add_service_status").val();
    if (!app || !server || !division || !node | !useAgent || !nodeStatus || !serviceStatus) {
        Utils.alert("请全部填写！");
        return false;
    }
    Utils.confirmWithKey("确定要添加Server？", function () {
        Utils.actionPostWithKey("gm/add_registry_server", {
            app: app,
            server: server,
            division: division,
            node: node,
            use_agent: useAgent,
            node_status: nodeStatus,
            service_status: serviceStatus
        }, function (data) {
            Utils.success("添加成功")
        });
    });
}

function addRegistryService() {
    let app = $("#registry_service_add_app").val(),
        server = $("#registry_service_add_server").val(),
        division = $("#registry_service_add_division").val(),
        node = $("#registry_service_add_node").val(),
        service = $("#registry_service_add_service").val(),
        serviceIp = $("#registry_service_add_service_ip").val(),
        servicePort = $("#registry_service_add_service_port").val(),
        adminPort = $("#registry_service_add_admin_port").val(),
        rpcPort = $("#registry_service_add_rpc_port").val();
    if (!app || !server || !division || !node | !service || !serviceIp || !servicePort || !adminPort || !rpcPort) {
        Utils.alert("请全部填写！");
        return false;
    }

    Utils.confirmWithKey("确定要添加Service?", function () {
        Utils.actionPostWithKey("gm/add_registry_service", {
            app: app,
            server: server,
            division: division,
            node: node,
            service: service,
            service_ip: serviceIp,
            service_port: servicePort,
            admin_port: adminPort,
            rpc_port: rpcPort
        }, function (data) {
            Utils.success("添加成功")
        });
    });
}

function queryAccountInfoByDeviceId() {
    let deviceId = $("#account_device_id").val();
    if (!deviceId) {
        Utils.alert("请输入deviceId");
        return;
    }
    Utils.queryWithoutUin("gm/get_device_info", {device_id: deviceId}, function (data) {
        console.log(data);
        if (!data) {
            Utils.alert("data error " + data);
            return;
        }
        let datas = data.split(" ");
        if (datas.length < 2) {
            Utils.alert("data error " + data);
            return;
        }
        let accId = datas[0].split(":")[1], lobby = datas[1].split(":")[1];
        $("#change_server_accid").text(accId);
        $("#change_server_old_lobby").text(lobby);
    })
}

function changeServer() {
    let deviceId = $("#account_device_id").val();
    if (!deviceId) {
        Utils.alert("请输入deviceId!");
        return false;
    }
    let newLobbyId = $("#change_server_new_lobby").val();
    if (!newLobbyId) {
        Utils.alert("请输入新lobbyId!");
        return false;
    }
    Utils.confirmWithKey("确定要将玩家转服到Lobby: "+newLobbyId+"？将影响玩家登录！！！", function () {
        Utils.actionPostWithKey("gm/change_server", {device_id: deviceId, lobby_id: newLobbyId}, function (data) {
            console.log(data);
            if (data === "ok") {
                Utils.success("修改成功");
            } else {
                Utils.alert("error! " + data);
            }
        });
    });
}

function bindLobby() {
    let deviceId = $("#account_device_id").val();
    if (!deviceId) {
        Utils.alert("请输入deviceId!");
        return false;
    }
    Utils.queryWithoutUin("gm/bind_lobby", {
       device_id: deviceId
    }, function (data) {
        console.log(data);
        Utils.success("绑定成功");

    });
}

function unbindLobby() {
    let deviceId = $("#account_device_id").val();
    if (!deviceId) {
        Utils.alert("请输入deviceId!");
        return false;
    }
    Utils.confirmWithKey("确定要解除账号绑定？将影响玩家登录！！！", function () {
        Utils.actionPostWithKey("gm/unbind_lobby", {device_id: deviceId}, function (data) {
            console.log(data);
            if (data === "ok") {
                Utils.success("解绑成功");
            } else {
                Utils.alert("解绑失败~" + data);
            }
        });
    });
}

function seeRecommend() {
    Utils.queryWithoutUin("gm/query_recommend", {}, function (data) {
        console.log("recommend:: " + data);
        $("#see_recommend").text(data);
    })
}

function changeRecommend() {
    let lobbyId = $("#change_recommend_lobby").val();
    if (!lobbyId) {
        Utils.alert("请输入推荐lobbyId");
        return false;
    }
    Utils.confirmWithKey("确定要将推荐服Lobby修改为："+lobbyId+"？这将影响玩家登录！！！", function () {
        Utils.actionPostWithKey("gm/change_recommend", {lobby_id: lobbyId}, function (data) {
            console.log(data);
            Utils.success("设置成功");
        });
    });
}

function updateNotice() {
    let content = $("#update_content").val();
    if (!content) {
        //content = "";
        Utils.alert("请输入公告！！！");
        return false;
    }
    Utils.confirmWithKey("确定要更新公告？", function () {
        Utils.actionPostWithKey("gm/update_notice", {content: encodeURIComponent(content)}, function (data) {
            //console.log(data);
            Utils.success("更新成功");
        });
    });
}

function getNotice() {
    Utils.queryWithoutUin("gm/get_notice", {}, function (data) {
        //console.log(data);
        let content = "";
        for (let i = 0; i < data.length; ++i) {
            let cnt = data[i];
            let date = new Date(cnt.timestamp*1000);
            let dateTime = `${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
            content = `${content}ID: ${cnt.id}\t time: ${dateTime}\t content: ${cnt.info}\n\n`;
        }
        $("#old_content").val(content);
    });
}

function deleteOldNotice() {
    let id = $("#old_content_id").val();
    if (!id) {
        Utils.alert("请输入公告ID！！！");
        return false;
    }
    id = parseInt(id);
    Utils.confirmWithKey(`确定删除公告，ID: ${id}?`, function () {
        Utils.actionPostWithKey("gm/delete_notice", {id: id}, function (data) {
            //console.log(data);
            Utils.success("删除公告成功");
        });
    });
}

function ChangeMailType() {
    let type = $("#notice_type_selector").val();
    if (type == 2) {
        $("#notice_uinlist_title").show();
        $("#notice_uinlist_textarea").show(400);
        $("#global_mail_div").hide(400);
        $("#delete_global_mail_div").hide(400);
    } else {
        $("#notice_uinlist_title").hide();
        $("#notice_uinlist_textarea").hide(400);
        $("#global_mail_div").show(400);
        $("#delete_global_mail_div").show(400);
    }
}

var attach_cnt = 0;
function AddNoticeAttachmentItem(type, addition) {
    let table = $("#notice_" + type + "attach_table");
    let id = parseInt($("#notice_" + type + "attach_newid" + addition).val());
    if (id <= 0) {
        Utils.alert("请输入/选择正确的ID");
        $("#notice_" + type + "attach_newid" + addition).focus();
        return ;
    }
    let num = $("#notice_" + type + "attach_newnum" + addition).val();
    let combobox = $("#notice_" + type + "attach_newid1");
    let name = id;
    if (combobox.length > 0) {
        name = $("option[value=" + id + "]", combobox).text();
        if (Utils.isEmpty(name)) name = id;
    }

    let i = attach_cnt + 1;
    let str = '<tr><td><div class="input-group"><span class="input-group-addon" style="min-width: 120px;"><span id="notice_' +
        type + 'attach_id_' + i + '" value="' + id + '" class="notice_' + type + 'attach_idclass">' + name + '</span></span>' +
        '<input id="notice_' + type +'attach_num_' + i + '" type="text" class="form-control notice_' + type + 'attach_numclass" style="min-width: 40px;" value="' +
        num + '"><span class="input-group-btn"><input class="btn btn-danger" type="button" onclick="javascript:DelNoticeAttachmentItem(\''
        + type + '\', ' + i + '); " value="删除" /></span></div></td></tr>';
    $(table).append(str);
    attach_cnt++;
}

function DelNoticeAttachmentItem(type, i) {
    let id_dom = $("#notice_" + type + "attach_id_" + i);
    //var num_dom = $("#notice_" + type + "attach_num_" + i);
    $(id_dom).parents("tr").remove();
}

function SubmitMail() {
    try {
        $("#notice_submit_url").val(PostTools.getPostURL());

        // PostTools.integerCheck("notice_id_textbox", "notice_submit_id");
        PostTools.integerCheck("notice_type_selector", "notice_submit_type");
        $("#notice_submit_srctype").val(100);
        // PostTools.timeCheck("notice_sendtime_textbox", "notice_submit_sendtime");
        // PostTools.timeCheck("notice_expiretime_textbox", "notice_submit_expiretime");
        PostTools.encodeStringCheck("notice_sender_textbox", "notice_submit_sender");
        PostTools.encodeStringCheck("notice_title_textbox", "notice_submit_title");
        PostTools.encodeStringCheck("notice_content_textarea", "notice_submit_content");
        // var coin = PostTools.encodeAttachCheck("coin", "notice_submit_coins");
        let item = PostTools.encodeAttachCheck("item", "notice_submit_items");
        if (item === false) {
            return;
        }
        let attach = 1;
        if (Utils.isEmpty(item))
            attach = 0;
        $("#notice_submit_haveattach").val(attach);

        let type = $("#notice_type_selector").val();
        let uinlist = "";
        if (type == 2) {
            uinlist = PostTools.encodeUinList("notice_uinlist_textarea");
        }
        $("#notice_submit_uinlist").val(uinlist);

        Utils.confirmWithKey("确定要发送邮件？", function () {
            $("#mail_submit_key").val($("#confirm_with_key_pwd").val());
            Utils.ajaxFormSubmit("new_mail_action", "gm/send_mail", "post", function(data) {
                Utils.success("邮件发送成功");
            });
        });
    } catch (e) {

    }
}

function getGlobalMails() {
    Utils.queryWithoutUin("gm/get_global_mails", {}, function (res) {
        let v = "";
        for (let i = 0; i < res.length; ++i) {
            let mail = res[i];
            let date = new Date(mail.timestamp * 1000);
            let time = `${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
            v = `${v}ID: ${mail.mail_id}\tTime: ${time}\tTitle: ${mail.subject}\tContent: ${mail.content}\n\n`;
       }
       $("#history_global_mails").val(v);
    });
}

function deleteGlobalMail() {
    let id = $("#global_mail_id").val();
    if (!id) {
        Utils.alert("请输入要删除的邮件ID");
        return false;
    }
    Utils.confirmWithKey(`确定要删除邮件：${id}吗？`, function () {
       Utils.actionPostWithKey("gm/del_global_mail", {mail_id: id}, function (data) {
          Utils.success("邮件删除成功");
       });
    });
}

function SubmitLuaStr() {
    try {
        $("#lua_script_submit_url").val(PostTools.getPostURL());
        PostTools.encodeStringCheck("lua_script_textarea", "lua_script_submit_luastr");

        Utils.confirmWithKey("确定要注入新的Lua脚本？", function () {
            $("#lua_script_submit_key").val($("#confirm_with_key_pwd").val());
            Utils.ajaxFormSubmit("lua_script_form", "gm/inject_lua_script", "post", function (data) {
                Utils.success("Lua 注入成功");
            });
        }, function () {
            Utils.success("您取消了Lua注入");
        });
    } catch (e) {

    }
}

function GetLuaStr() {
    Utils.queryWithoutUin("gm/get_lua_str", {}, function (data) {
        $("#lua_script_textarea").val(data);
    });
}

function queryAccountDetails() {
    let accId = $("#get_acc_details_account_id").val();
    let lobbyId = $("#get_acc_details_lobby_id").val();
    if (!accId || !lobbyId) {
        Utils.alert("请输入accID 和 lobbyID！！！");
        return false;
    }
    Utils.queryWithoutUin("get_account_info", {acc_id: accId, lobby_id: lobbyId}, function (data) {
       //console.log(data);
        let html = "";
        for (let k in data) {
            //console.log(k, JSON.stringify(data[k]));
            html = `${html}<tr><td>${k}</td><td>${JSON.stringify(data[k])}</td></tr>`;
        }
        $("#acc_details_body").html(html);
    });
}

window.setTimeout(PageInit, 100);
