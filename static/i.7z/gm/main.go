package main

import (
	"crypto/md5"
	"encoding/hex"
	"encoding/xml"
	"fmt"
	"github.com/labstack/echo"
	"github.com/labstack/echo/middleware"
	"html/template"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	lr "shared/mfxlocalregistry"
	"strconv"
	"time"
)

//type jwtCustomClaims struct {
//	Name  string `json:"name"`
//	Admin bool   `json:"admin"`
//	jwt.StandardClaims
//}

type TemplateRenderer struct {
	templates *template.Template
}

type endPoint struct {
	Ip   string `xml:"ip"`
	Port string `xml:"port"`
}

type validation struct {
	Username string `xml:"username"`
	Password string `xml:"password"`
	SuperKey string `xml:"super_key"`
}

type gmConfig struct {
	Validation        validation `xml:"validation"`
	Locator           endPoint   `xml:"locator"`
	RegistryAdmin     endPoint   `xml:"registry_admin"`
	AccountAdmin      endPoint   `xml:"account_admin"`
	CodeRepairService string     `xml:"code_repair_service"`
	NoticeService     string     `xml:"notice_service"`
	MailService       string     `xml:"mail_service"`
	AssetsPath        string     `xml:"assets_path"`
	GmPort            string     `xml:"gm_port"`
}

func (t *TemplateRenderer) Render(w io.Writer, name string, data interface{}, c echo.Context) error {
	//if viewContext, isMap := data.(map[string]interface{}); isMap {
	//	viewContext["reverse"] = c.Echo().Reverse
	//}
	return t.templates.ExecuteTemplate(w, name, data)
}

//func generateToken() (string, error) {
//	claims := &jwtCustomClaims{
//		"mayday",
//		true,
//		jwt.StandardClaims{
//			ExpiresAt: time.Now().Add(time.Hour * 2).Unix(),
//		},
//	}
//	// Create token with claims
//	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
//	// Generate encoded token and send it as response.
//	t, err := token.SignedString([]byte("secret"))
//	if err != nil {
//		return "", err
//	}
//	return t, nil
//}

//func login(c echo.Context) error {
//	username := c.FormValue("username")
//	password := c.FormValue("password")
//
//	if username == "mayday" && password == "mayday123" {
//		// Set custom claims
//		claims := &jwtCustomClaims{
//			"mayday",
//			true,
//			jwt.StandardClaims{
//				ExpiresAt: time.Now().Add(time.Hour * 2).Unix(),
//			},
//		}
//		// Create token with claims
//		token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
//		// Generate encoded token and send it as response.
//		t, err := token.SignedString([]byte("secret"))
//		if err != nil {
//			return err
//		}
//		return c.JSON(http.StatusOK, echo.Map{
//			"token": t,
//		})
//	}
//	return echo.ErrUnauthorized
//}

func accessible(c echo.Context) error {
	//tokenStr, err := generateToken()
	//if err != nil {
	//	return echo.ErrUnauthorized
	//}

	return c.Render(http.StatusOK, "index", nil)
}

//func restricted(c echo.Context) error {
//	fmt.Printf("------------")
//	ip := c.RealIP()
//	fmt.Printf("real ip, %v", ip)
//
//	user := c.Get("user").(*jwt.Token)
//	claims := user.Claims.(*jwtCustomClaims)
//	name := claims.Name
//	return c.String(http.StatusOK, "Welcome "+name+"!")
//}

var (
	config            gmConfig
	registryAdminAddr string
	accountAdminAddr  string

	expireTime = []uint32{0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22}
)

func initConfig(xmlFile string) bool {
	fmt.Printf("start with config: %s\n", xmlFile)
	fileData, err := ioutil.ReadFile(xmlFile)
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		return false
	}

	//var config gmConfig
	err = xml.Unmarshal(fileData, &config)
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		return false
	}
	registryAdminAddr = "http://" + config.RegistryAdmin.Ip + ":" + config.RegistryAdmin.Port + "/admin"
	accountAdminAddr = "http://" + config.AccountAdmin.Ip + ":" + config.AccountAdmin.Port + "/admin"

	return true
}

func main() {
	if len(os.Args) < 2 {
		fmt.Printf("need config")
		return
	}

	ok := initConfig(os.Args[1])
	if !ok {
		fmt.Printf("init config failed")
		return
	}

	// 先尝试拉取一次registry，如果失败则直接退出
	localRegistryIP := config.Locator.Ip
	localRegistryPort := config.Locator.Port
	lr.SetLocator(localRegistryIP, localRegistryPort)
	err := lr.QueryRegistry()
	if err != nil {
		panic(fmt.Sprintf("query registry from %s:%s failed, %s", localRegistryIP, localRegistryPort, err.Error()))
	}
	lr.StartQueryLoop(60)

	e := echo.New()

	e.Use(middleware.Logger())
	//fd, err := os.OpenFile("./gm.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0664)
	//if err != nil {
	//	return
	//}
	//defer fd.Close()
	//e.Use(middleware.LoggerWithConfig(middleware.LoggerConfig{
	//	Output: fd,
	//}))
	e.Use(middleware.Recover())
	e.Use(middleware.CORS())

	e.Static("/", config.AssetsPath+"/html")

	renderer := &TemplateRenderer{
		templates: template.Must(template.ParseGlob(config.AssetsPath + "/html/*.html")),
	}
	e.Renderer = renderer
	e.Use(middleware.BasicAuthWithConfig(middleware.BasicAuthConfig{
		Skipper:   skipper,
		Validator: validator,
	}))

	//e.POST("/login", login)
	e.GET("/", accessible)

	g := e.Group("/gm")
	g.Use(middleware.KeyAuthWithConfig(middleware.KeyAuthConfig{
		Skipper:   keyAuthSkipper,
		KeyLookup: "form:key",
		Validator: keyAuthValidator,
	}))
	//g.GET("", restricted)

	// registry
	e.GET("/get_all_registry", getAllRegistryServers)
	g.POST("/add_registry_server", addRegistryServer)
	g.POST("/add_registry_service", addRegistryService)
	g.POST("/edit_registry_server", editRegistryServer)
	g.POST("/edit_registry_service", editRegistryService)
	g.POST("/delete_registry", deleteRegistry)

	// 转服
	g.GET("/get_device_info", queryDeviceBindInfo)
	g.POST("/change_server", accountChangeBindLobby)

	// 绑定
	g.GET("/bind_lobby", bindLobby)
	g.POST("/unbind_lobby", unbindLobby)
	g.GET("/query_recommend", queryRecommendLobby)
	g.POST("/change_recommend", changeRecommendLobby)

	// lobby
	e.GET("/get_account_info", getAccountInfo)

	// notice
	g.GET("/get_notice", getNotice)
	g.POST("/update_notice", updateNotice)
	g.POST("/delete_notice", deleteContent)

	// mail
	g.POST("/send_mail", sendMail)
	g.GET("/get_global_mails", getGlobalMails)
	g.POST("/del_global_mail", delGlobalMail)

	// lua script
	g.GET("/get_lua_str", getLuaCode)
	g.POST("/inject_lua_script", injectLuaScript)

	// test
	e.GET("/hello", hello)
	e.GET("/testMail", testMailSender)
	e.GET("/testNotice", testNotice)
	e.GET("/testCodeRepair", testCodeRepair)

	e.Logger.Fatal(e.Start(":" + config.GmPort))
}

func hello(c echo.Context) error {
	//return c.String(http.StatusOK, "Hello World!")
	return c.Render(http.StatusOK, "index.html", map[string]interface{}{})
}

func skipper(c echo.Context) bool {
	fmt.Printf("\n---path: %s---\n", c.Path())
	ck, err := c.Cookie("gm")
	if err != nil {
		return false
	}
	if ck.Value != generateCookie(config.Validation.Username, config.Validation.Password) {
		return false
	}
	fmt.Printf("cookie: %s", ck.Value)
	return true
}

func validator(name, pwd string, c echo.Context) (bool, error) {
	if name == config.Validation.Username && pwd == config.Validation.Password {
		ck := new(http.Cookie)
		ck.Name = "gm"
		ck.Value = generateCookie(name, pwd)
		//ck.MaxAge = 3600 * 2
		ck.Expires = time.Now().Add(time.Hour * 2)
		ck.HttpOnly = true
		fmt.Printf("cookie expire: %d", ck.Expires.Unix())
		c.SetCookie(ck)
		return true, nil
	}
	return false, nil
}

func getExpireTimestamp() int64 {
	now := time.Now()
	hour := uint32(now.Hour())
	expire := uint32(0)
	for i := len(expireTime) - 1; i >= 0; i-- {
		if hour >= expireTime[i] {
			expire = expireTime[i] + 2
			if expire >= 24 {
				expire = 24
			}
			break
		}
	}
	tm1 := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())

	tm2 := tm1.Add(time.Hour * time.Duration(expire))
	timestamp := tm2.Unix()
	return timestamp
}

func generateCookie(name, pwd string) string {
	md5ctx := md5.New()
	md5ctx.Write([]byte(name + pwd))
	salt := strconv.FormatInt(getExpireTimestamp(), 10)
	md5ctx.Write([]byte(salt))
	res := md5ctx.Sum(nil)
	return hex.EncodeToString(res)
}

func keyAuthSkipper(c echo.Context) bool {
	if c.Request().Method == "GET" {
		return true
	}
	key := c.FormValue("key")
	if key == config.Validation.SuperKey {
		return true
	}
	return false
}

func keyAuthValidator(key string, c echo.Context) (bool, error) {
	if key == config.Validation.SuperKey {
		return true, nil
	}
	return false, nil
}
