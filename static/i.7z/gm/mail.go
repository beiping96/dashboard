package main

import (
	"context"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/labstack/echo"
	"github.com/rs/zerolog/log"
	"google.golang.org/grpc"
	"math/rand"
	"net/http"
	"net/url"
	"shared/mfxlocalregistry"
	mailService "shared/proto/server/mail"
	"strconv"
	"strings"
	"time"
)

const (
	constRPCTimeout        = time.Duration(3) * time.Second
	mailServers     uint32 = 1
	mailPlayers     uint32 = 2
)

func testMailSender(c echo.Context) error {
	accountID, err := strconv.ParseUint(c.QueryParam("account_id"), 0, 64)
	if err != nil {
		return c.String(http.StatusBadRequest, fmt.Sprintf("account_id not accepted %v", c.QueryParam("account_id")))
	}
	attachmentItems := []*mailService.CardMailAttachmentItem{}
	item1 := mailService.CardMailAttachmentItem{
		GoodsTypeID: 1,
		GoodsNum:    uint32(rand.Intn(10) + 1),
	}
	attachmentItems = append(attachmentItems, &item1)
	item2 := mailService.CardMailAttachmentItem{
		GoodsTypeID: 1001,
		GoodsNum:    uint32(rand.Intn(10) + 1),
	}
	attachmentItems = append(attachmentItems, &item2)
	item3 := mailService.CardMailAttachmentItem{
		GoodsTypeID: 3239,
		GoodsNum:    uint32(rand.Intn(10) + 1),
	}
	attachmentItems = append(attachmentItems, &item3)
	successAccountIds := mailSender([]uint64{accountID}, "testMailSubject", "testMailContent", attachmentItems)
	return c.String(http.StatusOK, fmt.Sprintf("success accountIDs %v", successAccountIds))
}

func sendMail(c echo.Context) error {
	mt := c.FormValue("type")
	mailType, err := strconv.ParseUint(mt, 0, 32)
	if err != nil || (mailType != 1 && mailType != 2) {
		return c.String(http.StatusOK, `{"result": 1, "error": "mail type error"}`)
	}

	subject := c.FormValue("title")
	content := c.FormValue("content")

	subject, err = url.QueryUnescape(subject)
	if err != nil {
		return c.String(http.StatusOK, `{"result": 1, "error": "title format wrong"}`)
	}
	content, err = url.QueryUnescape(content)
	if err != nil {
		return c.String(http.StatusOK, `{"result": 1, "error": "content format wrong"}`)
	}

	haveAttachments := c.FormValue("have_attach")
	var attachItems []*mailService.CardMailAttachmentItem
	if haveAttachments == "1" {
		attachStr := c.FormValue("items")
		attachStr, err = url.QueryUnescape(attachStr)
		if err != nil {
			return c.String(http.StatusOK, `{"result": 1, "error": "attachments format wrong"}`)
		}
		items := strings.Split(attachStr, "|")
		for _, item := range items {
			if len(item) > 0 {
				info := strings.Split(item, " ")
				if len(info) == 2 {
					goodsID, err1 := strconv.ParseUint(strings.TrimSpace(info[0]), 0, 32)
					num, err2 := strconv.ParseUint(strings.TrimSpace(info[1]), 0, 32)
					if err1 != nil && err2 != nil {
						return c.String(http.StatusOK, `{"result": 1, "error": "attachment item format wrong"}`)
					}
					a := mailService.CardMailAttachmentItem{
						GoodsTypeID: uint32(goodsID),
						GoodsNum:    uint32(num),
					}
					attachItems = append(attachItems, &a)
				}
			}
		}
	}
	if uint32(mailType) == mailServers {
		return sendMail2GlobalServer(c, subject, content, attachItems)
	} else if uint32(mailType) == mailPlayers {
		return sendMail2SpecifiedUsers(c, subject, content, attachItems)
	}
	return c.String(http.StatusInternalServerError, "")
}

func sendMail2GlobalServer(c echo.Context, subject, content string, attachItems []*mailService.CardMailAttachmentItem) error {
	err := globalMailSender(subject, content, attachItems)
	if err != nil {
		result := fmt.Sprintf(`{"result": 1, "error": "send global mail failed, err: %s"}`, err.Error())
		return c.String(http.StatusOK, result)
	}
	return c.String(http.StatusOK, `{"result": 0}`)
}

func sendMail2SpecifiedUsers(c echo.Context, subject, content string, attachItems []*mailService.CardMailAttachmentItem) error {
	accountStr := c.FormValue("acc_list")
	if accountStr == "" {
		return c.String(http.StatusOK, `{"result": 1, "error": "acc id is empty"}`)
	}
	accountStr, err := url.QueryUnescape(accountStr)
	if err != nil {
		return c.String(http.StatusOK, `{"result": 1, "error": "acc format wrong"}`)
	}
	accountIDs := strings.Split(accountStr, "|")

	var accIDs []uint64
	for _, accID := range accountIDs {
		accountID, err := strconv.ParseUint(strings.TrimSpace(accID), 0, 64)
		if err != nil {
			result := fmt.Sprintf(`{"result": 1, "error": "account id: %v format wrong"}`, accID)
			return c.String(http.StatusOK, result)
		}
		accIDs = append(accIDs, accountID)
	}
	if len(accIDs) <= 0 {
		return c.String(http.StatusOK, `{"result": 1, "error": "account is empty"}`)
	}
	mailSender(accIDs, subject, content, attachItems)
	fmt.Printf("acc: %v, sub: %v, cnt: %v, attach: %v", accountIDs, subject, content, attachItems)
	return c.JSON(http.StatusOK, map[string]interface{}{"result": 0})
}

func getGlobalMails(c echo.Context) error {
	pmails, err := globalMailReader()
	if err != nil {
		return c.String(http.StatusInternalServerError, "")
	}

	return c.JSON(http.StatusOK, map[string]interface{}{
		"result": 0,
		"msg":    pmails,
	})
}

func delGlobalMail(c echo.Context) error {
	id := c.FormValue("mail_id")
	mailID, err := strconv.ParseUint(id, 10, 64)
	if err != nil {
		return err
	}
	err = globalMailDelete(mailID)
	if err != nil {
		return err
	}
	return c.String(http.StatusOK, `{"result": 0}`)
}

func globalMailDelete(mailID uint64) error {
	fn := func(cli mailService.MailServiceClient, ctx context.Context) error {
		req := &mailService.DeleteGlobalMailReq{
			MailId: mailID,
		}
		rsp, err := cli.DeleteGlobalMail(ctx, req)
		if err != nil {
			log.Error().Msgf("mailService error DeleteGlobalMail : %v", err)
			return err
		}
		if rsp.GetResult() != 0 {
			return fmt.Errorf("mailService error DeleteGlobalMail result not zero : %v", rsp.GetResult())
		}
		return nil
	}
	return callRPC(fn)
}

func globalMailReader() ([]*mailService.Mail, error) {
	mails := []*mailService.Mail{}
	fn := func(cli mailService.MailServiceClient, ctx context.Context) error {
		req := &mailService.FetchGlobalMailReq{
			StartPos: 0,
			EndPos:   2,
		}
		rsp, err := cli.FetchGlobalMails(ctx, req)
		if err != nil {
			log.Error().Msgf("mailService error SendGlobalMail : %v", err)
			return err
		}
		if rsp.GetResult() != 0 {
			return fmt.Errorf("mailService error SendGlobalMail result not zero : %v", rsp.GetResult())
		}
		mails = rsp.GetMails()
		return nil
	}
	err := callRPC(fn)
	if err != nil {
		return mails, err
	}
	return mails, nil
}

func globalMailSender(subject string, content string,
	attachmentItems []*mailService.CardMailAttachmentItem) error {
	attachmentStr := ""
	if attachmentItems != nil && len(attachmentItems) > 0 {
		attachment := &mailService.CardMailAttachment{
			IsExist: true,
			Items:   attachmentItems,
		}
		attachmentData, err := proto.Marshal(attachment)
		if err != nil {
			return fmt.Errorf("mail attachment marshall err :%v info:%v",
				err, attachment)
		}
		attachmentStr = string(attachmentData)
	}
	mail := mailService.Mail{
		Type:       mailService.MailType_global,
		Subject:    subject,
		Content:    content,
		Attachment: attachmentStr,
	}
	fn := func(cli mailService.MailServiceClient, ctx context.Context) error {
		req := &mailService.SendGlobalMailReq{
			MailCtx: &mail,
		}
		rsp, err := cli.SendGlobalMail(ctx, req)
		if err != nil {
			log.Error().Msgf("mailService error SendGlobalMail : %v", err)
			return err
		}
		if rsp.GetResult() != 0 {
			return fmt.Errorf("mailService error SendGlobalMail result not zero : %v", rsp.GetResult())
		}
		return nil
	}
	return callRPC(fn)
}

func mailSender(accountIDs []uint64, subject string, content string,
	attachmentItems []*mailService.CardMailAttachmentItem) (successAccountIds []uint64) {
	attachmentStr := ""
	if attachmentItems != nil && len(attachmentItems) > 0 {
		attachment := &mailService.CardMailAttachment{
			IsExist: true,
			Items:   attachmentItems,
		}
		attachmentData, err := proto.Marshal(attachment)
		if err != nil {
			log.Error().Msgf("mail attachment marshall err :%v info:%v",
				err, attachment)
			return
		}
		attachmentStr = string(attachmentData)
	}
	mail := mailService.Mail{
		Type:       mailService.MailType_personal,
		Subject:    subject,
		Content:    content,
		Attachment: attachmentStr,
	}
	for _, accountID := range accountIDs {
		if err := subMailSender(accountID, &mail); err != nil {
			log.Error().Msgf("mailService accountID :%v mailInfo:%v error :%v",
				accountID, mail, err)
			continue
		}
		successAccountIds = append(successAccountIds, accountID)
	}
	return
}

func subMailSender(accountID uint64, mail *mailService.Mail) error {
	fn := func(cli mailService.MailServiceClient, ctx context.Context) error {
		req := &mailService.SendMailReq{
			AccountId: accountID,
			MailCtx:   mail,
		}
		rsp, err := cli.SendMail(ctx, req)
		if err != nil {
			log.Error().Msgf("mailService error SendMail : %v", err)
			return err
		}
		if rsp.GetResult() != 0 {
			return fmt.Errorf("mailService error SendMail result not zero : %v", rsp.GetResult())
		}
		return nil
	}
	return callRPC(fn)
}

func callRPC(proc func(mailService.MailServiceClient, context.Context) error) error {
	mailAddr, err := getMailRPCAddr()
	if err != nil {
		log.Error().Msgf("get mailService addr error failed: %v", err)
		return err
	}
	log.Debug().Msgf("use mailService rpc addr=%s", mailAddr)
	conn, err := grpc.Dial(mailAddr, grpc.WithInsecure())
	if err != nil {
		log.Error().Msgf("mailService error gRPC dial failed: %s", err.Error())
		return err
	}
	defer conn.Close()
	c := mailService.NewMailServiceClient(conn)
	ctx, cancel := context.WithTimeout(context.Background(), constRPCTimeout)
	defer cancel()
	return proc(c, ctx)
}

func getMailRPCAddr() (string, error) {
	ip, _, port, err := mfxlocalregistry.SelectEndpoint(config.MailService)
	if err != nil {
		log.Error().Msgf("mail error can't get mail service RPC addr from %v",
			config.MailService)
		return "", err
	}
	return fmt.Sprintf("%s:%d", ip, port), nil
}
