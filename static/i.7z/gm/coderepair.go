package main

import (
	"encoding/json"
	"fmt"
	"github.com/labstack/echo"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"net/http"
	"net/url"
	"shared/mfxlocalregistry"
	"strings"
)

func testCodeRepair(c echo.Context) error {
	luaStr := `local test = "test hot fix code"
	Log.Error(test)`
	err := writeCodeRepair(luaStr)
	if err != nil {
		return err
	}
	luaStr = readCodeRepair()
	return c.String(http.StatusOK, fmt.Sprintf("%v err : %v", luaStr, err))
}

func getLuaCode(c echo.Context) error {
	luaStr := readCodeRepair()
	//result := fmt.Sprintf(`{"result": 0, "msg": %v}`, luaStr)
	return c.JSON(http.StatusOK, map[string]interface{}{
		"result": 0,
		"msg":    luaStr,
	})
}

func injectLuaScript(c echo.Context) error {
	luaStr := c.FormValue("lua_str")
	luaStr, err := url.QueryUnescape(luaStr)
	if err != nil {
		return c.String(http.StatusOK, `{"result": 1, "error": "lua script format wrong"}`)
	}
	err = writeCodeRepair(luaStr)
	if err != nil {
		result := fmt.Sprintf(`{"result": 1, "error": "%s"}`, err.Error())
		return c.String(http.StatusOK, result)
	}
	return c.String(http.StatusOK, `{"result": 0}`)
}

// CodeRepairReadRsp - read luaStr
type CodeRepairReadRsp struct {
	Result  int    `json:"result"`
	Content string `json:"data"`
	Error   string `json:"error"`
}

func readCodeRepair() string {
	codeRepairURL := getCodeRepairURL()
	if codeRepairURL == "" {
		log.Error().Msg("readCodeRepair error can't get code repair URL")
		return ""
	}
	rsp, err := http.Get(codeRepairURL + "/getLuaStr")
	if err != nil {
		log.Error().Msgf("readCodeRepair error : %v", err)
		return ""
	}
	defer rsp.Body.Close()
	jsonByte, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		log.Error().Msgf("readCodeRepair readBody error : %v", err)
		return ""
	}
	readRsp := CodeRepairReadRsp{}
	err = json.Unmarshal(jsonByte, &readRsp)
	if err != nil {
		log.Error().Msgf("readCodeRepair jsonUnmarshal error : %v", err)
		return ""
	}
	if readRsp.Result != 0 {
		log.Error().Msgf("readCodeRepair result!=0 error : %v", readRsp.Error)
		return ""
	}
	luaStr, err := url.QueryUnescape(readRsp.Content)
	if err != nil {
		log.Error().Msgf("readCodeRepair URL decode error : %v", err)
		return ""
	}
	return luaStr
}

// CodeRepairWriteRsp - write luaStr
type CodeRepairWriteRsp struct {
	Result int    `json:"result"`
	Error  string `json:"error"`
}

func writeCodeRepair(luaStr string) error {
	codeRepairURL := getCodeRepairURL()
	if codeRepairURL == "" {
		return nil
	}
	rsp, err := http.Post(codeRepairURL+"/setLuaStr", "application/x-www-form-urlencoded",
		strings.NewReader(fmt.Sprintf("luaStr=%v", url.QueryEscape(luaStr))))
	if err != nil {
		return fmt.Errorf("codeRepair write codeRepair post error %v", err)
	}
	defer rsp.Body.Close()
	jsonByte, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return fmt.Errorf("codeRepair write codeRepair read rsp error %v", err)
	}
	writeRsp := CodeRepairWriteRsp{}
	err = json.Unmarshal(jsonByte, &writeRsp)
	if err != nil {
		return fmt.Errorf("codeRepair write codeRepair jsonUnmarshal error : %v", err)

	}
	if writeRsp.Result != 0 {
		return fmt.Errorf("codeRepair write codeRepair result!=0 err : %v", writeRsp.Error)
	}
	return nil
}

func getCodeRepairURL() string {
	ip, _, port, err := mfxlocalregistry.SelectEndpoint(config.CodeRepairService)
	if err != nil {
		log.Error().Msgf("codeRepair error can't get codeRepair service addr from %v : %v",
			config.CodeRepairService, err)
		return ""
	}
	return fmt.Sprintf("http://%s:%d", ip, port)
}
