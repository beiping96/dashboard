package main

import (
	"database/sql"
	"encoding/json"
	"encoding/xml"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"net"
	"net/http"
	"os"
	logUtil "shared/mfxlogutil"
	"strconv"
	"sync"
	"time"
)

// CardNoticeConfig define card notice config xml reflect struct
type CardNoticeConfig struct {
	DbIP          string `xml:"db_ip"`
	DbPort        string `xml:"db_port"`
	DbUser        string `xml:"db_user"`
	DbPwd         string `xml:"db_pwd"`
	DbName        string `xml:"db_name"`
	RefreshSecond string `xml:"refresh_second"`
	AdminPort     string `xml:"admin_port"`
	HTTPPort      string `xml:"http_port"`
	LogPath       string `xml:"log_path"`
	LogLevel      string `xml:"log_level"`
	MaxContentNum string `xml:"max_content_num"`
}

// ReadRsp Client read notice rsp
type ReadRsp struct {
	Result  int           `json:"result"`
	Error   string        `json:"error"`
	Content []ContentInfo `json:"content"`
}

// ContentInfo define for content info
type ContentInfo struct {
	Timestamp int    `json:"timestamp"`
	Info      string `json:"info"`
}

// AdminReadRsp Admin read all content
type AdminReadRsp struct {
	Result  int                `json:"result"`
	Error   string             `json:"error"`
	Content []AdminContentInfo `json:"admin_content"`
}

// AdminContentInfo define for admin content info
type AdminContentInfo struct {
	UID       int    `json:"id"`
	Timestamp int    `json:"timestamp"`
	Info      string `json:"info"`
}

// AdminWriteRsp Admin write notice rsp
type AdminWriteRsp struct {
	Result int    `json:"result"`
	Error  string `json:"error"`
}

// AdminDeleteRsp Admin delete notice rsp
type AdminDeleteRsp struct {
	Result int    `json:"result"`
	Error  string `json:"error"`
}

type noticeService struct {
	dbAddr        string
	maxContentNum int
	lock          sync.RWMutex
	// 写入的DB连接
	wDB *sql.DB
	// 读取的DB连接
	rDB *sql.DB
	// 当前公告
	content []*ContentInfo
	// IP白名单
	ipTable    map[string]bool
	skipIPAuth bool
}

var globalNoticeService *noticeService

func main() {
	if len(os.Args) < 2 {
		panic(fmt.Errorf("./notice notice.xml"))
	}
	configSource, err := ioutil.ReadFile(os.Args[1])
	if err != nil {
		panic(fmt.Errorf("Read configFile error : %v", err))
	}
	var config CardNoticeConfig
	err = xml.Unmarshal(configSource, &config)
	if err != nil {
		panic(fmt.Errorf("Unmarshal configFile error : %v", err))
	}
	if config.LogPath == "" {
		config.LogPath = "./notice.log"
	}
	fmt.Printf("log path is %s", config.LogPath)
	fmt.Printf("log path=%s, level=%s", config.LogPath, config.LogLevel)
	logUtil.SetupLogPath(config.LogPath)
	logUtil.SetupLogLevel(config.LogLevel)

	log.Info().Msgf("notice start %v", time.Now())

	interval, err := strconv.ParseInt(config.RefreshSecond, 10, 32)
	if err != nil {
		log.Panic().Msgf("start failed can't convert refreshSecond : %v", err)
	}
	maxContentNum, err := strconv.Atoi(config.MaxContentNum)
	if err != nil || maxContentNum <= 0 {
		log.Panic().Msgf("start failed can't convert MaxContentNum %v : %v", maxContentNum, err)
	}

	dbAddr := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8",
		config.DbUser, config.DbPwd, config.DbIP, config.DbPort, config.DbName)

	// init the context
	globalNoticeService = &noticeService{
		dbAddr:        dbAddr,
		skipIPAuth:    false,
		maxContentNum: maxContentNum,
	}

	// init the db connection
	log.Info().Msgf("db connection string: %s", dbAddr)
	dbInit(dbAddr)

	// load content from db immediately
	content, err := loadNoticeFromDB()
	if err != nil {
		log.Panic().Msg(err.Error())
	}
	updateNotice(content)

	// start the timer
	go initLoadFromDBTimer(int(interval))
	log.Info().Msgf("start notice timer for loading from db...")

	// start the http service
	if config.HTTPPort != "" {
		go startHTTPService(config)
	}

	// start the admin service
	http.HandleFunc("/admin_read_notice", readNoticeFromAdmin)
	http.HandleFunc("/admin_write_notice", writeNoticeFromAdmin)
	http.HandleFunc("/admin_delete_notice", deleteNoticeFromAdmin)
	server := &http.Server{Addr: config.AdminPort}
	err = server.ListenAndServe()
	if err != nil {
		log.Error().Msgf("ListenAndServe: ", err)
	}
	log.Info().Msgf("start notice service success, listen addr: %s", config.AdminPort)
	log.Info().Msgf("notice service start")
}

func dbInit(dbAddr string) {
	// read connection
	rDB, err := sql.Open("mysql", dbAddr)
	if err != nil {
		log.Panic().Msg(err.Error())
	}
	err = rDB.Ping()
	if err != nil {
		log.Panic().Msg(err.Error())
	}
	globalNoticeService.rDB = rDB

	// write connection
	wDB, err := sql.Open("mysql", dbAddr)
	if err != nil {
		log.Panic().Msg(err.Error())
	}
	err = wDB.Ping()
	if err != nil {
		log.Panic().Msg(err.Error())
	}
	globalNoticeService.wDB = wDB
	globalNoticeService.wDB.SetConnMaxLifetime(time.Duration(5) * time.Second)
}

func loadIPTableFromDB() (map[string]bool, error) {
	ipMap := make(map[string]bool, 100)
	sqlStr := fmt.Sprintf("SELECT ip FROM ip_table LIMIT 100")
	log.Info().Msgf("load ip: %v", sqlStr)

	rows, err := globalNoticeService.rDB.Query(sqlStr)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var ip string
		err = rows.Scan(&ip)
		if err != nil {
			log.Error().Msgf("notice service loadIPTableFormDB scan error : %v", err)
			continue
		}
		ipMap[ip] = true
	}
	return ipMap, nil
}

func loadNoticeFromDB() ([]*ContentInfo, error) {
	sql := fmt.Sprintf("SELECT info, timestamp FROM content ORDER BY timestamp DESC LIMIT %d",
		globalNoticeService.maxContentNum)
	log.Info().Msgf("load notice: %v", sql)
	rows, err := globalNoticeService.rDB.Query(sql)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	content := []*ContentInfo{}
	for rows.Next() {
		var contentInfo string
		var timestamp int
		if err = rows.Scan(&contentInfo, &timestamp); err != nil {
			return content, err
		}
		contentInfoStruct := &ContentInfo{
			Timestamp: timestamp,
			Info:      contentInfo,
		}
		content = append(content, contentInfoStruct)
	}
	return content, nil
}

func saveNoticeToDB(contentInfo string) error {
	sql := fmt.Sprintf("INSERT INTO content (info, timestamp) values ('%v', %v)",
		contentInfo, time.Now().Unix())
	log.Info().Msgf("save notice: %v", sql)

	err := globalNoticeService.wDB.Ping()
	if err != nil {
		log.Error().Msgf("save error: %v", err)
		return err
	}

	_, err = globalNoticeService.wDB.Exec(sql)
	if err != nil {
		log.Error().Msgf("save exec error: %v", err)
		return err
	}

	return nil
}

func updateNotice(content []*ContentInfo) {
	globalNoticeService.lock.Lock()
	defer globalNoticeService.lock.Unlock()
	globalNoticeService.content = content
}

func updateIPTable(ipTable map[string]bool) {
	globalNoticeService.lock.Lock()
	defer globalNoticeService.lock.Unlock()
	globalNoticeService.ipTable = ipTable
	if len(ipTable) > 0 {
		globalNoticeService.skipIPAuth = false
		return
	}
	globalNoticeService.skipIPAuth = true
}

func skipIPAuth() bool {
	globalNoticeService.lock.RLock()
	defer globalNoticeService.lock.RUnlock()
	return globalNoticeService.skipIPAuth
}

func ipTableContain(ip string) bool {
	globalNoticeService.lock.RLock()
	defer globalNoticeService.lock.RUnlock()
	_, ok := globalNoticeService.ipTable[ip]
	return ok
}

func getNotice() []*ContentInfo {
	globalNoticeService.lock.RLock()
	defer globalNoticeService.lock.RUnlock()
	return globalNoticeService.content
}

func initLoadFromDBTimer(interval int) {
	ticker := time.Tick(time.Duration(interval) * time.Second)
	for {
		<-ticker
		// timer is active
		log.Info().Msgf("update content timer is active %v", time.Now())

		// load the ip table
		ipMap, err := loadIPTableFromDB()
		if err != nil {
			log.Error().Msgf("load ip table from db error: %v", err)
		} else {
			updateIPTable(ipMap)
		}

		// load the notice
		content, err := loadNoticeFromDB()
		if err != nil {
			log.Error().Msgf("load from db error: %v", err)
			continue
		}

		log.Info().Msgf("load from db ok, content: %v", content)

		// update the content
		updateNotice(content)
		log.Info().Msgf("update notice from db success...")
	}
}

func deleteNoticeFromAdmin(rsp http.ResponseWriter, req *http.Request) {
	rip, _, _ := net.SplitHostPort(req.RemoteAddr)
	log.Info().Msgf("req from ip: %v method: %v", rip, req.Method)

	var result AdminDeleteRsp

	if !skipIPAuth() && !ipTableContain(rip) {
		log.Error().Msgf("error ip address %v", rip)
		result.Result = 1
		result.Error = "should in ip white-list"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	if req.Method != "POST" {
		log.Error().Msgf("error Method %v", req.Method)
		result.Result = 1
		result.Error = "should use POST method"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	req.ParseForm()
	log.Info().Msgf("form: %v", req.Form)
	contentUIDStr := req.FormValue("contentUID")
	if contentUIDStr == "" {
		log.Error().Msgf("contentUID is empty %v", rip)
		result.Result = 1
		result.Error = "contentUID is empty"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}
	contentUID, err := strconv.Atoi(contentUIDStr)
	if err != nil {
		log.Error().Msgf("convert contentUID %v error %v", contentUIDStr, err)
		result.Result = 1
		result.Error = "convert contentUID error"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	sql := fmt.Sprintf("DELETE FROM content WHERE id=%v",
		contentUID)
	log.Info().Msgf("delete notice: %v", sql)

	err = globalNoticeService.wDB.Ping()
	if err != nil {
		log.Error().Msgf("delete notice error: %v", err)
		result.Result = 1
		result.Error = "delete notice error"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	_, err = globalNoticeService.wDB.Exec(sql)
	if err != nil {
		log.Error().Msgf("delete notice error: %v", err)
		result.Result = 1
		result.Error = "delete notice error"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	result.Result = 0
	result.Error = ""
	body, _ := json.Marshal(result)
	rsp.Header().Add("Access-Control-Allow-Origin", "*")
	rsp.Write(body)
}

func readNoticeFromAdmin(rsp http.ResponseWriter, req *http.Request) {
	rip, _, _ := net.SplitHostPort(req.RemoteAddr)
	log.Info().Msgf("req from ip: %v method: %v", rip, req.Method)

	var result AdminReadRsp

	if !skipIPAuth() && !ipTableContain(rip) {
		log.Error().Msgf("error ip address %v", rip)
		result.Result = 1
		result.Error = "should in ip white-list"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	rows, err := globalNoticeService.rDB.Query("SELECT id, info, timestamp FROM content LIMIT 100")
	if err != nil {
		log.Error().Msgf("admin read error  %v", err)
		result.Result = 1
		result.Error = "admin read error"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}
	defer rows.Close()

	result.Result = 0
	result.Error = ""
	for rows.Next() {
		var id int
		var info string
		var timestamp int
		err := rows.Scan(&id, &info, &timestamp)
		if err != nil {
			log.Error().Msgf("admin read scan error : %v", err)
			continue
		}
		adminContent := AdminContentInfo{
			UID:       id,
			Info:      info,
			Timestamp: timestamp,
		}
		result.Content = append(result.Content, adminContent)
	}
	body, _ := json.Marshal(result)
	rsp.Header().Add("Access-Control-Allow-Origin", "*")
	rsp.Write(body)
	return
}

func writeNoticeFromAdmin(rsp http.ResponseWriter, req *http.Request) {
	rip, _, _ := net.SplitHostPort(req.RemoteAddr)
	log.Info().Msgf("req from ip: %v method: %v", rip, req.Method)

	var result AdminWriteRsp

	if !skipIPAuth() && !ipTableContain(rip) {
		log.Error().Msgf("error ip address %v", rip)
		result.Result = 1
		result.Error = "should in ip white-list"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	if req.Method != "POST" {
		log.Error().Msgf("error Method %v", req.Method)
		result.Result = 1
		result.Error = "should use POST method"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	req.ParseForm()
	log.Info().Msgf("form: %v", req.Form)

	content := req.FormValue("content")
	if content == "" {
		log.Error().Msgf("error, content is empty")
		result.Result = 1
		result.Error = "should contain 'content' field or not empty"
		body, _ := json.Marshal(result)
		rsp.Header().Add("Access-Control-Allow-Origin", "*")
		rsp.Write(body)
		return
	}

	log.Info().Msgf("content is %v", content)
	saveNoticeToDB(content)

	result.Result = 0
	result.Error = ""
	body, _ := json.Marshal(result)
	rsp.Header().Add("Access-Control-Allow-Origin", "*")
	rsp.Write(body)
}

func startHTTPService(config CardNoticeConfig) {
	mux := http.NewServeMux()
	mux.HandleFunc("/read_notice.py", httpReadNotice)
	err := http.ListenAndServe(config.HTTPPort, mux)
	if err != nil {
		log.Error().Msgf("ListenAndServe: %v", err)
	}
	log.Info().Msg("notice http start")
}

func httpReadNotice(rsp http.ResponseWriter, req *http.Request) {
	rip, _, _ := net.SplitHostPort(req.RemoteAddr)
	log.Info().Msgf("request from ip: %v method: %v", rip, req.Method)

	var result ReadRsp

	result.Result = 0
	for _, content := range getNotice() {
		result.Content = append(result.Content, *content)
	}
	result.Error = ""

	body, err := json.Marshal(result)
	if err != nil {
		log.Error().Msgf("notice service business error marshal %v : %v",
			result, err)
	}
	rsp.Header().Add("Access-Control-Allow-Origin", "*")
	rsp.Write(body)
}
