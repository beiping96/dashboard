package main

import (
	"container/list"
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"net"
	bd "shared/mfxbasedef"
	cp "shared/mfxcoredump"
	"shared/proto/server/mfxbase"
	"sync"
	"time"
)

var (
	dbstr string
	// t_server表数据
	serverLock sync.RWMutex
	serverMap  map[string]*bd.RegistryServerConfig

	// t_service表数据
	serviceLock sync.RWMutex
	serviceMap  map[string]*list.List

	adminLock    sync.RWMutex
	adminFromMap map[string]int32
)

func getServerMap() map[string]*bd.RegistryServerConfig {
	serverLock.RLock()
	defer serverLock.RUnlock()
	return serverMap
}

func getServiceMap() map[string]*list.List {
	serviceLock.RLock()
	defer serviceLock.RUnlock()
	return serviceMap
}

func getAdminFromMap() map[string]int32 {
	adminLock.RLock()
	defer adminLock.RUnlock()
	return adminFromMap
}

func loadServerFromRegistry(db *sql.DB) (map[string]*bd.RegistryServerConfig, error) {
	// 加载t_server
	rows, err := db.Query("SELECT app, server, division, node, use_agent, node_status, service_status FROM t_server")
	if err != nil {
		log.Error().Msgf("select t_server failed: %s", err.Error())
		return nil, err
	}
	defer rows.Close()

	m := make(map[string]*bd.RegistryServerConfig, 100)

	for rows.Next() {
		var app string
		var server string
		var division string
		var node string
		var use_agent uint32
		var node_status uint32
		var service_status uint32
		err = rows.Scan(&app, &server, &division, &node, &use_agent, &node_status, &service_status)
		if err != nil {
			log.Error().Msgf("scan failed: %s", err.Error())
			return nil, err
		}

		log.Debug().Msgf("server: app=%s, server=%s, division=%s, node=%s, use_agent=%v, node_status=%v, service_status=%v",
			app, server, division, node, use_agent, node_status, service_status)

		// 如果node_status或service_status有一个不为0，则应该丢弃
		if node_status != 0 || service_status != 0 {
			continue
		}

		// 加入到配置中
		c := &bd.RegistryServerConfig{
			App:           app,
			Server:        server,
			Division:      division,
			Node:          node,
			UseAgent:      use_agent,
			NodeStatus:    node_status,
			ServiceStatus: service_status,
		}

		key := bd.MakeLookupKey(app, server, division)
		m[key] = c
	}

	return m, nil
}

func loadServiceFromRegistry(db *sql.DB) (map[string]*list.List, error) {
	// 加载t_service
	rows, err := db.Query("SELECT app, server, division, node, service, service_ip, service_port, admin_port, rpc_port FROM t_service")
	if err != nil {
		log.Error().Msgf("select t_service failed: %s", err.Error())
		return nil, err
	}
	defer rows.Close()

	m := make(map[string]*list.List, 100)

	for rows.Next() {
		var app string
		var server string
		var division string
		var node string
		var service string
		var serviceIp string
		var servicePort int32
		var adminPort int32
		var rpcPort int32
		err = rows.Scan(&app, &server, &division, &node, &service, &serviceIp, &servicePort, &adminPort, &rpcPort)
		if err != nil {
			log.Error().Msgf("scan failed: %s", err.Error())
			return nil, err
		}

		log.Debug().Msgf("service: app=%s, server=%s, division=%s, node=%s, service=%s, serviceIp=%s, servicePort=%d, adminPort=%d, rpcPort=%d",
			app, server, division, node, service, serviceIp, servicePort, adminPort, rpcPort)

		c := bd.RegistryServiceConfig{
			App:         app,
			Server:      server,
			Division:    division,
			Node:        node,
			Service:     service,
			ServiceIp:   serviceIp,
			ServicePort: servicePort,
			AdminPort:   adminPort,
			RpcPort:     rpcPort,
		}

		key := bd.MakeLookupKey(app, server, division)
		l, ok := m[key]
		if ok {
			l.PushBack(c)
		} else {
			l = list.New()
			m[key] = l
			l.PushBack(c)
		}
	}

	return m, nil
}

func loadAdminAccessListFromRegistry(db *sql.DB) (map[string]int32, error) {
	rows, err := db.Query("SELECT ip, state FROM t_admin_from")
	if err != nil {
		log.Error().Msgf("select t_admin_from failed, %s", err.Error())
		return nil, err
	}
	defer rows.Close()
	m := make(map[string]int32, 10)
	for rows.Next() {
		var ip string
		var state int32
		err = rows.Scan(&ip, &state)
		if err != nil {
			log.Error().Msgf("scan failed, %s", err.Error())
			return nil, err
		}
		m[ip] = state
	}

	return m, nil
}

func loadRegistryFromMysql(s string) error {
	defer cp.CoredumpHandler()

	db, err := sql.Open("mysql", s)
	if err = db.Ping(); err != nil {
		return err
	}
	defer db.Close()

	server, err := loadServerFromRegistry(db)
	if err != nil {
		return err
	}

	service, err := loadServiceFromRegistry(db)
	if err != nil {
		return err
	}

	adminFrom, err := loadAdminAccessListFromRegistry(db)
	if err != nil {
		return err
	}

	// 合法性检查，并存储
	serverLock.Lock()
	serverMap = server
	serverLock.Unlock()

	serviceLock.Lock()
	serviceMap = service
	serviceLock.Unlock()

	adminLock.Lock()
	adminFromMap = adminFrom
	adminLock.Unlock()

	// 打印Registry中的数据
	dumpRegistryServerConfig()
	dumpRegistryServiceConfig()
	dumpRegistryAdminFromList()

	log.Info().Msg("load from mysql ok")
	return nil
}

func loadRegistryByTimer(s string, t uint32) {
	tick := time.NewTicker(time.Duration(t) * time.Second)
	for {
		select {
		case <-tick.C:
			log.Debug().Msg("load from mysql active")
			loadRegistryFromMysql(s)
		}
	}
}

func dumpRegistryServerConfig() {
	log.Info().Msg("registry server ===>")
	for k, v := range serverMap {
		log.Info().Msgf("key=%s", k)
		c := v
		log.Info().Msgf("app=%s, server=%s, division=%s, node=%s, use_agent=%v, node_status=%v, service_status=%v",
			c.App, c.Server, c.Division, c.Node, c.UseAgent, c.NodeStatus, c.ServiceStatus)
	}
	log.Info().Msg("<===")
}

func dumpRegistryServiceConfig() {
	log.Info().Msg("registry service ===>")
	for k, v := range serviceMap {
		log.Info().Msgf("key=%s", k)
		for e := v.Front(); e != nil; e = e.Next() {
			c := e.Value.(bd.RegistryServiceConfig)
			log.Info().Msgf("service: app=%s, server=%s, division=%s, node=%s, service=%s, serviceIp=%s, servicePort=%d, adminPort=%d, rpcPort=%d",
				c.App, c.Server, c.Division, c.Node, c.Service, c.ServiceIp, c.ServicePort, c.AdminPort, c.RpcPort)
		}
	}
	log.Info().Msg("<===")
}

func dumpRegistryAdminFromList() {
	log.Info().Msg("registry admin from ===>")
	for k, v := range adminFromMap {
		log.Info().Msgf("ip=%s, state=%d", k, v)
	}
	log.Info().Msg("<===")
}

func startBusiness(config MfxLocatorConfig, ch chan<- string) {
	dbstr = fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8", config.Mysql.Username, config.Mysql.Password, config.Mysql.Ep.Ip, config.Mysql.Ep.Port, config.Mysql.Database)

	// 启动时需要同步拉取Mysql里的数据
	// 如果失败，则记录错误并退出
	if err := loadRegistryFromMysql(dbstr); err != nil {
		log.Error().Msgf("start business failed: %s", err.Error())
		ch <- "mysql failed"
		return
	}

	// 启动一个定时器，定时从mysql中拉取server和service
	go loadRegistryByTimer(dbstr, config.RegistryRefreshInterval)

	// 初始化业务服务
	businessAddr := config.Business.Ip + ":" + config.Business.Port
	ls, err := net.Listen("tcp", businessAddr)
	if err != nil {
		log.Error().Msgf("business listen failed: %s", err.Error())
		ch <- "listen step failed"
		return
	}
	defer ls.Close()

	log.Info().Msgf("listen business addr=%s ok", businessAddr)
	ch <- "ready"

	srv := grpc.NewServer()
	mfxbase.RegisterLocatorServiceServer(srv, &LocatorServer{})
	reflection.Register(srv)
	srv.Serve(ls)

	log.Info().Msg("business exit")
	ch <- "exit"
	return
}

func getServerCount(m map[string]*bd.RegistryServerConfig) uint32 {
	return uint32(len(m))
}

func getServiceCount(m map[string]*list.List) uint32 {
	var count uint32 = 0
	for _, v := range m {
		count += uint32(v.Len())
	}
	return count
}

func getRegistryPbFormat() ([]byte, error) {
	rsp := &mfxbase.QueryRegistryRsp{}
	rsp.Result = 0

	server := getServerMap()
	serverLen := getServerCount(server)

	service := getServiceMap()
	serviceLen := getServiceCount(service)

	serverArray := make([]*mfxbase.RegistryServer, serverLen)
	i := 0
	for _, v := range server {
		c := v
		s := &mfxbase.RegistryServer{
			App:           c.App,
			Server:        c.Server,
			Division:      c.Division,
			Node:          c.Node,
			UseAgent:      c.UseAgent,
			NodeStatus:    c.NodeStatus,
			ServiceStatus: c.ServiceStatus,
		}
		serverArray[i] = s
		i += 1
	}
	rsp.Servers = serverArray

	serviceArray := make([]*mfxbase.RegistryService, serviceLen)
	i = 0
	for _, v := range service {
		for e := v.Front(); e != nil; e = e.Next() {
			c := e.Value.(bd.RegistryServiceConfig)
			s := &mfxbase.RegistryService{
				App:         c.App,
				Server:      c.Server,
				Division:    c.Division,
				Node:        c.Node,
				Service:     c.Service,
				ServiceIp:   c.ServiceIp,
				ServicePort: c.ServicePort,
				RpcPort:     c.RpcPort,
				AdminPort:   c.AdminPort,
			}
			serviceArray[i] = s
			i += 1
		}
	}
	rsp.Services = serviceArray

	return proto.Marshal(rsp)
}

func getRegistryServerString() string {
	m := getServerMap()
	s := ""

	for k, v := range m {
		s += k
		s += "\n"
		c := v
		s1 := fmt.Sprintf("app=%s, server=%s, division=%s, node=%s, use_agent=%v, node_status=%v, service_status=%v",
			c.App, c.Server, c.Division, c.Node, c.UseAgent, c.NodeStatus, c.ServiceStatus)
		s += s1
		s += "\n"
	}

	return s
}

func getRegistryServiceString() string {
	m := getServiceMap()
	s := ""

	for k, v := range m {
		s += k
		s += "\n"
		for e := v.Front(); e != nil; e = e.Next() {
			c := e.Value.(bd.RegistryServiceConfig)
			s1 := fmt.Sprintf("app=%s, server=%s, division=%s, node=%s, service=%s, serviceip=%s, serviceport=%d, adminport=%d, rpcport=%d",
				c.App, c.Server, c.Division, c.Node, c.Service, c.ServiceIp, c.ServicePort, c.AdminPort, c.RpcPort)
			s += s1
			s += "\n"
		}
	}

	return s
}

func addRegistryServer(server *bd.RegistryServerConfig) error {
	db, err := sql.Open("mysql", dbstr)
	if err = db.Ping(); err != nil {
		return err
	}
	defer db.Close()

	_, err = db.Exec("INSERT INTO t_server (app, server, division, node, use_agent, node_status, service_status) VALUES (?,?,?,?,?,?,?)",
		server.App, server.Server, server.Division, server.Node, server.UseAgent, server.NodeStatus, server.ServiceStatus)
	if err != nil {
		log.Error().Msgf("add registry server failed, %s", err.Error())
	}

	return err
}

func addRegistryService(service *bd.RegistryServiceConfig) error {
	db, err := sql.Open("mysql", dbstr)
	if err = db.Ping(); err != nil {
		return err
	}
	defer db.Close()

	_, err = db.Exec("INSERT INTO t_service (app, server, division, node, service, service_ip, service_port, admin_port, rpc_port) VALUES (?,?,?,?,?,?,?,?,?)",
		service.App, service.Server, service.Division, service.Node, service.Service, service.ServiceIp, service.ServicePort, service.AdminPort, service.RpcPort)

	if err != nil {
		log.Error().Msgf("add registry service failed, %s", err.Error())
	}

	return err
}

func editRegistryServer(server *bd.RegistryServerConfig) error {
	db, err := sql.Open("mysql", dbstr)
	if err = db.Ping(); err != nil {
		return err
	}
	defer db.Close()

	_, err = db.Exec("UPDATE t_server SET use_agent = ?, node_status = ?, service_status = ? WHERE app = ? AND server = ? AND division = ? AND node = ?",
		server.UseAgent, server.NodeStatus, server.ServiceStatus, server.App, server.Server, server.Division, server.Node)

	return err
}

func editRegistryService(service *bd.RegistryServiceConfig) error {
	db, err := sql.Open("mysql", dbstr)
	if err = db.Ping(); err != nil {
		return err
	}
	defer db.Close()

	_, err = db.Exec("UPDATE t_service SET service_ip = ?, service_port = ?, admin_port = ?, rpc_port = ? WHERE app = ? AND server = ? AND division = ? AND node = ? AND service = ?",
		service.ServiceIp, service.ServicePort, service.AdminPort, service.RpcPort, service.App, service.Server, service.Division, service.Node, service.Service)

	return err
}

func delRegistryServer(app, server, division, node string) error {
	db, err := sql.Open("mysql", dbstr)
	if err = db.Ping(); err != nil {
		return err
	}
	defer db.Close()
	_, err = db.Exec("DELETE FROM t_server WHERE app = ? AND server = ? AND division = ? AND node = ?",
		app, server, division, node)

	return err
}

func delRegistryService(app, server, division, node, service string) error {
	db, err := sql.Open("mysql", dbstr)
	if err = db.Ping(); err != nil {
		return err
	}
	defer db.Close()
	_, err = db.Exec("DELETE FROM t_service WHERE app = ? AND server = ? AND division = ? AND node = ? AND service = ?",
		app, server, division, node, service)

	return err
}

func getAllServersFromDB() (res []bd.RegistryServerConfig, err error) {
	db, err := sql.Open("mysql", dbstr)
	if err = db.Ping(); err != nil {
		return
	}
	rows, err := db.Query("SELECT app, server, division, node, use_agent, node_status, service_status FROM t_server")
	if err != nil {
		return
	}
	defer rows.Close()

	for rows.Next() {
		var (
			app           string
			server        string
			division      string
			node          string
			useAgent      uint32
			nodeStatus    uint32
			serviceStatus uint32
		)
		err = rows.Scan(&app, &server, &division, &node, &useAgent, &nodeStatus, &serviceStatus)
		if err != nil {
			return
		}
		c := bd.RegistryServerConfig{
			App: app, Server: server, Division: division, Node: node, UseAgent: useAgent, NodeStatus: nodeStatus,
			ServiceStatus: serviceStatus,
		}
		res = append(res, c)
	}
	return
}

func getAllServicesFromDB() (res []bd.RegistryServiceConfig, err error) {
	db, err := sql.Open("mysql", dbstr)
	if err = db.Ping(); err != nil {
		return
	}
	rows, err := db.Query("SELECT app, server, division, node, service, service_ip, service_port, admin_port, rpc_port FROM t_service")
	if err != nil {
		return
	}
	defer rows.Close()

	for rows.Next() {
		var (
			app         string
			server      string
			division    string
			node        string
			service     string
			serviceIp   string
			servicePort int32
			adminPort   int32
			rpcPort     int32
		)
		err = rows.Scan(&app, &server, &division, &node, &service, &serviceIp, &servicePort, &adminPort, &rpcPort)
		if err != nil {
			return
		}
		rowData := bd.RegistryServiceConfig{
			App:         app,
			Server:      server,
			Division:    division,
			Node:        node,
			Service:     service,
			ServiceIp:   serviceIp,
			ServicePort: servicePort,
			AdminPort:   adminPort,
			RpcPort:     rpcPort,
		}
		res = append(res, rowData)
	}
	return
}

// LocatorService的实现

type LocatorServer struct{}

func (s *LocatorServer) QueryRegistry(ctx context.Context, in *mfxbase.QueryRegistryReq) (*mfxbase.QueryRegistryRsp, error) {
	defer cp.CoredumpHandler()

	rsp := &mfxbase.QueryRegistryRsp{}
	rsp.Result = 0

	server := getServerMap()
	serverLen := getServerCount(server)

	service := getServiceMap()
	serviceLen := getServiceCount(service)

	serverArray := make([]*mfxbase.RegistryServer, serverLen)
	i := 0
	for _, v := range server {
		c := v
		s := &mfxbase.RegistryServer{
			App:           c.App,
			Server:        c.Server,
			Division:      c.Division,
			Node:          c.Node,
			UseAgent:      c.UseAgent,
			NodeStatus:    c.NodeStatus,
			ServiceStatus: c.ServiceStatus,
		}
		serverArray[i] = s
		i += 1
	}
	rsp.Servers = serverArray

	serviceArray := make([]*mfxbase.RegistryService, serviceLen)
	i = 0
	for _, v := range service {
		for e := v.Front(); e != nil; e = e.Next() {
			c := e.Value.(bd.RegistryServiceConfig)
			s := &mfxbase.RegistryService{
				App:         c.App,
				Server:      c.Server,
				Division:    c.Division,
				Node:        c.Node,
				Service:     c.Service,
				ServiceIp:   c.ServiceIp,
				ServicePort: c.ServicePort,
				RpcPort:     c.RpcPort,
				AdminPort:   c.AdminPort,
			}
			serviceArray[i] = s
			i += 1
		}
	}
	rsp.Services = serviceArray

	var adminFromArray []string
	for k, v := range adminFromMap {
		if v == 0 {
			adminFromArray = append(adminFromArray, k)
		}
	}
	rsp.AdminFrom = adminFromArray

	return rsp, nil
}
