package main

import (
	"encoding/json"
	"github.com/rs/zerolog/log"
	"net/http"
	lu "shared/mfxlogutil"
	bd "shared/mfxbasedef"
	"fmt"
	"net"
)

// Web 服务

type adminWebRsp struct {
	Result uint   `json:"result"`
	Error  string `json:"error"`
	Msg    string `json:"msg"`
}

func adminWebHandler(w http.ResponseWriter, r *http.Request) {
	var result adminWebRsp
	w.Header().Add("Access-Control-Allow-Origin", "*")

	//remoteIp := strings.Split(r.RemoteAddr, ":")[0]
	rip := r.Header.Get("X-Forwarded-For")
	if rip == "" {
		rip, _, _ = net.SplitHostPort(r.RemoteAddr)
	}
	adminAddrMap := getAdminFromMap()
	if state, ok := adminAddrMap[rip]; !ok || state != 0 {
		result.Result = 1
		result.Error = "access denied"
		rsp, _ := json.Marshal(result)
		log.Info().Msgf("access denied, remote ip: %s", rip)
		w.Write(rsp)
		return
	}

	r.ParseForm()
	log.Debug().Msgf("http request form: %v", r.Form)
	op := r.FormValue("op")
	switch op {
	case "query":
		log.Info().Msg("query the registry")
		info1 := getRegistryServerString()
		info2 := getRegistryServiceString()
		info1 += " | "
		info1 += info2
		result.Result = 0
		result.Msg = info1
		/*
			case "query_pb":
				log.Info().Msg("query the registry by pb-format")
				bin, err := getRegistryPbFormat()
				if err != nil {
					log.Error().Msgf("marshal failed: %s", err.Error())
				} else {
					w.Write(bin)
				}
				return*/
	case "query_from_db":
		log.Info().Msg("query registry from db")
		servers, err1 := getAllServersFromDB()
		services, err2 := getAllServicesFromDB()
		if err1 != nil || err2 != nil {
			result.Result = 1
			result.Error = "query registry error"
			break
		}
		fmt.Printf("serverLen: %d, serviceLen: %d,", len(servers), len(services))
		serversJson, err1 := json.Marshal(servers)
		servicesJson, err2 := json.Marshal(services)
		if err1 != nil || err2 != nil {
			result.Result = 1
			result.Error = "marshal failed"
			break
		}
		result.Result = 0
		result.Msg = string(serversJson) + "|" + string(servicesJson)

	case "add":
		addType := r.FormValue("type")
		contentStr := r.FormValue("content")
		content := []byte(contentStr)
		if addType == "server" {
			log.Info().Msg("add registry server")
			serverConfig := &bd.RegistryServerConfig{}
			err := json.Unmarshal(content, serverConfig)
			if err != nil {
				result.Result = 1
				result.Error = "unmarshal content failed"
				break
			}

			err = addRegistryServer(serverConfig)
			if err != nil {
				result.Result = 1
				result.Error = "add server failed, " + err.Error()
			}
		} else if addType == "service" {
			log.Info().Msg("add registry service")
			serviceConfig := &bd.RegistryServiceConfig{}
			err := json.Unmarshal(content, serviceConfig)
			if err != nil {
				result.Result = 1
				result.Error = "unmarshal content failed"
				break
			}

			err = addRegistryService(serviceConfig)
			if err != nil {
				result.Result = 1
				result.Error = "add server failed, " + err.Error()
			}
		}
	case "edit":
		editType := r.FormValue("type")
		contentStr := r.FormValue("content")
		content := []byte(contentStr)
		if editType == "server" {
			serverConfig := &bd.RegistryServerConfig{}
			err := json.Unmarshal(content, serverConfig)
			if err != nil {
				result.Result = 1
				result.Error = "unmarshal content failed"
				break
			}
			log.Info().Msgf("edit registry server, %v", serverConfig)
			err = editRegistryServer(serverConfig)
			if err != nil {
				result.Result = 1
				result.Error = "edit server failed, " + err.Error()
			}
		} else if editType == "service" {
			serviceConfig := &bd.RegistryServiceConfig{}
			err := json.Unmarshal(content, serviceConfig)
			if err != nil {
				result.Result = 1
				result.Error = "unmarshal content failed"
				break
			}
			log.Info().Msgf("edit registry service, %v", serviceConfig)
			err = editRegistryService(serviceConfig)
			if err != nil {
				result.Result = 1
				result.Error = "edit service failed, " + err.Error()
			}
		}
	case "del":
		delType := r.FormValue("type")
		app := r.FormValue("app")
		server := r.FormValue("server")
		division := r.FormValue("division")
		node := r.FormValue("node")
		var err error
		if delType == "server" {
			err = delRegistryServer(app, server, division, node)
		} else if delType == "service" {
			service := r.FormValue("service")
			err = delRegistryService(app, server, division, node, service)
		}
		if err != nil {
			result.Result = 1
			result.Error = "del registry failed, " + err.Error()
		}

	case "log":
		newLevel := lu.SetupLogLevel(r.FormValue("level"))
		log.Info().Msgf("log level set to %s", newLevel)
		result.Result = 0
		result.Msg = "log level set ok"
	case "":
		result.Result = 1
		result.Error = "invalid operation"
	default:
		result.Result = 1
		result.Error = "invalid operation"
	}

	rsp, _ := json.Marshal(result)
	w.Write(rsp)
}
