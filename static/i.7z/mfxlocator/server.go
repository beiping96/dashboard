package main

import (
	"encoding/xml"
	"fmt"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"net/http"
	bd "shared/mfxbasedef"
	lu "shared/mfxlogutil"
)

type MfxLocatorConfig struct {
	// 使用Mysql来从db里加载所有服务节点信息
	Mysql bd.MysqlConnection `xml:"mysql"`

	// 提供服务节点信息拉取
	Business bd.EndPoint `xml:"business"`
	Admin    bd.EndPoint `xml:"admin"`
	LogPath  string      `xml:"log_path"`
	LogLevel string      `xml:"log_level"`
	Threads  uint32      `xml:"threads"`

	// 专用配置
	RegistryRefreshInterval uint32 `xml:"registry_refresh_interval"`
}

/*
	开启本服务，会根据xml配置文件开启两个端口
	1 业务端口，可以使用socket+protobuf交互
	2 管理端口，可以利用http直接访问，比如动态修改日志等级

*/
func start(xmlFile string) bool {
	fmt.Printf("start with config: %s\n", xmlFile)

	fileData, err := ioutil.ReadFile(xmlFile)
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		return false
	}

	var config MfxLocatorConfig
	err = xml.Unmarshal(fileData, &config)
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		return false
	}

	fmt.Printf("log path=%s, level=%s\n", config.LogPath, config.LogLevel)

	// 设置日志输出与日志级别
	lu.SetupLogPath(config.LogPath)
	lu.SetupLogLevel(config.LogLevel)

	// 输出基础配置
	log.Info().Msgf("start with config: %s", xmlFile)
	log.Debug().Msgf("mysql connection: %s:%s", config.Mysql.Ep.Ip, config.Mysql.Ep.Port)
	log.Debug().Msgf("mysql database=%s, username=%s, password=%s", config.Mysql.Database, config.Mysql.Username, config.Mysql.Password)
	log.Debug().Msgf("business ip=%s, port=%s", config.Business.Ip, config.Business.Port)
	log.Debug().Msgf("admin ip=%s, port=%s", config.Admin.Ip, config.Admin.Port)
	log.Debug().Msgf("log path=%s, level=%s", config.LogPath, config.LogLevel)
	log.Debug().Msgf("threads=%d", config.Threads)

	// 绑定business端口，以socket+pb方式提供业务服务
	// 以另一个协程的方式运行初始化，与本协程以chan方式通信
	ch := make(chan string, 10)
	go startBusiness(config, ch)
	select {
	case s, _ := <-ch:
		if s == "ready" {
			log.Info().Msg("business is ready now")
			break
		} else {
			log.Error().Msgf("business send %s", s)
			log.Info().Msg("admin should exit by business exit or error")
			return false
		}
	}

	// 绑定admin端口，以web方式提供admin服务
	adminAddr := config.Admin.Ip + ":" + config.Admin.Port
	log.Info().Msgf("bind admin addr=%s", adminAddr)

	http.HandleFunc("/admin", adminWebHandler)
	admin := &http.Server{Addr: adminAddr, Handler: nil}
	err = admin.ListenAndServe()
	if err != nil {
		log.Fatal().Msgf("admin listen failed: %s", err.Error())
		return false
	}

	log.Info().Msg("admin exit")
	return true
}
