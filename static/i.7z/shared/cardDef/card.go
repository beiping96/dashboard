package cardDef

import (
	rds "shared/proto/server/battle"
	db "shared/proto/server/lobby"
)

type TypeID uint32

type Card struct {
	typeID      TypeID
	star        uint32
	isNewUnlock bool
}

func New(cardTypeID TypeID) (*Card, error) {
	return &Card{
		typeID:      cardTypeID,
		star:        1,
		isNewUnlock: true,
	}, nil
}

func (c Card) GetTypeID() TypeID {
	return c.typeID
}

func (c *Card) GetCardStarLevel() uint32 {
	return c.star
}

func (c *Card) SetCardStarLevel(laststar uint32) {
	c.star = laststar
}

func (c *Card) GetIsNewUnlock() bool {
	return c.isNewUnlock
}

func (c *Card) CardShow() {
	c.isNewUnlock = false
}

func FromDbProto(basic *db.DbPlayerCard) *Card {
	return &Card{
		typeID:      TypeID(basic.GetTypeID()),
		star:        basic.GetStar(),
		isNewUnlock: basic.GetIsNewUnlock(),
	}
}

func (c Card) ToDbProto() *db.DbPlayerCard {
	return &db.DbPlayerCard{
		TypeID:      uint32(c.typeID),
		Star:        c.star,
		IsNewUnlock: c.isNewUnlock,
	}
}

func FromRdsProto(basic *rds.RdsStarCard) Card {
	return Card{
		typeID: TypeID(basic.GetTypeId()),
		star:   basic.GetStar(),
	}
}

func (c Card) ToRdsProto() *rds.RdsStarCard {
	return &rds.RdsStarCard{
		TypeId: uint32(c.GetTypeID()),
		Star:   c.GetCardStarLevel(),
	}
}
