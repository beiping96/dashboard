package table

import (
	"github.com/rs/zerolog/log"
	"shared/csv"
	"strconv"
	"strings"
)

func GetHeroInitCards(heroTypeId int64) ([]int, bool) {
	cards, ok := heroInitCardsMap[heroTypeId]
	if !ok {
		log.Warn().Msgf("hero type id: %d not exist", heroTypeId)
	}
	return cards, ok
}

func GetTableCard(groupId, level uint32) (card TableCard, ok bool) {
	key := getDualKey(int64(groupId), int64(level))
	card, ok = cardMap[key]
	if !ok {
		log.Warn().Msgf("table card not found, groupId: %d, level: %d", groupId, level)
	}
	return
}

func GetAllCurseCardResIds() []uint32 {
	return curseCardResIds
}

func GetCardGrow(cardGroupId, starLevel uint32) (cardGrow *csv.TableCardGrowing, ok bool) {
	key := getDualKey(int64(cardGroupId), int64(starLevel))
	cardGrow, ok = cardGrowMap[key]
	if !ok {
		log.Warn().Msgf("card grow not found, card groupId: %d, starLevel: %d", cardGroupId, starLevel)
	}
	return
}

func GetMonsterByGroupTypeAndStageLevel(groupType uint32, nodeFloor uint32, stageLevel uint32) (groupArr []StageMonsterGroup, ok bool) {
	key := getDualKey(int64(groupType), int64(stageLevel))
	groupArrAll, ok := monsterTypeStageMap[key]
	if !ok {
		log.Warn().Msgf("monster group not found, group type: %d, stage level: %d", groupType, stageLevel)
		return
	}

	for _, g := range groupArrAll {
		if int(nodeFloor) >= g.MinFloor && int(nodeFloor) <= g.MaxFloor {
			groupArr = append(groupArr, g)
		}
	}
	if len(groupArr) <= 0 {
		ok = false
	}
	return
}

func GetMonsterPropertyByGroupAndChallengeLevel(propGroupId, challengeLevel uint32) (prop *csv.MonsterProperty, ok bool) {
	key := getDualKey(int64(propGroupId), int64(challengeLevel))
	prop, ok = monsterAttrGroupChallengeLevelMap[key]
	if !ok {
		log.Warn().Msgf("monster prop not found, groupId: %d, challengeLevel: %d", propGroupId, challengeLevel)
	}
	return
}

func GetMonsterAIWeight(aiId uint32) (MonsterAIWeight, bool) {
	weight, ok := monsterAICardWeightMap[int64(aiId)]
	if !ok {
		log.Warn().Msgf("monster ai weight not found, aiId: %d", aiId)
		return MonsterAIWeight{}, false
	}
	return weight, true
}

func GetBasicDrop(dropType uint32) (drop []uint32, ok bool) {
	drop, ok = basicDropMap[int64(dropType)]
	if !ok {
		log.Warn().Msgf("basic drop not found, dropType: %d", dropType)
	}
	return
}

func GetDropGoldConfig(mode, stageLevel, nodeType uint32) (cfg *csv.DropGold, ok bool) {
	key := getTripleKey(int64(mode), int64(stageLevel), int64(nodeType))
	cfg, ok = dropGoldMap[key]
	if !ok {
		log.Warn().Msgf("drop coin config not found, mode: %d, stageLevel: %d, nodeType: %d", mode, stageLevel, nodeType)
	}
	return
}

func GetPotionsFromTable(potionId uint32) (PotionInTable, bool) {
	potion, ok := potionInTableMap[int64(potionId)]
	if !ok {
		log.Warn().Msgf("potion %d not found", potionId)
	}
	return potion, ok
}

func GetAllPotionIds() []uint32 {
	return potionIds
}

func GetDropRelation(difficulty, stageLevel, dropFrom uint32) (relation *DropRelation, ok bool) {
	key := getTripleKey(int64(difficulty), int64(stageLevel), int64(dropFrom))
	relation, ok = dropRelationMap[key]
	if !ok {
		log.Warn().Msgf("drop relation not found, difficulty: %d, stageLevel: %d, dropFrom: %d", difficulty, stageLevel, dropFrom)
	}
	return
}

func GetGroupCardsByGroupId(groupId uint32) (groupCardTypeIDMap map[uint32]*csv.CardDropGroup, ok bool) {
	cards, ok := cardDropGroupMap[int64(groupId)]
	groupCardTypeIDMap = make(map[uint32]*csv.CardDropGroup)
	if !ok {
		log.Warn().Msgf("group cards not found, group Id: %d", groupId)
	} else {
		for _, c := range cards {
			groupCardTypeIDMap[uint32(c.Card_Type_ID)] = c
		}
	}
	return
}

func GetGroupRelicsByGroupId(groupId uint32) (groupRelicsMap map[uint32]*csv.RelicDropGroup, ok bool) {
	relics, ok := relicDropGroupMap[int64(groupId)]
	groupRelicsMap = make(map[uint32]*csv.RelicDropGroup)
	if !ok {
		log.Warn().Msgf("group relics not found, groupId: %d", groupId)
	} else {
		for _, r := range relics {
			groupRelicsMap[uint32(r.Relic_ID)] = r
		}
	}
	return
}

func GetGroupPotionsByGroupId(groupId uint32) (groupPotionsMap map[uint32]*csv.PotionDropGroup, ok bool) {
	potions, ok := potionDropGroupMap[int64(groupId)]
	groupPotionsMap = make(map[uint32]*csv.PotionDropGroup)
	if !ok {
		log.Warn().Msgf("group potions not found, groupId: %d", groupId)
	} else {
		for _, p := range potions {
			groupPotionsMap[uint32(p.Potion_ID)] = p
		}
	}
	return
}

func GetHeroInitUnlockCardsFromCsv(typeID int64) []int {
	v, ok := csv.TableCareerInitialValueMap[typeID]
	if !ok {
		return nil
	}
	cardStrArr := strings.Split(v.InitUnlockCards, ",")
	ids := make([]int, len(cardStrArr))
	for i, id := range cardStrArr {
		id, err := strconv.Atoi(id)
		if err != nil {
			return nil
		}
		ids[i] = id
	}
	return ids
}

func GetCardGrowFromCsv(ID int64) *csv.TableCardGrowing {
	cardGrow, ok := csv.TableCardGrowingMap[ID]
	if !ok {
		return nil
	}
	return cardGrow
}

func GetHeroGrowFromCsv(ID int64) *csv.TableHeroGrowing {
	heroGrow, ok := csv.TableHeroGrowingMap[ID]
	if !ok {
		return nil
	}
	return heroGrow
}

func GetStageEventConf(stageLevel, nodeFloor uint32) (events []*csv.StageEventRandom) {
	//var events []*csv.StageEventRandom
	for _, e := range csv.StageEventRandomMap {
		if (e.Stage_Level == 0 || e.Stage_Level == int(stageLevel)) && (int(nodeFloor) >= e.Min_Floor && int(nodeFloor) <= e.Max_Floor) {
			events = append(events, e)
		}
	}
	return
}

func GetStageEvent(eventId uint32) (event StageEvent, ok bool) {
	event, ok = stageEventMap[eventId]
	if !ok {
		log.Warn().Msgf("stage event not found, eventID: %d", eventId)
	}
	return
}

func GetUnknownNodeProbConfig(mode, stageLevel uint32) (cfg *csv.StageUnknownNodeProbability, ok bool) {
	key := getDualKey(int64(mode), int64(stageLevel))
	cfg, ok = unknownNodeProbMap[key]
	if !ok {
		log.Warn().Msgf("unknown node probability config not found, mode: %d, stageLevel: %d", mode, stageLevel)
	}
	return
}

func GetWeekdayCardShopMap() map[int64]*csv.TableCardShop {
	return weekdayCardShopMap
}

func GetWeekendCardShopMap() map[int64]*csv.TableCardShop {
	return weekendCardShopMap
}

func GetCardBag(ID uint32) *csv.TableCardBag {
	cardBag, ok := csv.TableCardBagMap[int64(ID)]
	if !ok {
		return nil
	}
	return cardBag
}

func GetCardBagDrop(ID uint32) *csv.TableCardBagDrop {
	cBDrop, ok := csv.TableCardBagDropMap[int64(ID)]
	if !ok {
		return nil
	}
	return cBDrop
}

func GetCardBagGroup(DropID uint32) map[int64]*csv.TableCardBagGroup {
	cardDropList := make(map[int64]*csv.TableCardBagGroup)
	for k, v := range csv.TableCardBagGroupMap {
		if uint32(v.DropGroupID) == DropID {
			cardDropList[k] = v
		}
	}
	return cardDropList
}

func GetCardTypeIDByPieceID(PieceID int) int {
	for _, v := range csv.TableCardGrowingMap {
		if v.CardPropID == PieceID {
			return v.CardGroupID
		}
	}
	return 0
}

func GetCoinConvertByID(ID int) *csv.TableCoinConvert {
	for i, v := range csv.TableCoinConvertMap {
		if v.ID == ID {
			return csv.TableCoinConvertMap[i]
		}
	}
	return nil
}

func GetStageMapSelection(mode, stageLevel uint32) (selectionArr []*csv.StageMapSelection, ok bool) {
	key := getDualKey(int64(mode), int64(stageLevel))
	selectionArr, ok = stageModeLevelMap[key]
	if !ok {
		log.Warn().Msgf("stage mode level selection not found, mode: %d, stageLevel: %d", mode, stageLevel)
	}
	return
}

func GetCardBagTradeByID(ID int) *csv.TableCardBagTrader {
	for i, v := range csv.TableCardBagTraderMap {
		if v.ShopPam == ID {
			return csv.TableCardBagTraderMap[i]
		}
	}
	return nil
}

func GetPropInfoByID(ID int) *csv.TableProp {
	for i, v := range csv.TablePropMap {
		if v.ID == ID {
			return csv.TablePropMap[i]
		}
	}
	return nil
}
