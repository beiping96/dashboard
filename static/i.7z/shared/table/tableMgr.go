package table

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"shared/csv"
	"strconv"
	"strings"
)

type StageMonster struct {
	MonsterId  int
	MonsterPos int
}

type StageMonsterGroup struct {
	GroupID    int
	GroupType  int
	StageLevel int
	MinFloor   int
	MaxFloor   int
	Monsters   []StageMonster
}

type TableCard struct {
	*csv.TableCards
	EffectIDs []int
}

type MonsterAICardWeight struct {
	CardId     uint32
	CardWeight uint32
}

type MonsterAIWeight struct {
	ID            uint32
	CardWeight    []MonsterAICardWeight
	TotalWeight   uint32
	OrderSequence []int
	CycleSequence []int
}

type PotionInTable struct {
	*csv.TablePotions
	Effect_IDs []int
}

type DropRelation struct {
	CardGroup   uint32
	RelicGroup  uint32
	PotionGroup uint32
}

type EventLinkage struct {
	Probability []int
	EventIds    []int
	Condition   int
	Param       int
}

type StageEvent struct {
	EffectIds  []int
	LinkEvents map[uint32]EventLinkage
}

var (
	heroInitCardsMap                  map[int64][]int
	cardMap                           map[int64]TableCard
	curseCardResIds                   []uint32
	cardGrowMap                       map[int64]*csv.TableCardGrowing
	monsterTypeStageMap               map[int64][]StageMonsterGroup
	monsterAttrGroupChallengeLevelMap map[int64]*csv.MonsterProperty
	monsterAICardWeightMap            map[int64]MonsterAIWeight
	basicDropMap                      map[int64][]uint32
	potionInTableMap                  map[int64]PotionInTable
	potionIds                         []uint32
	dropRelationMap                   map[int64]*DropRelation
	cardDropGroupMap                  map[int64][]*csv.CardDropGroup
	relicDropGroupMap                 map[int64][]*csv.RelicDropGroup
	potionDropGroupMap                map[int64][]*csv.PotionDropGroup
	weekdayCardShopMap                map[int64]*csv.TableCardShop
	weekendCardShopMap                map[int64]*csv.TableCardShop
	stageEventMap                     map[uint32]StageEvent
	stageModeLevelMap                 map[int64][]*csv.StageMapSelection
	dropGoldMap                       map[int64]*csv.DropGold
	unknownNodeProbMap                map[int64]*csv.StageUnknownNodeProbability
)

func getDualKey(m, n int64) int64 {
	return m<<32 + n
}

func getTripleKey(x, y, z int64) int64 {
	return x<<48 + y<<32 + z
}

func init() {
	checkStageEventRandom()
	checkStageInitEvent()

	initHeroInitCards()
	initCards()
	//initCardEffects()
	initCardGrowing()
	initLevelMonster()
	initMonsterAttr()
	initMonsterAIWeightMap()
	initBasicDrop()
	initPotions()

	initDropGold()
	initCardDropGroup()
	initRelicDropGroup()
	initPotionDropGroup()
	initDropRelation() // 必须在initCardDropGroup()之后执行
	initCardShop()
	initStageEvent()
	initStageMapSelection()
	initUnknownNodeProbability()
}

func initHeroInitCards() {
	heroInitCardsMap = make(map[int64][]int)
	errMap := make(map[int64]string)
	for k, v := range csv.TableCareerInitialValueMap {
		cards := v.InitCards
		cardStrArr := strings.Split(cards, ",")
		ids := make([]int, len(cardStrArr))
		for i, id := range cardStrArr {
			id, err := strconv.Atoi(id)
			if err != nil {
				errMap[k] = cards
				break
			}
			ids[i] = id
		}
		heroInitCardsMap[k] = ids
	}
	if len(errMap) > 0 {
		log.Error().Msg("table career init value err")
		for k, v := range errMap {
			log.Error().Msgf("card_id: %d, init cards: %s", k, v)
		}
		panic("table career init value err")
	}
}

func parseToIntArr(strArr []string) (res []int, err error) {
	for _, v := range strArr {
		iv, err := strconv.Atoi(v)
		if err != nil {
			return nil, err
		}
		res = append(res, iv)
	}
	return
}

func initCards() {
	cardMap = make(map[int64]TableCard)
	errMap := make(map[int64]string)
	for id, c := range csv.TableCardsMap {
		key := getDualKey(int64(c.CardGroupID), int64(c.Level))
		effectIds, err := parseToIntArr(strings.Split(c.EffectIDs, ","))
		if err != nil {
			errMap[id] = c.EffectIDs
			continue
		}
		card := TableCard{TableCards: c, EffectIDs: effectIds}
		if c.Type == csv.CARD_TYPE_CURSE {
			curseCardResIds = append(curseCardResIds, uint32(c.ID))
		}
		cardMap[key] = card
	}
	if len(errMap) > 0 {
		log.Error().Msgf("init card table failed >>>>>>>>")
		for id, effectIds := range errMap {
			log.Error().Msgf("ID: %d, effectIds: %s", id, effectIds)
		}
		panic("init card table failed <<<<<<<<")
	}
}

func initCardGrowing() {
	cardGrowMap = make(map[int64]*csv.TableCardGrowing)
	for _, c := range csv.TableCardGrowingMap {
		key := getDualKey(int64(c.CardGroupID), int64(c.CardStar))
		cardGrowMap[key] = c
	}
}

func initLevelMonster() {
	monsterTypeStageMap = make(map[int64][]StageMonsterGroup)
	for _, t := range csv.LevelMonsterMap {
		var monsterGroup StageMonsterGroup
		monsterGroup.GroupID = t.ID
		monsterGroup.GroupType = t.MonsterGroupType
		monsterGroup.StageLevel = t.Level_Config
		monsterGroup.MinFloor = t.Min_Floor
		monsterGroup.MaxFloor = t.Max_Floor
		if t.Monster1_ID != 0 {
			monster := StageMonster{MonsterId: t.Monster1_ID, MonsterPos: t.Monster1_Pos}
			monsterGroup.Monsters = append(monsterGroup.Monsters, monster)
		}
		if t.Monster2_ID != 0 {
			monster := StageMonster{MonsterId: t.Monster2_ID, MonsterPos: t.Monster2_Pos}
			monsterGroup.Monsters = append(monsterGroup.Monsters, monster)
		}
		if t.Monster3_ID != 0 {
			monster := StageMonster{MonsterId: t.Monster3_ID, MonsterPos: t.Monster3_Pos}
			monsterGroup.Monsters = append(monsterGroup.Monsters, monster)
		}
		if t.Monster4_ID != 0 {
			monster := StageMonster{MonsterId: t.Monster4_ID, MonsterPos: t.Monster4_Pos}
			monsterGroup.Monsters = append(monsterGroup.Monsters, monster)
		}
		key := getDualKey(int64(monsterGroup.GroupType), int64(monsterGroup.StageLevel))
		arr, ok := monsterTypeStageMap[key]
		if ok {
			arr = append(arr, monsterGroup)
		} else {
			arr = make([]StageMonsterGroup, 1)
			arr[0] = monsterGroup
		}

		monsterTypeStageMap[key] = arr
	}
}

func initMonsterAttr() {
	monsterAttrGroupChallengeLevelMap = make(map[int64]*csv.MonsterProperty)
	for _, v := range csv.MonsterPropertyMap {
		key := getDualKey(int64(v.Property_ID), int64(v.Challenge_Level))
		monsterAttrGroupChallengeLevelMap[key] = v
	}
}

func initMonsterAIWeightMap() {
	//monsterAIWeightMap = make(map[int64] int32)
	monsterAICardWeightMap = make(map[int64]MonsterAIWeight)
	errMap := make(map[int64]string)
	for id, v := range csv.MonsterAIMap {
		var monsterAiWeight MonsterAIWeight
		if v.OrderSequence != "" {
			orderSq := strings.Split(v.OrderSequence, ",")
			orderArr, err := parseToIntArr(orderSq)
			if err != nil {
				errMap[id] = v.OrderSequence
				continue
			}
			monsterAiWeight.OrderSequence = orderArr
		}
		if v.CycleSequence != "" {
			sq := strings.Split(v.CycleSequence, ",")
			arr, err := parseToIntArr(sq)
			if err != nil {
				errMap[id] = v.CycleSequence
				continue
			}
			monsterAiWeight.CycleSequence = arr
		}

		weight := 0

		if v.Card_ID_1 != 0 {
			weight += v.Card_Weight_1
			monsterAiWeight.CardWeight = append(monsterAiWeight.CardWeight, MonsterAICardWeight{CardId: uint32(v.Card_ID_1), CardWeight: uint32(v.Card_Weight_1)})
		}
		if v.Card_ID_2 != 0 {
			weight += v.Card_Weight_2
			monsterAiWeight.CardWeight = append(monsterAiWeight.CardWeight, MonsterAICardWeight{CardId: uint32(v.Card_ID_2), CardWeight: uint32(v.Card_Weight_2)})
		}
		if v.Card_ID_3 != 0 {
			weight += v.Card_Weight_3
			monsterAiWeight.CardWeight = append(monsterAiWeight.CardWeight, MonsterAICardWeight{CardId: uint32(v.Card_ID_3), CardWeight: uint32(v.Card_Weight_3)})
		}
		if v.Card_ID_4 != 0 {
			weight += v.Card_Weight_4
			monsterAiWeight.CardWeight = append(monsterAiWeight.CardWeight, MonsterAICardWeight{CardId: uint32(v.Card_ID_4), CardWeight: uint32(v.Card_Weight_4)})
		}
		if v.Card_ID_5 != 0 {
			weight += v.Card_Weight_5
			monsterAiWeight.CardWeight = append(monsterAiWeight.CardWeight, MonsterAICardWeight{CardId: uint32(v.Card_ID_5), CardWeight: uint32(v.Card_Weight_5)})
		}
		if v.Card_ID_6 != 0 {
			weight += v.Card_Weight_6
			monsterAiWeight.CardWeight = append(monsterAiWeight.CardWeight, MonsterAICardWeight{CardId: uint32(v.Card_ID_6), CardWeight: uint32(v.Card_Weight_6)})
		}
		//monsterAIWeightMap[id] = int32(weight)
		monsterAiWeight.TotalWeight = uint32(weight)
		monsterAiWeight.ID = uint32(id)
		monsterAICardWeightMap[id] = monsterAiWeight
	}
	if len(errMap) > 0 {
		log.Error().Msgf("monster ai init failed, sequence error>>>>")
		for k, v := range errMap {
			log.Error().Msgf("ai id: %d, sequence: %s", k, v)
		}
		panic("monster ai init failed, sequence error<<<<")
	}
}

func initBasicDrop() {
	basicDropMap = make(map[int64][]uint32)
	for k, v := range csv.BasicDropMap {
		dropItems := []uint32{}
		if v.Drop_1 != csv.DROP_ITEM_TYPE_NONE {
			dropItems = append(dropItems, uint32(v.Drop_1))
		}
		if v.Drop_2 != csv.DROP_ITEM_TYPE_NONE {
			dropItems = append(dropItems, uint32(v.Drop_2))
		}
		if v.Drop_3 != csv.DROP_ITEM_TYPE_NONE {
			dropItems = append(dropItems, uint32(v.Drop_3))
		}
		if v.Drop_4 != csv.DROP_ITEM_TYPE_NONE {
			dropItems = append(dropItems, uint32(v.Drop_4))
		}
		if v.Drop_5 != csv.DROP_ITEM_TYPE_NONE {
			dropItems = append(dropItems, uint32(v.Drop_5))
		}
		if v.Drop_6 != csv.DROP_ITEM_TYPE_NONE {
			dropItems = append(dropItems, uint32(v.Drop_6))
		}
		basicDropMap[k] = dropItems
	}
}

func initPotions() {
	numPotions := len(csv.TablePotionsMap)
	if numPotions == 0 {
		panic("no data in potions table")
	}
	potionIds = make([]uint32, numPotions, numPotions)
	potionInTableMap = make(map[int64]PotionInTable)
	errParseMap := make(map[uint32]string)
	var errEffectIdNotExist []uint32
	i := 0
	for k, v := range csv.TablePotionsMap {
		potionIds[i] = uint32(v.ID)
		i++
		effects := strings.Split(v.Effect_IDs, ",")
		effectIds, err := parseToIntArr(effects)
		if err != nil {
			errParseMap[uint32(v.ID)] = v.Effect_IDs
		}
		for _, id := range effectIds {
			_, ok := csv.TableCardEffectMap[int64(id)]
			if !ok {
				errEffectIdNotExist = append(errEffectIdNotExist, uint32(id))
			}
		}
		potionInTableMap[k] = PotionInTable{v, effectIds}
	}
	if len(errParseMap) > 0 || len(errEffectIdNotExist) > 0 {
		log.Error().Msgf("parse potions failed>>>>")
		for k, v := range errParseMap {
			log.Error().Msgf("potion id: %d, effectIds: %s", k, v)
		}
		for _, v := range errEffectIdNotExist {
			log.Error().Msgf("effect id: %d not exist in table effect", v)
		}
		panic("table potions parse failed")
	}
}

func initCardDropGroup() {
	cardDropGroupMap = make(map[int64][]*csv.CardDropGroup)
	errMap := make(map[int]int)
	for _, v := range csv.CardDropGroupMap {
		_, ok := GetTableCard(uint32(v.Card_Type_ID), 1)
		if !ok {
			errMap[v.ID] = v.Card_Type_ID
			continue
		}
		group, ok := cardDropGroupMap[int64(v.Group_ID)]
		if !ok {
			group = make([]*csv.CardDropGroup, 1)
			group[0] = v
		} else {
			group = append(group, v)
		}
		cardDropGroupMap[int64(v.Group_ID)] = group
	}
	if len(errMap) > 0 {
		log.Error().Msgf("init table card drop group failed>>>>>>")
		for k, v := range errMap {
			log.Error().Msgf("card type id not found from table card, id: %d, typeId: %d", k, v)
		}
		panic("init table card drop group failed<<<<<<")
	}
}

func initRelicDropGroup() {
	relicDropGroupMap = make(map[int64][]*csv.RelicDropGroup)
	errMap := make(map[int]int)
	for _, v := range csv.RelicDropGroupMap {
		_, ok := csv.RemainsMap[int64(v.Relic_ID)]
		if !ok {
			errMap[v.ID] = v.Relic_ID
			continue
		}
		group, ok := relicDropGroupMap[int64(v.Group_ID)]
		if !ok {
			group = make([]*csv.RelicDropGroup, 1)
			group[0] = v
		} else {
			group = append(group, v)
		}
		relicDropGroupMap[int64(v.Group_ID)] = group
	}
	if len(errMap) > 0 {
		log.Error().Msgf("init table relic drop group failed>>>>>>")
		for k, v := range errMap {
			log.Error().Msgf("relic id not found from table relic, id: %d, relicId: %d", k, v)
		}
		panic("init table relic drop group failed<<<<<<")
	}
}

func initPotionDropGroup() {
	potionDropGroupMap = make(map[int64][]*csv.PotionDropGroup)
	errMap := make(map[int]int)
	for _, v := range csv.PotionDropGroupMap {
		_, ok := csv.TablePotionsMap[int64(v.Potion_ID)]
		if !ok {
			errMap[v.ID] = v.Potion_ID
			continue
		}
		group, ok := potionDropGroupMap[int64(v.Group_ID)]
		if !ok {
			group = make([]*csv.PotionDropGroup, 1)
			group[0] = v
		} else {
			group = append(group, v)
		}
		potionDropGroupMap[int64(v.Group_ID)] = group
	}
	if len(errMap) > 0 {
		log.Error().Msgf("init table potion drop group failed>>>>>>")
		for k, v := range errMap {
			log.Error().Msgf("potion id not found from table potion, id: %d, potionId: %d", k, v)
		}
		panic("init table potion drop group failed<<<<<<")
	}
}

func initDropRelation() {
	dropRelationMap = make(map[int64]*DropRelation)
	var errIds []int
	for _, v := range csv.DropRelationMap {
		_, ok := cardDropGroupMap[int64(v.Card_Group)]
		if !ok {
			errIds = append(errIds, v.ID)
			continue
		}
		if v.Relic_Group != 0 {
			_, ok := relicDropGroupMap[int64(v.Relic_Group)]
			if !ok {
				errIds = append(errIds, v.ID)
				continue
			}
		}
		if v.Potion_Group != 0 {
			_, ok := potionDropGroupMap[int64(v.Potion_Group)]
			if !ok {
				errIds = append(errIds, v.ID)
				continue
			}
		}

		key := getTripleKey(int64(v.Difficulty), int64(v.Stage_Level), int64(v.Drop_From))
		dropRelationMap[key] = &DropRelation{
			CardGroup:   uint32(v.Card_Group),
			RelicGroup:  uint32(v.Relic_Group),
			PotionGroup: uint32(v.Potion_Group),
		}
	}
	if len(errIds) > 0 {
		log.Error().Msgf("drop relation table init failed>>>>>>")
		for _, v := range errIds {
			log.Error().Msgf("ID: %d, drop group not exist", v)
		}
		panic("drop relation table init failed<<<<<<")
	}
}

func initCardShop() {
	weekdayCardShopMap = make(map[int64]*csv.TableCardShop)
	weekendCardShopMap = make(map[int64]*csv.TableCardShop)
	for k, shop := range csv.TableCardShopMap {
		if shop.Type == csv.DAY_SHOP_NORMAL {
			weekdayCardShopMap[k] = shop
		} else {
			weekendCardShopMap[k] = shop
		}
	}
}

func initStageEvent() {
	stageEventMap = make(map[uint32]StageEvent)
	errMap := make(map[uint32][]uint32)
	for _, e := range csv.StageEventMap {
		optionMap := make(map[uint32]EventLinkage)
		//if e.Event_1_Probability == "" {
		//	continue
		//}
		var errIndex []uint32
		ef := false
		if e.Event_1_Probability != "" && e.Event_1_ID != "" {
			probs1, err := parseToIntArr(strings.Split(e.Event_1_Probability, ","))
			if err != nil {
				log.Error().Msgf("init stage event: err: %s", err.Error())
				ef = true
			}
			linkEventIds1, err := parseToIntArr(strings.Split(e.Event_1_ID, ","))
			if err != nil {
				ef = true
			}
			if !ef && len(probs1) != len(linkEventIds1) {
				ef = true
			}
			if ef {
				errIndex = append(errIndex, 1)
			} else if len(probs1) > 0 {
				optionMap[1] = EventLinkage{Probability: probs1, EventIds: linkEventIds1, Condition: e.Event_1_Condition, Param: e.Event_1_Param}
			}
		}

		if e.Event_2_Probability != "" && e.Event_2_ID != "" {
			ef = false
			probs2, err := parseToIntArr(strings.Split(e.Event_2_Probability, ","))
			if err != nil {
				ef = true
			}
			linkEventIds2, err := parseToIntArr(strings.Split(e.Event_2_ID, ","))
			if err != nil {
				ef = true
			}
			if !ef && len(probs2) != len(linkEventIds2) {
				ef = true
			}
			if ef {
				errIndex = append(errIndex, 2)
			} else if len(probs2) > 0 {
				optionMap[2] = EventLinkage{Probability: probs2, EventIds: linkEventIds2, Condition: e.Event_2_Condition, Param: e.Event_2_Param}
			}
		}

		if e.Event_3_Probability != "" && e.Event_3_ID != "" {
			ef = false
			probs3, err := parseToIntArr(strings.Split(e.Event_3_Probability, ","))
			if err != nil {
				ef = true
			}
			linkEventIds3, err := parseToIntArr(strings.Split(e.Event_3_ID, ","))
			if err != nil {
				ef = true
			}
			if !ef && len(probs3) != len(linkEventIds3) {
				ef = true
			}
			if ef {
				errIndex = append(errIndex, 3)
			} else if len(probs3) > 0 {
				optionMap[3] = EventLinkage{Probability: probs3, EventIds: linkEventIds3, Condition: e.Event_3_Condition, Param: e.Event_3_Param}
			}
		}

		if e.Event_4_Probability != "" && e.Event_4_ID != "" {
			ef = false
			probs4, err := parseToIntArr(strings.Split(e.Event_4_Probability, ","))
			if err != nil {
				ef = true
			}
			linkEventIds4, err := parseToIntArr(strings.Split(e.Event_4_ID, ","))
			if err != nil {
				ef = true
			}
			if !ef && len(probs4) != len(linkEventIds4) {
				ef = true
			}
			if ef {
				errIndex = append(errIndex, 4)
			} else if len(probs4) > 0 {
				optionMap[4] = EventLinkage{Probability: probs4, EventIds: linkEventIds4, Condition: e.Event_4_Condition, Param: e.Event_4_Param}
			}
		}
		var effects []int
		var err error
		if e.Effects != "" {
			effects, err = parseToIntArr(strings.Split(e.Effects, ","))
			var errEffect []int
			if err == nil {
				for _, eid := range effects {
					if _, ok := csv.StageEventEffectMap[int64(eid)]; !ok {
						errEffect = append(errEffect, eid)
					}
				}
				if len(errEffect) > 0 {
					panic(fmt.Sprintf("event effect: %v not exist", errEffect))
				}
			}
		}

		if err != nil || len(errIndex) > 0 {
			errMap[uint32(e.Event_ID)] = errIndex
		} else {
			stageEvent := StageEvent{EffectIds: effects, LinkEvents: optionMap}
			stageEventMap[uint32(e.Event_ID)] = stageEvent
		}
	}

	if len(errMap) > 0 {
		log.Error().Msgf("init stage event failed>>>>>")
		for eid, linkArr := range errMap {
			log.Error().Msgf("event id: %d, linkage event: %v", eid, linkArr)
		}
		panic("init stage event failed<<<<<")
	}
}

func initStageMapSelection() {
	var errIds []int
	stageModeLevelMap = make(map[int64][]*csv.StageMapSelection)
	for _, s := range csv.StageMapSelectionMap {
		if s.Difficulty_Max < s.Difficulty_Min || s.Map_ID_Max < s.Map_ID_Min {
			errIds = append(errIds, s.ID)
			continue
		}
		key := getDualKey(int64(s.Mode), int64(s.Stage_Level))
		stageModeLevelArr, _ := stageModeLevelMap[key]
		stageModeLevelArr = append(stageModeLevelArr, s)
		stageModeLevelMap[key] = stageModeLevelArr
	}
	if len(errIds) > 0 {
		log.Error().Msgf("init stage map selection failed>>>>>")
		for _, id := range errIds {
			log.Error().Msgf("init stage map selection error, id: %d", id)
		}
		panic("init stage map selection failed<<<<<")
	}
}

func initDropGold() {
	dropGoldMap = make(map[int64]*csv.DropGold)
	for _, d := range csv.DropGoldMap {
		key := getTripleKey(int64(d.Mode), int64(d.Stage_Level), int64(d.Node_Type))
		dropGoldMap[key] = d
	}
}

func initUnknownNodeProbability() {
	unknownNodeProbMap = make(map[int64]*csv.StageUnknownNodeProbability)
	for _, p := range csv.StageUnknownNodeProbabilityMap {
		key := getDualKey(int64(p.Mode), int64(p.Stage_Level))
		unknownNodeProbMap[key] = p
	}
}

func checkStageEventRandom() {
	var errId []int
	for _, effectRand := range csv.StageEventRandomMap {
		if _, ok := csv.StageEventMap[int64(effectRand.Event_ID)]; !ok {
			errId = append(errId, effectRand.Event_ID)
		}
	}
	if len(errId) > 0 {
		panic(fmt.Sprintf("effect random effectId: %v not exist", errId))
	}
}

func checkStageInitEvent() {
	var errEffectIDs []int
	for _, e := range csv.StageInitEventMap {
		if _, ok := csv.StageEventEffectMap[int64(e.Effect_ID)]; !ok {
			errEffectIDs = append(errEffectIDs, e.Effect_ID)
		}
	}
	if len(errEffectIDs) > 0 {
		log.Error().Msgf("check stage init event table failed>>>>>")
		for _, effectID := range errEffectIDs {
			log.Error().Msgf("effect id: %d not exist", effectID)
		}
		panic("check stage init event table failed<<<<<")
	}
}
