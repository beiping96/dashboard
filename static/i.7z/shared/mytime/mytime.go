//时间相关的
//所有的时间戳都用64位替代
package mytime

import (
	"github.com/alex023/clock"
	"github.com/rs/zerolog/log"
	"time"
)

type myTimer struct {
	timer *clock.Clock
}

var (
	timerIns         *myTimer
	dailyRefreshTime uint64
	zoneOffset       uint64 //时区相对于utc时间的偏移
)

func init() {
	log.Debug().Msgf("init mytimer")
	timerIns = NewTimer()
	dailyRefreshTime = 3 * 3600 //重置时间，每日凌晨3点
	_, tmpZoneOffset := time.Now().Zone()
	zoneOffset = uint64(tmpZoneOffset)
}

func NewTimer() *myTimer {
	return &myTimer{timer: clock.NewClock()}
}

func IsInSameDay(oldstamp, newstamp uint64) bool {
	oldday := (oldstamp + zoneOffset - dailyRefreshTime) / 86400
	newday := (newstamp + zoneOffset - dailyRefreshTime) / 86400
	return oldday == newday
}

//获取上次刷新的时间戳的上一次刷新时间
func GetLastRefreshTimePoint(timestamp uint64) uint64 {
	refreshTime := GetCurdayTimePoint(timestamp, dailyRefreshTime)
	if refreshTime < timestamp {
		return refreshTime
	}
	return refreshTime - 86400
}

func GetNextRefreshTimePoint(timestamp uint64) uint64 {
	refreshTime := GetCurdayTimePoint(timestamp, dailyRefreshTime)
	for refreshTime < timestamp {
		refreshTime += 86400
	}
	return refreshTime
}

func GetNextRefreshTimePointDuration() uint64 {
	curTime := uint64(time.Now().Unix())
	refreshTime := GetCurdayTimePoint(curTime, dailyRefreshTime)

	for refreshTime < curTime {
		refreshTime += 86400
	}
	return refreshTime - curTime
}

func GetCurdayTimePoint(timestamp, offset uint64) uint64 {
	dayCount := GetDay(timestamp + zoneOffset)
	return dayCount*86400 + offset
}

func GetDay(timestamp uint64) uint64 {
	return timestamp / 86400
}

func ParseTimeFormat(str string, defaultValue uint64) (uint64, error) {
	tm, err := time.Parse("2006-01-02 03:04:05", str)
	if err != nil {
		return defaultValue, err
	}
	return uint64(tm.Unix()), nil
}

func AddJobWithInterval(duration time.Duration, jobFunc func()) (clock.Job, bool) {
	return timerIns.AddJobWithInterval(duration, jobFunc)
}

func AddJobWithDeadtime(actionTime time.Time, jobFunc func()) (clock.Job, bool) {
	return timerIns.AddJobWithDeadtime(actionTime, jobFunc)
}

func AddJobRepeat(interval time.Duration, actionMax uint64, jobFunc func()) (clock.Job, bool) {
	return timerIns.AddJobRepeat(interval, actionMax, jobFunc)
}

func (t *myTimer) AddJobWithInterval(duration time.Duration, jobFunc func()) (clock.Job, bool) {
	return t.timer.AddJobWithInterval(duration, jobFunc)
}

func (t *myTimer) AddJobWithDeadtime(actionTime time.Time, jobFunc func()) (clock.Job, bool) {
	return t.timer.AddJobWithDeadtime(actionTime, jobFunc)
}

func (t *myTimer) AddJobRepeat(interval time.Duration, actionMax uint64, jobFunc func()) (clock.Job, bool) {
	return t.timer.AddJobRepeat(interval, actionMax, jobFunc)
}
