package mfxgrpcpool

import (
	"context"
	"fmt"
	gp "github.com/processout/grpc-go-pool"
	"google.golang.org/grpc"
	"sync"
	"time"
)

// GRPCPool keep 1..N connection pool
type GRPCPool struct {
	pools map[string]*gp.Pool
	lock  sync.RWMutex

	configSize int
	configIdle time.Duration
	configLife time.Duration
}

// New create new grpcPool
// configSize: size for each pool
// configIdle: cute connection after - 0
// configLife: refresh connection after - 5
func New(configSize int, configIdle, configLife time.Duration) *GRPCPool {
	return &GRPCPool{
		pools: make(map[string]*gp.Pool),

		configSize: configSize,
		configIdle: configIdle,
		configLife: configLife,
	}
}

// GetConn get grpc connection
func (grpcPool *GRPCPool) GetConn(ctx context.Context, grpcAddr string) (*gp.ClientConn, error) {
	grpcPool.lock.RLock()
	pool, ok := grpcPool.pools[grpcAddr]
	grpcPool.lock.RUnlock()

	if ok {
		return pool.Get(ctx)
	}
	factory := func() (*grpc.ClientConn, error) {
		return grpc.Dial(grpcAddr, grpc.WithInsecure())
	}
	pool, err := gp.New(factory, grpcPool.configSize, grpcPool.configSize,
		grpcPool.configIdle, grpcPool.configLife)
	if err != nil {
		return nil, fmt.Errorf("mail service grpc pool create error %v %v",
			grpcAddr, err)
	}

	grpcPool.lock.Lock()
	oldPool, ok := grpcPool.pools[grpcAddr]
	if ok {
		pool.Close()
		pool = oldPool
	} else {
		grpcPool.pools[grpcAddr] = pool
	}
	grpcPool.lock.Unlock()

	return pool.Get(ctx)
}

// CloseAll close all pool
func (grpcPool *GRPCPool) CloseAll() {
	for _, pool := range grpcPool.pools {
		pool.Close()
	}
}
