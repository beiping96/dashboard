package mfxlocalregistry

import (
	"container/list"
	"fmt"
	"github.com/rs/zerolog/log"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
	"runtime/debug"
	bd "shared/mfxbasedef"
	"shared/proto/server/mfxbase"
	"sync"
	"time"
)

var (
	// locator相关信息
	locatorIP     string
	locatorPort   string
	locatorServer string

	// registry相关信息
	// t_server表数据
	serverLock sync.RWMutex
	serverMap  map[string]*bd.RegistryServerConfig

	// t_service表数据
	serviceLock sync.RWMutex
	serviceMap  map[string]*list.List

	// serviceSet 由t_server和t_service产生的数据集合
	set *serviceSet

	// t_admin_from表数据
	adminLock    sync.RWMutex
	adminFromMap map[string]int32
)

func init() {
	set = NewServiceSet()
}

func getServerMap() map[string]*bd.RegistryServerConfig {
	serverLock.RLock()
	defer serverLock.RUnlock()
	return serverMap
}

func getServiceMap() map[string]*list.List {
	serviceLock.RLock()
	defer serviceLock.RUnlock()
	return serviceMap
}

func getAdminFromMap() map[string]int32 {
	adminLock.RLock()
	defer adminLock.RUnlock()
	return adminFromMap
}

func saveRegistry(info *mfxbase.QueryRegistryRsp) {
	// server
	server := make(map[string]*bd.RegistryServerConfig, 100)
	for _, e := range info.Servers {
		log.Debug().Msgf("e: %v", e)
		s := &bd.RegistryServerConfig{
			App:           e.App,
			Server:        e.Server,
			Division:      e.Division,
			Node:          e.Node,
			UseAgent:      e.UseAgent,
			NodeStatus:    e.NodeStatus,
			ServiceStatus: e.ServiceStatus,
		}
		key := bd.MakeLookupKey(s.App, s.Server, s.Division)
		server[key] = s
	}
	serverLock.Lock()
	serverMap = server
	serverLock.Unlock()

	// service
	service := make(map[string]*list.List, 100)
	for _, e := range info.Services {
		log.Debug().Msgf("e: %v", e)
		s := bd.RegistryServiceConfig{
			App:         e.App,
			Server:      e.Server,
			Division:    e.Division,
			Node:        e.Node,
			Service:     e.Service,
			ServiceIp:   e.ServiceIp,
			ServicePort: e.ServicePort,
			AdminPort:   e.AdminPort,
			RpcPort:     e.RpcPort,
		}
		key := bd.MakeLookupKey(s.App, s.Server, s.Division)
		l, ok := service[key]
		if ok {
			l.PushBack(s)
		} else {
			l = list.New()
			service[key] = l
			l.PushBack(s)
		}
	}
	serviceLock.Lock()
	serviceMap = service
	serviceLock.Unlock()

	adminFrom := make(map[string]int32, len(info.AdminFrom))
	for _, ip := range info.AdminFrom {
		adminFrom[ip] = 0
	}
	adminLock.Lock()
	adminFromMap = adminFrom
	adminLock.Unlock()
	log.Debug().Msgf("adminfrom: %v", adminFrom)

	// 生成serviceSet
	set.Import(server, service)
}

// QueryRegistry 在开始时需要调用此函数，以拿到registry信息
// 如果失败，则当前调用节点应该退出
func QueryRegistry() error {
	defer func() {
		if err := recover(); err != nil {
			log.Error().Msgf("err=%v stack=%v", err, string(debug.Stack()))
		}
	}()

	log.Debug().Msgf("query registry from %s begin...", locatorServer)
	conn, err := grpc.Dial(locatorServer, grpc.WithInsecure())
	if err != nil {
		return err
	}
	defer conn.Close()

	c := mfxbase.NewLocatorServiceClient(conn)
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	if r, err := c.QueryRegistry(ctx, &mfxbase.QueryRegistryReq{}); err != nil {
		return err
	} else {
		log.Debug().Msgf("query registry result: %d", r.Result)
		saveRegistry(r)
		return nil
	}
}

func loadFromLocator(t uint32) {
	tick := time.NewTicker(time.Duration(t) * time.Second)
	for {
		select {
		case <-tick.C:
			log.Debug().Msg("query from locator active")
			if err := QueryRegistry(); err != nil {
				log.Error().Msgf("query from locator failed: %s", err.Error())
			}
		}
	}
}

// StartQueryLoop 启动一个定时拉取registry的timer
// registry的信息会存储在当前模块中
func StartQueryLoop(t uint32) error {
	log.Debug().Msgf("begin a query loop for registry, duration=%d", t)
	go loadFromLocator(t)
	return nil
}

// SetLocator 设置locator的地址
func SetLocator(ip string, port string) {
	locatorIP = ip
	locatorPort = port
	locatorServer = fmt.Sprintf("%s:%s", locatorIP, locatorPort)
	log.Debug().Msgf("locator server set to %s", locatorServer)
}

// QueryEndpoint 根据app/server/division来明确获取一个节点的信息
func QueryEndpoint(app string, server string, division string) (string, int32, int32, int32, error) {
	key := bd.MakeLookupKey(app, server, division)
	s1 := getServerMap()
	s2 := getServiceMap()

	l1, ok := s1[key]
	if !ok {
		return "", 0, 0, 0, fmt.Errorf("server %s not found", key)
	}
	l2, ok := s2[key]
	if !ok {
		return "", 0, 0, 0, fmt.Errorf("service %s not found", key)
	}

	for e := l2.Front(); e != nil; e = e.Next() {
		c := e.Value.(bd.RegistryServiceConfig)
		if c.Node == l1.Node {
			return c.ServiceIp, c.ServicePort, c.AdminPort, c.RpcPort, nil
		}
	}
	return "", 0, 0, 0, fmt.Errorf("node=%s not found in registry", l1.Node)
}

func PickEndpoint(service string) (string, int32, int32, int32, error) {
	app, server, _, err := bd.ParseDivision(service)
	if err != nil {
		return "", 0, 0, 0, err
	}
	return QueryEndpoint(app, server, service)
}

// SelectEndpoint 使用配置的service名来选择一个合适的节点
// 1. app.server.xxservice这种格式，会使用round-robin算法找一个节点
// 2. app.server.3这种格式，会直接找这个节点，不会使用round-robin
func SelectEndpoint(service string) (string, int32, int32, error) {
	ip, busPort, rpcPort, err := set.Select(service)
	if err == nil {
		return ip, busPort, rpcPort, err
	}

	ip, busPort, _, rpcPort, err = PickEndpoint(service)
	if err == nil {
		return ip, busPort, rpcPort, err
	}

	return "", 0, 0, fmt.Errorf("service=%s not found", service)
}

// IsRemoteAdminIPAllowed 验证一个ip是否在admin白名单中的ip
func IsRemoteAdminIPAllowed(ip string) bool {
	ipMap := getAdminFromMap()
	_, ok := ipMap[ip]
	return ok
}
