package mfxlocalregistry

import (
	"container/list"
	"fmt"
	"github.com/rs/zerolog/log"
	bd "shared/mfxbasedef"
	"sync"
)

// serviceArray 同一种service的数组
type serviceArray struct {
	Array  []*bd.RegistryServiceConfig
	Cursor uint32
}

// serviceSet 不同种service数组，用service名来映射
type serviceSet struct {
	O    map[string]*serviceArray
	lock sync.RWMutex
}

func NewServiceSet() *serviceSet {
	return &serviceSet{
		O: make(map[string]*serviceArray, 1),
	}
}

func (rr *serviceSet) importNodeService(mapping map[string]*serviceArray, key string, serviceList *list.List, serverMap map[string]*bd.RegistryServerConfig) {
	rr.lock.RLock()
	defer rr.lock.RUnlock()

	for e := serviceList.Front(); e != nil; e = e.Next() {
		c := e.Value.(bd.RegistryServiceConfig)
		if c.Service == "" {
			// 服务名为空的不会导入
			continue
		}
		s, ok := serverMap[key]
		if !ok {
			// 没有对应服务节点的不会导入
			continue
		}
		// 这个服务节点的NodeStatus和ServiceStatus都必须为0，有一个不为0则不导入
		if s.NodeStatus != 0 || s.ServiceStatus != 0 {
			continue
		}
		log.Debug().Msgf("import key=%s serviceobject=%s", key, c.Service)
		m, ok := mapping[c.Service]
		if ok {
			m.Array = append(m.Array, &c)
		} else {
			cursor := uint32(0)
			oldm, ok := rr.O[c.Service]
			if ok {
				cursor = oldm.Cursor
			}
			m := &serviceArray{
				Array:  make([]*bd.RegistryServiceConfig, 1),
				Cursor: cursor,
			}
			m.Array[0] = &c
			mapping[c.Service] = m
		}
	}
}

func (rr *serviceSet) Import(serverMap map[string]*bd.RegistryServerConfig, serviceMap map[string]*list.List) {
	// 遍历servcieMap表
	// 一个key是表达一个节点进程的含义
	// 一个value是一个List，因为一个节点进程可能包含多个服务
	tmp := make(map[string]*serviceArray, 100)
	for key, serviceList := range serviceMap {
		// 单个节点下可能包含多个不同服务
		rr.importNodeService(tmp, key, serviceList, serverMap)
	}
	// dump一下
	for k, v := range tmp {
		log.Debug().Msgf("key=%s", k)
		log.Debug().Msgf("cursor=%v", v.Cursor)
		for i := 0; i < len(v.Array); i++ {
			log.Debug().Msgf("[%d]=%v", i, v.Array[i])
		}
	}
	// 导入！
	rr.lock.Lock()
	defer rr.lock.Unlock()
	rr.O = tmp
}

func (rr *serviceSet) Select(serviceObject string) (string, int32, int32, error) {
	rr.lock.Lock()
	defer rr.lock.Unlock()
	m, ok := rr.O[serviceObject]
	if !ok {
		return "", 0, 0, fmt.Errorf("service=%s not exist", serviceObject)
	}

	index := m.Cursor
	if index >= uint32(len(m.Array)) {
		index = 0
	}

	s := m.Array[index]
	index++
	m.Cursor = index
	return s.ServiceIp, s.ServicePort, s.RpcPort, nil
}
