package idgen

import (
	"time"
)

// session id的格式描述
// uint64长度
// 高32位是unix时间戳
// 中间16位是一个自增值，所以一秒内一个conn最多支持产生65535个session id
// 低16位是conn进程的id号，所以conn进程最多可以部署65535个

// GenConnSessionID 为conn产生一个sessionID
func GenConnSessionID(connID uint16, seed uint16) uint64 {
	return uint64(time.Now().Unix())<<32 + uint64(seed)<<16 + uint64(connID)
}

// ParseConnSessionID 拆分一个sessionID
func ParseConnSessionID(sessionID uint64) (uint16, uint16, uint32) {
	ts := uint32(sessionID >> 32)
	seed := uint16(uint32(sessionID) >> 16)
	connID := uint16(sessionID)
	return connID, seed, ts
}
