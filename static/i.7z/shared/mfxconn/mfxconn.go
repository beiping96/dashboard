package mfxconn

import (
	"bytes"
	"encoding/binary"
	"errors"
	"github.com/rs/zerolog/log"
	"io"
	"net"
	tb "shared/mfxtcpbuffer"
)

const (
	// conn内部命令，保留
	CmdReserved     = 65000
	CmdSessionEnter = 65001
	CmdSessionLeave = 65002
	CmdSessionRoute = 65003
	CmdSessionKick  = 65004
	CmdMasterSet    = 65011
	CmdMasterYou    = 65012
	CmdMasterNot    = 65013
	CmdBroadcastAll = 65021
	CmdKickAll      = 65022
)

// Header 通过conn的包的包头结构
type Header struct {
	BodyLen   uint16
	CmdID     uint16
	UserData  uint32
	Timestamp uint32
}

const (
	LengthOfBodyLen   = 2
	LengthOfCmdID     = 2
	LengthOfUserData  = 4
	LengthOfTimestamp = 4

	BodyLenStart   = 0
	BodyLenEnd     = 2
	CmdIDStart     = 2
	CmdIDEnd       = 4
	UserDataStart  = 4
	UserDataEnd    = 8
	TimestampStart = 8
	TimestampEnd   = 12

	LengthOfHeader    = LengthOfBodyLen + LengthOfCmdID + LengthOfUserData + LengthOfTimestamp
	LengthOfMaxBody   = 65000
	LengthOfMaxPacket = LengthOfHeader + LengthOfMaxBody
)

// 辅助函数实现

// IsInnerCmd 是否是conn内部命令，如果从客户端发上来，则直接丢弃
func IsInnerCmd(cmdID uint16) bool {
	return cmdID >= CmdReserved
}

// ParseHeader 解析包头
func ParseHeader(hdr []byte) *Header {
	bodyLen := binary.BigEndian.Uint16(hdr[BodyLenStart:BodyLenEnd])
	cmdID := binary.BigEndian.Uint16(hdr[CmdIDStart:CmdIDEnd])
	userData := binary.BigEndian.Uint32(hdr[UserDataStart:UserDataEnd])
	timestamp := binary.BigEndian.Uint32(hdr[TimestampStart:TimestampEnd])
	return &Header{
		BodyLen:   bodyLen,
		CmdID:     cmdID,
		UserData:  userData,
		Timestamp: timestamp,
	}
}

// SendHeader 直接发送一个包头，有些conn命令比较简单，body为0
func SendHeader(w io.Writer, bodyLen, cmdID uint16, userData, timestamp uint32) error {
	hdr := make([]byte, LengthOfHeader)

	bodyLenBuf := hdr[BodyLenStart:BodyLenEnd]
	binary.BigEndian.PutUint16(bodyLenBuf, bodyLen)
	cmdIDBuf := hdr[CmdIDStart:CmdIDEnd]
	binary.BigEndian.PutUint16(cmdIDBuf, cmdID)
	userDataBuf := hdr[UserDataStart:UserDataEnd]
	binary.BigEndian.PutUint32(userDataBuf, userData)
	timestampBuf := hdr[TimestampStart:TimestampEnd]
	binary.BigEndian.PutUint32(timestampBuf, timestamp)

	_, err := w.Write(hdr)
	return err
}

// TinyCmd 这是conn的内部命令所需要的一些参数，用json来传递
type TinyCmd struct {
	StrParam string
}

// SendMasterSet 告知此conn我想成为master
func SendMasterSet(w io.Writer) error {
	return SendHeader(w, 0, CmdMasterSet, 0, 0)
}

// SendMasterYou 告知对端是此conn的master
func SendMasterYou(w io.Writer) error {
	return SendHeader(w, 0, CmdMasterYou, 0, 0)
}

// SendMasterNot 告知对端并不是conn的master
func SendMasterNot(w io.Writer) error {
	return SendHeader(w, 0, CmdMasterNot, 0, 0)
}

// SendKickAll 让conn踢掉此conn上的所有人
func SendKickAll(w io.Writer) error {
	return SendHeader(w, 0, CmdKickAll, 0, 0)
}

// MakeSessionPkt 根据一些关键值和包体，来构造一个session包
func MakeSessionPkt(sessions []uint64, cmdID uint16, userData, timestamp uint32, body []byte) []byte {
	bufU16 := make([]byte, 2)
	bufU32 := make([]byte, 4)
	bufU64 := make([]byte, 8)
	var buffer bytes.Buffer

	sessionNum := uint16(len(sessions))
	newBodyLen := uint16(len(body)) + 2 + 8*sessionNum

	// hdr填充
	binary.BigEndian.PutUint16(bufU16, newBodyLen)
	buffer.Write(bufU16)
	binary.BigEndian.PutUint16(bufU16, cmdID)
	buffer.Write(bufU16)
	binary.BigEndian.PutUint32(bufU32, userData)
	buffer.Write(bufU32)
	binary.BigEndian.PutUint32(bufU32, timestamp)
	buffer.Write(bufU32)

	// 在hdr和body之间加上一个uint16和一个uint64的数组
	binary.BigEndian.PutUint16(bufU16, sessionNum)
	buffer.Write(bufU16)
	for i := 0; i < int(sessionNum); i++ {
		binary.BigEndian.PutUint64(bufU64, sessions[i])
		buffer.Write(bufU64)
	}

	// body填充
	buffer.Write(body)

	return buffer.Bytes()
}

// CopySessionPkt 根据一个包头和包体，产生一个新的session包
func CopySessionPkt(sessions []uint64, hdr, body []byte) ([]byte, uint16) {
	header := ParseHeader(hdr)
	return MakeSessionPkt(sessions, header.CmdID, header.UserData, header.Timestamp, body), header.CmdID
}

// NewSessionPkt 新建一个session包，但指定新的CmdID
func NewSessionPkt(sessions []uint64, cmdID uint16, hdr, body []byte) []byte {
	header := ParseHeader(hdr)
	return MakeSessionPkt(sessions, cmdID, header.UserData, header.Timestamp, body)
}

// MakeCommonPkt 根据一些关键值和包体，来构造一个普通包
func MakeCommonPkt(cmdID uint16, userData, timestamp uint32, body []byte) []byte {
	bufU16 := make([]byte, 2)
	bufU32 := make([]byte, 4)
	var buffer bytes.Buffer

	bodyLen := uint16(len(body))

	// hdr填充
	binary.BigEndian.PutUint16(bufU16, bodyLen)
	buffer.Write(bufU16)
	binary.BigEndian.PutUint16(bufU16, cmdID)
	buffer.Write(bufU16)
	binary.BigEndian.PutUint32(bufU32, userData)
	buffer.Write(bufU32)
	binary.BigEndian.PutUint32(bufU32, timestamp)
	buffer.Write(bufU32)

	// body填充
	buffer.Write(body)

	return buffer.Bytes()
}

// CopyCommonPkt 根据一个包头和包体，来复制一个新的普通包
func CopyCommonPkt(hdr, body []byte) ([]byte, uint16) {
	header := ParseHeader(hdr)
	return MakeCommonPkt(header.CmdID, header.UserData, header.Timestamp, body), header.CmdID
}

// ParseSessionBody 解析session类包的包体
func ParseSessionBody(body []byte) (uint16, []uint64, []byte) {
	// body 包含了一个uint16，一个uint64数组，和后面真正的包体
	sessionNum := binary.BigEndian.Uint16(body[:2])
	sessions := make([]uint64, sessionNum)
	for i := 0; i < int(sessionNum); i++ {
		b := 2 + i*8
		sessionID := binary.BigEndian.Uint64(body[b:(b + 8)])
		sessions[i] = sessionID
	}
	b := 2 + sessionNum*8
	return sessionNum, sessions, body[b:]
}

// HandleStream 在conn的tcp数据流上进行切包的通用处理过程
func HandleStream(conn net.Conn, handler func(conn net.Conn, hdr, body []byte)) error {
	var (
		buffer = tb.NewBuffer(conn, 2*LengthOfMaxPacket)
		hdr    []byte
		body   []byte
		err    error
	)

	for {
		// 从conn中读数据到buffer中
		_, err = buffer.Read()
		if err != nil {
			log.Debug().Msgf("read conn=%s failed: %s", conn.RemoteAddr().String(), err.Error())
			break
		}

		// 尝试解析已进入buffer中的数据
		needShift := false
		for {
			hdr, err = buffer.Peek(LengthOfHeader)
			if err != nil {
				break
			}

			// 获取包体长度
			bodyLen := binary.BigEndian.Uint16(hdr[BodyLenStart:BodyLenEnd])
			if bodyLen > LengthOfMaxBody {
				return errors.New("body lenght above max length")
			}

			totalLen := buffer.Length()
			requiredLen := int(LengthOfHeader + bodyLen)
			if totalLen >= requiredLen {
				// 拿到包体，body是一个切片
				body = buffer.Get(LengthOfHeader, int(bodyLen))
				needShift = true

				// 触发处理函数，是否复制hdr和body由处理函数决定
				handler(conn, hdr, body)

				// 继续搜索是否有完整包到达
				continue
			} else {
				break
			}
		}

		if needShift {
			buffer.Shift()
		}
	}

	return err
}
