package mfxbasedef

import (
	"errors"
	"fmt"
	"strings"
)

// 关于微服务的一些配置

type EndPoint struct {
	Ip   string `xml:"ip"`
	Port string `xml:"port"`
}

type Locator struct {
	Ep              EndPoint `xml:"endpoint"`
	Protocol        string   `xml:"protocol"`
	RefreshInterval uint32   `xml:"refresh_interval"`
}

type MysqlConnection struct {
	Ep       EndPoint `xml:"endpoint"`
	Database string   `xml:"database"`
	Username string   `xml:"username"`
	Password string   `xml:"password"`
}

type RedisConnection struct {
	Ep EndPoint `xml:"endpoint"`
}

type RegistryServerConfig struct {
	App           string
	Server        string
	Division      string
	Node          string
	UseAgent      uint32
	NodeStatus    uint32
	ServiceStatus uint32
}

type RegistryServiceConfig struct {
	App         string
	Server      string
	Division    string
	Node        string
	Service     string
	ServiceIp   string
	ServicePort int32
	AdminPort   int32
	RpcPort     int32
}

func MakeLookupKey(app string, server string, division string) string {
	return app + "!" + server + "!" + division
}

func MakeDivision(app string, server string, id int32) string {
	return fmt.Sprintf("%s.%s.%d", app, server, id)
}

func ParseDivision(division string) (string, string, string, error) {
	s := strings.Split(division, ".")
	if len(s) != 3 {
		return "", "", "", errors.New("division shoud be a.b.c")
	}
	return s[0], s[1], s[2], nil
}

// 关于系统方面的一些配置

type ShmPoolConfig struct {
	DataSize  uint32 `xml:"data_size"`
	DataCount uint32 `xml:"data_count"`
}
