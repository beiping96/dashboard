package mfxtcpbuffer

import (
	"errors"
	"io"
)

type buffer struct {
	reader io.Reader
	buf    []byte
	start  int
	end    int
}

func NewBuffer(reader io.Reader, len int) buffer {
	buf := make([]byte, len)
	return buffer{reader, buf, 0, 0}
}

// 当前buffer里有多少数据
func (b *buffer) Length() int {
	return b.end - b.start
}

// 向前平移，一般是由于Get的副作用导致缓冲区前边一段为空了
func (b *buffer) Shift() {
	if b.start == 0 {
		return
	}
	copy(b.buf, b.buf[b.start:b.end])
	b.end -= b.start
	b.start = 0
}

// 从reader读取若干个数据，并返回数据字节数
func (b *buffer) Read() (int, error) {
	b.Shift()
	n, err := b.reader.Read(b.buf[b.end:])
	if err != nil {
		return n, err
	}
	b.end += n
	return n, nil
}

// 检索n个字节，此函数没有副作用
func (b *buffer) Peek(n int) ([]byte, error) {
	if b.end-b.start >= n {
		buf := b.buf[b.start:(b.start + n)]
		return buf, nil
	}
	return nil, errors.New("not enough data to peek")
}

// 跳过offset个字节，然后取出n个字节，有副作用
func (b *buffer) Get(offset, n int) []byte {
	b.start += offset
	buf := b.buf[b.start:(b.start + n)]
	b.start += n
	return buf
}
