package logutil

import (
	"github.com/natefinch/lumberjack"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
)

func SetupLogPath(logFile string) {
	zerolog.TimeFieldFormat = "2006-01-02 15:04:05.000 MST"
	output := &lumberjack.Logger{
		Filename:   logFile,
		MaxSize:    20,
		MaxBackups: 9,
		MaxAge:     28,
		Compress:   false,
	}
	log.Logger = zerolog.New(output).With().Timestamp().Logger()
}

func SetupLogLevel(level string) string {
	switch level {
	case "debug":
		zerolog.SetGlobalLevel(zerolog.DebugLevel)
		return "debug"
	case "info":
		zerolog.SetGlobalLevel(zerolog.InfoLevel)
		return "info"
	case "warn":
		zerolog.SetGlobalLevel(zerolog.WarnLevel)
		return "warn"
	case "error":
		zerolog.SetGlobalLevel(zerolog.ErrorLevel)
		return "error"
	case "fatal":
		zerolog.SetGlobalLevel(zerolog.FatalLevel)
		return "fatal"
	case "panic":
		zerolog.SetGlobalLevel(zerolog.PanicLevel)
		return "panic"
	default:
		zerolog.SetGlobalLevel(zerolog.InfoLevel)
		return "info"
	}
}
