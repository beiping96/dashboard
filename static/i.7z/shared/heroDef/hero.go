package heroDef

import (
	cfg "lobby/config"
	cardD "shared/cardDef"
	portal "shared/proto/client/portal"
	rds "shared/proto/server/battle"
	db "shared/proto/server/lobby"
	"shared/table"
)

type Hero struct {
	uid       uint64
	typeID    uint32
	initCards []cardD.TypeID
	star      uint32
}

func New(typeID uint32) (Hero, error) {
	uid, err := generateID()
	if err != nil {
		return Hero{}, err
	}
	heroInitCards, ok := table.GetHeroInitCards(int64(typeID))
	initCards := make([]cardD.TypeID, len(heroInitCards))
	if ok {
		for i, v := range heroInitCards {
			initCards[i] = cardD.TypeID(v)
		}
	}
	return Hero{uid: uid, typeID: typeID, initCards: initCards, star: 1}, nil
}

func (h Hero) GetUID() uint64 {
	return h.uid
}
func (h Hero) GetTypeID() uint32 {
	return h.typeID
}

func (h *Hero) GetInitCards() []cardD.TypeID {
	return h.initCards
}

func (h Hero) GetStarLevel() uint32 {
	return h.star
}

func (h *Hero) SetStarLevel(lastStar uint32) {
	h.star = lastStar
}

func (h Hero) ToClientProto() *portal.PlayerHero {
	ans := portal.PlayerHero{
		HeroUid:    &h.uid,
		HeroTypeId: &h.typeID,
	}
	return &ans
}

func FromDbProto(basic *db.DbPlayerHero) Hero {
	var initCards []cardD.TypeID
	for _, v := range basic.GetInitCards() {
		initCards = append(initCards, cardD.TypeID(v))
	}
	return Hero{
		uid:       basic.GetUid(),
		typeID:    basic.GetTypeID(),
		initCards: initCards,
		star:      basic.GetStarLevel(),
	}
}

func FromRdsProto(h *rds.RdsHeroBase) Hero {
	var initCards = make([]cardD.TypeID, len(h.InitCards))
	for i, v := range h.InitCards {
		initCards[i] = cardD.TypeID(v)
	}
	return Hero{
		uid:       h.Uid,
		typeID:    h.TypeID,
		initCards: initCards,
	}
}

func (h Hero) ToDbProto() *db.DbPlayerHero {
	var ans db.DbPlayerHero
	ans.Uid = h.uid
	ans.TypeID = h.typeID
	var initCards []uint32
	for _, v := range h.initCards {
		initCards = append(initCards, uint32(v))
	}
	ans.InitCards = initCards
	ans.StarLevel = h.star
	return &ans
}

func (h *Hero) ToRdsProto() *rds.RdsHeroBase {
	var heroBase rds.RdsHeroBase
	heroBase.Uid = h.uid
	heroBase.TypeID = h.typeID
	var initCards = make([]uint32, len(h.initCards))
	for i, v := range h.initCards {
		initCards[i] = uint32(v)
	}
	heroBase.InitCards = initCards
	return &heroBase
}

func generateID() (uint64, error) {
	id, err := cfg.RedisPool.Cmd("INCR", "GLOBAL&HERO&UID&GENERATOR").Int64()
	if err != nil {
		return 0, err
	}
	return uint64(id) + 100, nil
}
