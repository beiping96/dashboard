package mfxcoredump

import (
	"runtime/debug"
	"strings"

	"github.com/rs/zerolog/log"
)

// CoredumpHandler 应用层可以直接使用defer CoredumpHandler来捕获异常，并打印栈帧
func CoredumpHandler() {
	if err := recover(); err != nil {
		log.Error().Msgf("%v", err)
		stack := string(debug.Stack())
		ss := strings.Split(stack, "\n")
		for i := 0; i < len(ss); i++ {
			str := strings.Replace(ss[i], "\t", "    ", -1)
			log.Error().Msgf("%s", str)
		}
	}
}
