package mfxredisutil

import (
	"github.com/mediocregopher/radix.v2/cluster"
	"github.com/mediocregopher/radix.v2/pool"
	"github.com/mediocregopher/radix.v2/redis"
	"strings"
)

// RedisUtil Redis的工具结构定义，内含集群和非集群两个对象
type RedisUtil struct {
	clusterDisabled bool
	cluster         *cluster.Cluster
	standalone      *pool.Pool
}

// NewRedisUtil 初始化一个Redis工具
func NewRedisUtil(redisAddr string) (*RedisUtil, error) {
	// 先以单例模式连接上去
	c, err := redis.Dial("tcp", redisAddr)
	if err != nil {
		return nil, err
	}

	// 检测是否开启了集群模式
	s, err := c.Cmd("INFO", "CLUSTER").Str()
	if err != nil {
		c.Close()
		return nil, err
	}

	array := strings.Split(s, "\r")
	if len(array) < 2 {
		c.Close()
		return nil, err
	}

	s = array[1]
	array = strings.Split(s, ":")
	if len(array) == 2 && array[1] == "1" {
		// 集群模式
		c.Close()
		opt := cluster.Opts{
			Addr:             redisAddr,
			PoolSize:         10,
			Dialer:           nil,
			MaxRedirectCount: 5,
		}
		if c, err := cluster.NewWithOpts(opt); err == nil {
			return &RedisUtil{clusterDisabled: false, cluster: c, standalone: nil}, nil
		} else {
			return nil, err
		}
	} else {
		// 单例模式
		c.Close()
		p, err := pool.New("tcp", redisAddr, 10)
		if err != nil {
			return nil, err
		}
		return &RedisUtil{clusterDisabled: true, cluster: nil, standalone: p}, nil
	}
}

// Close 关闭Redis工具
func (n *RedisUtil) Close() {
	if n.clusterDisabled {
		n.standalone.Empty()
	} else {
		n.cluster.Close()
	}
}

// GetMode 获得Redis服务器的模式，单例模式或集群模式
func (n *RedisUtil) GetMode() string {
	if n.clusterDisabled {
		return "standalone"
	} else {
		return "cluster"
	}
}

// GetForKey 依据key值找到对应的hash槽位的Redis节点
func (n *RedisUtil) GetForKey(key string) (*redis.Client, error) {
	if n.clusterDisabled {
		return n.standalone.Get()
	}
	return n.cluster.GetForKey(key)
}

// Put 将GetForKey返回的Redis节点释放掉
func (n *RedisUtil) Put(c *redis.Client) {
	if n.clusterDisabled {
		n.standalone.Put(c)
	} else {
		n.cluster.Put(c)
	}
}

// Cmd 执行命令
func (n *RedisUtil) Cmd(cmd string, args ...interface{}) *redis.Resp {
	if n.clusterDisabled {
		return n.standalone.Cmd(cmd, args)
	}
	return n.cluster.Cmd(cmd, args)
}

// GetRespError 命令的返回错误对象，也可能是nil
func GetRespError(resp *redis.Resp) error {
	return resp.Err
}

// IsRespNil 命令的返回为空
func IsRespNil(resp *redis.Resp) bool {
	return resp.IsType(redis.Nil)
}
