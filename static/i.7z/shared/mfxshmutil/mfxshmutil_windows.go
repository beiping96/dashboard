package mfxshmutil

import (
	"unsafe"
)

const (
	shmCreate = 00001000
)

type ShmChunk struct {
	ShmID   uint64
	Key     uint64
	Size    uint64
	ShmAddr uint64
}

type ShmUnitInfo struct {
	UnitCount uint32
	UnitSize  uint32
	DataSize  uint32
}

type ShmUnitPrefix struct {
	UnitInUse   uint8
	ReservedU8  uint8
	ReservedU16 uint16
	DataLen     uint32
	UserData    uint64
	// 后面就是数据了
	// DataLen表示后面数据的长度
}

func NewShmChunk(key uint64, dataSize, dataCount uint32) (*ShmChunk, error) {
	var info ShmUnitInfo
	var prefix ShmUnitPrefix
	size := uint64(unsafe.Sizeof(info)) + (uint64(dataCount))*(uint64(unsafe.Sizeof(prefix))+uint64(dataSize))
	sc := &ShmChunk{
		ShmID:   uint64(0),
		Key:     key,
		Size:    size,
		ShmAddr: 0,
	}
	return sc, nil
}

func (sc *ShmChunk) Attach() error {
	return nil
}

func (sc *ShmChunk) Detach() {
}

func (sc *ShmChunk) Start(dataSize, dataCount uint32, handler func(int32, *ShmUnitPrefix)) {
}

func (sc *ShmChunk) Resume(handler func(int32, *ShmUnitPrefix)) error {
	return nil
}

func (sc *ShmChunk) Lock(index int32) bool {
	return false
}

func (sc *ShmChunk) Free(index int32) {
}

func (sc *ShmChunk) Save(index int32, userData uint64, data []byte) error {
	return nil
}

func (sc *ShmChunk) Load(index int32) (uint64, []byte, error) {
	return 0, nil, nil
}
