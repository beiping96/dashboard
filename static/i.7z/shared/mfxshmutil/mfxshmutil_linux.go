package mfxshmutil

import (
	"errors"
	"reflect"
	"syscall"
	"unsafe"
)

const (
	shmCreate = 00001000
)

type ShmChunk struct {
	ShmID   uint64
	Key     uint64
	Size    uint64
	ShmAddr uint64
}

type ShmUnitInfo struct {
	UnitCount uint32
	UnitSize  uint32
	DataSize  uint32
}

type ShmUnitPrefix struct {
	UnitInUse   uint8
	ReservedU8  uint8
	ReservedU16 uint16
	DataLen     uint32
	UserData    uint64
	// 后面就是数据了
	// DataLen表示后面数据的长度
}

func NewShmChunk(key uint64, dataSize, dataCount uint32) (*ShmChunk, error) {
	var info ShmUnitInfo
	var prefix ShmUnitPrefix
	size := uint64(unsafe.Sizeof(info)) + (uint64(dataCount))*(uint64(unsafe.Sizeof(prefix))+uint64(dataSize))

	k := uintptr(key)
	s := uintptr(size)
	shmID, _, errno := syscall.Syscall(syscall.SYS_SHMGET, k, s, shmCreate|0600)
	if errno != 0 {
		err := errno
		return nil, err
	}

	sc := &ShmChunk{
		ShmID:   uint64(shmID),
		Key:     key,
		Size:    size,
		ShmAddr: 0,
	}
	return sc, nil
}

func (sc *ShmChunk) Attach() error {
	if sc.ShmAddr != 0 {
		return nil
	}

	shmAddr, _, errno := syscall.Syscall(syscall.SYS_SHMAT, uintptr(sc.ShmID), 0, 0)
	if errno != 0 {
		err := errno
		return err
	}

	sc.ShmAddr = uint64(shmAddr)
	return nil
}

func (sc *ShmChunk) Detach() {
	if sc.ShmAddr != 0 {
		syscall.Syscall(syscall.SYS_SHMDT, uintptr(sc.ShmAddr), 0, 0)
		sc.ShmAddr = 0
	}
}

func (sc *ShmChunk) Start(dataSize, dataCount uint32, handler func(int32, *ShmUnitPrefix)) {
	if sc.ShmAddr == 0 {
		return
	}

	var o ShmUnitPrefix
	info := sc.getUnitInfo()
	info.UnitCount = dataCount
	info.UnitSize = dataSize + uint32(unsafe.Sizeof(o))
	info.DataSize = dataSize
	for i := int32(0); i < int32(info.UnitCount); i++ {
		prefix := sc.getUnitPrefix(i)
		prefix.UnitInUse = 0
		prefix.ReservedU8 = 0
		prefix.ReservedU16 = 0
		prefix.DataLen = 0
		prefix.UserData = 0
		handler(i, prefix)
	}
}

func (sc *ShmChunk) Resume(handler func(int32, *ShmUnitPrefix)) error {
	if sc.ShmAddr == 0 {
		return errors.New("shm addr = 0, can't resume")
	}

	info := sc.getUnitInfo()
	for i := int32(0); i < int32(info.UnitCount); i++ {
		prefix := sc.getUnitPrefix(i)
		handler(i, prefix)
	}
	return nil
}

func (sc *ShmChunk) getUnitInfo() *ShmUnitInfo {
	return (*ShmUnitInfo)(unsafe.Pointer(uintptr(sc.ShmAddr)))
}

func (sc *ShmChunk) getUnit(index int32) uintptr {
	var o ShmUnitInfo
	info := (*ShmUnitInfo)(unsafe.Pointer(uintptr(sc.ShmAddr)))
	unit := sc.ShmAddr + uint64(unsafe.Sizeof(o)) + uint64(uint32(index)*info.UnitSize)
	return uintptr(unit)
}

func (sc *ShmChunk) getUnitPrefix(index int32) *ShmUnitPrefix {
	return (*ShmUnitPrefix)(unsafe.Pointer(uintptr(sc.getUnit(index))))
}

func (sc *ShmChunk) getUnitData(index int32) uintptr {
	var prefix ShmUnitPrefix
	unit := sc.getUnit(index)
	return unit + unsafe.Sizeof(prefix)
}

func (sc *ShmChunk) Lock(index int32) bool {
	prefix := sc.getUnitPrefix(index)
	if prefix.UnitInUse == 0 {
		prefix.UnitInUse = 1
		prefix.ReservedU8 = 0
		prefix.ReservedU16 = 0
		prefix.DataLen = 0
		prefix.UserData = 0
		return true
	} else {
		return false
	}
}

func (sc *ShmChunk) Free(index int32) {
	if index < 0 {
		return
	}
	info := sc.getUnitInfo()
	if uint32(index) >= info.UnitCount {
		return
	}

	prefix := sc.getUnitPrefix(index)
	if prefix.UnitInUse != 0 {
		prefix.UnitInUse = 0
		prefix.ReservedU8 = 0
		prefix.ReservedU16 = 0
		prefix.DataLen = 0
		prefix.UserData = 0
	} else {
		prefix.ReservedU8 = 0
		prefix.ReservedU16 = 0
		prefix.DataLen = 0
		prefix.UserData = 0
	}
}

func (sc *ShmChunk) Save(index int32, userData uint64, data []byte) error {
	if index < 0 {
		return errors.New("index < 0")
	}
	info := sc.getUnitInfo()
	if uint32(index) >= info.UnitCount {
		return errors.New("index > max")
	}
	prefix := sc.getUnitPrefix(index)
	if prefix.UnitInUse == 0 {
		return errors.New("index can't save")
	}

	dataLen := uint32(len(data))
	if dataLen > info.DataSize {
		return errors.New("data length > max")
	}

	prefix.UserData = userData
	prefix.DataLen = uint32(len(data))

	var o []byte
	slice := (*reflect.SliceHeader)(unsafe.Pointer(&o))
	slice.Cap = int(info.DataSize)
	slice.Len = int(info.DataSize)
	slice.Data = sc.getUnitData(index)

	copy(o, data)

	return nil
}

func (sc *ShmChunk) Load(index int32) (uint64, []byte, error) {
	if index < 0 {
		return 0, nil, errors.New("index < 0")
	}
	info := sc.getUnitInfo()
	if uint32(index) >= info.UnitCount {
		return 0, nil, errors.New("index > max")
	}
	prefix := sc.getUnitPrefix(index)
	if prefix.UnitInUse == 0 {
		return 0, nil, errors.New("index can't load")
	}

	var o []byte
	slice := (*reflect.SliceHeader)(unsafe.Pointer(&o))
	slice.Cap = int(info.DataSize)
	slice.Len = int(prefix.DataLen)
	slice.Data = sc.getUnitData(index)

	dup := make([]byte, prefix.DataLen)
	copy(dup, o)

	return prefix.UserData, dup, nil
}
