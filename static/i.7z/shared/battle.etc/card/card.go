package card

import (
	"errors"
	"fmt"
	"shared/csv"
	pb "shared/proto/client/battle"
	rds "shared/proto/server/battle"
	"shared/table"
)

// Type Enum
type Type int32

const (
	_ Type = iota
	// Attack Card
	Attack
	// Skill Card
	Skill
	// Power card
	Power
	// Status card
	Status
	// Curse card
	Curse
)

// Rarity Enum
type Rarity int32

const (
	_ Rarity = iota
	// White Card
	White
	// Blue Card
	Blue
	// Gold Card
	Gold
)

// Spec Enum
type Spec int32

const (
	_ Spec = iota
	// Normal - 正常弃牌
	Normal
	// ExhaustedWithUsed - 使用后即消耗
	ExhaustedWithUsed
	// ExhaustedWithoutUsed - 未使用 弃牌阶段消耗
	ExhaustedWithoutUsed
	// Exhausted - 入手即消耗
	Exhausted
)

// MoveDesc - desc card moving
type MoveDesc struct {
	ID     uint32
	ResID  uint32
	From   pb.BattleCardPosEnum
	To     pb.BattleCardPosEnum
	Reason pb.BattleCardReasonEnum
	Param  uint32
}

// ToClientProto convert MoveDesc to pb.BattleCardChange
func (m MoveDesc) ToClientProto() *pb.BattleCardChange {
	ans := pb.BattleCardChange{
		CardId:     &m.ID,
		CardTypeId: &m.ResID,
	}
	ans.From = &m.From
	ans.To = &m.To
	ans.Reason = &m.Reason
	ans.Param = &m.Param
	return &ans
}

// Card struct - describe one card status
type Card struct {
	ID         uint32
	ResID      uint32
	TypeID     uint32
	Star       uint32
	Type       Type
	Rarity     Rarity
	Spec       Spec
	Cost       uint32
	Level      uint32
	MaxLevel   uint32
	RoundTimes uint32
}

// New create one Card
func New(id uint32, typeID uint32, starLevel uint32, cardLevel uint32) (Card, error) {
	cardTable, ok := table.GetTableCard(typeID, cardLevel)
	if !ok {
		return Card{}, fmt.Errorf("card not found, typeId: %d", typeID)
	}
	cardGrow, ok := table.GetCardGrow(uint32(cardTable.CardGroupID), starLevel)
	if !ok {
		return Card{}, fmt.Errorf("card grow not found, cardGroupId: %d, starlevel: %d",
			typeID, starLevel)
	}
	sp := Exhausted
	if cardTable.Exhaust == csv.GENERAL_FALSE && cardTable.Ethereal == csv.GENERAL_FALSE {
		sp = Normal
	} else if cardTable.Exhaust == csv.GENERAL_TRUE {
		sp = ExhaustedWithUsed
	} else if cardTable.Ethereal == csv.GENERAL_TRUE {
		sp = ExhaustedWithoutUsed
	}

	return Card{
		ID:         id,
		ResID:      uint32(cardTable.ID),
		TypeID:     typeID,
		Star:       starLevel,
		Rarity:     White,
		Spec:       sp,
		Level:      uint32(cardTable.Level),
		Type:       Type(cardTable.Type),
		Cost:       uint32(cardTable.Cost),
		MaxLevel:   uint32(cardGrow.MaxLevel),
		RoundTimes: 0,
	}, nil
}

// LevelUp - keep cardID level-up Card
func (cardOne Card) LevelUp() (newCard Card, err error) {
	if cardOne.Level == cardOne.MaxLevel {
		err = errors.New("card level up, out of max level")
		return
	}
	cardTable, ok := table.GetTableCard(cardOne.TypeID, cardOne.Level+1)
	if !ok {
		err = errors.New("card level up, can't found next level config")
		return
	}
	newCard = Card{
		ID:         cardOne.ID,
		ResID:      uint32(cardTable.ID),
		TypeID:     cardOne.TypeID,
		Star:       cardOne.Star,
		Rarity:     cardOne.Rarity,
		Spec:       cardOne.Spec,
		Level:      uint32(cardTable.Level),
		Type:       Type(cardTable.Type),
		Cost:       uint32(cardTable.Cost),
		MaxLevel:   cardOne.MaxLevel,
		RoundTimes: cardOne.RoundTimes,
	}
	return
}

// ToClientProto convert Card struct to BattleCard
func (cardOne Card) ToClientProto() *pb.BattleCard {
	ans := pb.BattleCard{}
	ans.Id = &cardOne.ID
	ans.CardTypeId = &cardOne.ResID
	ans.CardLevel = &cardOne.Level
	ans.CardCost = &cardOne.Cost
	ans.CardStar = &cardOne.Star
	ans.RoundTimes = &cardOne.RoundTimes
	return &ans
}

// ToRdsCardProto convert Card struct to RdsCard
func (cardOne *Card) ToRdsCardProto() *rds.RdsCard {
	return &rds.RdsCard{
		Id:       cardOne.ID,
		ResID:    cardOne.ResID,
		TypeID:   cardOne.TypeID,
		Star:     cardOne.Star,
		Type:     uint32(cardOne.Type),
		Rarity:   int32(cardOne.Rarity),
		Spec:     int32(cardOne.Spec),
		Cost:     cardOne.Cost,
		Level:    cardOne.Level,
		MaxLevel: cardOne.MaxLevel,
	}
}

// FromRdsCardProto convert Card struct from RdsCard
func FromRdsCardProto(c *rds.RdsCard) Card {
	return Card{
		ID:         c.Id,
		ResID:      c.ResID,
		TypeID:     c.TypeID,
		Star:       c.Star,
		Type:       Type(c.Type),
		Rarity:     Rarity(c.Rarity),
		Spec:       Spec(c.Spec),
		Cost:       c.Cost,
		Level:      c.Level,
		MaxLevel:   c.MaxLevel,
		RoundTimes: 0,
	}
}

// String - achieve String interface
func (cardOne Card) String() string {
	s := "{"
	s += fmt.Sprintf("CARD_ID:%v,", cardOne.ID)
	s += fmt.Sprintf("CARD_ResID:%v,", cardOne.ResID)
	s += fmt.Sprintf("CARD_TypeID:%v,", cardOne.TypeID)
	s += fmt.Sprintf("CARD_Type:%v,", cardOne.Type)
	s += "}"
	return s
}
