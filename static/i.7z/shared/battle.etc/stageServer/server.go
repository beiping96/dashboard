package stageServer

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"github.com/sony/sonyflake"
	"runtime/debug"
	"shared/battle.etc/stage"
	"shared/battle.etc/stageDef"
	"shared/csv"
	cp "shared/mfxcoredump"
	"time"
)

type stageMgr interface {
	Get(stageUID uint64) *stage.Stage
	Save(*stage.Stage)
	StageOver(stageUID uint64, playerIDs []uint64)
	NoticeDown(stageDef.Notice)
	OperationDown(stageDef.Operation)
}

type stageRuntime struct {
	stageMgr          stageMgr
	stageUIDGenerator *sonyflake.Sonyflake
	inChan            chan *stageDef.In

	battleStatus map[uint64]map[uint32]*battleRuntime
	stageMap     map[uint64]*stage.Stage
	stageTTL     map[uint64]time.Time
}

type battleRuntime struct {
	playerRound map[uint64]chan interface{}
	battleChan  chan<- *stageDef.BattleOperationParam
	allPlayer   map[uint64]bool
}

// Run stage runtime goroutine
func Run(stageMgrOne stageMgr, inChan chan *stageDef.In, lobbyID uint16) error {
	// sleep 11 millisecond before start
	// ensure the time during restart snowflake will bigger than 10 millisecond
	time.Sleep(time.Duration(11) * time.Millisecond)
	mainMgr := stageRuntime{
		stageMgr:          stageMgrOne,
		stageUIDGenerator: sonyflake.NewSonyflake(sonyflake.Settings{MachineID: func() (uint16, error) { return lobbyID, nil }}),
		inChan:            inChan,
		battleStatus:      make(map[uint64]map[uint32]*battleRuntime),
		stageMap:          make(map[uint64]*stage.Stage),
		stageTTL:          make(map[uint64]time.Time),
	}
	go mainMgr.run()
	return nil
}

func (i *stageRuntime) run() {
	defer func() {
		if err := recover(); err != nil {
			log.Error().Msgf("stageMgr %v error, errinfo:%v, stack:%v",
				i, err, string(debug.Stack()))
		}
		log.Debug().Msgf("stageMgr %v defer be called", i)
	}()
	duration := time.Duration(10) * time.Minute
	tick := time.Tick(duration)
	for {
		breakNow := false
		select {
		case in, ok := <-i.inChan:
			i.handle(in)
			if !ok {
				log.Info().Msgf("stageMgr stop here, in chan is closed %v", i)
				breakNow = true
			}
		case <-tick:
			oldLen := len(i.stageMap)
			now := time.Now()
			for stageUID, lastTriggerTime := range i.stageTTL {
				if now.Sub(lastTriggerTime) <= duration {
					continue
				}
				delete(i.stageTTL, stageUID)
				delete(i.stageMap, stageUID)
				delete(i.battleStatus, stageUID)
			}
			log.Info().Msgf("stageMgr clean is happened GC oldLen:%v newLen:%v",
				oldLen, len(i.stageMap))
		}
		if breakNow {
			break
		}
	}
}

func (i *stageRuntime) handle(in *stageDef.In) {
	defer cp.CoredumpHandler()
	reply := stageDef.InReply{}
	defer func() {
		// skip nil channel - some message don't need reply
		if in.ReplyChan == nil {
			return
		}
		// reply
		select {
		case in.ReplyChan <- reply:
			log.Debug().Msgf("stageMgr %v debug catch in:%v reply:%v",
				i, in, reply)
			close(in.ReplyChan)
		default:
			log.Info().Msgf("stageMgr %v info the replyChan not nil but channelMaker not listening %v",
				i, in)
		}
	}()
	switch in.Type {
	case stageDef.CreateStage:
		createStage, ok := in.Param.(stageDef.CreateStageParam)
		if !ok {
			reply.Result = csv.ERRCODE_FAILED
			log.Error().Msgf("stageMgr error createStage error reflect createStageParam error %v",
				createStage)
			return
		}
		stageUID, err := i.stageUIDGenerator.NextID()
		if err != nil {
			reply.Result = csv.ERRCODE_FAILED
			log.Error().Msgf("stageMgr error createStage error stageUID generator error %v",
				err)
			return
		}
		if _, err := i.stage(stageUID); err == nil {
			reply.Result = csv.ERRCODE_FAILED
			log.Error().Msgf("stageMgr error createStage error stageUID has exist %v",
				createStage)
			return
		}
		stageNew, err := stage.New(&createStage.StagePlayer, createStage.Hero, 1,
			createStage.StageMode, createStage.StageDifficulty, stageUID)
		if err != nil {
			reply.Result = csv.ERRCODE_FAILED
			log.Warn().Msgf("stageMgr error createStage %v", err)
			return
		}
		reply.Result = csv.ERRCODE_SUCCESS
		reply.Param = stageNew
		i.stageMap[stageUID] = &stageNew
		i.stageTTL[stageUID] = time.Now()
		i.stageMgr.Save(&stageNew)
		return
	case stageDef.PlayerUp:
		if in.StageUID == 0 || in.PlayerID == 0 {
			reply.Result = csv.ERRCODE_FAILED
			log.Error().Msgf("stageMgr error PlayerUp stageUID or playerID is zero, %v",
				in)
			return
		}
		method, ok := in.Param.(stageDef.Method)
		if !ok {
			reply.Result = csv.ERRCODE_FAILED
			log.Error().Msgf("stageMgr error PlayerUp reflect param error, %v",
				in)
			return
		}
		stageSource, err := i.stage(in.StageUID)
		if err != nil {
			reply.Result = csv.ERRCODE_FAILED
			log.Error().Msgf("stageMgr error PlayerUp error stage has not exist %v %v",
				in.StageUID, err)
			return
		}
		heroUID := uint64(0)
		for localHeroUID, heroOne := range stageSource.Heros {
			if heroOne.PlayerID == in.PlayerID {
				heroUID = localHeroUID
				break
			}
		}
		if heroUID == 0 {
			reply.Result = csv.ERRCODE_NO_HERO_IN_STAGE
			return
		}
		stageCopy := stage.FromRdsStageProto(stageSource.ToRdsStageProto())
		err = i.handlePlayerMethod(&stageCopy, stageCopy.Heros[heroUID], in.NodeID, method, &reply)
		if err != nil {
			log.Warn().Msgf("stageMgr error PlayerUp error handlePlayerMethod %v %v",
				in.StageUID, err)
			return
		}
		i.stageMap[in.StageUID] = &stageCopy
		i.stageTTL[in.StageUID] = time.Now()
		i.stageMgr.Save(&stageCopy)
		return
	case stageDef.BattleStart:
		nodeStatus, ok := i.battleStatus[in.StageUID]
		if !ok {
			return
		}
		battleStatus, ok := nodeStatus[in.NodeID]
		if !ok {
			return
		}
		battleStatus.allPlayer = in.Param.(map[uint64]bool)
		i.stageTTL[in.StageUID] = time.Now()
	case stageDef.BattleStatus:
		nodeStatus, ok := i.battleStatus[in.StageUID]
		if !ok {
			return
		}
		battleStatus, ok := nodeStatus[in.NodeID]
		if !ok {
			return
		}
		battleStatus.playerRound = in.Param.(map[uint64]chan interface{})
		i.stageTTL[in.StageUID] = time.Now()
	case stageDef.BattleOver:
		stageOne, err := i.stage(in.StageUID)
		if err != nil {
			log.Warn().Msgf("stageMgr %v error battleOver writer can't found stage %v",
				i, err)
			return
		}
		i.handleBattleOver(stageOne, in)
	case stageDef.NoticeDown:
		notice, ok := in.Param.(stageDef.Notice)
		if !ok {
			log.Error().Msgf("stageMgr %v error PlayerNotice param is nil",
				i)
			return
		}
		log.Debug().Msgf("stageMgr noticeDown %v", notice.CmdCode)
		i.stageMgr.NoticeDown(notice)
	case stageDef.OperationDown:
		op, ok := in.Param.(stageDef.Operation)
		if !ok {
			log.Error().Msgf("stageMgr %v error PlayerOperation param is nil",
				i)
			return
		}
		i.stageMgr.OperationDown(op)
	case stageDef.DelStage:
		err := i.handleDelStage(in.StageUID)
		if err != nil {
			log.Error().Msgf("stageMgr %v error delStage error %v",
				i, err)
		}
		return
	case stageDef.CheckBattle:
		err := i.handleCheckBattle(in.StageUID, in.NodeID, in.PlayerID, &reply)
		if err != nil {
			log.Error().Msgf("stageMgr %v error CheckBattle error %v",
				i, err)
		}
		return
	case stageDef.CheckEvent:
		i.handleCleanInEvent(in.StageUID, in.PlayerID)
		return
	default:
		reply.Result = csv.ERRCODE_FAILED
		log.Error().Msgf("stageMgr %v error catch the unknown inType %v",
			i, in)
	}
}

func (i *stageRuntime) stage(stageUID uint64) (*stage.Stage, error) {
	stg, ok := i.stageMap[stageUID]
	if ok {
		return stg, nil
	}
	stg = i.stageMgr.Get(stageUID)
	if stg == nil {
		return nil, fmt.Errorf("stageMgr get stage error can't found stage %v", stageUID)
	}
	i.stageMap[stageUID] = stg
	return stg, nil
}

// String achieve the string format interface
func (i *stageRuntime) String() string {
	ans := "stageMgr "
	ans += fmt.Sprintf("stageLen:%v ", len(i.stageMap))
	return ans
}
