package stageServer

import (
	"fmt"
	"github.com/gogo/protobuf/proto"
	"github.com/rs/zerolog/log"
	"shared/battle.etc/hero"
	"shared/battle.etc/node"
	"shared/battle.etc/stage"
	"shared/battle.etc/stageDef"
	pb "shared/proto/client/battle"
	cmd "shared/proto/share/command"
	"strconv"
	"time"
)

func (i *stageRuntime) handleBattleStart(stageUID uint64, nodeID uint32) func(chan<- *stageDef.BattleOperationParam, uint64) {
	return func(battleInChan chan<- *stageDef.BattleOperationParam, playerID uint64) {
		_, ok := i.battleStatus[stageUID]
		if !ok {
			i.battleStatus[stageUID] = make(map[uint32]*battleRuntime)
		}
		_, ok = i.battleStatus[stageUID][nodeID]
		if !ok {
			newBattleRuntime := battleRuntime{
				playerRound: make(map[uint64]chan interface{}),
				allPlayer:   make(map[uint64]bool),
			}
			i.battleStatus[stageUID][nodeID] = &newBattleRuntime
		}
		i.battleStatus[stageUID][nodeID].battleChan = battleInChan
		log.Debug().Msgf("stageMgr handleBattleStart be called, %v", i.battleStatus)
	}
}

func (i *stageRuntime) handleBattleOver(stageOne *stage.Stage, in *stageDef.In) {
	nodeID := in.NodeID
	// clean battle status
	delete(i.battleStatus[stageOne.UID], nodeID)
	// do battle over
	battleOverParam := in.Param.(stageDef.BattleOverParam)
	winnerCamp := battleOverParam.WinnerCamp
	winnerS, loserS := []*hero.InStage{}, []*hero.InStage{}
	for _, winner := range battleOverParam.WinnerS.([]*hero.InStage) {
		winnerS = append(winnerS, winner)
	}
	for _, loser := range battleOverParam.LoserS.([]*hero.InStage) {
		loserS = append(loserS, loser)
	}
	log.Debug().Msgf("battle over be called winners %v losers %v", winnerS, loserS)
	rewardMap, skipReward := stageOne.BattleOverWriterWithCheck(nodeID, winnerS, loserS, i.inChan)
	// save here
	i.stageTTL[in.StageUID] = time.Now()
	i.stageMgr.Save(stageOne)

	for uid, reward := range rewardMap {
		go i.handleBattleOverResultActionDown(stageOne, nodeID, uid, winnerCamp, reward, skipReward)
	}
	// down Loser result
	for _, h := range loserS {
		// down Loser result
		go i.handleBattleOverResultActionDown(stageOne, nodeID, h.GetUID(), winnerCamp, node.Reward{}, skipReward)
	}
	allPlayerID := []uint64{}
	for _, h := range winnerS {
		allPlayerID = append(allPlayerID, h.PlayerID)
	}
	for _, h := range loserS {
		allPlayerID = append(allPlayerID, h.PlayerID)
	}
	go func() {
		for _, playerID := range allPlayerID {
			// write player inBattle data
			i.inChan <- &stageDef.In{
				Type: stageDef.OperationDown,
				Param: stageDef.Operation{
					PlayerID: playerID,
					Op: stageDef.PlayerOperation{
						Type:   stageDef.PlayerOperationEnumWriteInBattle,
						Param1: 0,
						Param2: 0,
					},
				},
			}
		}
	}()
}

func (i *stageRuntime) handleBattleOverResultActionDown(stageOne *stage.Stage, nodeID uint32,
	heroUID uint64, winnerCamp uint32, reward node.Reward, skipReward bool) {
	stageUIDStr := strconv.FormatUint(stageOne.UID, 10)
	rsp := pb.BattleResultNotice{
		StageUid:    &stageUIDStr,
		StageNodeId: &nodeID,
		WinnerCamp:  &winnerCamp,
	}
	if !skipReward {
		rsp.Reward = reward.ToClientProto()
	}
	log.Debug().Msgf("battle %v:%v debug result action info:%v",
		stageUIDStr, nodeID, rsp)
	data, err := proto.Marshal(&rsp)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			stageUIDStr, nodeID, err, rsp)
	}
	stageNotice := stageDef.Notice{
		PlayerID: stageOne.Heros[heroUID].PlayerID,
		CmdCode:  cmd.CLIENT_RSP_CMD_BATTLE_RESULT_NOTICE,
		Data:     data,
	}
	i.inChan <- &stageDef.In{
		Type:  stageDef.NoticeDown,
		Param: stageNotice,
	}
}

func (i *stageRuntime) handleDelStage(stageUID uint64) error {
	stageOne, err := i.stage(stageUID)
	if err != nil {
		return err
	}
	log.Debug().Msgf("stage destroy uid:%v",
		stageUID)
	for _, nodeOne := range stageOne.Nodes {
		if nodeOne.Status == node.InBattle {
			return fmt.Errorf("try del stage %v error, battle not stop ", stageUID)
		}
	}
	playerIDs := []uint64{}
	for _, h := range stageOne.Heros {
		playerIDs = append(playerIDs, h.PlayerID)
	}
	i.stageMgr.StageOver(stageUID, playerIDs)
	delete(i.stageMap, stageUID)
	delete(i.stageTTL, stageUID)
	return nil
}

func (i *stageRuntime) handleCheckBattle(stageUID uint64, nodeID uint32, playerID uint64, reply *stageDef.InReply) error {
	nodeStatus, ok := i.battleStatus[stageUID]
	if !ok {
		reply.Param = false
		i.cleanInBattle(stageUID, nodeID, playerID)
		return nil
	}
	_, ok = nodeStatus[nodeID]
	if !ok {
		reply.Param = false
		i.cleanInBattle(stageUID, nodeID, playerID)
		return nil
	}
	reply.Param = true
	return nil
}

func (i *stageRuntime) cleanInBattle(stageUID uint64, nodeID uint32, playerID uint64) {
	stage, err := i.stage(stageUID)
	if err != nil {
		return
	}
	nd, ok := stage.Nodes[nodeID]
	if ok && nd.Status == node.InBattle {
		nd.Status = node.Normal
		stage.Nodes[nodeID] = nd
	}
	for heroUID, heroOne := range stage.Heros {
		if heroOne.PlayerID == playerID && heroOne.FlagInBattle {
			heroOne.FlagInBattle = false
			stage.Heros[heroUID] = heroOne
		}
	}
	i.stageMgr.Save(stage)
}

func (i *stageRuntime) handleCleanInEvent(stageUID uint64, playerID uint64) {
	stg, err := i.stage(stageUID)
	if err != nil {
		return
	}
	for heroUID, h := range stg.Heros {
		if h.PlayerID == playerID && h.FlagInEvent {
			h.ResetFromBeforeEventAttr()
			h.FlagInEvent = false
			stg.Heros[heroUID] = h
			i.stageMgr.Save(stg)
			log.Debug().Msgf("handle clean in event and save")
			return
		}
	}
}
