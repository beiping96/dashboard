package stageServer

import (
	"errors"
	"fmt"
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/battle"
	"shared/battle.etc/card"
	"shared/battle.etc/hero"
	"shared/battle.etc/potion"
	"shared/battle.etc/relic"
	"shared/battle.etc/stage"
	"shared/battle.etc/stageDef"
	"shared/cardDef"
	"shared/csv"
	pb "shared/proto/client/battle"
)

func (i *stageRuntime) handlePlayerMethod(stageOne *stage.Stage, myHero hero.InStage,
	nodeID uint32, method stageDef.Method, reply *stageDef.InReply) error {
	switch method.Type {
	case stageDef.TouchNode:
		err := i.handlePlayerMethodTouchNode(stageOne, myHero, nodeID, reply)
		log.Debug().Msgf("stageMgr debug touchNode %v %v", nodeID, err)
		return err
	case stageDef.BattleOperation, stageDef.BattleChooseCard:
		err := i.handleBattleOperationUP(stageOne, myHero, nodeID, reply)
		log.Debug().Msgf("stageMgr debug BattleOperation %v BattleChooseCard %v %v", method, nodeID, err)
		return err
	case stageDef.BattleLeave:
		err := i.handleBattleLeave(stageOne, myHero, nodeID, reply)
		log.Debug().Msgf("stageMgr debug BattleLeave %v %v", nodeID, err)
		return err
	case stageDef.BattleOffline:
		err := i.handleBattleOffline(stageOne, myHero, nodeID)
		log.Debug().Msgf("stageMgr debug BattleOffline %v %v", nodeID, err)
		return err
	case stageDef.RestCardLevelUp:
		cardID, _ := method.Param.(uint32)
		err := i.handleRestCardLevelUP(stageOne, myHero, nodeID, cardID, reply)
		log.Debug().Msgf("stageMgr debug RestCardLevelUp %v %v", nodeID, err)
		return err
	case stageDef.RestRecover:
		err := i.handleRestRecover(stageOne, myHero, nodeID, reply)
		log.Debug().Msgf("stageMgr debug RestRecover %v %v", nodeID, err)
		return err
	case stageDef.ShopBuy:
		param, _ := method.Param.(stageDef.ShopBuyParam)
		err := i.handleShopBuy(stageOne, myHero, nodeID, &param, reply)
		log.Debug().Msgf("stageMgr debug ShopBuy, nodeId: %d, param: %v, %v", nodeID, param, err)
		return err
	case stageDef.ChooseEvent:
		param, _ := method.Param.(stageDef.ChooseEventParam)
		err := i.handleChooseEvent(stageOne, myHero, nodeID, param, reply)
		log.Debug().Msgf("stageMgr debug ChooseEvent, curEventId: %d, param: %v, nodeId: %d, %v", myHero.CurEventID, param, nodeID, err)
		return err
	case stageDef.ChooseInitEvent:
		param, _ := method.Param.(stageDef.ChooseInitEventParam)
		err := i.handleChooseInitEvent(stageOne, myHero, param, reply)
		log.Debug().Msgf("stageMgr debug ChooseInitEvent, param: %+v", param)
		return err
	case stageDef.OpenReward:
		err := i.handleOpenReward(stageOne, myHero, nodeID, reply)
		log.Debug().Msgf("stageMgr debug OpenReward %v %v", nodeID, err)
		return err
	case stageDef.CloseReward:
		err := i.handleCloseReward(stageOne, myHero, nodeID, reply)
		log.Debug().Msgf("stageMgr debug CloseReward %v %v", nodeID, err)
		return err
	case stageDef.ChooseReward:
		choose, _ := method.Param.(stageDef.ChooseRewardParam)
		err := i.handleChooseReward(stageOne, myHero, nodeID, choose, reply)
		log.Debug().Msgf("stageMgr debug ChooseReward %v %v", nodeID, err)
		return err
	case stageDef.DestroyStage:
		err := i.handleDestroyStage(stageOne, myHero, reply)
		log.Debug().Msgf("stageMgr debug DestroyStage %v %v", nodeID, err)
		return err
	case stageDef.DropPotion:
		potionID, _ := method.Param.(uint32)
		err := i.handleDropPotion(stageOne, myHero, potionID, reply)
		log.Debug().Msgf("stageMgr debug DropPotion %v %v", nodeID, err)
		return err
	case stageDef.Reconnection:
		err := i.handleReconnection(stageOne, myHero, nodeID, reply)
		log.Debug().Msgf("stageMgr debug Reconnection %v %v", nodeID, err)
		return err
	case stageDef.Resurgence:
		resurgenceType, _ := method.Param.(uint32)
		err := i.handleResurgence(stageOne, myHero, resurgenceType, reply)
		log.Debug().Msgf("stageMgr debug Resurgence %v %v %v", resurgenceType, err, reply)
		return err
	case stageDef.RelicInStageChoose:
		relicInStageChooseParam, _ := method.Param.(stageDef.RelicInStageChooseParam)
		err := i.handleRelicInStageChoose(stageOne, myHero, relicInStageChooseParam, reply)
		log.Debug().Msgf("stageMgr debug RelicInStageChoose %v %v", relicInStageChooseParam, err)
		return err
	default:
		reply.Result = csv.ERRCODE_FAILED
		return errors.New("stageMgr error handlePlayerMethod unknown type")
	}
}

func (i *stageRuntime) handlePlayerMethodTouchNode(stageOne *stage.Stage, myHero hero.InStage,
	nodeID uint32, reply *stageDef.InReply) error {
	touchNodeReply := stageDef.TouchNodeReply{}
	if myHero.FlagInBattle {
		reply.Result = csv.ERRCODE_IN_BATTLE_TOUCH_NODE_ERROR
		return fmt.Errorf("stageTouch error hero has in battle flag %v", stageOne)
	}
	if myHero.FlagQuit {
		reply.Result = csv.ERRCODE_BATTLE_STAGE_DESTROY
		return fmt.Errorf("stageTouch error hero has quit flag %v", stageOne)
	}
	if myHero.HP == 0 {
		reply.Result = csv.ERRCODE_BATTLE_HERO_NO_LIFE
		return fmt.Errorf("stageTouch error hero's hp is zero %v", stageOne)
	}
	result, err := stageOne.Touch(nodeID, myHero, i.inChan, &touchNodeReply, i.handleBattleStart(stageOne.UID, nodeID))
	reply.Result = result
	reply.Param = touchNodeReply
	return err
}

func (i *stageRuntime) battleChanForPlayer(stageUID uint64, nodeID uint32, playerID uint64) (bool, chan interface{}) {
	stageStatus, ok := i.battleStatus[stageUID]
	if !ok {
		return false, nil
	}
	nodeStatus, ok := stageStatus[nodeID]
	if !ok {
		return false, nil
	}
	battleChan, ok := nodeStatus.playerRound[playerID]
	if !ok {
		return true, nil
	}
	return true, battleChan
}

func (i *stageRuntime) handleBattleOperationUP(stageOne *stage.Stage, myHero hero.InStage,
	nodeID uint32, reply *stageDef.InReply) error {
	_, battleChan := i.battleChanForPlayer(stageOne.UID, nodeID, myHero.PlayerID)
	reply.Result = csv.ERRCODE_SUCCESS
	reply.Param = battleChan
	if battleChan == nil {
		reply.Result = csv.ERRCODE_NOT_IN_TURN
	}
	return nil
}

func (i *stageRuntime) handleBattleLeave(stageOne *stage.Stage, myHero hero.InStage,
	nodeID uint32, reply *stageDef.InReply) error {
	battleIsExist, battleChan := i.battleChanForPlayer(stageOne.UID, nodeID, myHero.PlayerID)
	if battleChan != nil {
		// player up chan is no buffer
		// DO NOT hold stageMgr process
		go func() {
			battleChan <- battle.FinishRoundOperation()
		}()
	}
	if !battleIsExist {
		log.Debug().Msgf("stageMgr player up leave battle, but battle process is not exist %v:%v",
			stageOne.UID, nodeID)
		return nil
	}
	upToBattleProcess := stageDef.BattleOperationParam{
		Control: battle.Control{
			Enum: "leave",
			UID:  myHero.GetUID(),
		},
	}
	i.battleStatus[stageOne.UID][nodeID].battleChan <- &upToBattleProcess
	reply.Result = csv.ERRCODE_SUCCESS
	return nil
}

func (i *stageRuntime) handleBattleOffline(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32) error {
	battleIsExist, _ := i.battleChanForPlayer(stageOne.UID, nodeID, myHero.PlayerID)
	if !battleIsExist {
		log.Debug().Msgf("stageMgr player up leave battle, but battle process is not exist %v:%v",
			stageOne.UID, nodeID)
		return nil
	}
	upToBattleProcess := stageDef.BattleOperationParam{
		Control: battle.Control{
			Enum: "offline",
			UID:  myHero.GetUID(),
		},
	}
	i.battleStatus[stageOne.UID][nodeID].battleChan <- &upToBattleProcess
	return nil
}

func (i *stageRuntime) handleRestCardLevelUP(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32,
	cardID uint32, reply *stageDef.InReply) error {
	result, newResID, err := stageOne.RestCardLevelUp(myHero, nodeID, cardID)
	reply.Result = result
	reply.Param = newResID
	return err
}

func (i *stageRuntime) handleRestRecover(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32,
	reply *stageDef.InReply) error {
	result, newHP, relicInStage, err := stageOne.RestRecover(myHero, nodeID)
	reply.Result = result
	recoverReply := stageDef.RestRecoverReply{
		NewHP:        newHP,
		RelicInStage: relicInStage,
	}
	reply.Param = recoverReply
	return err
}

func (i *stageRuntime) handleShopBuy(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32, param *stageDef.ShopBuyParam,
	reply *stageDef.InReply) (err error) {
	result := stageOne.ShopPurchase(&myHero, nodeID, param.ItemID, param.ItemType, param.ItemIndex, param.Rsp)
	reply.Result = result
	return nil
}

func (i *stageRuntime) handleChooseEvent(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32,
	param stageDef.ChooseEventParam, reply *stageDef.InReply) error {

	eventResult, linkageEventID, stop, resultCode := stageOne.ChooseEvent(myHero, nodeID, param.OperationIndex, param.CardIDs)
	reply.Result = resultCode
	reply.Param = stageDef.ChooseEventReply{
		EventResult:    eventResult,
		LinkageEventID: linkageEventID,
		EventStop:      stop,
	}
	return nil
}

func (i *stageRuntime) handleChooseInitEvent(stageOne *stage.Stage, myHero hero.InStage, param stageDef.ChooseInitEventParam,
	reply *stageDef.InReply) error {
	eventResult, resultCode := stageOne.ChooseInitEvent(myHero, param.EventID, param.Param)
	reply.Result = resultCode
	reply.Param = eventResult
	return nil
}

func (i *stageRuntime) handleOpenReward(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32,
	reply *stageDef.InReply) error {
	relicInStage, result, err := stageOne.OpenReward(myHero, nodeID)
	reply.Result = result
	if relicInStage != nil {
		reply.Param = *relicInStage
	}
	return err
}

func (i *stageRuntime) handleCloseReward(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32,
	reply *stageDef.InReply) error {
	reply.Result = csv.ERRCODE_SUCCESS
	if nodeID != 0 {
		return nil
	}
	initC, ok := stageOne.InitConfigMap[myHero.GetUID()]
	if !ok || initC.Type != 2 {
		reply.Result = csv.ERRCODE_BATTLE_REWARD_NOT_EXIST
		return nil
	}
	delete(stageOne.InitConfigMap, myHero.GetUID())
	return nil
}

func (i *stageRuntime) handleChooseReward(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32,
	chooseRewardParam stageDef.ChooseRewardParam, reply *stageDef.InReply) error {
	chooseRewardReply := stageDef.ChooseRewardReply{}
	result, err := stageOne.ChooseReward(myHero, nodeID, chooseRewardParam, &chooseRewardReply)
	if err != nil {
		reply.Result = csv.ERRCODE_FAILED
		return err
	}
	reply.Result = result
	reply.Param = chooseRewardReply
	return nil
}

func (i *stageRuntime) handleDestroyStage(stageOne *stage.Stage, myHero hero.InStage, reply *stageDef.InReply) error {
	stageUID := stageOne.UID
	log.Debug().Msgf("stage destroy uid:%v",
		stageUID)
	myHero.FlagQuit = true
	stageOne.Heros[myHero.GetUID()] = myHero
	stageOne.TryDestroy(false, false, 0, i.inChan, nil)
	return nil
}

func (i *stageRuntime) handleDropPotion(stageOne *stage.Stage, myHero hero.InStage, potionTypeID uint32, reply *stageDef.InReply) error {
	stageUID := stageOne.UID
	log.Debug().Msgf("stage dropPotion uid:%v potionID:%v",
		stageUID, potionTypeID)
	if myHero.FlagInBattle {
		reply.Result = csv.ERRCODE_BATTLE_IS_EXIST
		return nil
	}
	defer func() {
		potionList := []uint32{}
		for _, pOne := range myHero.Potions {
			potionList = append(potionList, pOne.ToClientProto())
		}
		reply.Param = potionList
	}()

	index := -1
	for indexLocal, potionOne := range myHero.Potions {
		if potionOne == potion.Potion(potionTypeID) {
			index = indexLocal
			break
		}
	}
	if index < 0 {
		reply.Result = csv.ERRCODE_BATTLE_POTION_NOT_EXIST
		return nil
	}
	myHero.Potions = append(myHero.Potions[:index], myHero.Potions[index+1:]...)
	stageOne.Heros[myHero.GetUID()] = myHero
	return nil
}

func (i *stageRuntime) handleReconnection(stageOne *stage.Stage, myHero hero.InStage, nodeID uint32, reply *stageDef.InReply) error {
	stageStatus, ok := i.battleStatus[stageOne.UID]
	replyBattleNotExist := uint32(0)
	if !ok {
		reply.Result = csv.ERRCODE_SUCCESS
		reply.Param = replyBattleNotExist
		return nil
	}
	battleStatus, ok := stageStatus[nodeID]
	if !ok {
		reply.Result = csv.ERRCODE_SUCCESS
		reply.Param = replyBattleNotExist
		return nil
	}
	ok = battleStatus.allPlayer[myHero.PlayerID]
	if !ok {
		battleStatus.battleChan <- &stageDef.BattleOperationParam{
			Control: battle.Control{
				Enum: "stop",
			},
		}
		reply.Result = csv.ERRCODE_SUCCESS
		reply.Param = replyBattleNotExist
		return nil
	}
	reply.Result = csv.ERRCODE_SUCCESS
	reply.Param = uint32(1)
	battleStatus.battleChan <- &stageDef.BattleOperationParam{
		Control: battle.Control{
			Enum: "reconnection",
			UID:  myHero.GetUID(),
		},
	}
	return nil
}

func (i *stageRuntime) handleResurgence(stageOne *stage.Stage, myHero hero.InStage, resurgenceType uint32, reply *stageDef.InReply) error {
	if myHero.FlagInBattle {
		reply.Result = csv.ERRCODE_BATTLE_IS_EXIST
		return nil
	}
	if myHero.HP > 0 {
		reply.Result = csv.ERRCODE_BATTLE_HERO_HP_NOT_ZERO
		return nil
	}
	if myHero.Life <= 0 {
		reply.Result = csv.ERRCODE_BATTLE_HERO_NO_LIFE
		return nil
	}
	if resurgenceType != 0 {
		findOption := false
		for _, recoverOption := range myHero.RecoverOption {
			if recoverOption == resurgenceType {
				findOption = true
				break
			}
		}
		if !findOption {
			reply.Result = csv.ERRCODE_FAILED
			log.Error().Msgf("stageMgr err Resurgence option %v not exist in hero.RecoverOption",
				resurgenceType)
			return nil
		}
	}
	resurgenceReply := stageDef.ResurgenceReply{}
	switch resurgenceType {
	case 0:
		myHero.HP = myHero.ResurgenceHP
		myHero.Potions = make([]potion.Potion, len(myHero.ResurgencePotions))
		copy(myHero.Potions, myHero.ResurgencePotions)
		reply.Result = csv.ERRCODE_SUCCESS
	case 1:
		myHero.HP = myHero.HPLimit
		reply.Result = csv.ERRCODE_SUCCESS
	case 2:
		myHero.HP = myHero.ResurgenceHP
		myHero.Potions = make([]potion.Potion, len(myHero.ResurgencePotions))
		copy(myHero.Potions, myHero.ResurgencePotions)
		var canLevelUpCardIndex []uint32
		for i, c := range myHero.AllCards {
			if c.Level < c.MaxLevel {
				canLevelUpCardIndex = append(canLevelUpCardIndex, uint32(i))
			}
		}
		for i := 0; i < 3; i++ {
			if len(canLevelUpCardIndex) == 0 {
				continue
			}
			r := rand.Intn(len(canLevelUpCardIndex))
			allCardsIndex := canLevelUpCardIndex[r]
			oldCard := myHero.AllCards[allCardsIndex]
			newCard, err := oldCard.LevelUp()
			if err != nil {
				log.Error().Msgf("randomCardLvUp: card cannot level up: %v", oldCard)
				continue
			}
			myHero.AllCards[allCardsIndex] = newCard
			levelUp := pb.BattleResurgenceCardLvUp{}
			levelUp.OldCard = oldCard.ToClientProto()
			levelUp.NewCard = newCard.ToClientProto()
			resurgenceReply.CardLvUp = append(resurgenceReply.CardLvUp, &levelUp)
			canLevelUpCardIndex = append(canLevelUpCardIndex[:r], canLevelUpCardIndex[r+1:]...)
		}
		reply.Result = csv.ERRCODE_SUCCESS
	case 3:
		myHero.HP = myHero.ResurgenceHP
		myHero.Potions = make([]potion.Potion, len(myHero.ResurgencePotions))
		copy(myHero.Potions, myHero.ResurgencePotions)
		canGetRelic := []uint32{}
		for relicID := range csv.RemainsMap {
			_, ok := myHero.GetRelic(uint32(relicID))
			if ok {
				continue
			}
			canGetRelic = append(canGetRelic, uint32(relicID))
		}
		if len(canGetRelic) > 0 {
			relicTypeID := canGetRelic[rand.Intn(len(canGetRelic))]
			relicInStage, err := myHero.AddRelic(relicTypeID, stageOne.Difficulty, stageOne.Level)
			if err != nil {
				log.Error().Msgf("handleResurgence addRelic %v error:  %v", relicTypeID, err)
			} else {
				if relicInStage != nil {
					resurgenceReply.RelicInStage = append(resurgenceReply.RelicInStage, relicInStage)
				}
				resurgenceReply.RelicTypeID = relicTypeID
			}
		}
		reply.Result = csv.ERRCODE_SUCCESS
	case 4:
		myHero.HP = myHero.ResurgenceHP
		myHero.Potions = make([]potion.Potion, len(myHero.ResurgencePotions))
		copy(myHero.Potions, myHero.ResurgencePotions)
		canGetPotion := []potion.Potion{}
		for potionID := range csv.TablePotionsMap {
			canGetPotion = append(canGetPotion, potion.Potion(potionID))
		}
		for i := 0; i < 3; i++ {
			if len(canGetPotion) <= 0 {
				continue
			}
			potionID := canGetPotion[rand.Intn(len(canGetPotion))]
			err := myHero.AddPotion(potionID)
			if err != nil {
				continue
			}
			resurgenceReply.Potions = append(resurgenceReply.Potions, potionID.ToClientProto())
		}
		reply.Result = csv.ERRCODE_SUCCESS
	case 5:
		myHero.HP = myHero.ResurgenceHP
		myHero.Potions = make([]potion.Potion, len(myHero.ResurgencePotions))
		copy(myHero.Potions, myHero.ResurgencePotions)
		myHero.RecoverPlusMorePower = true
		reply.Result = csv.ERRCODE_SUCCESS
	case 6:
		myHero.HP = myHero.ResurgenceHP
		myHero.Potions = make([]potion.Potion, len(myHero.ResurgencePotions))
		copy(myHero.Potions, myHero.ResurgencePotions)
		myHero.RecoverPlusMoreMPAndCard = true
		reply.Result = csv.ERRCODE_SUCCESS
	default:
		reply.Result = csv.ERRCODE_FAILED
		return nil
	}
	myHero.Life--
	if _, ok := myHero.GetRelic(relic.MoreHpAfterResurgence); ok {
		if basic, _, _, ok := relic.GetRelicBasic(relic.MoreHpAfterResurgence); ok {
			hpAdd := uint32(basic)
			relicInStage := pb.BattleRelicInStage{}
			relicTypeID := relic.MoreHpAfterResurgence
			relicInStage.RelicTypeId = &relicTypeID
			hpChange := pb.BattleRelicInStageChange{}
			oldHp := myHero.HP
			hpChange.OldValue = &oldHp
			if oldHp+hpAdd > myHero.HPLimit {
				myHero.HP = myHero.HPLimit
			} else {
				myHero.HP = oldHp + hpAdd
			}
			hpChange.NewValue = &myHero.HP
			relicInStage.HpChange = &hpChange
			resurgenceReply.RelicInStage = append(resurgenceReply.RelicInStage, &relicInStage)
		}
	}
	if _, ok := myHero.GetRelic(relic.SelectCardLvUpAfterResurgence); ok {
		relicInStage := pb.BattleRelicInStage{}
		relicTypeID := relic.SelectCardLvUpAfterResurgence
		relicInStage.RelicTypeId = &relicTypeID
		for _, cardOne := range myHero.AllCards {
			_, err := cardOne.LevelUp()
			if err != nil {
				continue
			}
			relicInStage.ChooseCard = append(relicInStage.ChooseCard, cardOne.ToClientProto())
		}
		resurgenceReply.RelicInStage = append(resurgenceReply.RelicInStage, &relicInStage)
	}
	if _, ok := myHero.GetRelic(relic.AddPotionAfterResurgence); ok {
		if basic, _, _, ok := relic.GetRelicBasic(relic.AddPotionAfterResurgence); ok {
			relicInStage := pb.BattleRelicInStage{}
			relicTypeID := relic.AddPotionAfterResurgence
			relicInStage.RelicTypeId = &relicTypeID
			canGetPotion := []potion.Potion{}
			for potionID := range csv.TablePotionsMap {
				canGetPotion = append(canGetPotion, potion.Potion(potionID))
			}
			for i := 0; i < basic; i++ {
				if len(canGetPotion) <= 0 {
					continue
				}
				potionID := canGetPotion[rand.Intn(len(canGetPotion))]
				err := myHero.AddPotion(potionID)
				if err != nil {
					continue
				}
				relicInStage.GotPotion = append(relicInStage.GotPotion, potionID.ToClientProto())
			}
			resurgenceReply.RelicInStage = append(resurgenceReply.RelicInStage, &relicInStage)
		}
	}
	if _, ok := myHero.GetRelic(relic.AddCardAfterResurgence); ok {
		if basic, _, _, ok := relic.GetRelicBasic(relic.AddCardAfterResurgence); ok && basic > 0 {
			if dropCard := hero.GetDropCards(&myHero, stageOne.Difficulty, stageOne.Level, csv.DROP_FROM_ENEMY, uint32(basic)); len(dropCard) > 0 {
				relicInStage := pb.BattleRelicInStage{}
				relicTypeID := relic.AddCardAfterResurgence
				relicInStage.RelicTypeId = &relicTypeID
				for _, cardResID := range dropCard {
					cardConfig, ok := csv.TableCardsMap[int64(cardResID)]
					if !ok {
						log.Error().Msgf("drop card resID:%v not exist in config", cardResID)
						continue
					}
					cardTypeID := uint32(cardConfig.CardGroupID)
					cardLevel := uint32(cardConfig.Level)
					cardStar := uint32(1)
					cardD, ok := myHero.CardPool[cardDef.TypeID(cardTypeID)]
					if ok {
						cardStar = cardD.GetCardStarLevel()
					}
					newCard, err := myHero.AddOneCard(cardTypeID, cardStar, cardLevel)
					if err != nil {
						log.Error().Msgf("resurgence error trigger relic add resID:%v card %v", cardResID, err)
						continue
					}
					relicInStage.GotCard = append(relicInStage.GotCard, newCard.ToClientProto())
				}
				resurgenceReply.RelicInStage = append(resurgenceReply.RelicInStage, &relicInStage)
			}
		}
	}
	// finally
	stageOne.Heros[myHero.GetUID()] = myHero
	reply.Param = resurgenceReply
	return nil
}

func (i *stageRuntime) handleRelicInStageChoose(stageOne *stage.Stage, myHero hero.InStage, relicInStageChooseParam stageDef.RelicInStageChooseParam, reply *stageDef.InReply) error {
	param, ok := myHero.GetRelic(relicInStageChooseParam.RelicTypeID)
	if !ok {
		reply.Result = csv.ERRCODE_RELIC_NOT_EXIST
		return nil
	}
	if param != 0 {
		reply.Result = csv.ERRCODE_BATTLE_REWARD_NOT_EXIST
		return nil
	}
	cardID, potionID := relicInStageChooseParam.CardID, relicInStageChooseParam.PotionID
	relicUpdate := myHero.Relics[relicInStageChooseParam.RelicTypeID]
	reply.Result = csv.ERRCODE_SUCCESS
	relicInStageChooseReply := stageDef.RelicInStageChooseReply{}
	switch relicInStageChooseParam.RelicTypeID {
	case relic.SelectPowerCardBeforeBattle:
		cardOne, ok := myHero.GetCard(cardID)
		if !ok {
			reply.Result = csv.ERRCODE_CARD_NOT_EXIST
			return nil
		}
		if cardOne.Type != card.Power {
			reply.Result = csv.ERRCODE_FAILED
			return nil
		}
		relicUpdate.Param = cardID
		myHero.Relics[relicInStageChooseParam.RelicTypeID] = relicUpdate
		stageOne.Heros[myHero.GetUID()] = myHero
		relicInStageChooseReply.Card = cardOne.ToClientProto()
		reply.Param = relicInStageChooseReply
		return nil
	case relic.SelectAttackCardBeforeBattle:
		cardOne, ok := myHero.GetCard(cardID)
		if !ok {
			reply.Result = csv.ERRCODE_CARD_NOT_EXIST
			return nil
		}
		if cardOne.Type != card.Attack {
			reply.Result = csv.ERRCODE_FAILED
			return nil
		}
		relicUpdate.Param = cardID
		myHero.Relics[relicInStageChooseParam.RelicTypeID] = relicUpdate
		stageOne.Heros[myHero.GetUID()] = myHero
		relicInStageChooseReply.Card = cardOne.ToClientProto()
		reply.Param = relicInStageChooseReply
		return nil
	case relic.SelectSkillCardBeforeBattle:
		cardOne, ok := myHero.GetCard(cardID)
		if !ok {
			reply.Result = csv.ERRCODE_CARD_NOT_EXIST
			return nil
		}
		if cardOne.Type != card.Skill {
			reply.Result = csv.ERRCODE_FAILED
			return nil
		}
		relicUpdate.Param = cardID
		myHero.Relics[relicInStageChooseParam.RelicTypeID] = relicUpdate
		stageOne.Heros[myHero.GetUID()] = myHero
		relicInStageChooseReply.Card = cardOne.ToClientProto()
		reply.Param = relicInStageChooseReply
		return nil
	case relic.SelectPotions:
		index := -1
		for indexLocal, p := range relicUpdate.SelectPotion {
			if p == potion.Potion(potionID) {
				index = indexLocal
				break
			}
		}
		if index < 0 {
			reply.Result = csv.ERRCODE_BATTLE_REWARD_NOT_EXIST
			return nil
		}
		myHero.AddPotion(potion.Potion(potionID))
		relicUpdate.SelectPotion = append(relicUpdate.SelectPotion[:index], relicUpdate.SelectPotion[index+1:]...)
		myHero.Relics[relicInStageChooseParam.RelicTypeID] = relicUpdate
		stageOne.Heros[myHero.GetUID()] = myHero
		potions := []uint32{}
		for _, p := range myHero.Potions {
			potions = append(potions, p.ToClientProto())
		}
		relicInStageChooseReply.Potions = potions
		reply.Param = relicInStageChooseReply
		return nil
	case relic.SelectCards:
		index := -1
		for indexLocal, c := range relicUpdate.SelectCard {
			if c.ID == cardID {
				index = indexLocal
				break
			}
		}
		if index < 0 {
			reply.Result = csv.ERRCODE_BATTLE_REWARD_NOT_EXIST
			return nil
		}
		cardOne := relicUpdate.SelectCard[index]
		myHero.AddOneCardStruct(cardOne)
		relicUpdate.SelectCard = append(relicUpdate.SelectCard[:index], relicUpdate.SelectCard[index+1:]...)
		myHero.Relics[relicInStageChooseParam.RelicTypeID] = relicUpdate
		stageOne.Heros[myHero.GetUID()] = myHero
		relicInStageChooseReply.Card = cardOne.ToClientProto()
		reply.Param = relicInStageChooseReply
		return nil
	case relic.SelectCardLvUpAfterResurgence:
		cardOne, ok := myHero.GetCard(cardID)
		if !ok {
			reply.Result = csv.ERRCODE_CARD_NOT_EXIST
			return nil
		}
		newCard, err := cardOne.LevelUp()
		if err != nil {
			reply.Result = csv.ERRCODE_FAILED
			return nil
		}
		_, err = myHero.RemoveOneCard(cardID)
		if err != nil {
			reply.Result = csv.ERRCODE_FAILED
			return nil
		}
		err = myHero.AddOneCardStruct(newCard)
		if err != nil {
			reply.Result = csv.ERRCODE_FAILED
			return nil
		}
		relicUpdate.Param = 1
		myHero.Relics[relicInStageChooseParam.RelicTypeID] = relicUpdate
		stageOne.Heros[myHero.GetUID()] = myHero
		relicInStageChooseReply.Card = newCard.ToClientProto()
		reply.Param = relicInStageChooseReply
		return nil
	default:
		reply.Result = csv.ERRCODE_FAILED
		return nil
	}
}
