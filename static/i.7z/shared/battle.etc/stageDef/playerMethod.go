package stageDef

import (
	pb "shared/proto/client/battle"
)

type methodType uint16

const (
	_ methodType = iota
	// TouchNode battle_single_pve_touch_req
	TouchNode
	// BattleOperation battle_operation_req
	BattleOperation
	// BattleChooseCard battle_choose_card_req
	BattleChooseCard
	// BattleLeave battle_leave_battle_req
	BattleLeave
	// BattleOffline call by playerMgr
	BattleOffline
	// RestCardLevelUp battle_card_level_up_req
	RestCardLevelUp
	// RestRecover battle_recover_req
	RestRecover
	// OpenReward battle_reward_open_req
	OpenReward
	// CloseReward battle_reward_close_req
	CloseReward
	// ChooseReward battle_choice_reward_req
	ChooseReward
	// DestroyStage battle_single_pve_destroy_req
	DestroyStage
	// ShopBuy battle_shop_purchase_req
	ShopBuy
	// ChooseEvent battle_choose_event_req
	ChooseEvent
	// DropPotion battle_drop_potion_req
	DropPotion
	// Reconnection battle_reconnection_req
	Reconnection
	// Resurgence battle_resurgence_req
	Resurgence
	// ChooseInitEvent stage_choose_init_event_req
	ChooseInitEvent
	// RelicInStageChoose battle_relic_in_stage_choose_req
	RelicInStageChoose
)

// Method - desc player do something up to stageMgr
type Method struct {
	Type  methodType
	Param interface{}
}

// TouchNodeReply define for nodeTouch method reply
type TouchNodeReply struct {
	Status     uint32
	BattleData pb.BattleData
	ShopItem   pb.BattleShop
	RestStatus []uint32
	Treasure   pb.BattleReward
	MeetID     uint32
	InBattle   bool
}

// BattleOperationParam define for battleOperation up to battle process
type BattleOperationParam struct {
	Control interface{}
}

// RestRecoverReply define for restRecover method reply
type RestRecoverReply struct {
	NewHP        uint32
	RelicInStage []pb.BattleRelicInStage
}

// ChooseEventParam define for choose event param
type ChooseEventParam struct {
	OperationIndex uint32
	CardIDs        []uint32
}

// ChooseInitEventParam define for choose init event param
type ChooseInitEventParam struct {
	EventID uint32
	Param   uint32
}

// ChooseEventReply define for chooseEvent method reply
type ChooseEventReply struct {
	EventResult    pb.BattleEventResult
	LinkageEventID uint32
	EventStop      bool
}

// ChooseRewardParam define for chooseReward operation up to battle process
type ChooseRewardParam struct {
	RewardBagUID uint32
	RewardType   pb.BattleRewardEnum
	ItemID       uint32
}

// ChooseRewardReply define for chooseReward method reply
type ChooseRewardReply struct {
	NewGold      uint32
	RelicInStage []pb.BattleRelicInStage
}

// ShopBuyParam define for shop buy
type ShopBuyParam struct {
	ItemID    uint32
	ItemType  uint32
	ItemIndex uint32
	Rsp       *pb.BattleShopPurchaseRsp
}

// ResurgenceReply define for resurgence method reply
type ResurgenceReply struct {
	CardLvUp     []*pb.BattleResurgenceCardLvUp
	Potions      []uint32
	RelicTypeID  uint32
	RelicInStage []*pb.BattleRelicInStage
}

// RelicInStageChooseParam define for relic choose
type RelicInStageChooseParam struct {
	RelicTypeID uint32
	CardID      uint32
	PotionID    uint32
}

// RelicInStageChooseReply define fir relic choose method reply
type RelicInStageChooseReply struct {
	Card    *pb.BattleCard
	Potions []uint32
}
