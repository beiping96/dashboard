package stageDef

import (
	db "shared/proto/server/lobby"
)

const (
	// PlayerOperationEnumWriteInBattle define for stage write player InBattle Data
	PlayerOperationEnumWriteInBattle uint32 = 1
	// PlayerOperationEnumCleanSinglePve define for clean singPve UID write player singlePveUID
	PlayerOperationEnumCleanSinglePve uint32 = 2
	// PlayerOperationEnumAddRewardGoods define for stage over give player box reward
	PlayerOperationEnumAddRewardGoods uint32 = 3
)

// PlayerOperation define for stage write playerData
type PlayerOperation struct {
	Type   uint32
	Param1 uint64
	Param2 uint32
}

// ToDbProto convert PlayerOperation
func (op *PlayerOperation) ToDbProto() *db.DbStageOperation {
	if op == nil {
		return nil
	}
	return &db.DbStageOperation{
		Type:   op.Type,
		Param1: op.Param1,
		Param2: op.Param2,
	}
}

// FromDbStageOperation convert PlayerOperation
func FromDbStageOperation(opDb *db.DbStageOperation) *PlayerOperation {
	return &PlayerOperation{
		Type:   opDb.GetType(),
		Param1: opDb.GetParam1(),
		Param2: opDb.GetParam2(),
	}
}
