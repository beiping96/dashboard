package stageDef

import (
	"shared/battle.etc/stagePlayer"
	"shared/heroDef"
	cmd "shared/proto/share/command"
)

type inType uint8

const (
	_ inType = iota
	// CreateStage 创建地宫
	CreateStage
	// PlayerUp 玩家上行
	PlayerUp
	// BattleStart 战斗开始
	BattleStart
	// BattleStatus 战斗状态
	BattleStatus
	// BattleOver 战斗结束
	BattleOver
	// NoticeDown 下行通知
	NoticeDown
	// OperationDown 下行操作
	OperationDown
	// DelStage 删除地宫
	DelStage
	// CheckBattle 检查战斗
	CheckBattle
	// CheckEvent 检查事件
	CheckEvent
)

// In - desc common struct into stageMgr
type In struct {
	Type      inType
	ReplyChan chan<- InReply
	StageUID  uint64
	NodeID    uint32
	PlayerID  uint64
	Param     interface{}
}

// InReply - desc common reply struct after In
type InReply struct {
	Result int32
	Param  interface{}
}

// Notice - desc stage driving notice to player
type Notice struct {
	PlayerID uint64
	CmdCode  cmd.CLIENT_RSP_CMD
	Data     []byte
}

// Operation - desc stageMgr write playerData
type Operation struct {
	PlayerID uint64
	Op       PlayerOperation
}

// BattleStatusParam - desc battle status write stage
type BattleStatusParam struct {
	HeroUIDs []uint64
}

// BattleOverParam - desc battle process write stage
type BattleOverParam struct {
	WinnerS    interface{}
	LoserS     interface{}
	WinnerCamp uint32
}

// CreateStageParam define for createStage method
type CreateStageParam struct {
	StagePlayer     stagePlayer.StagePlayer
	Hero            heroDef.Hero
	StageMode       uint32
	StageDifficulty uint32
}
