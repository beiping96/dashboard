package hero

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/potion"
	"shared/csv"
	"strconv"
	"strings"
)

func (heroOne *InStage) countAttr(attrIDs []uint32) error {
	localAttrStr := ""
	for _, heroConfig := range csv.TableHeroGrowingMap {
		if uint32(heroConfig.HeroID) == heroOne.GetTypeID() && uint32(heroConfig.HeroStar) == heroOne.GetStarLevel() {
			localAttrStr = heroConfig.GlobalAttr
			break
		}
	}
	localAttrIDs := []uint32{}
	for _, attrIDStr := range strings.Split(localAttrStr, ",") {
		if attrIDStr == "" {
			continue
		}
		attrID, err := strconv.Atoi(attrIDStr)
		if err != nil {
			log.Error().Msgf("config error heroGrowing heroTypeID:%v heroStar:%v localAttrString:%v error:%v",
				heroOne.GetTypeID(), heroOne.GetStarLevel(), localAttrStr, err)
			continue
		}
		localAttrIDs = append(localAttrIDs, uint32(attrID))
	}
	for _, attrID := range append(attrIDs, localAttrIDs...) {
		err := heroOne.countAttrOne(attrID)
		if err != nil {
			log.Error().Msgf("config error heroGrowing heroTypeID:%v heroStar:%v attrID:%v error:%v",
				heroOne.GetTypeID(), heroOne.GetStarLevel(), attrID, err)
			continue
		}
	}
	return nil
}

func (heroOne *InStage) countAttrOne(attrID uint32) error {
	config, ok := csv.HeroGrowingAttrMap[int64(attrID)]
	if !ok {
		return fmt.Errorf("config HeroGrowingAttrMap error not exist %v", attrID)
	}
	switch config.Enum {
	case csv.HG_ATTR_INIT_HP:
		heroOne.HPLimit += uint32(config.Param)
		heroOne.HP = heroOne.HPLimit
		return nil
	case csv.HG_ATTR_MONSTER_DROP_GOLD:
		heroOne.MonsterDropGoldAddPercent += uint32(config.Param)
		return nil
	case csv.HG_ATTR_REST_RECOVER_HP:
		heroOne.RestRecoverHpAdd += uint32(config.Param)
		return nil
	case csv.HG_ATTR_RELIVE_TIMES:
		heroOne.Life += uint32(config.Param)
		return nil
	case csv.HG_ATTR_INIT_GAIN_RAND_POTION:
		for loopI := 0; loopI < config.Param; loopI++ {
			lenPotion := len(csv.TablePotionsMap)
			if lenPotion == 0 {
				break
			}
			allPotionIDs := make([]potion.Potion, lenPotion)
			localLoopI := 0
			for potionID := range csv.TablePotionsMap {
				allPotionIDs[localLoopI] = potion.Potion(potionID)
				localLoopI++
			}
			heroOne.AddPotion(allPotionIDs[rand.Intn(lenPotion)])
		}
		return nil
	case csv.HG_ATTR_BATTLE_SHOP_ITEM_PRICE:
		heroOne.ShopPriceSubPercent += uint32(config.Param)
		return nil
	case csv.HG_ATTR_POTION_SLOT_QUANTITY:
		heroOne.PotionsMaxNum += uint32(config.Param)
		return nil
	case csv.HG_ATTR_VISION_RANGE:
		heroOne.StageViewPlus += uint32(config.Param)
		return nil
	default:
		return fmt.Errorf("config HeroGrowingAttrMap error not exist enum %v", config)
	}
}
