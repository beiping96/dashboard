package hero

import (
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/csv"
	"shared/table"
)

// RandDropCards drop cards
func RandDropCards(cardWeightMap, cardUpgradeMap map[uint32]uint32, totalWeight, copies uint32) (cardResIds []uint32) {
	weight := int(totalWeight)
	for i := int32(0); i < int32(copies); i++ {
		if weight <= 0 {
			return
		}
		randWeight := rand.Intn(weight) + 1
		for cardTypeID, w := range cardWeightMap {
			if randWeight <= int(w) {
				conf, ok := table.GetTableCard(cardTypeID, 1)
				if !ok {
					log.Error().Msgf("card not found at table, card Type Id: %d, level: %d",
						cardTypeID, 1)
					continue
				}
				crd := uint32(conf.ID)
				randUpgrade := uint32(rand.Intn(100) + 1)
				if randUpgrade <= cardUpgradeMap[cardTypeID] {
					if conf2, ok := table.GetTableCard(cardTypeID, 2); ok {
						crd = uint32(conf2.ID)
					}
				}
				cardResIds = append(cardResIds, crd)
				weight -= int(w)
				delete(cardWeightMap, cardTypeID)
				break
			}
			randWeight -= int(w)
		}
	}
	return
}

// GetDropCards drop cards
func GetDropCards(h *InStage, stageDifficulty, stageLevel, dropFrom, copies uint32) (dropCardsResIds []uint32) {
	if h == nil {
		return
	}
	dropRelation, ok := table.GetDropRelation(stageDifficulty, stageLevel, dropFrom)
	if !ok {
		return
	}
	cardDropGroupID := dropRelation.CardGroup
	if cardDropGroupID == 0 {
		log.Debug().Msgf("drop card group id == 0")
		return
	}

	dropCardsResIds = GetDropCardsByGroupID(h, cardDropGroupID, copies)
	return
}

// GetDropCardsByGroupID drop card
func GetDropCardsByGroupID(h *InStage, cardDropGroupID uint32, copies uint32) (dropCardsResIds []uint32) {
	groupCardMap, ok := table.GetGroupCardsByGroupId(cardDropGroupID)
	if !ok {
		log.Error().Msgf("no drop card group. group id: %d", cardDropGroupID)
		return
	}
	cardWeightMap := make(map[uint32]uint32)
	cardUpgradeMap := make(map[uint32]uint32)
	totalWeight := 0

	for k, c := range groupCardMap {
		unlocked := h.CheckCardUnlocked(uint32(c.Card_Type_ID))
		if !unlocked {
			continue
		}
		count := h.CountFromAllCards(uint32(c.Card_Type_ID))
		newWeight := c.Weight + c.Weight_Revise*int(count)
		if newWeight <= 0 {
			continue
		}
		cardWeightMap[k] = uint32(newWeight)
		cardUpgradeMap[k] = uint32(c.Upgrade_Probability)
		totalWeight += newWeight
	}
	if totalWeight <= 0 {
		return
	}
	dropCardsResIds = RandDropCards(cardWeightMap, cardUpgradeMap, uint32(totalWeight), copies)
	return
}

// GetRelicDropGroupMap drop relic
func GetRelicDropGroupMap(h *InStage, stageDifficulty, stageLevel, dropFrom uint32) (relicDropGroupMap map[uint32]*csv.RelicDropGroup, canDrop bool) {
	relation, ok := table.GetDropRelation(stageDifficulty, stageLevel, dropFrom)
	if !ok {
		log.Error().Msgf("drop relation not found, difficulty: %d, stageLevel: %d, dropFrom: shop", stageDifficulty, stageLevel)
		return nil, false
	}
	relicGroupID := relation.RelicGroup
	if relicGroupID == 0 {
		log.Debug().Msgf("drop relic group id == 0")
		return nil, false
	}
	relicDropGroupMap, ok = table.GetGroupRelicsByGroupId(relicGroupID)
	if !ok {
		log.Error().Msgf("group relics not found, groupId: %d", relicGroupID)
		return nil, false
	}
	return relicDropGroupMap, true
}

// GetDropRelics drop relic
func GetDropRelics(h *InStage, relicDropGroupMap map[uint32]*csv.RelicDropGroup, num uint32) (relicIds []uint32) {
	totalWeight := 0
	for k, r := range relicDropGroupMap {
		_, exist := h.GetRelic(uint32(r.Relic_ID))
		if exist || r.Weight <= 0 {
			delete(relicDropGroupMap, k)
			continue
		}
		totalWeight += r.Weight
	}

	for i := 0; i < int(num); i++ {
		if totalWeight <= 0 {
			return
		}
		randWeight := rand.Intn(totalWeight) + 1
		for k, r := range relicDropGroupMap {
			if randWeight <= r.Weight {
				relicIds = append(relicIds, uint32(r.Relic_ID))
				totalWeight -= r.Weight
				delete(relicDropGroupMap, k)
				break
			}
			randWeight -= r.Weight
		}
	}
	return
}

// GetDropPotions drop potion
func GetDropPotions(h *InStage, difficulty, stageLevel, dropFrom, num uint32) (potionIds []uint32) {
	relation, ok := table.GetDropRelation(difficulty, stageLevel, dropFrom)
	if !ok {
		log.Error().Msgf("no drop relation, difficulty: %d, stageLevel: %d, from: %d", difficulty, stageLevel, dropFrom)
		return
	}
	potionGroupID := relation.PotionGroup
	if potionGroupID == 0 {
		log.Debug().Msgf("drop potion group id == 0")
		return
	}
	groupPotionMap, ok := table.GetGroupPotionsByGroupId(potionGroupID)
	if !ok {
		log.Error().Msgf("no drop potion group, group id: %d", potionGroupID)
		return
	}
	totalWeight := 0
	for k, p := range groupPotionMap {
		if p.Weight <= 0 {
			delete(groupPotionMap, k)
			continue
		}
		totalWeight += p.Weight
	}
	if totalWeight <= 0 {
		return
	}
	for i := 0; i < int(num); i++ {
		if totalWeight <= 0 {
			return
		}
		randWeight := rand.Intn(totalWeight) + 1
		for _, p := range groupPotionMap {
			if randWeight <= p.Weight {
				potionIds = append(potionIds, uint32(p.Potion_ID))
				break
			}
			randWeight -= p.Weight
		}
	}
	return
}
