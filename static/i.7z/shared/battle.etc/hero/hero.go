package hero

import (
	"errors"
	"fmt"
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/buff"
	"shared/battle.etc/card"
	"shared/battle.etc/potion"
	"shared/battle.etc/relic"
	"shared/battle.etc/stagePlayer"
	"shared/cardDef"
	"shared/csv"
	heroD "shared/heroDef"
	pb "shared/proto/client/battle"
	rds "shared/proto/server/battle"
	"shared/table"
)

// BeforeEventAttr save hero status before event trigger
type BeforeEventAttr struct {
	Hp       uint32
	HpLimit  uint32
	Relics   []relic.Relic
	AllCards []card.Card
	Potions  []potion.Potion
	Gold     uint32
}

// InStage struct - hero in stage
type InStage struct {
	heroD.Hero
	PlayerID                  uint64
	PlayerName                string
	LobbyID                   uint32
	HP                        uint32
	HPLimit                   uint32
	MPLimit                   uint32
	BuffGlobal                []buff.Buff
	Relics                    map[uint32]relic.Relic
	AllCards                  []card.Card
	CardPool                  map[cardDef.TypeID]cardDef.Card
	Potions                   []potion.Potion
	PotionsMaxNum             uint32
	Gold                      uint32
	SpeedGlobal               uint32
	Life                      uint32
	maxCardID                 uint32
	NodeID                    uint32
	FlagInBattle              bool
	FlagInEvent               bool
	AttrBeforeEvent           BeforeEventAttr
	FlagQuit                  bool
	DiscardTimes              uint32
	NonRepeatingEvents        map[uint32]bool
	CurEventID                uint32
	CurProcess                uint32
	MonsterDropGoldAddPercent uint32
	RestRecoverHpAdd          uint32
	ShopPriceSubPercent       uint32
	StageViewPlus             uint32
	ResurgenceHP              uint32
	ResurgencePotions         []potion.Potion
	FinishNode                uint32
	EnemyNum                  uint32
	EliteNum                  uint32
	BossNum                   uint32
	RecoverOption             []uint32
	RecoverPlusMorePower      bool
	RecoverPlusMoreMPAndCard  bool
}

// NewHeroInStage create a new hero in stage, copy attr from playerState
func NewHeroInStage(player *stagePlayer.StagePlayer, myHero heroD.Hero, stageDifficulty uint32, stageLevel uint32) (InStage, error) {
	var buffGlobal []buff.Buff
	var potions []potion.Potion
	typeID := myHero.GetTypeID()
	tableHeroInitVal, _ := csv.TableCareerInitialValueMap[int64(typeID)]

	hero := InStage{
		Hero:                      myHero,
		PlayerID:                  player.PlayerID,
		PlayerName:                player.PlayerName,
		LobbyID:                   player.LobbyID,
		HP:                        uint32(tableHeroInitVal.InitMaxBlood),
		HPLimit:                   uint32(tableHeroInitVal.InitMaxBlood),
		MPLimit:                   uint32(tableHeroInitVal.InitPower),
		BuffGlobal:                buffGlobal,
		Relics:                    make(map[uint32]relic.Relic),
		Potions:                   potions,
		PotionsMaxNum:             3,
		Gold:                      uint32(tableHeroInitVal.InitGold),
		SpeedGlobal:               uint32(tableHeroInitVal.InitSpeed),
		Life:                      3,
		maxCardID:                 0,
		DiscardTimes:              0,
		NonRepeatingEvents:        make(map[uint32]bool),
		CurEventID:                0,
		CurProcess:                0,
		MonsterDropGoldAddPercent: 0,
		RestRecoverHpAdd:          0,
		ShopPriceSubPercent:       0,
		StageViewPlus:             0,
		FinishNode:                0,
		EnemyNum:                  0,
		EliteNum:                  0,
		BossNum:                   0,
	}

	initCards := hero.Hero.GetInitCards()
	playerCards := player.AllCards
	for _, v := range initCards {
		c, ok := playerCards[v]
		if !ok {
			log.Error().Msgf("new hero in stage error, hero init cards TypeID:%v not in player cardsPool",
				v)
			continue
		}
		_, err := hero.AddOneCard(uint32(v), c.GetCardStarLevel(), 1)
		if err != nil {
			log.Error().Msgf("new hero in stage error, Create card error %v", err)
		}
	}
	log.Debug().Msgf("init hero card pool, player cards: %v", playerCards)
	hero.CardPool = make(map[cardDef.TypeID]cardDef.Card)
	for typeID, c := range playerCards {
		tableCard, ok := table.GetTableCard(uint32(typeID), 1)
		if !ok {
			return InStage{}, fmt.Errorf("card: %d not found at table", typeID)
		}
		if ok && (tableCard.Career == tableHeroInitVal.Career && (tableCard.Hero == 0 || uint32(tableCard.Hero) == hero.GetTypeID()) ||
			tableCard.Career == csv.CAREER_NONE) {
			hero.CardPool[c.GetTypeID()] = c
		}
	}
	log.Debug().Msgf("Create hero cards:%v", hero.AllCards)
	// add heroAttr
	err := hero.countAttr(player.AllHeroAttrIDs)
	if err != nil {
		log.Error().Msgf("hero: countAttr error:%v hero:%v globalAttrIDs:%v",
			err, hero, player.AllHeroAttrIDs)
		return hero, err
	}
	// Finally add relic
	_, err = hero.AddRelic(uint32(tableHeroInitVal.InitRelic), stageDifficulty, stageLevel)
	if err != nil {
		log.Error().Msgf("hero: initRelic error :%v", err)
	}
	log.Debug().Msgf("debug new heroInStage, initRelic : %v heroInStage : %v",
		tableHeroInitVal.InitRelic, hero)
	return hero, nil
}

// ChangeResID called after stage change res ID
func (heroOne InStage) ChangeResID() InStage {
	heroOne.NodeID = 0
	heroOne.HP = heroOne.HPLimit
	if heroOne.FlagInBattle || heroOne.FlagInEvent {
		log.Error().Msgf("Debug flag in battle after boss !!!! %v", heroOne)
	}
	return heroOne
}

// ToClientProto convert Hero to StageHero
func (heroOne InStage) ToClientProto() *pb.StageHero {
	ans := pb.StageHero{}
	uid, typeID := heroOne.GetUID(), heroOne.GetTypeID()
	ans.HeroUid = &uid
	ans.HeroTypeId = &typeID
	ans.OwnerPlayerId = &heroOne.PlayerID
	ans.OwnerPlayerName = &heroOne.PlayerName
	return &ans
}

// ToClientProtoInfo convert Hero to StageHeroInfo
func (heroOne InStage) ToClientProtoInfo() *pb.StageHeroInfo {
	ans := pb.StageHeroInfo{}
	uid, typeID := heroOne.GetUID(), heroOne.GetTypeID()
	ans.HeroUid = &uid
	ans.HeroTypeId = &typeID
	ans.OwnerPlayerId = &heroOne.PlayerID
	ans.Hp = &heroOne.HP
	ans.HpLimit = &heroOne.HPLimit
	for _, r := range heroOne.Relics {
		ans.Relics = append(ans.Relics, r.ToClientProto())
	}
	log.Debug().Msgf("--------relic to client proto: %+v", ans.Relics)
	for _, c := range heroOne.AllCards {
		ans.Cards = append(ans.Cards, c.ToClientProto())
	}
	for _, p := range heroOne.Potions {
		ans.Potions = append(ans.Potions, p.ToClientProto())
	}
	ans.Gold = &heroOne.Gold
	ans.Life = &heroOne.Life
	ans.RecoverOption = heroOne.RecoverOption
	return &ans
}

// ToRdsStageHero convert Hero to RdsStageHero
func (heroOne *InStage) ToRdsStageHero() *rds.RdsStageHero {
	rdsHeroBase := heroOne.Hero.ToRdsProto()
	rdsBuffs := make([]*rds.RdsBuff, len(heroOne.BuffGlobal))
	for i, bf := range heroOne.BuffGlobal {
		rdsBuffs[i] = bf.ToRdsProto()
	}
	var rdsRelics []*rds.RdsRelic
	for _, rlc := range heroOne.Relics {
		rdsRelics = append(rdsRelics, rlc.ToRdsRelicProto())
	}
	rdsCards := make([]*rds.RdsCard, len(heroOne.AllCards))
	for i, c := range heroOne.AllCards {
		rdsCards[i] = c.ToRdsCardProto()
	}
	rdsPotions := make([]uint32, len(heroOne.Potions))
	for i, p := range heroOne.Potions {
		rdsPotions[i] = p.ToClientProto()
	}
	rdsCardPool := make([]*rds.RdsStarCard, len(heroOne.CardPool))
	i := 0
	for _, c := range heroOne.CardPool {
		rdsCardPool[i] = c.ToRdsProto()
		i++
	}
	nonRepeatingEvents := make([]uint32, len(heroOne.NonRepeatingEvents))
	i = 0
	for eventID := range heroOne.NonRepeatingEvents {
		nonRepeatingEvents[i] = eventID
		i++
	}
	attrPotions := make([]uint32, len(heroOne.AttrBeforeEvent.Potions))
	for i, p := range heroOne.AttrBeforeEvent.Potions {
		attrPotions[i] = uint32(p)
	}
	attrCards := make([]*rds.RdsCard, len(heroOne.AttrBeforeEvent.AllCards))
	for i, c := range heroOne.AttrBeforeEvent.AllCards {
		attrCards[i] = c.ToRdsCardProto()
	}
	attrRelics := make([]*rds.RdsRelic, len(heroOne.AttrBeforeEvent.Relics))
	for i, r := range heroOne.AttrBeforeEvent.Relics {
		attrRelics[i] = r.ToRdsRelicProto()
	}
	beforeEventAttr := &rds.RdsBeforeEventAttr{
		Gold:    heroOne.AttrBeforeEvent.Gold,
		Hp:      heroOne.AttrBeforeEvent.Hp,
		HpLimit: heroOne.AttrBeforeEvent.HpLimit,
		Potions: attrPotions,
		Cards:   attrCards,
		Relics:  attrRelics,
	}
	rdsResurgencePotions := make([]uint32, len(heroOne.ResurgencePotions))
	for i, p := range heroOne.ResurgencePotions {
		rdsResurgencePotions[i] = p.ToClientProto()
	}
	return &rds.RdsStageHero{
		Hero:                      rdsHeroBase,
		PlayerID:                  heroOne.PlayerID,
		PlayerName:                heroOne.PlayerName,
		LobbyID:                   heroOne.LobbyID,
		Hp:                        heroOne.HP,
		HpLimit:                   heroOne.HPLimit,
		MpLimit:                   heroOne.MPLimit,
		BuffGlobal:                rdsBuffs,
		Relics:                    rdsRelics,
		AllCards:                  rdsCards,
		Potions:                   rdsPotions,
		PotionsMaxNum:             heroOne.PotionsMaxNum,
		Gold:                      heroOne.Gold,
		SpeedGlobal:               heroOne.SpeedGlobal,
		Life:                      heroOne.Life,
		MaxCardId:                 heroOne.maxCardID,
		FlagInBattle:              heroOne.FlagInBattle,
		CardPool:                  rdsCardPool,
		NodeId:                    heroOne.NodeID,
		FlagQuit:                  heroOne.FlagQuit,
		DiscardTimes:              heroOne.DiscardTimes,
		CurEventId:                heroOne.CurEventID,
		CurEventEffectProcess:     heroOne.CurProcess,
		NonRepeatingEvents:        nonRepeatingEvents,
		MonsterDropGoldAddPercent: heroOne.MonsterDropGoldAddPercent,
		RestRecoverHpAdd:          heroOne.RestRecoverHpAdd,
		ShopPriceSubPercent:       heroOne.ShopPriceSubPercent,
		StageViewPlus:             heroOne.StageViewPlus,
		AttrBeforeEvent:           beforeEventAttr,
		FlagInEvent:               heroOne.FlagInEvent,
		ResurgenceHp:              heroOne.ResurgenceHP,
		ResurgencePotions:         rdsResurgencePotions,
		FinishNode:                heroOne.FinishNode,
		EnemyNum:                  heroOne.EnemyNum,
		EliteNum:                  heroOne.EliteNum,
		BossNum:                   heroOne.BossNum,
		RecoverOption:             heroOne.RecoverOption,
		RecoverPlusMorePower:      heroOne.RecoverPlusMorePower,
		RecoverPlusMoreMpAndCard:  heroOne.RecoverPlusMoreMPAndCard,
	}
}

// FromRdsProto convert Hero from RdsStageHero
func FromRdsProto(rsh *rds.RdsStageHero) InStage {
	heroBase := heroD.FromRdsProto(rsh.Hero)
	bfs := make([]buff.Buff, len(rsh.BuffGlobal))
	for i, bf := range rsh.BuffGlobal {
		bfs[i] = buff.FromRdsProto(bf)
	}
	rls := make(map[uint32]relic.Relic, len(rsh.Relics))
	for _, r := range rsh.Relics {
		rls[r.TypeID] = relic.FromRdsRelicProto(r)
	}
	cards := make([]card.Card, len(rsh.AllCards))
	for i, c := range rsh.AllCards {
		cards[i] = card.FromRdsCardProto(c)
	}
	potions := make([]potion.Potion, len(rsh.Potions))
	for i, p := range rsh.Potions {
		potions[i] = potion.Potion(p)
	}
	cardPool := make(map[cardDef.TypeID]cardDef.Card, len(rsh.CardPool))
	for _, c := range rsh.CardPool {
		starCard := cardDef.FromRdsProto(c)
		cardPool[starCard.GetTypeID()] = starCard
	}
	nonRepeatingEvents := make(map[uint32]bool)
	for _, eventID := range rsh.NonRepeatingEvents {
		nonRepeatingEvents[eventID] = true
	}
	var beforeEventAttr BeforeEventAttr
	if rsh.AttrBeforeEvent != nil {
		attrPotions := make([]potion.Potion, len(rsh.AttrBeforeEvent.Potions))
		for i, p := range rsh.AttrBeforeEvent.Potions {
			attrPotions[i] = potion.Potion(p)
		}
		attrCards := make([]card.Card, len(rsh.AttrBeforeEvent.Cards))
		for i, c := range rsh.AttrBeforeEvent.Cards {
			attrCards[i] = card.FromRdsCardProto(c)
		}
		attrRelics := make([]relic.Relic, len(rsh.AttrBeforeEvent.Relics))
		for i, r := range rsh.AttrBeforeEvent.Relics {
			attrRelics[i] = relic.FromRdsRelicProto(r)
		}
		beforeEventAttr = BeforeEventAttr{
			Gold:     rsh.AttrBeforeEvent.Gold,
			Hp:       rsh.AttrBeforeEvent.Hp,
			HpLimit:  rsh.AttrBeforeEvent.HpLimit,
			Potions:  attrPotions,
			AllCards: attrCards,
			Relics:   attrRelics,
		}
	}
	resurgencePotions := make([]potion.Potion, len(rsh.GetResurgencePotions()))
	for i, p := range rsh.GetResurgencePotions() {
		resurgencePotions[i] = potion.Potion(p)
	}
	return InStage{
		Hero:                      heroBase,
		PlayerID:                  rsh.PlayerID,
		PlayerName:                rsh.PlayerName,
		LobbyID:                   rsh.LobbyID,
		HP:                        rsh.Hp,
		HPLimit:                   rsh.HpLimit,
		MPLimit:                   rsh.MpLimit,
		BuffGlobal:                bfs,
		Relics:                    rls,
		AllCards:                  cards,
		Potions:                   potions,
		PotionsMaxNum:             rsh.PotionsMaxNum,
		Gold:                      rsh.Gold,
		SpeedGlobal:               rsh.SpeedGlobal,
		Life:                      rsh.Life,
		maxCardID:                 rsh.MaxCardId,
		FlagInBattle:              rsh.FlagInBattle,
		CardPool:                  cardPool,
		NodeID:                    rsh.NodeId,
		FlagQuit:                  rsh.FlagQuit,
		DiscardTimes:              rsh.DiscardTimes,
		CurEventID:                rsh.CurEventId,
		CurProcess:                rsh.CurEventEffectProcess,
		NonRepeatingEvents:        nonRepeatingEvents,
		MonsterDropGoldAddPercent: rsh.GetMonsterDropGoldAddPercent(),
		RestRecoverHpAdd:          rsh.GetRestRecoverHpAdd(),
		ShopPriceSubPercent:       rsh.GetShopPriceSubPercent(),
		StageViewPlus:             rsh.GetStageViewPlus(),
		AttrBeforeEvent:           beforeEventAttr,
		FlagInEvent:               rsh.FlagInEvent,
		ResurgenceHP:              rsh.GetResurgenceHp(),
		FinishNode:                rsh.GetFinishNode(),
		EnemyNum:                  rsh.GetEnemyNum(),
		EliteNum:                  rsh.GetEliteNum(),
		BossNum:                   rsh.GetBossNum(),
		RecoverOption:             rsh.GetRecoverOption(),
		RecoverPlusMorePower:      rsh.GetRecoverPlusMorePower(),
		RecoverPlusMoreMPAndCard:  rsh.GetRecoverPlusMoreMpAndCard(),
		ResurgencePotions:         resurgencePotions,
	}
}

// String - achieve String interface
func (heroOne InStage) String() string {
	s := "Hero Struct:"
	s += fmt.Sprintf(" ID: %v", heroOne.GetUID())
	s += fmt.Sprintf(" typeID: %v", heroOne.GetTypeID())
	s += fmt.Sprintf(" PlayerID: %v", heroOne.PlayerID)
	s += fmt.Sprintf(" hp %v", heroOne.HP)
	s += fmt.Sprintf(" recoverOption %v", heroOne.RecoverOption)
	return s
}

// AddOneCard add one card in Hero.AllCards
func (heroOne *InStage) AddOneCard(cardTypeID uint32, starLevel uint32, cardLevel uint32) (card.Card, error) {
	cardOne, err := card.New(heroOne.GenerateCardID(), cardTypeID, starLevel, cardLevel)
	if err != nil {
		return cardOne, err
	}
	return cardOne, heroOne.AddOneCardStruct(cardOne)
}

// GenerateCardID generate cardID in heroInStage
func (heroOne *InStage) GenerateCardID() uint32 {
	heroOne.maxCardID++
	return heroOne.maxCardID
}

// AddOneCardStruct add one card struct into Hero.AllCards
func (heroOne *InStage) AddOneCardStruct(c card.Card) error {
	for _, v := range heroOne.AllCards {
		if v.ID == c.ID {
			return errors.New("Battle create card error: repeat cardUID")
		}
	}
	heroOne.AllCards = append(heroOne.AllCards, c)
	return nil
}

// RemoveOneCard remove one card in Hero.AllCards
func (heroOne *InStage) RemoveOneCard(cardID uint32) (removedCard card.Card, err error) {
	var findCard bool
	var cardIndex int
	for index, v := range heroOne.AllCards {
		if v.ID == cardID {
			findCard = true
			cardIndex = index
			removedCard = heroOne.AllCards[cardIndex]
			break
		}
	}
	if !findCard {
		err = errors.New("Battle create card error: unFind cardUID")
		return
	}
	heroOne.AllCards = append(heroOne.AllCards[:cardIndex], heroOne.AllCards[cardIndex+1:]...)
	return
}

// GetRelic - get relic in heroInStage param
func (heroOne *InStage) GetRelic(relicTypeID uint32) (param uint32, ok bool) {
	relic := heroOne.Relics[relicTypeID]
	param = relic.Param
	ok = relic.IsExist
	return
}

// AddRelic add one relic in Hero.Relics
func (heroOne *InStage) AddRelic(relicTypeID uint32, stageDifficulty uint32, stageLevel uint32) (*pb.BattleRelicInStage, error) {
	relicOne, err := relic.New(relicTypeID)
	if err != nil {
		return nil, err
	}
	relicOne.IsExist = true
	if heroOne.Relics[relicTypeID].IsExist {
		return nil, fmt.Errorf("Battle create relic error: repeat relicTypeID:%v", relicTypeID)
	}
	heroOne.Relics[relicTypeID] = relicOne
	return heroOne.countAfterAddRelic(relicTypeID, stageDifficulty, stageLevel), nil
}

func (heroOne *InStage) countAfterAddRelic(relicTypeID uint32, stageDifficulty uint32, stageLevel uint32) *pb.BattleRelicInStage {
	param1, param2, _, _ := relic.GetRelicBasic(relicTypeID)
	relicInStage := pb.BattleRelicInStage{}
	relicInStage.RelicTypeId = &relicTypeID
	switch relicTypeID {
	case relic.MpLimitAndMoreCardsBeforeBattle, relic.MpLimitAndUnShowAI, relic.MpLimitAndEnemyPower, relic.MpLimitAndNoGold, relic.MpLimitAndNoPotion, relic.MpLimitAndRandomCurseWhenOpenTreasure:
		attrChange := pb.BattleRelicInStageChange{}
		oldValue := heroOne.MPLimit
		attrChange.OldValue = &oldValue
		heroOne.MPLimit += uint32(param1)
		attrChange.NewValue = &heroOne.MPLimit
		relicInStage.MpLimitChange = &attrChange
		return &relicInStage
	case relic.RandomCardLvUp:
		var canLevelUpCardIndex []uint32
		for i, c := range heroOne.AllCards {
			if c.Level < c.MaxLevel && c.Type == card.Type(param2) {
				canLevelUpCardIndex = append(canLevelUpCardIndex, uint32(i))
			}
		}
		for i := 0; i < param1; i++ {
			if len(canLevelUpCardIndex) == 0 {
				continue
			}
			r := rand.Intn(len(canLevelUpCardIndex))
			allCardsIndex := canLevelUpCardIndex[r]
			oldCard := heroOne.AllCards[allCardsIndex]
			newCard, err := oldCard.LevelUp()
			if err != nil {
				log.Error().Msgf("randomCardLvUp: card cannot level up: %v", oldCard)
				continue
			}
			heroOne.AllCards[allCardsIndex] = newCard
			levelUp := pb.BattleRelicInStageCardLvUp{}
			levelUp.OldCard = oldCard.ToClientProto()
			levelUp.NewCard = newCard.ToClientProto()
			relicInStage.CardLvUp = append(relicInStage.CardLvUp, &levelUp)
			canLevelUpCardIndex = append(canLevelUpCardIndex[:r], canLevelUpCardIndex[r+1:]...)
		}
		return &relicInStage
	case relic.GetGold:
		attrChange := pb.BattleRelicInStageChange{}
		oldValue := heroOne.Gold
		attrChange.OldValue = &oldValue
		heroOne.Gold += uint32(param1)
		attrChange.NewValue = &heroOne.Gold
		relicInStage.GoldChange = &attrChange
		return &relicInStage
	case relic.HpLimit1, relic.HpLimit2, relic.HpLimit3, relic.HpLimitAndCurse:
		attrChange := pb.BattleRelicInStageChange{}
		oldValue := heroOne.HPLimit
		attrChange.OldValue = &oldValue
		heroOne.HP += uint32(param1)
		heroOne.HPLimit += uint32(param1)
		attrChange.NewValue = &heroOne.HPLimit
		relicInStage.HpLimitChange = &attrChange
		if relicTypeID == relic.HpLimitAndCurse {
			ids := table.GetAllCurseCardResIds()
			for i := 0; i < param2; i++ {
				r := rand.Intn(len(ids))
				cardConf, _ := csv.TableCardsMap[int64(ids[r])]
				c, err := heroOne.AddOneCard(uint32(cardConf.CardGroupID), 1, 1)
				if err != nil {
					log.Error().Msgf("relic hpLimitAndCurse failed, %s", err.Error())
					continue
				}
				gotCard := c.ToClientProto()
				relicInStage.GotCard = append(relicInStage.GotCard, gotCard)
			}
		}
		return &relicInStage
	case relic.SelectPowerCardBeforeBattle:
		for _, cardOne := range heroOne.AllCards {
			if cardOne.Type != card.Power {
				continue
			}
			relicInStage.ChooseCard = append(relicInStage.ChooseCard, cardOne.ToClientProto())
		}
		return &relicInStage
	case relic.SelectAttackCardBeforeBattle:
		for _, cardOne := range heroOne.AllCards {
			if cardOne.Type != card.Attack {
				continue
			}
			relicInStage.ChooseCard = append(relicInStage.ChooseCard, cardOne.ToClientProto())
		}
		return &relicInStage
	case relic.SelectSkillCardBeforeBattle:
		for _, cardOne := range heroOne.AllCards {
			if cardOne.Type != card.Skill {
				continue
			}
			relicInStage.ChooseCard = append(relicInStage.ChooseCard, cardOne.ToClientProto())
		}
		return &relicInStage
	case relic.SelectPotions:
		num := param1
		allPotion := table.GetAllPotionIds()
		relicUpdate := heroOne.Relics[relic.SelectPotions]
		for i := 0; i < num; i++ {
			if len(allPotion) <= 0 {
				continue
			}
			potionID := allPotion[rand.Intn(len(allPotion))]
			relicInStage.ChoosePotion = append(relicInStage.ChoosePotion, potionID)
			relicUpdate.SelectPotion = append(relicUpdate.SelectPotion, potion.Potion(potionID))
		}
		heroOne.Relics[relic.SelectPotions] = relicUpdate
		return &relicInStage
	case relic.SelectCards:
		num := uint32(param1)
		relicUpdate := heroOne.Relics[relic.SelectCards]
		for _, cardResID := range GetDropCards(heroOne, stageDifficulty, stageLevel, csv.DROP_FROM_ENEMY, num) {
			cardConfig, ok := csv.TableCardsMap[int64(cardResID)]
			if !ok {
				log.Error().Msgf("drop error cardResID:%v not exist in config", cardResID)
				continue
			}
			cardTypeID := uint32(cardConfig.CardGroupID)
			cardLevel := uint32(cardConfig.Level)
			cardStar := uint32(1)
			if c, ok := heroOne.CardPool[cardDef.TypeID(cardTypeID)]; ok {
				cardStar = c.GetCardStarLevel()
			}
			cardNew, err := card.New(heroOne.GenerateCardID(), cardTypeID, cardStar, cardLevel)
			if err != nil {
				continue
			}
			relicInStage.ChooseCard = append(relicInStage.ChooseCard, cardNew.ToClientProto())
			relicUpdate.SelectCard = append(relicUpdate.SelectCard, cardNew)
		}
		heroOne.Relics[relic.SelectCards] = relicUpdate
		return &relicInStage
	default:
		return nil
	}
}

// RecordHeroAttrBeforeEvent for event trigger
func (heroOne *InStage) RecordHeroAttrBeforeEvent() {
	var relics = make([]relic.Relic, len(heroOne.Relics))
	i := 0
	for _, r := range heroOne.Relics {
		relics[i] = relic.FromRdsRelicProto(r.ToRdsRelicProto())
		i++
	}
	var allCards = make([]card.Card, len(heroOne.AllCards))
	for i, c := range heroOne.AllCards {
		allCards[i] = card.FromRdsCardProto(c.ToRdsCardProto())
	}
	var potions = make([]potion.Potion, len(heroOne.Potions))
	for i, p := range heroOne.Potions {
		potions[i] = p
	}
	heroOne.AttrBeforeEvent = BeforeEventAttr{
		Hp:       heroOne.HP,
		HpLimit:  heroOne.HPLimit,
		Relics:   relics,
		AllCards: allCards,
		Potions:  potions,
		Gold:     heroOne.Gold,
	}
}

// ResetFromBeforeEventAttr  for event trigger
func (heroOne *InStage) ResetFromBeforeEventAttr() {
	heroOne.Gold = heroOne.AttrBeforeEvent.Gold
	heroOne.HP = heroOne.AttrBeforeEvent.Hp
	heroOne.HPLimit = heroOne.AttrBeforeEvent.HpLimit
	heroOne.Relics = make(map[uint32]relic.Relic)
	for _, r := range heroOne.AttrBeforeEvent.Relics {
		heroOne.Relics[r.TypeID] = relic.FromRdsRelicProto(r.ToRdsRelicProto())
	}
	heroOne.AllCards = make([]card.Card, len(heroOne.AttrBeforeEvent.AllCards))
	for i, c := range heroOne.AttrBeforeEvent.AllCards {
		heroOne.AllCards[i] = card.FromRdsCardProto(c.ToRdsCardProto())
	}
	heroOne.Potions = make([]potion.Potion, len(heroOne.AttrBeforeEvent.Potions))
	for i, p := range heroOne.AttrBeforeEvent.Potions {
		heroOne.Potions[i] = p
	}
}

// AddPotion add one Potion in Hero.Potions
func (heroOne *InStage) AddPotion(potionOne potion.Potion) error {
	if uint32(len(heroOne.Potions)) >= heroOne.PotionsMaxNum {
		return errors.New("Battle create potion error: out of max potion count")
	}
	heroOne.Potions = append(heroOne.Potions, potionOne)
	return nil
}

// CountFromAllCards count all cards num
func (heroOne *InStage) CountFromAllCards(typeID uint32) (count int32) {
	count = 0
	for _, c := range heroOne.AllCards {
		if c.TypeID == typeID {
			count++
		}
	}
	return
}

// CheckCardUnlocked as name
func (heroOne *InStage) CheckCardUnlocked(typeID uint32) bool {
	_, ok := heroOne.CardPool[cardDef.TypeID(typeID)]
	return ok
}

// GetCard as name
func (heroOne *InStage) GetCard(cardID uint32) (c card.Card, ok bool) {
	for _, crd := range heroOne.AllCards {
		if crd.ID == cardID {
			return crd, true
		}
	}
	return
}

// GetAllTypeIDCards get same typeID cards
func (heroOne *InStage) GetAllTypeIDCards(typeID uint32) []card.Card {
	var cards []card.Card
	for _, c := range heroOne.AllCards {
		if c.TypeID == typeID {
			cards = append(cards, c)
		}
	}
	return cards
}

// GetAllTypeCards get same type cards
func (heroOne *InStage) GetAllTypeCards(cardType uint32) []card.Card {
	var cards []card.Card
	for _, c := range heroOne.AllCards {
		if c.Type == card.Type(cardType) {
			cards = append(cards, c)
		}
	}
	return cards
}

// LevelUpOneCard heroInStage cards lv-up
func (heroOne *InStage) LevelUpOneCard(cardID uint32) (newCard card.Card, err error) {
	cardIndex := -1
	for i, c := range heroOne.AllCards {
		if c.ID == cardID {
			cardIndex = i
			break
		}
	}
	if cardIndex >= 0 {
		//oldCard := &heroOne.AllCards[cardIndex]
		newCard, err = heroOne.AllCards[cardIndex].LevelUp()
		if err != nil {
			return
		}
		heroOne.AllCards[cardIndex] = newCard
	} else {
		err = fmt.Errorf("card not found, cardID: %d", cardID)
	}
	return
}

// ChangeHeroEventFlag for event
func (heroOne *InStage) ChangeHeroEventFlag(flag bool) {
	heroOne.FlagInEvent = flag
	if flag == false {
		heroOne.CurProcess = 0
	}
}

// ChangeHeroHP heroInStage hp change
func (heroOne *InStage) ChangeHeroHP(deltaHP int32) {
	newHp := int32(heroOne.HP) + deltaHP
	if newHp < 0 {
		newHp = 0
	} else if newHp > int32(heroOne.HPLimit) {
		newHp = int32(heroOne.HPLimit)
	}
	heroOne.HP = uint32(newHp)
}

// ChangeHeroHpLimit heroInStage hpLimit change
func (heroOne *InStage) ChangeHeroHpLimit(deltaHpLimit int32) (hpChange int32, hpLimitChange int32) {
	oldHpLimit := heroOne.HPLimit
	oldHp := heroOne.HP

	newHpLimit := int32(heroOne.HPLimit) + deltaHpLimit
	if newHpLimit <= 0 {
		heroOne.HPLimit = 0
		heroOne.HP = 0
		hpChange = int32(oldHp)
		hpLimitChange = int32(oldHpLimit)
		return
	}

	heroOne.HPLimit = uint32(newHpLimit)
	if deltaHpLimit > 0 {
		heroOne.HP += uint32(deltaHpLimit)
	} else if heroOne.HP > uint32(newHpLimit) {
		heroOne.HP = uint32(newHpLimit)
	}
	newHpLimitResult := heroOne.HPLimit
	newHp := heroOne.HP

	hpChange = int32(newHp) - int32(oldHp)
	hpLimitChange = int32(newHpLimitResult) - int32(oldHpLimit)
	return
}

// ChangeHeroGold heroInStage gold change
func (heroOne *InStage) ChangeHeroGold(deltaGold int32) {
	newGold := int32(heroOne.Gold) + deltaGold
	if newGold <= 0 {
		heroOne.Gold = 0
	} else {
		heroOne.Gold = uint32(newGold)
	}
}

// AddSpecifiedIDCardN heroInStage add specified card
func (heroOne *InStage) AddSpecifiedIDCardN(cardResID uint32, num uint32) (newCards []card.Card, err error) {
	cardConf, ok := csv.TableCardsMap[int64(cardResID)]
	if !ok {
		err = fmt.Errorf("cardResId: %d not exist at card config", cardResID)
		return
	}
	cardTypeID := uint32(cardConf.CardGroupID)
	starLevel := uint32(1)
	cp, ok := heroOne.CardPool[cardDef.TypeID(cardTypeID)]
	if ok {
		starLevel = cp.GetCardStarLevel()
	}
	for i := 0; i < int(num); i++ {
		var c card.Card
		c, err = heroOne.AddOneCard(cardTypeID, starLevel, uint32(cardConf.Level))
		if err != nil {
			return
		}

		newCards = append(newCards, c)
	}
	return
}

// RemoveSpecifiedRelic relic remove
func (heroOne *InStage) RemoveSpecifiedRelic(relicID uint32) {
	delete(heroOne.Relics, relicID)
}

// AddRandomPotionN random potions
func (heroOne *InStage) AddRandomPotionN(num uint32) (potions []uint32) {
	allPotionIds := table.GetAllPotionIds()
	if len(allPotionIds) <= 0 {
		return
	}
	for i := 0; i < int(num); i++ {
		if len(heroOne.Potions) >= int(heroOne.PotionsMaxNum) {
			log.Debug().Msgf("cannot add potion for potion is full, len(h.potions): %d, h.potionsMaxNum: %d",
				len(heroOne.Potions), heroOne.PotionsMaxNum)
			return
		}
		randIndex := rand.Intn(len(allPotionIds))
		potionID := allPotionIds[randIndex]
		heroOne.Potions = append(heroOne.Potions, potion.Potion(potionID))
		potions = append(potions, potionID)
	}
	return
}
