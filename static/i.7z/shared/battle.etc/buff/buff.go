package buff

import (
	"github.com/rs/zerolog/log"
	"shared/csv"
	pb "shared/proto/client/battle"
	rds "shared/proto/server/battle"
)

const (
	// Angry - 愤怒
	Angry uint32 = 103
	// Burn - 燃烧
	Burn uint32 = 104
	// Electricity - 感电
	Electricity uint32 = 105
	// Frozen - 冰冻
	Frozen uint32 = 106
	// AttackPowerless - 虚弱
	AttackPowerless uint32 = 107
	// EasyToHurt - 易伤
	EasyToHurt uint32 = 108
	// BlockLess - 脆弱
	BlockLess uint32 = 109
	// Reflect - 荆棘
	Reflect uint32 = 110
	// BlockAfterAttack - 浴血
	BlockAfterAttack uint32 = 111
	// AngryAfterAttack - 狂怒
	AngryAfterAttack uint32 = 112
	// MoreCardsAfterBadCard - 免疫机能
	MoreCardsAfterBadCard uint32 = 113
	// KeepBlock - 硬化皮肤
	KeepBlock uint32 = 114
	// AngryControl - 愤怒控制 - 减1点
	AngryControl uint32 = 115
	// AngryControlPlus - 愤怒控制 - 不减
	AngryControlPlus uint32 = 116
	// TwiceAttack - 双重打击
	TwiceAttack uint32 = 117
	// AutoBlock - 自动护甲
	AutoBlock uint32 = 118
	// AngryAfterBeAttacked - 复仇
	AngryAfterBeAttacked uint32 = 119
	// AngryBeforeRound - 战吼
	AngryBeforeRound uint32 = 120
	// BurnAllBeforeRound - 火焰斗篷
	BurnAllBeforeRound uint32 = 121
	// BurnAfterBurn - 深度烧伤
	BurnAfterBurn uint32 = 122
	// KeepMP - 电能护甲
	KeepMP uint32 = 123
	// ElectricityAllBeforeRound - 静电放射
	ElectricityAllBeforeRound uint32 = 124
	// AttackAfterElectricity - 雷神之力
	AttackAfterElectricity uint32 = 125
	// BlockAbsolutely - 寒冰屏障
	BlockAbsolutely uint32 = 126
	// AttackAfterFrozen - 冻骨极寒
	AttackAfterFrozen uint32 = 127
	// FrozenAllBeforeRound - 冰霜领域
	FrozenAllBeforeRound uint32 = 128
	// TwiceSkill - 双重施法
	TwiceSkill uint32 = 129
	// MoreCardsBeforeRound - 急速吟唱
	MoreCardsBeforeRound uint32 = 130
	// RecoverHpAfterRound - 再生
	RecoverHpAfterRound uint32 = 131
	// PowerfulAfterBeHurt - 激怒
	PowerfulAfterBeHurt uint32 = 132
	// PowerfulAfterRound - 进化
	PowerfulAfterRound uint32 = 133
	// BlockAfterFirstBeHurt - 硬质甲壳
	BlockAfterFirstBeHurt uint32 = 134
	// BlockAfterRoundFirstBeHurt - 再生甲壳
	BlockAfterRoundFirstBeHurt uint32 = 135

	// BlockPlusAfterBeHurt - 适应甲壳
	BlockPlusAfterBeHurt uint32 = 136

	// BlockAfterRound - 多层甲壳
	BlockAfterRound uint32 = 137
	// PowerfulAfterSkillCard - 能量汲取
	PowerfulAfterSkillCard uint32 = 138
	// CardToDisAfterSkillAndPowerCard - 邪能诅咒
	CardToDisAfterSkillAndPowerCard uint32 = 139
	// CardToDrawAfterSkillAndPowerCard - 深渊诅咒
	CardToDrawAfterSkillAndPowerCard uint32 = 140
	// HandCardCostChange - 手牌费用变更
	HandCardCostChange uint32 = 141
	// TurnReflect - 火焰屏障
	TurnReflect uint32 = 142
	// ResistDeBuff - 魔法屏障
	ResistDeBuff uint32 = 143
)

// Buff struct - describe one buff status
type Buff struct {
	TypeID uint32
	Param  uint32
}

// GetBasic - get config number
func GetBasic(buffTypeID uint32) int {
	configBuff, ok := csv.BuffMap[int64(buffTypeID)]
	if !ok {
		log.Error().Msgf("buff config error %v not exist", buffTypeID)
		return 0
	}
	return configBuff.Basic
}

// GetBuffType get buff config type
func GetBuffType(buffTypeID uint32) int {
	config, ok := csv.BuffMap[int64(buffTypeID)]
	if !ok {
		log.Error().Msgf("buff config not exist: %d", buffTypeID)
		return 0
	}
	return config.Buff_Type
}

// ToClientProto convert Buff struct to BattleBuff
func (buffOne Buff) ToClientProto() *pb.BattleBuff {
	ans := pb.BattleBuff{
		TypeId: &buffOne.TypeID,
		Param:  &buffOne.Param,
	}
	return &ans
}

// ToRdsProto convert Buff struct to RdsBuff
func (buffOne *Buff) ToRdsProto() *rds.RdsBuff {
	return &rds.RdsBuff{
		TypeID: buffOne.TypeID,
		Param:  buffOne.Param,
	}
}

// FromRdsProto convert Buff struct from RdsBuff
func FromRdsProto(rdsBuff *rds.RdsBuff) Buff {
	return Buff{
		TypeID: rdsBuff.TypeID,
		Param:  rdsBuff.Param,
	}
}
