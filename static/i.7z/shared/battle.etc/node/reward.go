package node

import (
	pb "shared/proto/client/battle"
	rds "shared/proto/server/battle"
)

// Reward - desc rewardItems save in Node
type Reward struct {
	RewardBagS map[uint32]RewardBag
	bagInsID   uint32
}

func newReward() Reward {
	return Reward{
		RewardBagS: make(map[uint32]RewardBag),
		bagInsID:   1,
	}
}

func (reward *Reward) addBag(rewardBag RewardBag) {
	reward.RewardBagS[reward.bagInsID] = rewardBag
	reward.bagInsID++
}

// ToClientProto - Reward to client proto
func (reward Reward) ToClientProto() *pb.BattleReward {
	ans := pb.BattleReward{}
	for bagUID, bag := range reward.RewardBagS {
		ans.BagS = append(ans.BagS, bag.toClientProto(bagUID))
	}
	return &ans
}

// ToRdsNodeReward - Reward to rds proto
func (reward Reward) ToRdsNodeReward(heroUID uint64) *rds.RdsNodeReward {
	ans := rds.RdsNodeReward{}
	ans.HeroUID = heroUID
	for bagUID, bag := range reward.RewardBagS {
		ans.BagS = append(ans.BagS, bag.toRdsRewardBag(bagUID))
	}
	return &ans
}

// FromRdsNodeReward - Reward from rds proto
func FromRdsNodeReward(rdsNodeReward *rds.RdsNodeReward) (heroUID uint64, reward Reward) {
	reward = newReward()
	heroUID = rdsNodeReward.GetHeroUID()
	for _, rdsRewardBag := range rdsNodeReward.GetBagS() {
		bagUID, bag := fromRdsRewardBag(rdsRewardBag)
		reward.RewardBagS[bagUID] = bag
	}
	return
}

const (
	// RewardBagTypeConst 固有
	RewardBagTypeConst uint32 = 1
	// RewardBagTypeChoice N选一
	RewardBagTypeChoice uint32 = 2
)

// RewardBag - desc one bag in Reward
type RewardBag struct {
	IsBossBox   bool
	Type        uint32
	ItemS       []RewardItem
	RelicTypeID uint32
}

func (rewardBag RewardBag) toClientProto(bagUID uint32) *pb.BattleRewardBag {
	rewardType := uint32(1)
	if rewardBag.IsBossBox {
		rewardType = 2
	}
	ans := pb.BattleRewardBag{
		RewardBagInsId: &bagUID,
		RewardType:     &rewardType,
		NeedChoice:     &rewardBag.Type,
		RelicTypeId:    &rewardBag.RelicTypeID,
	}
	for _, rewardItem := range rewardBag.ItemS {
		ans.Item = append(ans.Item, rewardItem.toClientProto())
	}
	return &ans
}

func (rewardBag RewardBag) toRdsRewardBag(bagUID uint32) *rds.RdsRewardBag {
	ans := rds.RdsRewardBag{
		Uid:         bagUID,
		IsBossBox:   rewardBag.IsBossBox,
		Type:        rewardBag.Type,
		RelicTypeID: rewardBag.RelicTypeID,
	}
	for _, rewardItem := range rewardBag.ItemS {
		ans.ItemS = append(ans.ItemS, rewardItem.toRdsRewardItem())
	}
	return &ans
}

func fromRdsRewardBag(rdsRewardBag *rds.RdsRewardBag) (bagUID uint32, rewardBag RewardBag) {
	bagUID = rdsRewardBag.GetUid()
	rewardBag.IsBossBox = rdsRewardBag.GetIsBossBox()
	rewardBag.Type = rdsRewardBag.GetType()
	rewardBag.RelicTypeID = rdsRewardBag.GetRelicTypeID()
	for _, rdsRewardItem := range rdsRewardBag.GetItemS() {
		rewardBag.ItemS = append(rewardBag.ItemS, fromRdsRewardItem(rdsRewardItem))
	}
	return
}

// RewardItem - desc one item in RewardBag
type RewardItem struct {
	Gold         uint32
	PotionTypeID uint32
	RelicTypeID  uint32
	CardResID    uint32
}

func (rewardItem RewardItem) toClientProto() *pb.BattleRewardItem {
	ans := pb.BattleRewardItem{}
	if rewardItem.Gold > 0 {
		rewardType := pb.BattleRewardEnum_BReward_Gold
		ans.Type = &rewardType
		ans.ItemId = &rewardItem.Gold
		return &ans
	}
	if rewardItem.PotionTypeID > 0 {
		rewardType := pb.BattleRewardEnum_BReward_Potion
		ans.Type = &rewardType
		ans.ItemId = &rewardItem.PotionTypeID
		return &ans
	}
	if rewardItem.RelicTypeID > 0 {
		rewardType := pb.BattleRewardEnum_BReward_Relic
		ans.Type = &rewardType
		ans.ItemId = &rewardItem.RelicTypeID
		return &ans
	}
	if rewardItem.CardResID > 0 {
		rewardType := pb.BattleRewardEnum_BReward_Card
		ans.Type = &rewardType
		ans.ItemId = &rewardItem.CardResID
		return &ans
	}
	return nil
}

func (rewardItem RewardItem) toRdsRewardItem() *rds.RdsRewardItem {
	return &rds.RdsRewardItem{
		Gold:         rewardItem.Gold,
		PotionTypeID: rewardItem.PotionTypeID,
		RelicTypeID:  rewardItem.RelicTypeID,
		CardResID:    rewardItem.CardResID,
	}
}

func fromRdsRewardItem(rdsRewardItem *rds.RdsRewardItem) RewardItem {
	return RewardItem{
		Gold:         rdsRewardItem.GetGold(),
		PotionTypeID: rdsRewardItem.GetPotionTypeID(),
		RelicTypeID:  rdsRewardItem.GetRelicTypeID(),
		CardResID:    rdsRewardItem.GetCardResID(),
	}
}
