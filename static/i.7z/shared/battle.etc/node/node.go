package node

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math"
	"math/rand"
	"shared/battle.etc/hero"
	"shared/battle.etc/monster"
	"shared/battle.etc/relic"
	"shared/battle.etc/shop"
	"shared/csv"
	pb "shared/proto/client/battle"
	rds "shared/proto/server/battle"
	"shared/table"
)

const (
	// Boss 最终BOSS
	Boss uint32 = 1
	// Elite 精英怪
	Elite uint32 = 2
	// Enemy 普通怪
	Enemy uint32 = 3
	// Shop 商店
	Shop uint32 = 4
	// Rest 篝火
	Rest uint32 = 5
	// Treasure 宝箱
	Treasure uint32 = 6
	// Unknown 未知类型
	Unknown uint32 = 7
	// Meet 奇遇
	Meet uint32 = 8
)

// Status 节点状态
type Status uint32

const (
	_ Status = iota
	// Normal 未触发
	Normal
	// InBattle 战斗中
	InBattle
	// Finish 已触发
	Finish
)

// Node - struct desc one node in stage
type Node struct {
	ID               uint32
	Type             uint32 // 地图显示的
	UnShowType       uint32 // 服务器自己用的
	Status           Status
	HeroUIDs         map[uint64]bool
	InBattleHeroUIDs map[uint64]bool
	RewardS          map[uint64]Reward
	MonsterS         []monster.Monster
	MonsterGroupID   uint32
	ShopItems        map[uint64]shop.Shop
	RestStatus       map[uint64]bool
	EventIDs         map[uint64]uint32
}

// New create new node
func New(nodeID, nodeType, nodeFloor, stageMode, difficulty, stageLevel uint32, heroes map[uint64]hero.InStage) (Node, error) {
	var monsters []monster.Monster
	var monsterGroupID uint32
	var rewardMap = make(map[uint64]Reward)
	var unShownType uint32
	var shopItemsMap = make(map[uint64]shop.Shop)
	var eventIdsMap = make(map[uint64]uint32)
	switch nodeType {
	case Enemy, Elite, Boss:
		var err error
		monsterGroupID, monsters, err = getNodeMonsters(nodeType, nodeFloor, stageLevel, difficulty)
		if err != nil {
			return Node{}, err
		}
		for hid, h := range heroes {
			th := h
			reward, err := getReward(stageMode, nodeType, difficulty, stageLevel, &th)
			if err != nil {
				return Node{}, err
			}
			rewardMap[hid] = reward
		}
	case Shop:
		for hid, h := range heroes {
			th := h
			goods, err := shop.GetShopItems(difficulty, stageLevel, &th)
			if err != nil {
				return Node{}, err
			}
			shopItemsMap[hid] = goods
		}
		log.Debug().Msgf("node shop: %v", shopItemsMap)
	case Rest:
	case Treasure:
		for hid, h := range heroes {
			th := h
			reward, err := getReward(stageMode, Treasure, difficulty, stageLevel, &th)
			if err != nil {
				return Node{}, err
			}
			rewardMap[hid] = reward
		}
	case Unknown:
		var err error
		unShownType, err = randUnknownNodeType(stageMode, stageLevel)
		if err != nil {
			return Node{}, err
		}
		if unShownType == Enemy {
			//var err error
			monsterGroupID, monsters, err = getNodeMonsters(uint32(unShownType), nodeFloor, stageLevel, difficulty)
			if err != nil {
				return Node{}, err
			}
			for hid, h := range heroes {
				th := h
				reward, err := getReward(stageMode, Enemy, difficulty, stageLevel, &th)
				if err != nil {
					return Node{}, err
				}
				rewardMap[hid] = reward
			}
		} else if unShownType == Shop {
			for hid, h := range heroes {
				th := h
				goods, err := shop.GetShopItems(difficulty, stageLevel, &th)
				if err != nil {
					return Node{}, err
				}
				shopItemsMap[hid] = goods
			}
			log.Debug().Msgf("node shop: %v", shopItemsMap)
		} else if unShownType == Treasure {
			for hid, h := range heroes {
				th := h
				reward, err := getReward(stageMode, Treasure, difficulty, stageLevel, &th)
				if err != nil {
					return Node{}, err
				}
				rewardMap[hid] = reward
			}
		} else if unShownType == Meet {
			for hid, h := range heroes {
				th := h
				eventID, ok := getNodeEvent(&th, stageLevel, nodeFloor)
				if !ok || eventID == 0 {
					return Node{}, fmt.Errorf("node type event, but there isn't event id, stageLevel: %d, nodeFloor: %d", stageLevel, nodeFloor)
				}
				eventIdsMap[hid] = eventID
			}
		}
	}
	node := Node{
		ID:               nodeID,
		Type:             nodeType,
		UnShowType:       unShownType,
		Status:           Normal,
		HeroUIDs:         make(map[uint64]bool),
		InBattleHeroUIDs: make(map[uint64]bool),
		MonsterS:         monsters,
		MonsterGroupID:   monsterGroupID,
		ShopItems:        shopItemsMap,
		RewardS:          rewardMap,
		EventIDs:         eventIdsMap,
	}
	return node, nil
}

// ToClientProto convert node struct to pb.StageNode
func (nodeOne Node) ToClientProto(heroUID uint64) *pb.StageNode {
	ans := pb.StageNode{}
	ans.Id = &nodeOne.ID
	t := nodeOne.Type
	if nodeOne.Type == Unknown {
		t = nodeOne.UnShowType
	}
	ans.Type = &t
	s := uint32(nodeOne.Status)
	ans.Status = &s
	for k := range nodeOne.HeroUIDs {
		ans.HeroUids = append(ans.HeroUids, k)
	}
	hasReward := uint32(0)
	switch t {
	case Rest:
		if restStatus, ok := nodeOne.RestStatus[heroUID]; !ok || !restStatus {
			hasReward = 1
		}
	default:
		if nodeOne.RewardS != nil && nodeOne.Status == Finish {
			reward, ok := nodeOne.RewardS[heroUID]
			if ok && len(reward.RewardBagS) > 0 {
				hasReward = 1
			}
		}
	}
	ans.HasReward = &hasReward
	return &ans
}

// ToRdsStageNode convert node struct to RdsStageNode
func (nodeOne *Node) ToRdsStageNode() *rds.RdsStageNode {
	var heroUIDs, inBattleHeroUIDs []uint64
	for k := range nodeOne.HeroUIDs {
		heroUIDs = append(heroUIDs, k)
	}
	for k := range nodeOne.InBattleHeroUIDs {
		inBattleHeroUIDs = append(inBattleHeroUIDs, k)
	}
	var rewardS []*rds.RdsNodeReward
	for k, v := range nodeOne.RewardS {
		rewardS = append(rewardS, v.ToRdsNodeReward(k))
	}
	rdsMonsters := make([]*rds.RdsMonster, len(nodeOne.MonsterS))
	for i, m := range nodeOne.MonsterS {
		rdsMonsters[i] = m.ToRdsMonsterProto()
	}
	var restStatus []uint64
	for k, v := range nodeOne.RestStatus {
		if v == true {
			restStatus = append(restStatus, k)
		}
	}
	var shops []*rds.RdsShopType
	for k, s := range nodeOne.ShopItems {
		shops = append(shops, s.ToRdsShopProto(k))
	}
	//log.Debug().Msgf("marshal shops : %v", shops)
	var events []*rds.RdsEventItem
	for uid, eventID := range nodeOne.EventIDs {
		events = append(events, &rds.RdsEventItem{HeroUID: uid, EventId: eventID})
	}
	return &rds.RdsStageNode{
		Id:              nodeOne.ID,
		Type:            uint32(nodeOne.Type),
		UnShowType:      uint32(nodeOne.UnShowType),
		Status:          uint32(nodeOne.Status),
		HeroIds:         heroUIDs,
		InBattleHeroIds: inBattleHeroUIDs,
		RewardS:         rewardS,
		Shops:           shops,
		Monsters:        rdsMonsters,
		MonsterGroupID:  nodeOne.MonsterGroupID,
		RestStatus:      restStatus,
		Events:          events,
	}
}

// FromRdsProto convert node struct from RdsStageNode
func FromRdsProto(rdsNode *rds.RdsStageNode) Node {
	heroUIDs := make(map[uint64]bool)
	for _, v := range rdsNode.GetHeroIds() {
		heroUIDs[v] = true
	}
	inBattleHeroUIDs := make(map[uint64]bool)
	for _, v := range rdsNode.GetInBattleHeroIds() {
		inBattleHeroUIDs[v] = true
	}
	rewardS := make(map[uint64]Reward)
	for _, v := range rdsNode.GetRewardS() {
		heroUID, reward := FromRdsNodeReward(v)
		rewardS[heroUID] = reward
	}
	monsters := make([]monster.Monster, len(rdsNode.GetMonsters()))
	for i, m := range rdsNode.GetMonsters() {
		monsters[i] = monster.FromRdsMonsterProto(m)
	}
	restStatus := make(map[uint64]bool)
	for _, v := range rdsNode.GetRestStatus() {
		restStatus[v] = true
	}
	shops := make(map[uint64]shop.Shop)
	for _, s := range rdsNode.GetShops() {
		shops[s.GetHeroUID()] = shop.FromRdsShopProto(s)
	}
	events := make(map[uint64]uint32)
	for _, e := range rdsNode.GetEvents() {
		events[e.GetHeroUID()] = e.GetEventId()
	}
	return Node{
		ID:               rdsNode.GetId(),
		Type:             rdsNode.GetType(),
		UnShowType:       rdsNode.GetUnShowType(),
		Status:           Status(rdsNode.GetStatus()),
		HeroUIDs:         heroUIDs,
		InBattleHeroUIDs: inBattleHeroUIDs,
		RewardS:          rewardS,
		ShopItems:        shops,
		MonsterS:         monsters,
		MonsterGroupID:   rdsNode.GetMonsterGroupID(),
		RestStatus:       restStatus,
		EventIDs:         events,
	}
}

func getNodeMonsters(nodeType, nodeFloor, stageLevel, difficulty uint32) (uint32, []monster.Monster, error) {
	monsterGroups, ok := table.GetMonsterByGroupTypeAndStageLevel(nodeType, nodeFloor, stageLevel)
	if !ok {
		return 0, nil, fmt.Errorf("node init failed, monster groups not found, group type: %d, stageLevel: %d, nodeFloor: %d",
			nodeType, stageLevel, nodeFloor)
	}
	randIndex := rand.Intn(len(monsterGroups))
	monsters := make([]monster.Monster, len(monsterGroups[randIndex].Monsters))
	for i, m := range monsterGroups[randIndex].Monsters {
		mst, err := monster.New(uint32(m.MonsterId), difficulty, uint32(m.MonsterPos))
		if err != nil {
			return 0, nil, fmt.Errorf("node init failed, new monster failed, monsterTypeId: %d, challengeLevel: %d",
				m.MonsterId, difficulty)
		}
		monsters[i] = mst
	}
	return uint32(monsterGroups[randIndex].GroupID), monsters, nil
}

// GetEventMonsters event trigger battle
func GetEventMonsters(monsterGroupID uint32, difficulty uint32) (monsters []monster.Monster, err error) {
	levelMonsterConf, ok := csv.LevelMonsterMap[int64(monsterGroupID)]
	if !ok {
		err = fmt.Errorf("level monster group: [%d] not found", monsterGroupID)
		return
	}
	if levelMonsterConf.Monster1_ID != 0 {
		mst, err1 := monster.New(uint32(levelMonsterConf.Monster1_ID), difficulty, uint32(levelMonsterConf.Monster1_Pos))
		if err1 != nil {
			err = err1
			return
		}
		monsters = append(monsters, mst)
	}
	if levelMonsterConf.Monster2_ID != 0 {
		mst, err1 := monster.New(uint32(levelMonsterConf.Monster2_ID), difficulty, uint32(levelMonsterConf.Monster2_Pos))
		if err1 != nil {
			err = err1
			return
		}
		monsters = append(monsters, mst)
	}
	if levelMonsterConf.Monster3_ID != 0 {
		mst, err1 := monster.New(uint32(levelMonsterConf.Monster3_ID), difficulty, uint32(levelMonsterConf.Monster3_Pos))
		if err1 != nil {
			err = err1
			return
		}
		monsters = append(monsters, mst)
	}
	if levelMonsterConf.Monster4_ID != 0 {
		mst, err1 := monster.New(uint32(levelMonsterConf.Monster4_ID), difficulty, uint32(levelMonsterConf.Monster4_Pos))
		if err1 != nil {
			err = err1
			return
		}
		monsters = append(monsters, mst)
	}
	return
}

// GetEventBattleReward event trigger battle
func GetEventBattleReward(h *hero.InStage, relicID uint32) Reward {
	reward := newReward()
	_, ok := h.Relics[relicID]
	if ok {
		return reward
	}
	bagItem := RewardItem{RelicTypeID: relicID}
	bag := RewardBag{Type: RewardBagTypeConst, ItemS: []RewardItem{bagItem}}
	reward.addBag(bag)
	return reward
}

// GetEventEffectReward event trigger reward
func GetEventEffectReward(h *hero.InStage, rewardType uint32, num uint32) (Reward, *pb.BattleRelicInStage, error) {
	reward := newReward()
	switch int(rewardType) {
	case csv.REWARD_TYPE_CARD:

	case csv.REWARD_TYPE_RELIC:
	case csv.REWARD_TYPE_POTION:
		relicTypeID := relic.MpLimitAndNoPotion
		if _, ok := h.GetRelic(relicTypeID); ok {
			relicInStage := pb.BattleRelicInStage{}
			relicInStage.RelicTypeId = &relicTypeID
			log.Debug().Msgf("relic.MpLimitAndNoPotion, hero cannot get potions anymore")
			return Reward{}, &relicInStage, nil
		}
		potionIDs := table.GetAllPotionIds()
		if len(potionIDs) <= 0 {
			return Reward{}, nil, fmt.Errorf("no config potions")
		}
		for i := 0; i < int(num); i++ {
			randIndex := rand.Intn(len(potionIDs))
			bagItem := RewardItem{PotionTypeID: potionIDs[randIndex]}
			bag := RewardBag{Type: RewardBagTypeConst, ItemS: []RewardItem{bagItem}}
			reward.addBag(bag)
		}
	default:
		log.Error().Msgf("reward type: %d not exist", rewardType)
		return Reward{}, nil, fmt.Errorf("reward type: %d not exist", rewardType)
	}
	return reward, nil, nil
}

func getReward(stageMode, nodeType, difficulty, stageLevel uint32, h *hero.InStage) (Reward, error) {
	var dropFrom uint32
	switch nodeType {
	case Enemy:
		dropFrom = csv.DROP_FROM_ENEMY
	case Elite:
		dropFrom = csv.DROP_FROM_ELITE
	case Boss:
		dropFrom = csv.DROP_FROM_BOSS
	case Treasure:
		dropFrom = csv.DROP_FROM_TREASURE
	default:
		return Reward{}, fmt.Errorf("drop form error, %d", nodeType)
	}
	basicDrop, ok := table.GetBasicDrop(dropFrom)
	if !ok {
		return Reward{}, fmt.Errorf("drop not found, nodeType: %d", nodeType)
	}
	var reward = newReward()

	for _, dropItem := range basicDrop {
		switch dropItem {
		case csv.DROP_ITEM_TYPE_GOLD:
			if _, ok := h.GetRelic(relic.MpLimitAndNoGold); ok {
				log.Debug().Msgf("relic.MpLimitAndNoGold: cannot get coin anymore")
				break
			}
			dropGoldCfg, ok := table.GetDropGoldConfig(stageMode, stageLevel, nodeType)
			if !ok {
				log.Error().Msgf("drop gold config not found, mode: %d, stageLevel: %d, nodeType: %d", stageMode, stageLevel, nodeType)
				break
			}
			//randGold := rand.Intn(51) + 50
			// range: [min, max]
			randGold := rand.Intn(dropGoldCfg.Drop_Max+1-dropGoldCfg.Drop_Min) + dropGoldCfg.Drop_Min
			if dropFrom == csv.DROP_FROM_ENEMY || dropFrom == csv.DROP_FROM_ELITE || dropFrom == csv.DROP_FROM_BOSS {
				randGold += int(math.Ceil(float64(randGold) * (float64(h.MonsterDropGoldAddPercent) / 100)))
			}
			//reward.Gold = uint32(randGold)
			bagItem := RewardItem{Gold: uint32(randGold)}
			bag := RewardBag{Type: RewardBagTypeConst}
			bag.ItemS = append(bag.ItemS, bagItem)
			reward.addBag(bag)
		case csv.DROP_ITEM_TYPE_CARD:
			copies := uint32(3)
			dropCardResIds := hero.GetDropCards(h, difficulty, stageLevel, dropFrom, copies)
			if len(dropCardResIds) <= 0 {
				break
			}

			var bagItems []RewardItem
			for _, resID := range dropCardResIds {
				bagItems = append(bagItems, RewardItem{CardResID: resID})
			}
			bag := RewardBag{Type: RewardBagTypeChoice, ItemS: bagItems}
			reward.addBag(bag)
		case csv.DROP_ITEM_TYPE_RELIC:
			relicDropMap, canDrop := hero.GetRelicDropGroupMap(h, difficulty, stageLevel, dropFrom)
			if !canDrop {
				break
			}
			basicCopies := uint32(1)
			if dropFrom == csv.DROP_FROM_BOSS {
				basicCopies = 3
				bossDropRelics := hero.GetDropRelics(h, relicDropMap, basicCopies)
				var bossBagItems []RewardItem
				for i := 0; i < len(bossDropRelics); i++ {
					bagItem := RewardItem{RelicTypeID: uint32(bossDropRelics[i])}
					bossBagItems = append(bossBagItems, bagItem)
				}
				if len(bossBagItems) <= 0 {
					log.Warn().Msgf("there is not boss drop relics")
					break
				}
				bossRelicsBag := RewardBag{Type: RewardBagTypeChoice, IsBossBox: true, ItemS: bossBagItems}
				reward.addBag(bossRelicsBag)
				log.Debug().Msgf("boss drop relics bag: %+v", bossRelicsBag)
				break
			}

			basicDropRelics := hero.GetDropRelics(h, relicDropMap, basicCopies)
			for i := 0; i < len(basicDropRelics); i++ {
				bagItem := RewardItem{RelicTypeID: uint32(basicDropRelics[i])}
				bag := RewardBag{Type: RewardBagTypeConst, ItemS: []RewardItem{bagItem}}
				reward.addBag(bag)
			}
			if _, ok := h.GetRelic(relic.EliteDropRelic); ok && nodeType == Elite {
				basic, _, _, ok := relic.GetRelicBasic(relic.EliteDropRelic)
				if ok {
					addRelicNum := uint32(basic) - basicCopies
					addRelicIds := hero.GetDropRelics(h, relicDropMap, addRelicNum)
					for _, r := range addRelicIds {
						bagItem := RewardItem{RelicTypeID: r}
						bag := RewardBag{Type: RewardBagTypeConst, ItemS: []RewardItem{bagItem}, RelicTypeID: relic.EliteDropRelic}
						reward.addBag(bag)
					}
				}
			}

		case csv.DROP_ITEM_TYPE_POTION:
			if _, ok := h.GetRelic(relic.MpLimitAndNoPotion); ok {
				log.Debug().Msgf("relic.MpLimitAndNoPotion: cannot get potion anymore")
				break
			}
			probability := rand.Intn(2) // 0 or 1
			if probability == 0 {
				break
			}

			potionNum := uint32(1)
			potions := hero.GetDropPotions(h, difficulty, stageLevel, dropFrom, potionNum)
			for _, potionID := range potions {
				bagItem := RewardItem{PotionTypeID: potionID}
				bag := RewardBag{Type: RewardBagTypeConst, ItemS: []RewardItem{bagItem}}
				reward.addBag(bag)
			}

		}
	}
	log.Debug().Msgf("node reward: %v", reward)
	return reward, nil
}

func getNodeEvent(h *hero.InStage, stageLevel, nodeFloor uint32) (eventID uint32, ok bool) {
	eventConf := table.GetStageEventConf(stageLevel, nodeFloor)
	if len(eventConf) <= 0 {
		return
	}
	totalWeight := 0
	filteredEventMap := make(map[uint32]*csv.StageEventRandom)
	for _, e := range eventConf {
		if e.Weight <= 0 {
			continue
		}
		// non-repeating event
		if e.Repeat == csv.GENERAL_FALSE {
			if _, ok := h.NonRepeatingEvents[uint32(e.Event_ID)]; ok {
				continue
			}
		}
		totalWeight += e.Weight
		filteredEventMap[uint32(e.Event_ID)] = e
	}
	if totalWeight <= 0 {
		return
	}
	randWight := rand.Intn(totalWeight) + 1
	for _, e := range filteredEventMap {
		if randWight <= e.Weight {
			eventID = uint32(e.Event_ID)
			ok = true
			if e.Repeat == csv.GENERAL_FALSE {
				h.NonRepeatingEvents[eventID] = true
			}
			break
		}
		randWight -= e.Weight
	}
	return
}

func randUnknownNodeType(mode, stageLevel uint32) (nodeType uint32, err error) {
	cfg, ok := table.GetUnknownNodeProbConfig(mode, stageLevel)
	if !ok {
		err = fmt.Errorf("unknown node config not exist, mode: %d, stageLevel: %d", mode, stageLevel)
		return
	}
	var weightArr []int
	var nodeTypes []uint32
	totalWeight := 0
	if cfg.Enemy > 0 {
		totalWeight += cfg.Enemy
		weightArr = append(weightArr, cfg.Enemy)
		nodeTypes = append(nodeTypes, Enemy)
	}
	if cfg.Shop > 0 {
		totalWeight += cfg.Shop
		weightArr = append(weightArr, cfg.Shop)
		nodeTypes = append(nodeTypes, Shop)
	}
	if cfg.Treasure > 0 {
		totalWeight += cfg.Treasure
		weightArr = append(weightArr, cfg.Treasure)
		nodeTypes = append(nodeTypes, Treasure)
	}
	if cfg.Event > 0 {
		totalWeight += cfg.Event
		weightArr = append(weightArr, cfg.Event)
		nodeTypes = append(nodeTypes, Meet)
	}
	if totalWeight <= 0 {
		err = fmt.Errorf("unknown weight: %d <= 0", totalWeight)
		return
	}
	randWeight := rand.Intn(totalWeight) + 1
	log.Debug().Msgf("unknown node rand: %d", randWeight)
	for i, w := range weightArr {
		if randWeight <= w {
			nodeType = nodeTypes[i]
			break
		}
		randWeight -= w
	}
	return
}
