package stage

import (
	"errors"
	"fmt"
	"github.com/rs/zerolog/log"
	"math"
	"math/rand"
	"shared/battle.etc/card"
	"shared/battle.etc/hero"
	"shared/battle.etc/node"
	"shared/battle.etc/relic"
	"shared/battle.etc/stageDef"
	"shared/battle.etc/stagePlayer"
	"shared/cardDef"
	"shared/csv"
	heroD "shared/heroDef"
	pb "shared/proto/client/battle"
	rds "shared/proto/server/battle"
	"shared/table"
	"strconv"
	"time"
)

// Stage struct - save in redis
type Stage struct {
	UID           uint64
	SourceID      uint32
	Mode          uint32
	Difficulty    uint32
	Nodes         map[uint32]node.Node
	Heros         map[uint64]hero.InStage
	Time          time.Time
	Level         uint32
	InitConfigMap map[uint64]InitConfig
}

// InitConfig - stage start trigger
type InitConfig struct {
	// 1. 初始事件
	// 2. BOSS宝箱
	Type     uint32
	EventIDs []uint32
	Reward   node.Reward
}

// ToClientProto convert Stage struct to StageInfo
func (stageOne Stage) ToClientProto(playerID uint64) *pb.StageInfo {
	ans := pb.StageInfo{}
	stageUIDStr := strconv.FormatUint(stageOne.UID, 10)
	ans.Uid = &stageUIDStr
	ans.SourceId = &stageOne.SourceID
	ans.Level = &stageOne.Level
	ans.Mode = &stageOne.Mode
	ans.Difficulty = &stageOne.Difficulty
	heroUID := uint64(0)
	for _, heroOne := range stageOne.Heros {
		ans.Heros = append(ans.Heros, heroOne.ToClientProto())
		if heroOne.PlayerID == playerID {
			ans.Mine = heroOne.ToClientProtoInfo()
			heroUID = heroOne.GetUID()
		}
	}
	heroInitConfig, ok := stageOne.InitConfigMap[heroUID]
	if ok {
		ans.InitConfig = &pb.StageInitConfig{
			Type:     &heroInitConfig.Type,
			EventIds: heroInitConfig.EventIDs,
			Treasure: heroInitConfig.Reward.ToClientProto(),
		}
	}

	nodeS := []*pb.StageNode{}
	for _, nd := range stageOne.Nodes {
		nodeS = append(nodeS, nd.ToClientProto(heroUID))
	}
	ans.Nodes = nodeS
	unixTime := uint32(stageOne.Time.Unix())
	ans.Unixtime = &unixTime
	log.Debug().Msgf("stage proto uid:%v sourceID:%v info: %v",
		stageOne.UID, stageOne.SourceID, ans)
	return &ans
}

// ToRdsStageProto convert Stage struct to RdsStage
func (stageOne *Stage) ToRdsStageProto() *rds.RdsStage {
	nodes := []*rds.RdsStageNode{}
	for _, n := range stageOne.Nodes {
		nodes = append(nodes, n.ToRdsStageNode())
	}
	hs := []*rds.RdsStageHero{}
	for _, h := range stageOne.Heros {
		hs = append(hs, h.ToRdsStageHero())
	}
	initConfig := []*rds.RdsStageInitConfig{}
	for heroUID, c := range stageOne.InitConfigMap {
		initConfigOne := rds.RdsStageInitConfig{
			HeroUid:  heroUID,
			Type:     c.Type,
			EventIds: c.EventIDs,
			RewardS:  c.Reward.ToRdsNodeReward(heroUID),
		}
		initConfig = append(initConfig, &initConfigOne)
	}
	return &rds.RdsStage{
		Uid:        stageOne.UID,
		SourceId:   stageOne.SourceID,
		Nodes:      nodes,
		Heroes:     hs,
		Time:       stageOne.Time.Unix(),
		Level:      stageOne.Level,
		Mode:       stageOne.Mode,
		Difficulty: stageOne.Difficulty,
		InitConfig: initConfig,
	}
}

// FromRdsStageProto convert Stage struct from RdsStage
func FromRdsStageProto(s *rds.RdsStage) Stage {
	nds := make(map[uint32]node.Node)
	for _, n := range s.Nodes {
		nds[n.Id] = node.FromRdsProto(n)
	}
	heros := make(map[uint64]hero.InStage)
	for _, h := range s.Heroes {
		heroInStage := hero.FromRdsProto(h)
		heros[heroInStage.GetUID()] = heroInStage
	}
	initConfigMap := make(map[uint64]InitConfig)
	for _, rdsInitConfig := range s.GetInitConfig() {
		_, reward := node.FromRdsNodeReward(rdsInitConfig.GetRewardS())
		initConfigMap[rdsInitConfig.GetHeroUid()] = InitConfig{
			Type:     rdsInitConfig.GetType(),
			EventIDs: rdsInitConfig.GetEventIds(),
			Reward:   reward,
		}
	}
	return Stage{
		UID:           s.Uid,
		SourceID:      s.SourceId,
		Nodes:         nds,
		Heros:         heros,
		Time:          time.Unix(s.Time, 0),
		Level:         s.Level,
		Mode:          s.Mode,
		Difficulty:    s.Difficulty,
		InitConfigMap: initConfigMap,
	}
}

// New create stage
func New(player *stagePlayer.StagePlayer, myHero heroD.Hero, stageLevel uint32, stageMode uint32, stageDifficulty uint32, stageUID uint64) (Stage, error) {
	s := Stage{}
	// Basic init
	if stageLevel == 0 {
		stageLevel = 1
	}
	if stageDifficulty == 0 {
		stageDifficulty = 1
	}
	sourceID, ok := getRandomStageSourceID(stageLevel, stageMode, stageDifficulty)
	if !ok {
		return s, fmt.Errorf("create stage error stageLevel:%v, stageMode:%v, stageDifficulty:%v",
			stageLevel, stageMode, stageDifficulty)
	}

	s.UID = stageUID
	s.Level = stageLevel
	s.Time = time.Now()
	s.SourceID = sourceID
	s.Mode = stageMode
	s.Difficulty = stageDifficulty

	// Heros init
	heros := make(map[uint64]hero.InStage)
	heroInStage, err := hero.NewHeroInStage(player, myHero, stageDifficulty, stageLevel)
	if err != nil {
		return Stage{}, err
	}
	heros[heroInStage.GetUID()] = heroInStage
	s.Heros = heros
	s.InitConfigMap = make(map[uint64]InitConfig)
	configs, ok := getRandomInitEventConfig(&heroInStage, 3)
	if ok {
		var initConfig InitConfig
		initConfig.Type = 1 // initEvent
		for _, conf := range configs {
			initConfig.EventIDs = append(initConfig.EventIDs, uint32(conf.ID))
		}
		s.InitConfigMap[heroInStage.GetUID()] = initConfig
	}
	return s, nil
}

func getRandomInitEventConfig(h *hero.InStage, num uint32) (initConfigs []*csv.StageInitEvent, ok bool) {
	heroConf, ok := csv.TableCareerInitialValueMap[int64(h.GetTypeID())]
	if !ok {
		return
	}
	totalWeight := 0
	var configs []*csv.StageInitEvent
	for _, conf := range csv.StageInitEventMap {
		if conf.Weight <= 0 {
			continue
		}
		if heroConf.Career == conf.Career_Limited || conf.Career_Limited == 0 {
			configs = append(configs, conf)
			totalWeight += conf.Weight
		}
	}
	if totalWeight <= 0 {
		return
	}
	if len(configs) < int(num) {
		num = uint32(len(configs))
	}
	var selectedConf []*csv.StageInitEvent
	for n := 0; n < int(num); n++ {
		if totalWeight <= 0 {
			break
		}
		randWeight := rand.Intn(totalWeight) + 1
		for i := 0; i < len(configs); i++ {
			if randWeight <= configs[i].Weight {
				selectedConf = append(selectedConf, configs[i])
				totalWeight -= configs[i].Weight
				configs = append(configs[:i], configs[i+1:]...)
				break
			}
			randWeight -= configs[i].Weight
		}
	}
	if len(selectedConf) > 0 {
		ok = true
	}
	return selectedConf, ok
}

func (stageOne *Stage) changeResID(nextResID uint32, rewardMap map[uint64]node.Reward) error {
	// change res ID
	stageOne.SourceID = nextResID
	// level plus
	stageOne.Level++
	// clean nodes
	newStageNodes := make(map[uint32]node.Node)
	stageOne.Nodes = newStageNodes
	// re write heros
	newStageHeros := make(map[uint64]hero.InStage)
	for heroUID, heroOne := range stageOne.Heros {
		newStageHeros[heroUID] = heroOne.ChangeResID()
	}
	stageOne.Heros = newStageHeros
	// write boss reward
	for heroUID, reward := range rewardMap {
		stageOne.InitConfigMap[heroUID] = InitConfig{
			Type:   2,
			Reward: reward,
		}
	}
	return nil
}

// Touch node, if hero can arrived this node, return new Stage
func (stageOne *Stage) Touch(touchedNodeID uint32, h hero.InStage,
	stageInChan chan<- *stageDef.In, reply *stageDef.TouchNodeReply,
	battleStartCallback func(chan<- *stageDef.BattleOperationParam, uint64)) (int32, error) {
	log.Debug().Msgf("stage debug touch %v", stageOne)
	// re touch
	if touchedNodeID == h.NodeID {
		myNode, ok := stageOne.Nodes[touchedNodeID]
		if !ok {
			return csv.ERRCODE_BATTLE_NODE_NOT_EXIST, fmt.Errorf("touch node not exist")
		}
		if myNode.Status == node.Finish {
			if myNode.Type == node.Unknown {
				myNode.Type = myNode.UnShowType
			}
			reply.Status = uint32(myNode.Type)
			if myNode.Type == node.Shop {
				heroShop, ok := myNode.ShopItems[h.GetUID()]
				if !ok {
					return csv.ERRCODE_FAILED, errors.New("touch show shop not exist")
				}
				reply.ShopItem = *heroShop.ToClientShopProto()
				return csv.ERRCODE_SUCCESS, nil
			}
			if myNode.Type == node.Rest {
				stat, ok := myNode.RestStatus[h.GetUID()]
				if !ok || stat == false {
					states := make([]uint32, 2)
					states[0] = 1 // 可休息
					states[1] = 2 // 可升级卡牌
					reply.RestStatus = states
				}
				return csv.ERRCODE_SUCCESS, nil
			}
			reward, ok := myNode.RewardS[h.GetUID()]
			if !ok {
				return csv.ERRCODE_FAILED, errors.New("touch show reward not exist")
			}
			if myNode.Type == node.Enemy || myNode.Type == node.Elite ||
				myNode.Type == node.Boss || myNode.Type == node.Treasure {
				reply.Treasure = *reward.ToClientProto()
			}
			return csv.ERRCODE_SUCCESS, nil
		}
	}

	nextResNode, ok := getStageNode(stageOne.SourceID, touchedNodeID)
	if !ok {
		return csv.ERRCODE_FAILED, fmt.Errorf("touched node not found at xml, touched nodeID: %d", touchedNodeID)
	}
	log.Debug().Msgf("hero.nodeID: %d", h.NodeID)
	// skip first node connection check
	firstNode := false
	if nextResNode.Floor == 1 && h.NodeID == 0 {
		firstNode = true
	}
	// has upon connection
	if !firstNode && !isNextNode(stageOne.SourceID, h.NodeID, touchedNodeID) {
		return csv.ERRCODE_FAILED, fmt.Errorf("the node: %d cannot be touched, not connected", touchedNodeID)
	}
	// find nextNode
	nextNode, ok := stageOne.Nodes[touchedNodeID]
	if !ok {
		// nextNode not exist - create it
		nodeFloor, ok := getStageNodeFloor(stageOne.SourceID, touchedNodeID)
		if !ok {
			return csv.ERRCODE_FAILED, fmt.Errorf("the stageSourceID: %d, node: %d not found at stageRes",
				stageOne.SourceID, touchedNodeID)
		}
		nextNodeLocal, err := node.New(touchedNodeID, nextResNode.NodeType, nodeFloor, stageOne.Mode, stageOne.Difficulty, stageOne.Level, stageOne.Heros)
		if err != nil {
			return csv.ERRCODE_FAILED, err
		}
		// save newNode in Stage
		err = stageOne.addNewNodeWriter(&nextNodeLocal)
		if err != nil {
			return csv.ERRCODE_FAILED, err
		}
		nextNode = stageOne.Nodes[nextNodeLocal.ID]
		log.Debug().Msgf("stage debug touch create New Node %v", nextNode)
	}

	reply.Status = uint32(nextNode.Type)

	if nextNode.Status != node.Normal {
		return csv.ERRCODE_BATTLE_REPEAT_TOUCH, errors.New("stage is not normal")
	}

	if h.FlagInEvent == true {
		h.ResetFromBeforeEventAttr()
		log.Debug().Msgf("reset from before event attr: %v", h.AttrBeforeEvent)
		h.CurProcess = 0
		h.FlagInEvent = false
		stageOne.Heros[h.GetUID()] = h
	}

	// exec depend on node.Node.Type
	switch nextNode.Type {
	case node.Boss, node.Elite, node.Enemy:
		// stage change in this function
		battleData, err := stageOne.tryTouchBattleNode(nextNode, h, stageInChan, battleStartCallback)
		if err != nil {
			return csv.ERRCODE_FAILED, err
		}
		reply.BattleData = *battleData
		reply.InBattle = true
	case node.Shop:
		err := stageOne.changeNodeStatusFromNormal2FinishWriter(nextNode, &h)
		if err != nil {
			return csv.ERRCODE_FAILED, err
		}
		heroShop, _ := nextNode.ShopItems[h.GetUID()]
		reply.ShopItem = *heroShop.ToClientShopProto()
		log.Debug().Msgf("touch node rsp: shop: %v", reply.ShopItem)
	case node.Rest:
		err := stageOne.changeNodeStatusFromNormal2FinishWriter(nextNode, &h)
		if err != nil {
			return csv.ERRCODE_FAILED, err
		}
		stat, ok := nextNode.RestStatus[h.GetUID()]
		if !ok || stat == false {
			states := make([]uint32, 2)
			states[0] = 1 // 可休息
			states[1] = 2 // 可升级卡牌
			reply.RestStatus = states
		}
	case node.Treasure:
		err := stageOne.changeNodeStatusFromNormal2FinishWriter(nextNode, &h)
		if err != nil {
			return csv.ERRCODE_FAILED, err
		}
		reward, ok := nextNode.RewardS[h.GetUID()]
		if !ok {
			return csv.ERRCODE_FAILED, fmt.Errorf("node.Treasure reward not found, stage: %d, node: %d, heroUID: %d",
				stageOne.UID, nextNode.ID, h.GetUID())
		}
		reply.Treasure = *reward.ToClientProto()
	case node.Unknown:
		if nextNode.UnShowType == node.Shop || nextNode.UnShowType == node.Treasure {
			err := stageOne.changeNodeStatusFromNormal2FinishWriter(nextNode, &h)
			if err != nil {
				return csv.ERRCODE_FAILED, err
			}
			if nextNode.UnShowType == node.Shop {
				heroShop, _ := nextNode.ShopItems[h.GetUID()]
				reply.ShopItem = *heroShop.ToClientShopProto()
			} else if nextNode.UnShowType == node.Treasure {
				reward, ok := nextNode.RewardS[h.GetUID()]
				if !ok {
					return csv.ERRCODE_FAILED, fmt.Errorf("node.unshown.Treasure reward not found, stage: %d, node: %d, heroUID: %d",
						stageOne.UID, nextNode.ID, h.GetUID())
				}
				reply.Treasure = *reward.ToClientProto()
			}
		} else if nextNode.UnShowType == node.Enemy {
			battleData, err := stageOne.tryTouchBattleNode(nextNode, h, stageInChan, battleStartCallback)
			if err != nil {
				return csv.ERRCODE_FAILED, err
			}
			reply.BattleData = *battleData
			reply.InBattle = true
		} else if nextNode.UnShowType == node.Meet {
			eventID, _ := nextNode.EventIDs[h.GetUID()]
			//err := stageOne.changeHeroEventID(&h, eventID)
			h.CurEventID = eventID
			h.RecordHeroAttrBeforeEvent()
			log.Debug().Msgf("-----hero record event attr: %+v", h.AttrBeforeEvent)
			//stageOne.changeHeroEventFlag(&h, true)
			h.ChangeHeroEventFlag(true)
			//if err != nil {
			//	return csv.ERRCODE_FAILED, err
			//}
			stageOne.Heros[h.GetUID()] = h
			reply.MeetID = eventID
		}
		reply.Status = uint32(nextNode.UnShowType)
	}
	log.Debug().Msgf("stage debug touch down status %v: battleData %v", reply.Status, reply.BattleData)
	return csv.ERRCODE_SUCCESS, nil
}

// exec under lock
func (stageOne *Stage) moveForward(heroUID uint64, nodeID uint32) error {
	// add heroID to node
	nd, ok := stageOne.Nodes[nodeID]
	if !ok {
		return fmt.Errorf("there is no node with nodeID: %d", nodeID)
	}
	nd.HeroUIDs[heroUID] = true
	// remove heroUid from inBattleHeroUIDs or do nothing if there is no heroUid
	delete(nd.InBattleHeroUIDs, heroUID)
	stageOne.Nodes[nodeID] = nd
	h, ok := stageOne.Heros[heroUID]
	if !ok {
		return fmt.Errorf("there is no hero : %d at node: %d", heroUID, nodeID)
	}
	h.NodeID = nodeID
	h.FinishNode++
	nodeType := nd.Type
	if nd.Type == node.Unknown {
		nodeType = nd.UnShowType
	}
	switch nodeType {
	case node.Enemy:
		h.EnemyNum++
	case node.Elite:
		h.EliteNum++
	case node.Boss:
		h.BossNum++
	default:
	}
	stageOne.Heros[heroUID] = h
	return nil
}

// exec under lock
func (stageOne *Stage) moveBackward(heroUID uint64, nodeID uint32) error {
	nd, ok := stageOne.Nodes[nodeID]
	if !ok {
		return fmt.Errorf("there is no node with nodeID: %d", nodeID)
	}
	delete(nd.InBattleHeroUIDs, heroUID)
	stageOne.Nodes[nodeID] = nd
	return nil
}

// ShopPurchase for shop
func (stageOne *Stage) ShopPurchase(myHero *hero.InStage, nodeID, itemID, itemType, itemIndex uint32, rsp *pb.BattleShopPurchaseRsp) (result int32) {
	result = int32(csv.ERRCODE_SUCCESS)

	nd, ok := stageOne.Nodes[nodeID]
	if !ok {
		result = csv.ERRCODE_BATTLE_NODE_NOT_EXIST
		return //fmt.Errorf("there is not node, nodeID: %d", nodeID)
	}

	heroShop, ok := nd.ShopItems[myHero.GetUID()]
	if !ok {
		result = csv.ERRCODE_BATTLE_SHOP_NOT_EXIST
		return
	}
	goldOldVal := myHero.Gold
	price := uint32(0)
	switch pb.ShopItemType(itemType) {
	case pb.ShopItemType_SHOP_ITEM_TYPE_CARD, pb.ShopItemType_SHOP_ITEM_TYPE_RELIC, pb.ShopItemType_SHOP_ITEM_TYPE_POTION:
		item, ok := heroShop.FindItem(itemType, itemIndex)
		if !ok {
			result = csv.ERRCODE_BATTLE_SHOP_ITEM_NOT_EXIST
			return
		}
		price = item.CurrentPrice
		if myHero.Gold < item.CurrentPrice {
			result = csv.ERRCODE_BATTLE_SHOP_MONEY_NOT_ENOUGH
			return
		}

		if item.State != uint32(pb.BattleShopItemState_BATTLE_SHOP_ITEM_ON_SAIL) {
			result = csv.ERRCODE_BATTLE_SHOP_ITEM_SOLD_OUT
			return
		}

		if itemType == uint32(pb.ShopItemType_SHOP_ITEM_TYPE_CARD) {
			crd, ok := csv.TableCardsMap[int64(item.ItemID)]
			if !ok {
				result = csv.ERRCODE_CARD_NOT_EXIST
				return //fmt.Errorf("card not exist, cardid: %d", itemID)
			}
			cp, _ := myHero.CardPool[cardDef.TypeID(crd.CardGroupID)]
			newCard, err := stageOne.purchaseCardHeroInStageWriter(myHero, item.CurrentPrice, uint32(crd.CardGroupID), cp.GetCardStarLevel(), uint32(crd.Level))
			if err != nil {
				result = csv.ERRCODE_SYS_INTERNAL_ERROR
				return //err
			}
			rsp.PurchasedCard = newCard.ToClientProto()
			heroShop.Cards[itemIndex].State = uint32(pb.BattleShopItemState_BATTLE_SHOP_ITEM_SOLD_OUT)
		} else if itemType == uint32(pb.ShopItemType_SHOP_ITEM_TYPE_RELIC) {
			newRelic, relicInStage, err := stageOne.purchaseRelicHeroInStageWriter(myHero, item.CurrentPrice, item.ItemID)
			if err != nil {
				result = csv.ERRCODE_SYS_INTERNAL_ERROR
				return //err
			}
			rsp.PurchasedRelic = newRelic.ToClientProto()
			rsp.RelicInStage = relicInStage
			heroShop.Relics[itemIndex].State = uint32(pb.BattleShopItemState_BATTLE_SHOP_ITEM_SOLD_OUT)
		} else if itemType == uint32(pb.ShopItemType_SHOP_ITEM_TYPE_POTION) {
			if _, ok := myHero.GetRelic(relic.MpLimitAndNoPotion); ok {
				result = csv.ERRCODE_BATTLE_SHOP_CANNOT_BUY_POTION_WITH_FUNNEL_RELIC
				return
			}
			if len(myHero.Potions) >= int(myHero.PotionsMaxNum) {
				result = csv.ERRCODE_BATTLE_POTION_OUT_OF_RANGE
				return
			}
			err := stageOne.purchasePotionHeroInStageWriter(myHero, item.CurrentPrice, item.ItemID)
			if err != nil {
				result = csv.ERRCODE_SYS_INTERNAL_ERROR
				return //err
			}
			heroShop.Potions[itemIndex].State = uint32(pb.BattleShopItemState_BATTLE_SHOP_ITEM_SOLD_OUT)
		}
		deliverymanRelic := false
		if deliverymanRelic {
			//refresh
			refreshItem, err := heroShop.RefreshItem(myHero, 1, stageOne.Level, itemType, itemIndex)
			if err != nil {
				result = csv.ERRCODE_BATTLE_SHOP_REFRESH_ITEM_FAILED
				return //err
			}
			if itemType == uint32(pb.ShopItemType_SHOP_ITEM_TYPE_CARD) {
				heroShop.Cards[itemIndex] = refreshItem
			} else if itemType == uint32(pb.ShopItemType_SHOP_ITEM_TYPE_RELIC) {
				heroShop.Relics[itemIndex] = refreshItem
			} else if itemType == uint32(pb.ShopItemType_SHOP_ITEM_TYPE_POTION) {
				heroShop.Potions[itemIndex] = refreshItem
			}
		}

		err := stageOne.purchaseShopWriter(nodeID, myHero.GetUID(), &heroShop)
		if err != nil {
			result = csv.ERRCODE_SYS_INTERNAL_ERROR
			return //err
		}
	case pb.ShopItemType_SHOP_ITEM_TYPE_DISCARD:
		if heroShop.DiscardRemainTimes <= 0 {
			result = csv.ERRCODE_BATTLE_SHOP_ALREADY_DISCARDED
			return //fmt.Errorf("already discard")
		}
		if myHero.Gold < heroShop.DiscardCost {
			result = csv.ERRCODE_BATTLE_SHOP_MONEY_NOT_ENOUGH
			return //fmt.Errorf("discard money not enough")
		}
		price = heroShop.DiscardCost
		err := stageOne.purchaseDiscardHeroInStageWriter(myHero, heroShop.DiscardCost, itemID)
		if err != nil {
			result = csv.ERRCODE_SYS_INTERNAL_ERROR
			return //err
		}

		heroShop.DiscardRemainTimes--
		err = stageOne.purchaseShopWriter(nodeID, myHero.GetUID(), &heroShop)
		if err != nil {
			result = csv.ERRCODE_SYS_INTERNAL_ERROR
			return //err
		}
	}
	//rsp.Result = &result
	goldNewVal := goldOldVal - price
	goldChange := pb.BattleAttrChange{OldValue: &goldOldVal, NewValue: &goldNewVal}
	rsp.GoldChange = &goldChange
	rsp.Shop = heroShop.ToClientShopProto()
	return //nil
}

func (stageOne *Stage) executeStageEventEffect(h *hero.InStage, effectID uint32, params []int32,
	result *pb.BattleEventResult) (eventStop bool, err error) {
	switch effectID {
	case csv.EVENT_EFFECT_GO_NEXT_FLOOR: // 去下一层
		eventStop = true
		return
	case csv.EVENT_EFFECT_CURRENT_HP: // 当前生命值
		if len(params) < 1 {
			err = fmt.Errorf("param not match got 0 need 1")
			return
		}

		//err = stageOne.changeHeroHp(h, params[0])
		deltaHp := params[0]
		if deltaHp < 0 && int32(h.HP)+deltaHp <= 0 {
			deltaHp = 1 - int32(h.HP) // 至少保留一点血量
			eventStop = true
		}
		h.ChangeHeroHP(deltaHp)
		if result.HpChange != nil {
			deltaHp += *result.HpChange
		}

		result.HpChange = &deltaHp
		return

	case csv.EVENT_EFFECT_CHANGE_HP_LIMIT: // 最大生命值
		if len(params) < 1 {
			err = fmt.Errorf("param not match got 0 need 1")
			return
		}
		hpChange := int32(0)
		deltaHpLimit := params[0]
		if deltaHpLimit < 0 && int32(h.HPLimit)+deltaHpLimit <= 0 {
			deltaHpLimit = 1 - int32(h.HPLimit)
			eventStop = true
		}
		hpChange, _ = h.ChangeHeroHpLimit(deltaHpLimit)
		deltaHp := hpChange
		if result.HpChange != nil {
			deltaHp += *result.HpChange
		}
		//deltaHpLimit := hpLimitChange
		if result.HpLimitChange != nil {
			deltaHpLimit += *result.HpLimitChange
		}

		result.HpChange = &deltaHp
		result.HpLimitChange = &deltaHpLimit
		return
	case csv.EVENT_EFFECT_CHANGE_CUR_HP_PER: // 当前生命百分比修改生命值
		if len(params) < 1 {
			err = fmt.Errorf("param not match got 0 need 1")
			return
		}
		deltaHp := int32(math.Ceil(float64(h.HP) * (float64(params[0]) / 100)))
		if deltaHp < 0 && int32(h.HP)+deltaHp <= 0 {
			deltaHp = 1 - int32(h.HP)
			eventStop = true
		}
		//err = stageOne.changeHeroHp(h, deltaHp)
		h.ChangeHeroHP(deltaHp)
		hpChange := deltaHp
		if result.HpChange != nil {
			hpChange += *result.HpChange
		}

		result.HpChange = &hpChange
		return
	case csv.EVENT_EFFECT_CHANGE_HP_LIMIT_PER: // 最大生命百分比修改生命值
		if len(params) < 1 {
			err = fmt.Errorf("param not match got 0 need 1")
			return
		}
		deltaHp := int32(math.Ceil(float64(h.HPLimit) * (float64(params[0]) / 100)))
		if deltaHp < 0 && int32(h.HP)+deltaHp <= 0 {
			deltaHp = 1 - int32(h.HP)
			eventStop = true
		}
		//err = stageOne.changeHeroHp(h, deltaHp)
		h.ChangeHeroHP(deltaHp)
		localDeltaHp := deltaHp
		if result.HpChange != nil {
			localDeltaHp += *result.HpChange
		}

		result.HpChange = &localDeltaHp
		return
	case csv.EVENT_EFFECT_CHANGE_GOLD: // 奥金修改
		if len(params) < 1 {
			err = fmt.Errorf("param not match got 0 need 1")
			return
		}
		//err = stageOne.changeHeroGold(h, params[0])
		h.ChangeHeroGold(params[0])
		if _, ok := h.GetRelic(relic.MpLimitAndNoGold); ok && params[0] > 0 {
			relicInStage := pb.BattleRelicInStage{}
			relicTypeID := relic.MpLimitAndNoGold
			relicInStage.RelicTypeId = &relicTypeID
			result.RelicInStage = append(result.RelicInStage, &relicInStage)
			return
		}
		deltaGold := params[0]
		if result.GoldChange != nil {
			deltaGold += *result.GoldChange
		}

		result.GoldChange = &deltaGold
		return
	case csv.EVENT_EFFECT_GET_SPECIFIED_ID_CARD_X: // 获得指定ID卡牌X张
		if len(params) < 2 {
			err = fmt.Errorf("param: %v not match, need 2", params)
			return
		}
		var newCards []card.Card
		newCards, err = h.AddSpecifiedIDCardN(uint32(params[0]), uint32(params[1]))
		if err != nil {
			return
		}
		for _, c := range newCards {
			result.GotCards = append(result.GotCards, c.ToClientProto())
		}
		return
	case csv.EVENT_EFFECT_GET_RANDOM_RELIC: // 获得随机遗物
		if len(params) < 2 {
			err = fmt.Errorf("param: %v not match, need 2", params)
			return
		}
		relicDropGroupID := uint32(params[0])
		num := uint32(params[1])
		dropGroupMap, ok := table.GetGroupRelicsByGroupId(relicDropGroupID)
		if !ok {
			log.Warn().Msgf("event relic drop group not found, groupID: %d", relicDropGroupID)
			return
		}
		relicIDs := hero.GetDropRelics(h, dropGroupMap, num)
		for _, relicID := range relicIDs {
			var relicInStage *pb.BattleRelicInStage
			relicInStage, err = h.AddRelic(relicID, stageOne.Difficulty, stageOne.Level)
			if err != nil {
				return
			}
			result.GotRelics = append(result.GotRelics, relicID)
			if relicInStage != nil {
				result.RelicInStage = append(result.RelicInStage, relicInStage)
			}
		}
		return
	case csv.EVENT_EFFECT_GET_SPECIFIED_RELIC: // 获得指定遗物
		if len(params) < 1 {
			err = fmt.Errorf("param not match got 0 need 1")
			return
		}
		relicID := uint32(params[0])
		if _, ok := h.GetRelic(relicID); ok {
			return
		}
		var relicInStage *pb.BattleRelicInStage
		relicInStage, err = h.AddRelic(relicID, stageOne.Difficulty, stageOne.Level)
		if err != nil {
			return
		}
		result.GotRelics = append(result.GotRelics, relicID)
		if relicInStage != nil {
			result.RelicInStage = append(result.RelicInStage, relicInStage)
		}
		return
	case csv.EVENT_EFFECT_REMOVE_SPECIFIED_RELIC: // 失去指定遗物
		if len(params) < 1 {
			err = fmt.Errorf("param not match got 0 need 1")
			return
		}
		relicID := uint32(params[0])
		h.RemoveSpecifiedRelic(relicID)

		result.RemoveRelics = append(result.RemoveRelics, relicID)
		return
	case csv.EVENT_EFFECT_GET_RANDOM_POTION_X: // 获得X瓶随机药水
		if len(params) < 1 {
			err = fmt.Errorf("param not match got 0 need 1")
			return
		}
		if _, ok := h.GetRelic(relic.MpLimitAndNoPotion); ok {
			relicTypeID := relic.MpLimitAndNoPotion
			relicInStage := pb.BattleRelicInStage{}
			relicInStage.RelicTypeId = &relicTypeID
			result.RelicInStage = append(result.RelicInStage, &relicInStage)
			return
		}
		var potions []uint32
		potions = h.AddRandomPotionN(uint32(params[0]))
		result.GotPotions = append(result.GotPotions, potions...)
		return
	case csv.EVENT_EFFECT_DISCARD_TYPEID_CARD_X: // 丢弃指定typeId卡牌
		if len(params) < 2 {
			err = fmt.Errorf("param not match got %d need 2", len(params))
			return
		}
		typeID := uint32(params[0])
		num := int(params[1])
		cards := h.GetAllTypeIDCards(typeID)
		if len(cards) > num {
			sortCardByLevel(cards)
		} else {
			num = len(cards)
		}
		for i := 0; i < num; i++ {
			removedCard, err := h.RemoveOneCard(cards[i].ID)
			if err != nil {
				log.Warn().Msgf("event remove cards: %v", err)
				continue
			}
			result.RemoveCards = append(result.RemoveCards, removedCard.ToClientProto())
		}

		return
	case csv.EVENT_EFFECT_DISCARD_TYPE_CARD_X: // 随机丢弃x张类型卡牌
		if len(params) < 2 {
			err = fmt.Errorf("param not match got %d need 2", len(params))
			return
		}
		cardType := uint32(params[0])
		num := int(params[1])
		cards := h.GetAllTypeCards(cardType)
		if len(cards) < num {
			num = len(cards)
		}

		for i := 0; i < num; i++ {
			if len(cards) <= 0 {
				break
			}
			randIndex := rand.Intn(len(cards))
			removedCard, err := h.RemoveOneCard(cards[randIndex].ID)
			cards = append(cards[:randIndex], cards[randIndex+1:]...)
			if err != nil {
				log.Warn().Msgf("event remove type card failed, %v", err)
				continue
			}
			result.RemoveCards = append(result.RemoveCards, removedCard.ToClientProto())
		}

		return
	case csv.EVENT_EFFECT_UPGRADE_TYPE_CARD_X: // 随机升级x张类型卡牌
		if len(params) < 2 {
			err = fmt.Errorf("param not match got %d need 2", len(params))
			return
		}
		cardType := uint32(params[0])
		num := int(params[1])
		cards := h.GetAllTypeCards(cardType)
		// remove cannot level up cards
		for i := 0; i < len(cards); i++ {
			if cards[i].Level >= cards[i].MaxLevel {
				cards = append(cards[:i], cards[i+1:]...)
			}
		}
		if len(cards) < num {
			num = len(cards)
		}
		for i := 0; i < num; i++ {
			if len(cards) <= 0 {
				break
			}
			randIndex := rand.Intn(len(cards))
			oldCard := cards[randIndex]
			newCard, err := h.LevelUpOneCard(oldCard.ID)
			cards = append(cards[:randIndex], cards[randIndex+1:]...)
			if err != nil {
				log.Warn().Msgf("event effect level up type cards failed, %v", err)
				continue
			}
			lvCard := pb.BattleEventCardLvUp{
				OldCard: oldCard.ToClientProto(),
				NewCard: newCard.ToClientProto(),
			}
			result.LvUpCards = append(result.LvUpCards, &lvCard)
		}

		return
	case csv.EVENT_EFFECT_REMOVE_ALL_HERO_GOLD:
		goldChange := -int32(h.Gold)
		h.Gold = 0
		result.GoldChange = &goldChange

		return
	case csv.EVENT_EFFECT_UPGRADE_ALL_ATTACK_CARD, csv.EVENT_EFFECT_UPGRADE_ALL_BLOCK_CARD: // 随机升级所有打击、防御卡牌
		var cards []card.Card
		for _, typeID := range params {
			typeIDCards := h.GetAllTypeIDCards(uint32(typeID))
			cards = append(cards, typeIDCards...)
		}

		for _, c := range cards {
			if c.Level >= c.MaxLevel {
				continue
			}
			newCard, err := h.LevelUpOneCard(c.ID)
			if err != nil {
				log.Warn().Msgf("event effect level up all attack/block card failed, %v", err)
				continue
			}
			lvCard := pb.BattleEventCardLvUp{
				OldCard: c.ToClientProto(),
				NewCard: newCard.ToClientProto(),
			}
			result.LvUpCards = append(result.LvUpCards, &lvCard)
		}

		return
	case csv.EVENT_EFFECT_GET_DROP_CARD:
		if len(params) < 2 {
			err = fmt.Errorf("param not match got %d need 2", len(params))
			return
		}
		dropGroupID := uint32(params[0])
		copies := uint32(params[1])
		cardResIDs := hero.GetDropCardsByGroupID(h, dropGroupID, copies)
		//var addCards []card.Card
		for _, resID := range cardResIDs {
			conf, _ := csv.TableCardsMap[int64(resID)]
			crd, ok := h.CardPool[cardDef.TypeID(conf.CardGroupID)]
			if !ok {
				log.Error().Msgf("card not found at pool: %d", crd.GetTypeID())
				continue
			}
			cardOne, err := h.AddOneCard(uint32(conf.CardGroupID), crd.GetCardStarLevel(), uint32(conf.Level))
			if err != nil {
				log.Error().Msgf("rest add card error, dropCard, typeID: %d, starLevel: %d, level: %d", conf.CardGroupID, crd.GetCardStarLevel(), conf.Level)
				continue
			}
			//addCards = append(addCards, cardOne)
			result.GotCards = append(result.GotCards, cardOne.ToClientProto())
		}
		return
	case csv.EVENT_EFFECT_UPGRADE_RANDOM_CARD_X:
		if len(params) < 1 {
			err = fmt.Errorf("param not match, got 0 need 1")
			return
		}
		var filteredCard []card.Card
		for _, c := range h.AllCards {
			if c.Level < c.MaxLevel {
				filteredCard = append(filteredCard, c)
			}
		}
		num := int(params[0])
		if len(filteredCard) < num {
			num = len(filteredCard)
		}
		for i := 0; i < num; i++ {
			randIndex := rand.Intn(len(filteredCard))
			crd := filteredCard[randIndex]
			newCard, err := h.LevelUpOneCard(crd.ID)
			if err != nil {
				log.Error().Msgf("level up card failed: %v", err)
				continue
			}
			lvCard := pb.BattleEventCardLvUp{
				OldCard: crd.ToClientProto(),
				NewCard: newCard.ToClientProto(),
			}
			result.LvUpCards = append(result.LvUpCards, &lvCard)
			filteredCard = append(filteredCard[:randIndex], filteredCard[randIndex+1:]...)
		}
		return
	case csv.EVENT_EFFECT_CHANGE_INIT_RELIC_TO_ANOTHER:
		if len(params) < 1 {
			err = fmt.Errorf("param not match, got 0 need 1")
			return
		}
		relicDropGroupID := uint32(params[0])
		dropGroupMap, ok := table.GetGroupRelicsByGroupId(relicDropGroupID)
		if !ok {
			log.Warn().Msgf("event relic drop group not found, groupID: %d", relicDropGroupID)
			return
		}
		relicIDs := hero.GetDropRelics(h, dropGroupMap, 1)
		for _, relicID := range relicIDs {
			_, err = h.AddRelic(relicID, stageOne.Difficulty, stageOne.Level)
			if err != nil {
				return
			}
			result.GotRelics = append(result.GotRelics, relicID)
		}
		conf, _ := csv.TableCareerInitialValueMap[int64(h.GetTypeID())]
		if _, ok := h.GetRelic(uint32(conf.InitRelic)); ok {
			h.RemoveSpecifiedRelic(uint32(conf.InitRelic))
			result.RemoveRelics = append(result.RemoveRelics, uint32(conf.InitRelic))
		}
		return
	default:
		err = fmt.Errorf("effect id : %d not found", effectID)
		return
	}
}

func sortCardByLevel(cards []card.Card) {
	for i := 0; i < len(cards)-1; i++ {
		for j := i + 1; j < len(cards); j++ {
			if cards[i].Level > cards[j].Level {
				cards[i], cards[j] = cards[j], cards[i]
			}
		}
	}
}
