package stage

import (
	"errors"
	"fmt"
	"github.com/rs/zerolog/log"
	"math"
	"math/rand"
	"shared/battle.etc/card"
	"shared/battle.etc/hero"
	"shared/battle.etc/node"
	"shared/battle.etc/potion"
	"shared/battle.etc/relic"
	"shared/battle.etc/stageDef"
	"shared/cardDef"
	"shared/csv"
	pb "shared/proto/client/battle"
	"shared/table"
)

// RestCardLevelUp - CMD battle_card_level_up_req
func (stageOne *Stage) RestCardLevelUp(myHero hero.InStage, nodeID uint32, cardID uint32) (result int32, newCardResID uint32, err error) {
	myNode, ok := stageOne.Nodes[nodeID]
	if !ok {
		return csv.ERRCODE_BATTLE_NODE_NOT_EXIST, newCardResID, err
	}
	log.Debug().Msgf("card level up debug cardID:%v, allCard:%v",
		cardID, myHero.AllCards)
	canRecover := myNode.Type == node.Rest || (myNode.Type == node.Unknown && myNode.UnShowType == node.Rest)
	if !canRecover {
		return csv.ERRCODE_BATTLE_NODE_NOT_EXIST, newCardResID, err
	}
	if myNode.Status != node.Finish {
		return csv.ERRCODE_BATTLE_NODE_NOT_FINISH, newCardResID, err
	}
	if myHero.FlagInBattle {
		return csv.ERRCODE_BATTLE_IS_EXIST, newCardResID, err
	}
	if myHero.NodeID != nodeID {
		return csv.ERRCODE_BATTLE_TOUCH_ERROR, newCardResID, err
	}
	myRestStatus, ok := myNode.RestStatus[myHero.GetUID()]
	if ok && myRestStatus {
		return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, newCardResID, err
	}
	myCard := card.Card{}
	myCardIndex := -1
	for index, c := range myHero.AllCards {
		if c.ID == cardID {
			myCardIndex = index
			myCard = c
			break
		}
	}
	if myCardIndex < 0 {
		return csv.ERRCODE_BATTLE_CARD_NOT_EXIST, newCardResID, err
	}
	newCard, err := myCard.LevelUp()
	if err != nil {
		return csv.ERRCODE_BATTLE_CARD_LEVEL_UP_ERR, newCardResID, err
	}
	newCardResID = newCard.ResID

	myNode.RestStatus[myHero.GetUID()] = true
	stageOne.Nodes[nodeID] = myNode
	// cardLevelUp
	_, err = myHero.RemoveOneCard(newCard.ID)
	if err != nil {
		return csv.ERRCODE_FAILED, newCardResID, errors.New("battle node cardLevelUpReward error, removeCard error")
	}
	err = myHero.AddOneCardStruct(newCard)
	if err != nil {
		return csv.ERRCODE_FAILED, newCardResID, errors.New("battle node cardLevelUpReward error, addOneCardStruct error")
	}
	// save node
	myNode.HeroUIDs[myHero.GetUID()] = true
	stageOne.Nodes[nodeID] = myNode
	// save hero
	stageOne.Heros[myHero.GetUID()] = myHero
	return csv.ERRCODE_SUCCESS, newCardResID, nil
}

// RestRecover - CMD battle_recover_req
func (stageOne *Stage) RestRecover(myHero hero.InStage, nodeID uint32) (int32, uint32, []pb.BattleRelicInStage, error) {
	myNode, ok := stageOne.Nodes[nodeID]
	if !ok {
		return csv.ERRCODE_BATTLE_NODE_NOT_EXIST, 0, nil, nil
	}
	canRecover := myNode.Type == node.Rest || (myNode.Type == node.Unknown && myNode.UnShowType == node.Rest)
	if !canRecover {
		return csv.ERRCODE_BATTLE_NODE_NOT_EXIST, 0, nil, nil
	}
	if myNode.Status != node.Finish {
		return csv.ERRCODE_BATTLE_NODE_NOT_FINISH, 0, nil, nil
	}
	if myHero.FlagInBattle {
		return csv.ERRCODE_BATTLE_IS_EXIST, 0, nil, nil
	}
	if myHero.NodeID != nodeID {
		return csv.ERRCODE_BATTLE_TOUCH_ERROR, 0, nil, nil
	}
	myRestStatus, ok := myNode.RestStatus[myHero.GetUID()]
	if ok && myRestStatus {
		return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, 0, nil, nil
	}

	// remove reward
	myNode.RestStatus[myHero.GetUID()] = true
	stageOne.Nodes[nodeID] = myNode
	// recover
	hpUp := uint32(float32(myHero.HPLimit)*0.3) + myHero.RestRecoverHpAdd
	if (myHero.HP + hpUp) > myHero.HPLimit {
		myHero.HP = myHero.HPLimit
	} else {
		myHero.HP += hpUp
	}

	var addCards []card.Card
	if _, ok := myHero.GetRelic(relic.MoreCardAfterRecoverHpInRest); ok {
		basic, _, _, ok := relic.GetRelicBasic(relic.MoreCardAfterRecoverHpInRest)
		if ok {
			for i := 0; i < basic; i++ {
				// same as drop from enemy
				dropCards := hero.GetDropCards(&myHero, stageOne.Difficulty, stageOne.Level, csv.DROP_FROM_ENEMY, 3)
				for _, resID := range dropCards {
					conf, _ := csv.TableCardsMap[int64(resID)]
					crd, ok := myHero.CardPool[cardDef.TypeID(conf.CardGroupID)]
					if !ok {
						log.Error().Msgf("card not found at pool: %d", crd.GetTypeID())
						continue
					}
					cardOne, err := myHero.AddOneCard(uint32(conf.CardGroupID), crd.GetCardStarLevel(), uint32(conf.Level))
					if err != nil {
						log.Error().Msgf("rest add card error, dropCard, typeID: %d, starLevel: %d, level: %d", conf.CardGroupID, crd.GetCardStarLevel(), conf.Level)
						continue
					}
					addCards = append(addCards, cardOne)
				}
			}
		}
	}
	// save node
	myNode.HeroUIDs[myHero.GetUID()] = true
	stageOne.Nodes[nodeID] = myNode
	// save hero
	stageOne.Heros[myHero.GetUID()] = myHero
	var stageRelicsInfo []pb.BattleRelicInStage
	if len(addCards) > 0 {
		relicID := uint32(relic.MoreCardAfterRecoverHpInRest)
		gotCards := make([]*pb.BattleCard, len(addCards))
		for i, c := range addCards {
			gotCards[i] = c.ToClientProto()
		}
		relicInStage := pb.BattleRelicInStage{
			RelicTypeId: &relicID,
			GotCard:     gotCards,
		}
		stageRelicsInfo = append(stageRelicsInfo, relicInStage)
	}
	return csv.ERRCODE_SUCCESS, myHero.HP, stageRelicsInfo, nil
}

// ChooseReward - CMD battle_choice_reward_req
func (stageOne *Stage) ChooseReward(myHero hero.InStage, nodeID uint32,
	chooseRewardParam stageDef.ChooseRewardParam, reply *stageDef.ChooseRewardReply) (int32, error) {
	log.Debug().Msgf("choice Reward : %v", chooseRewardParam)
	reward := node.Reward{}
	if nodeID == 0 {
		if myHero.NodeID != nodeID {
			return csv.ERRCODE_BATTLE_TOUCH_ERROR, nil
		}
		initC, ok := stageOne.InitConfigMap[myHero.GetUID()]
		if !ok || initC.Type != 2 {
			return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, nil
		}
		reward = initC.Reward
	} else {
		myNode, ok := stageOne.Nodes[nodeID]
		if !ok {
			return csv.ERRCODE_BATTLE_NODE_NOT_EXIST, nil
		}
		reply.NewGold = myHero.Gold
		canRecover := myNode.Type == node.Treasure || myNode.UnShowType == node.Treasure
		if !canRecover {
			return csv.ERRCODE_BATTLE_NODE_NOT_EXIST, nil
		}
		if myNode.Status != node.Finish {
			return csv.ERRCODE_BATTLE_NODE_NOT_FINISH, nil
		}
		if myHero.FlagInBattle {
			return csv.ERRCODE_BATTLE_IS_EXIST, nil
		}
		if myHero.NodeID != nodeID {
			return csv.ERRCODE_BATTLE_TOUCH_ERROR, nil
		}
		reward, ok = myNode.RewardS[myHero.GetUID()]
		if !ok {
			return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, nil
		}
	}
	rewardBag, ok := reward.RewardBagS[chooseRewardParam.RewardBagUID]
	if !ok {
		return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, nil
	}
	switch chooseRewardParam.RewardType {
	case pb.BattleRewardEnum_BReward_Card: // 卡牌
		findReward := false
		for _, rewardItem := range rewardBag.ItemS {
			if rewardItem.CardResID == chooseRewardParam.ItemID {
				findReward = true
				break
			}
		}
		if !findReward {
			return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, nil
		}
		c, ok := csv.TableCardsMap[int64(chooseRewardParam.ItemID)]
		if !ok {
			return csv.ERRCODE_BATTLE_CARD_NOT_EXIST, nil
		}
		cardTypeID := uint32(c.CardGroupID)
		cardLevel := uint32(c.Level)
		// remove reward
		delete(reward.RewardBagS, chooseRewardParam.RewardBagUID)
		if nodeID > 0 {
			myNode := stageOne.Nodes[nodeID]
			myNode.RewardS[myHero.GetUID()] = reward
			stageOne.Nodes[nodeID] = myNode
		} else {
			initC := stageOne.InitConfigMap[myHero.GetUID()]
			initC.Reward = reward
			stageOne.InitConfigMap[myHero.GetUID()] = initC
		}
		// getCardStar
		cardStar := uint32(1)
		for _, c := range myHero.AllCards {
			if c.TypeID == cardTypeID {
				cardStar = c.Star
				break
			}
		}
		// add card
		_, err := myHero.AddOneCard(cardTypeID, cardStar, cardLevel)
		if err != nil {
			return csv.ERRCODE_FAILED, fmt.Errorf("rewardCardWriter error %v", err)
		}
		// save hero
		stageOne.Heros[myHero.GetUID()] = myHero
		return csv.ERRCODE_SUCCESS, nil
	case pb.BattleRewardEnum_BReward_Relic: // 遗物
		findReward := false
		for _, rewardItem := range rewardBag.ItemS {
			if rewardItem.RelicTypeID == chooseRewardParam.ItemID {
				findReward = true
				break
			}
		}
		if !findReward {
			return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, nil
		}
		// remove reward
		delete(reward.RewardBagS, chooseRewardParam.RewardBagUID)
		if nodeID > 0 {
			myNode := stageOne.Nodes[nodeID]
			myNode.RewardS[myHero.GetUID()] = reward
			stageOne.Nodes[nodeID] = myNode
		} else {
			initC := stageOne.InitConfigMap[myHero.GetUID()]
			initC.Reward = reward
			stageOne.InitConfigMap[myHero.GetUID()] = initC
		}
		// add relic
		relicInStageOne, err := myHero.AddRelic(chooseRewardParam.ItemID, stageOne.Difficulty, stageOne.Level)
		if err != nil {
			return csv.ERRCODE_FAILED, fmt.Errorf("rewardRelicWriter error %v", err)
		}
		// save hero
		stageOne.Heros[myHero.GetUID()] = myHero
		reply.NewGold = myHero.Gold
		if relicInStageOne != nil {
			reply.RelicInStage = append(reply.RelicInStage, *relicInStageOne)
		}
		return csv.ERRCODE_SUCCESS, nil
	case pb.BattleRewardEnum_BReward_Potion: // 药剂
		findReward := false
		for _, rewardItem := range rewardBag.ItemS {
			if rewardItem.PotionTypeID == chooseRewardParam.ItemID {
				findReward = true
				break
			}
		}
		if !findReward {
			return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, nil
		}
		if uint32(len(myHero.Potions)) >= myHero.PotionsMaxNum {
			return csv.ERRCODE_BATTLE_POTION_OUT_OF_RANGE, nil
		}
		// remove reward
		delete(reward.RewardBagS, chooseRewardParam.RewardBagUID)
		if nodeID > 0 {
			myNode := stageOne.Nodes[nodeID]
			myNode.RewardS[myHero.GetUID()] = reward
			stageOne.Nodes[nodeID] = myNode
		} else {
			initC := stageOne.InitConfigMap[myHero.GetUID()]
			initC.Reward = reward
			stageOne.InitConfigMap[myHero.GetUID()] = initC
		}
		// add potion
		err := myHero.AddPotion(potion.Potion(chooseRewardParam.ItemID))
		if err != nil {
			return csv.ERRCODE_FAILED, fmt.Errorf("rewardPotionWriter err %v", err)
		}
		// save hero
		stageOne.Heros[myHero.GetUID()] = myHero
		return csv.ERRCODE_SUCCESS, nil
	case pb.BattleRewardEnum_BReward_Gold: // 金币
		findReward := false
		for _, rewardItem := range rewardBag.ItemS {
			if rewardItem.Gold == chooseRewardParam.ItemID {
				findReward = true
				break
			}
		}
		if !findReward {
			return csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, nil
		}
		// remove reward
		delete(reward.RewardBagS, chooseRewardParam.RewardBagUID)
		if nodeID > 0 {
			myNode := stageOne.Nodes[nodeID]
			myNode.RewardS[myHero.GetUID()] = reward
			stageOne.Nodes[nodeID] = myNode
		} else {
			initC := stageOne.InitConfigMap[myHero.GetUID()]
			initC.Reward = reward
			stageOne.InitConfigMap[myHero.GetUID()] = initC
		}
		// add gold
		myHero.Gold += chooseRewardParam.ItemID
		// save hero
		stageOne.Heros[myHero.GetUID()] = myHero
		reply.NewGold = myHero.Gold
		return csv.ERRCODE_SUCCESS, nil
	default:
		return csv.ERRCODE_FAILED, nil
	}
}

// OpenReward - CMD battle_reward_open_req
func (stageOne *Stage) OpenReward(myHero hero.InStage, nodeID uint32) (*pb.BattleRelicInStage, int32, error) {
	myNode, ok := stageOne.Nodes[nodeID]
	if !ok {
		return nil, csv.ERRCODE_BATTLE_NODE_NOT_EXIST, nil
	}
	_, ok = myNode.RewardS[myHero.GetUID()]
	if !ok {
		return nil, csv.ERRCODE_BATTLE_REWARD_NOT_EXIST, nil
	}

	if myNode.Type == node.Treasure || (myNode.Type == node.Unknown && myNode.UnShowType == node.Treasure) {
		// do relic
		_, ok = myHero.GetRelic(relic.MpLimitAndRandomCurseWhenOpenTreasure)
		if ok {
			_, copies, _, ok := relic.GetRelicBasic(relic.MpLimitAndRandomCurseWhenOpenTreasure)
			curseCardResIds := table.GetAllCurseCardResIds()
			if ok && copies > 0 && len(curseCardResIds) > 0 {
				var addedCurseCards []card.Card
				for i := 0; i < copies; i++ {
					c, _ := csv.TableCardsMap[int64(curseCardResIds[rand.Intn(len(curseCardResIds))])]
					curseCard, err := myHero.AddOneCard(uint32(c.CardGroupID), 1, 1)
					if err != nil {
						return nil, csv.ERRCODE_FAILED, fmt.Errorf("relic.MpLimitAndRandomCurseWhenOpenTreasure add curse card failed, %s",
							err.Error())
					}
					addedCurseCards = append(addedCurseCards, curseCard)
				}
				stageOne.Heros[myHero.GetUID()] = myHero
				// save
				relicTypeID := uint32(relic.MpLimitAndRandomCurseWhenOpenTreasure)
				relicInStage := pb.BattleRelicInStage{}
				relicInStage.RelicTypeId = &relicTypeID
				for _, c := range addedCurseCards {
					relicInStage.GotCard = append(relicInStage.GotCard, c.ToClientProto())
				}
				return &relicInStage, csv.ERRCODE_SUCCESS, nil
			}
		}
	}
	return nil, csv.ERRCODE_SUCCESS, nil
}

// ChooseEvent for event
func (stageOne *Stage) ChooseEvent(myHero hero.InStage, nodeID uint32, optionIndex uint32,
	cardIDs []uint32) (eventResult pb.BattleEventResult, linkageEventID uint32, eventStop bool, result int32) {
	log.Debug().Msgf("choose event: optionIndex: %d", optionIndex)
	result = csv.ERRCODE_SUCCESS

	eventID := myHero.CurEventID

	event, ok := table.GetStageEvent(eventID)
	if !ok {
		result = csv.ERRCODE_EVENT_NOT_EXIST
		return
	}

	if myHero.CurProcess > 0 && int(myHero.CurProcess) >= len(event.EffectIds) {
		log.Error().Msgf("cur process: %d, event.effectIds: %v", myHero.CurProcess, event.EffectIds)
		result = csv.ERRCODE_EVENT_EFFECT_FINISHED
		return
	}
	log.Debug().Msgf("hero cur event process : %d", myHero.CurProcess)
	if len(event.EffectIds) > 0 {
		log.Debug().Msgf("eventID: %d, effectIds: %v", eventID, event.EffectIds)
		processEffectID := event.EffectIds[myHero.CurProcess]
		effect, _ := csv.StageEventEffectMap[int64(processEffectID)]
		if effect.Effect_Type == csv.EVENT_EFFECT_UPGRADE_ONE_CARD || effect.Effect_Type == csv.EVENT_EFFECT_DISCARD_ONE_CARD {
			if len(cardIDs) != effect.Param1 {
				log.Error().Msgf("event choose card, cardIds: %v, effect.param1: %d", cardIDs, effect.Param1)
				result = csv.ERRCODE_EVENT_PARAM_NOT_MATCH
				return
			}
			if effect.Effect_Type == csv.EVENT_EFFECT_UPGRADE_ONE_CARD {
				for _, cid := range cardIDs {
					c, ok := myHero.GetCard(cid)
					if ok {
						newCard, err := c.LevelUp()
						if err != nil {
							result = csv.ERRCODE_BATTLE_CARD_LEVEL_UP_ERR
							return
						}
						_, err = myHero.RemoveOneCard(newCard.ID)
						if err != nil {
							log.Error().Msgf("event add card, remove card first, %v", err)
							result = csv.ERRCODE_SYS_INTERNAL_ERROR
							return
						}
						err = myHero.AddOneCardStruct(newCard)
						if err != nil {
							log.Error().Msgf("event add card: %v", err)
							result = csv.ERRCODE_SYS_INTERNAL_ERROR
							return
						}
						eventResult.LvUpCards = append(eventResult.LvUpCards, &pb.BattleEventCardLvUp{
							OldCard: c.ToClientProto(),
							NewCard: newCard.ToClientProto(),
						})
					}
				}
			} else if effect.Effect_Type == csv.EVENT_EFFECT_DISCARD_ONE_CARD {
				for _, cid := range cardIDs {
					removedCard, err := myHero.RemoveOneCard(cid)
					if err != nil {
						log.Error().Msgf("event remove card: %v", err)
						result = csv.ERRCODE_EVENT_REMOVE_CARD_FAILED
						return
					}
					eventResult.RemoveCards = append(eventResult.RemoveCards, removedCard.ToClientProto())
				}
			}
			err := stageOne.changeNodeStatusFromNormal2FinishWriter(stageOne.Nodes[nodeID], &myHero)
			if err != nil {
				return
			}
			eventStop = true
			myHero.ChangeHeroEventFlag(false)
			stageOne.Heros[myHero.GetUID()] = myHero
			return
		}
	}

	// effect
	//canExecute := checkEventEffectCanExecute(&myHero, event.EffectIds)
	//if !canExecute {
	//	result = csv.ERRCODE_EVENT_EFFECT_CANNOT_EXECUTE
	//	return
	//}

	if optionIndex == 0 || int(optionIndex) > len(event.LinkEvents) { // optionIndex [1,2,3...len(event.LinkEvents)]
		log.Debug().Msgf("choose event illegal option, optionIndex: %d, eventID: %d", optionIndex, eventID)
		result = csv.ERRCODE_EVENT_ILLEGAL_OPTION
		return
	}

	// next event
	option, ok := event.LinkEvents[optionIndex]
	if !ok {
		log.Error().Msgf("choose event, branch event not exist, eventID: %d, optionIndex: %d", eventID, optionIndex)
		result = csv.ERRCODE_EVENT_NOT_EXIST
		return
	}
	available := checkEventCanChoose(&myHero, &option)
	if !available {
		log.Debug().Msgf("choose event optionIndex unsatisfied, optionIndex: %d, eventID: %d", optionIndex, eventID)
		result = csv.ERRCODE_EVENT_OPTION_UNSATISFIED
		return
	}

	r := rand.Intn(100) + 1
	var randIndex int
	for i, p := range option.Probability {
		if r <= p {
			randIndex = i
			break
		}
		r -= p
	}

	linkageEventID = uint32(option.EventIds[randIndex])
	linkageEvent, ok := table.GetStageEvent(linkageEventID)
	if !ok {
		result = csv.ERRCODE_EVENT_NOT_EXIST
		return
	}
	var err error
	effectStop := false
	for i := int(myHero.CurProcess); i < len(linkageEvent.EffectIds); i++ {
		effectID := linkageEvent.EffectIds[i]
		effect, _ := csv.StageEventEffectMap[int64(effectID)]
		if effect.Effect_Type == csv.EVENT_EFFECT_UPGRADE_ONE_CARD || effect.Effect_Type == csv.EVENT_EFFECT_DISCARD_ONE_CARD {
			myHero.CurEventID = linkageEventID
			stageOne.Heros[myHero.GetUID()] = myHero
			return
		}
		var params []int32
		if effect.Param1 != 0 {
			params = append(params, int32(effect.Param1))
		}
		if effect.Param2 != 0 {
			params = append(params, int32(effect.Param2))
		}
		if effect.Param3 != 0 {
			params = append(params, int32(effect.Param3))
		}
		if effect.Effect_Type == csv.EVENT_EFFECT_START_A_WAR {
			if len(params) < 2 {
				result = csv.ERRCODE_EVENT_PARAM_NOT_MATCH
				log.Error().Msgf("event start a war param not enough")
				return
			}
			nd := stageOne.Nodes[nodeID]
			err = stageOne.changeMeetNode2Battle(&nd, &myHero, uint32(params[0]), uint32(params[1]))
			if err != nil {
				log.Error().Msgf("event change meet node to battle: %v", err)
				result = csv.ERRCODE_SYS_INTERNAL_ERROR
				return
			}

			return
		} else if effect.Effect_Type == csv.EVENT_EFFECT_GAIN_REWARD {
			if len(params) < 2 {
				result = csv.ERRCODE_EVENT_PARAM_NOT_MATCH
				log.Error().Msgf("params not enough")
				return
			}
			nd := stageOne.Nodes[nodeID]

			//eventStop = true
			nd.UnShowType = node.Treasure
			relicInStage, err := stageOne.addNodeHeroEventEffectReward(&nd, &myHero, uint32(params[0]), uint32(params[1]))
			if err != nil {
				result = csv.ERRCODE_SYS_INTERNAL_ERROR
				log.Error().Msgf("event add node hero effect reward: %v", err)
				return
			}
			reward, ok := nd.RewardS[myHero.GetUID()]
			if ok {
				eventResult.ChoiceReward = reward.ToClientProto()
			}
			if relicInStage != nil {
				eventResult.RelicInStage = append(eventResult.RelicInStage, relicInStage)
			}
			myHero.ChangeHeroEventFlag(false)
			stageOne.Heros[myHero.GetUID()] = myHero
			return
		}
		effectStop, err = stageOne.executeStageEventEffect(&myHero, uint32(effect.Effect_Type), params, &eventResult)
		if err != nil {
			log.Error().Msgf("event effect execute failed: %v", err)
			result = csv.ERRCODE_SYS_INTERNAL_ERROR
			return
		}
		myHero.CurProcess++
		if effectStop == true {
			break
		}
	}
	myHero.CurProcess = 0

	myHero.CurEventID = linkageEventID
	if effectStop || len(linkageEvent.LinkEvents) <= 0 {
		eventStop = true
		myHero.ChangeHeroEventFlag(false)
		err = stageOne.changeNodeStatusFromNormal2FinishWriter(stageOne.Nodes[nodeID], &myHero)
		if err != nil {
			result = csv.ERRCODE_SYS_INTERNAL_ERROR
			return
		}
	} else {
		stageOne.Heros[myHero.GetUID()] = myHero
	}

	return
}

// ChooseInitEvent init event
func (stageOne *Stage) ChooseInitEvent(myHero hero.InStage, eventID uint32, param uint32) (eventResult pb.BattleEventResult,
	result int32) {
	initConfig, ok := stageOne.InitConfigMap[myHero.GetUID()]
	if !ok || initConfig.Type != 1 || stageOne.Level != 1 || myHero.NodeID != 0 { // type == 1 means init event
		result = csv.ERRCODE_STAGE_INIT_EVENT_NOT_EXIST
		return
	}
	exist := false
	for _, e := range initConfig.EventIDs {
		if eventID == e {
			exist = true
			break
		}
	}
	if !exist {
		result = csv.ERRCODE_STAGE_INIT_EVENT_ID_ILLEGAL
		return
	}
	event, _ := csv.StageInitEventMap[int64(eventID)]
	effect, _ := csv.StageEventEffectMap[int64(event.Effect_ID)]
	var params []int32
	if effect.Param1 != 0 {
		params = append(params, int32(effect.Param1))
	}
	if effect.Param2 != 0 {
		params = append(params, int32(effect.Param2))
	}
	if effect.Param3 != 0 {
		params = append(params, int32(effect.Param3))
	}
	_, err := stageOne.executeStageEventEffect(&myHero, uint32(effect.Effect_Type), params, &eventResult)
	if err != nil {
		log.Error().Msgf("init event effect execute failed: %v", err)
		result = csv.ERRCODE_SYS_INTERNAL_ERROR
		return
	}
	delete(stageOne.InitConfigMap, myHero.GetUID())
	stageOne.Heros[myHero.GetUID()] = myHero
	result = csv.ERRCODE_SUCCESS
	return
}

func checkEventEffectCanExecute(h *hero.InStage, effectConfigIds []int) bool {
	for _, id := range effectConfigIds {
		effect, ok := csv.StageEventEffectMap[int64(id)]
		if !ok {
			log.Error().Msgf("event effect table id not found: %d", id)
			continue
		}

		switch effect.Effect_Type {
		case csv.EVENT_EFFECT_CURRENT_HP:
			if effect.Param1 == 0 {
				return false
			}
			newHp := int32(h.HP) + int32(effect.Param1)
			if newHp <= 0 {
				return false
			}
		case csv.EVENT_EFFECT_CHANGE_HP_LIMIT:
			if effect.Param1 == 0 {
				return false
			}
			newHpLimit := int32(h.HPLimit) + int32(effect.Param1)
			if newHpLimit <= 0 {
				return false
			}
		case csv.EVENT_EFFECT_CHANGE_CUR_HP_PER:
			if effect.Param1 == 0 {
				return false
			}
			deltaHp := int32(math.Ceil(float64(h.HP) * (float64(effect.Param1) / 100)))
			newHp := int32(h.HP) + deltaHp
			if newHp <= 0 {
				return false
			}
		case csv.EVENT_EFFECT_CHANGE_HP_LIMIT_PER: // 最大生命百分比修改生命值
			if effect.Param1 == 0 {
				return false
			}
			deltaHp := int32(math.Ceil(float64(h.HPLimit) * (float64(effect.Param1) / 100)))
			newHp := int32(h.HP) + deltaHp
			if newHp <= 0 {
				return false
			}
		}
	}
	return true
}

func checkEventCanChoose(h *hero.InStage, option *table.EventLinkage) bool {
	switch option.Condition {
	case csv.EVENT_CONDITION_NONE:
		return true
	case csv.EVENT_CONDITION_GOLD_NUM:
		if int(h.Gold) < option.Param {
			return false
		}
	case csv.EVENT_CONDITION_HP_NUM:
		if int(h.HP) < option.Param {
			return false
		}
	case csv.EVENT_CONDITION_HP_LIMIT_NUM:
		if int(h.HPLimit) < option.Param {
			return false
		}
	case csv.EVENT_CONDITION_RELIC_EXIST:
		if _, ok := h.GetRelic(uint32(option.Param)); !ok {
			return false
		}
	case csv.EVENT_CONDITION_TYPEID_CARD_EXIST:
		cards := h.GetAllTypeIDCards(uint32(option.Param))
		if len(cards) <= 0 {
			return false
		}
	case csv.EVENT_CONDITION_HURT_VALUE_CARD_EXIST:
		exist := false
		for _, c := range h.AllCards {
			crd, ok := csv.TableCardsMap[int64(c.ResID)]
			if ok && crd.Init_Hurt > option.Param {
				exist = true
				break
			}
		}
		if !exist {
			return false
		}
	default:
	}
	return true
}
