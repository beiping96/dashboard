package stage

import (
	"errors"
	"fmt"
	"github.com/rs/zerolog/log"
	"shared/battle.etc/battle"
	"shared/battle.etc/card"
	"shared/battle.etc/hero"
	"shared/battle.etc/node"
	"shared/battle.etc/potion"
	"shared/battle.etc/relic"
	"shared/battle.etc/shop"
	"shared/battle.etc/stageDef"
	pb "shared/proto/client/battle"
)

// BattleOverWriterWithCheck rewrite heroInStage after battle over
func (stage *Stage) BattleOverWriterWithCheck(nodeID uint32, winnerS []*hero.InStage, loserS []*hero.InStage,
	inChan chan<- *stageDef.In) (rewardMap map[uint64]node.Reward, skipReward bool) {
	stageUID := stage.UID
	rewardMap = make(map[uint64]node.Reward)
	// write winner
	for _, newHeroInStage := range winnerS {
		oldHeroInStage, ok := stage.Heros[newHeroInStage.GetUID()]
		if !ok {
			log.Error().Msgf("battle %v:%v error, battle over writer can't found oldHero in stage heroUID:%v",
				stageUID, nodeID, newHeroInStage.GetUID())
			continue
		}
		if oldHeroInStage.FlagInBattle == false {
			log.Error().Msgf("battle %v:%v error, battle over writer oldHeroInBattleFlag == false heroUID:%v",
				stageUID, nodeID, newHeroInStage.GetUID())
			continue
		}
		reward, err := stage.battleOverWriter(nodeID, *newHeroInStage, true)
		if err != nil {
			log.Error().Msgf("battle %v:%v error, battle over writer skip hero %v reward",
				stageUID, nodeID, newHeroInStage.GetUID())
			continue
		}
		rewardMap[newHeroInStage.GetUID()] = reward
	}
	// write loser
	for _, newHeroInStage := range loserS {
		oldHeroInStage, ok := stage.Heros[newHeroInStage.GetUID()]
		if !ok {
			log.Error().Msgf("battle %v:%v error, battle over writer can't found oldHero in stage heroUID:%v",
				stageUID, nodeID, newHeroInStage.GetUID())
			continue
		}
		if oldHeroInStage.FlagInBattle == false {
			log.Error().Msgf("battle %v:%v error, battle over writer oldHeroInBattleFlag == false heroUID:%v",
				stageUID, nodeID, newHeroInStage.GetUID())
			continue
		}
		_, err := stage.battleOverWriter(nodeID, *newHeroInStage, false)
		if err != nil {
			log.Error().Msgf("battle %v:%v error, battle over writer skip hero %v",
				stageUID, nodeID, newHeroInStage.GetUID())
		}
	}
	// Try stage destroy
	bossOverAndWin := false
	lastNode := false
	newResID := uint32(0)
	if stage.Nodes[nodeID].Type == node.Boss && len(winnerS) > 0 {
		bossOverAndWin = true
		localNewResID, ok := getRandomStageSourceID(stage.Level+1, stage.Mode, stage.Difficulty)
		if !ok {
			// if don't have next
			lastNode = true
			// skip battleReward
			skipReward = true
		} else {
			newResID = localNewResID
		}
	}
	go stage.TryDestroy(lastNode, bossOverAndWin, newResID, inChan, rewardMap)
	return
}
func (stage *Stage) battleOverWriter(nodeID uint32, newHeroInStage hero.InStage, win bool) (node.Reward, error) {
	newHeroInStage.FlagInBattle = false
	newHeroInStage.FlagInEvent = false
	stageUID := stage.UID
	reward := node.Reward{}
	heroID := newHeroInStage.GetUID()
	stage.Heros[heroID] = newHeroInStage

	if stage.Nodes[nodeID].Status != node.InBattle {
		log.Error().Msgf("battle %v:%v error, battle over writer nodeStatus is not inBattle",
			stageUID, nodeID)
		return reward, nil
	}
	if win {
		// win move to next node
		err := stage.moveForward(heroID, nodeID)
		if err != nil {
			return reward, err
		}
		newNode := stage.Nodes[nodeID]
		reward = newNode.RewardS[heroID]
		newNode.Status = node.Finish
		newNode.UnShowType = node.Treasure
		stage.Nodes[nodeID] = newNode
		return reward, nil
	}
	// lose move back to node
	err := stage.moveBackward(heroID, nodeID)
	if err != nil {
		return reward, err
	}
	newNode := stage.Nodes[nodeID]
	newNode.Status = node.Normal
	stage.Nodes[nodeID] = newNode
	return reward, nil
}

func (stage *Stage) addNewNodeWriter(newNode *node.Node) error {
	_, ok := stage.Nodes[newNode.ID]
	if ok {
		return fmt.Errorf("cannot add the node for it has exist")
	}
	stage.Nodes[newNode.ID] = *newNode
	return nil
}

func (stage *Stage) changeNodeStatusFromNormal2FinishWriter(newNode node.Node, myHero *hero.InStage) error {
	heroUID := myHero.GetUID()
	newNode.Status = node.Finish
	newNode.HeroUIDs[heroUID] = true
	stage.Nodes[newNode.ID] = newNode
	myHero.NodeID = newNode.ID
	stage.Heros[heroUID] = *myHero
	return nil
}

func (stage *Stage) tryTouchBattleNode(myNode node.Node, myHero hero.InStage,
	stageInChan chan<- *stageDef.In, battleStartCallback func(chan<- *stageDef.BattleOperationParam, uint64)) (*pb.BattleData, error) {
	stageUID := stage.UID
	heroUID := myHero.GetUID()
	nodeID := myNode.ID
	log.Debug().Msgf("stage debug touch try touch battle Node %v", stageUID)

	myNode.Status = node.InBattle
	myNode.InBattleHeroUIDs[heroUID] = true
	stage.Nodes[nodeID] = myNode
	myHero.FlagInBattle = true
	stage.Heros[heroUID] = myHero

	battleData, battleInChan, err := battle.New(stage.UID, stage.Difficulty, stageInChan, &myNode, myHero, true, battle.GetPVEDefaultConfig(true))
	if err != nil {
		return nil, err
	}
	battleStartCallback(battleInChan, myHero.PlayerID)
	return battleData.ToClientProto(myHero), nil
}

// TryDestroy try destroy stage
func (stage *Stage) TryDestroy(lastNode bool, bossOverAndWin bool, nextResID uint32,
	inChan chan<- *stageDef.In, rewardMap map[uint64]node.Reward) {
	stageUID := stage.UID
	log.Debug().Msgf("stage try Destroy %v", stageUID)
	tryFunc := func(overType int) {
		if overType != 2 {
			// del stage
			inChan <- &stageDef.In{
				Type:     stageDef.DelStage,
				StageUID: stage.UID,
			}
		} else {
			// stage to next res id
			err := stage.changeResID(nextResID, rewardMap)
			if err != nil {
				log.Error().Msgf("stage destroy to next stage error : %v", err)
			}
		}
		// notice stage over
		err := stageResultNotice(stage, uint32(overType), inChan)
		if err != nil {
			log.Error().Msgf("stage destroy to next stage error : %v", err)
		}
	}
	if bossOverAndWin && lastNode {
		tryFunc(1)
		return
	}
	if bossOverAndWin {
		tryFunc(2)
		return
	}
	for _, heroOne := range stage.Heros {
		if heroOne.FlagInBattle {
			return
		}
		if heroOne.FlagQuit {
			continue
		}
		return
	}
	tryFunc(3)
	return
}
func (stage *Stage) purchaseShopWriter(nodeID uint32, heroUID uint64, s *shop.Shop) error {
	nd, ok := stage.Nodes[nodeID]
	if !ok {
		return fmt.Errorf("node not found")
	}
	nd.ShopItems[heroUID] = *s
	stage.Nodes[nodeID] = nd
	return nil
}

func (stage *Stage) purchaseCardHeroInStageWriter(h *hero.InStage, moneyDelta uint32, cardTypeID, starLevel, cardLevel uint32) (newCard card.Card, err error) {
	if h.FlagInBattle {
		err = errors.New("battle node purchaseCard error, hero has FlagInBattle")
		return
	}

	h.Gold -= moneyDelta
	newCard, err = h.AddOneCard(cardTypeID, starLevel, cardLevel)
	if err != nil {
		return
	}

	stage.Heros[h.GetUID()] = *h
	return
}

func (stage *Stage) purchasePotionHeroInStageWriter(h *hero.InStage, moneyDelta uint32, potionID uint32) error {
	if h.FlagInBattle {
		return errors.New("battle node purchasePotion error, hero has FlagInBattle")
	}

	h.Gold -= moneyDelta
	h.Potions = append(h.Potions, potion.Potion(potionID))
	stage.Heros[h.GetUID()] = *h
	return nil
}

func (stage *Stage) purchaseRelicHeroInStageWriter(h *hero.InStage, moneyDelta uint32, relicTypeID uint32) (newRelic relic.Relic, relicInStage *pb.BattleRelicInStage, err error) {
	if h.FlagInBattle {
		err = errors.New("battle node purchaseRelic error, hero has FlagInBattle")
		return
	}
	h.Gold -= moneyDelta
	relicInStage, err = h.AddRelic(relicTypeID, stage.Difficulty, stage.Level)
	if err != nil {
		return
	}
	newRelic = h.Relics[relicTypeID]
	stage.Heros[h.GetUID()] = *h
	return
}

func (stage *Stage) purchaseDiscardHeroInStageWriter(h *hero.InStage, moneyDelta uint32, discardID uint32) error {
	if h.FlagInBattle {
		return errors.New("battle node purchaseRelic error, hero has FlagInBattle")
	}
	h.Gold -= moneyDelta
	h.DiscardTimes++
	_, err := h.RemoveOneCard(discardID)
	if err != nil {
		return err
	}
	stage.Heros[h.GetUID()] = *h
	return nil
}

func (stage *Stage) changeMeetNode2Battle(nd *node.Node, h *hero.InStage, monsterGroupID uint32, rewardRelicID uint32) (err error) {
	nd.UnShowType = node.Enemy
	monsters, err := node.GetEventMonsters(monsterGroupID, stage.Difficulty)
	if err != nil {
		return err
	}
	nd.MonsterGroupID = monsterGroupID
	nd.MonsterS = monsters

	reward := node.GetEventBattleReward(h, rewardRelicID)
	nd.RewardS[h.GetUID()] = reward

	stage.Nodes[nd.ID] = *nd
	return nil
}

func (stage *Stage) addNodeHeroEventEffectReward(nd *node.Node, h *hero.InStage, rewardType uint32,
	num uint32) (relicInStage *pb.BattleRelicInStage, err error) {
	err = stage.changeNodeStatusFromNormal2FinishWriter(*nd, h)
	if err != nil {
		return
	}
	newNode := stage.Nodes[nd.ID]
	reward, relicInStage, err := node.GetEventEffectReward(h, rewardType, num)
	if err != nil {
		return
	}

	newNode.RewardS[h.GetUID()] = reward

	stage.Nodes[nd.ID] = newNode
	return
}
