package stage

import (
	"encoding/xml"
	"fmt"
	"github.com/rs/zerolog/log"
	"io/ioutil"
	"math/rand"
	"os"
	"path/filepath"
	"shared/table"
	"strconv"
	"strings"
)

type resNode struct {
	NodeID    uint32 `xml:"nodeId,attr"`
	NodeType  uint32 `xml:"nodeType,attr"`
	Sort      uint32 `xml:"sort,attr"`
	Floor     uint32 `xml:"floor,attr"`
	Param1    string `xml:"param1,attr"`
	Param2    string `xml:"param2,attr"`
	Connect   string `xml:"connect,attr"`
	NextNodes []uint32
}

type resStage struct {
	StageSourceID uint32    `xml:"ID,attr"`
	Phase         uint32    `xml:"level,attr"` // 阶段
	Nodes         []resNode `xml:"nodeItem"`
}

var (
	resStageMap           map[uint32]resStage
	resStageSourceIDs     []uint32
	resStageSourceNodeMap map[uint32]map[uint32]resNode
)

// TODO
// change config add init it in server start
func init() {
	initStageMap()       // 1
	initStageSourceIds() // 2
}

func initStageMap() {
	log.Debug().Msgf("stage map node config init")
	resStageMap = make(map[uint32]resStage)
	resStageSourceNodeMap = make(map[uint32]map[uint32]resNode)
	err := filepath.Walk("./resource", func(path string, info os.FileInfo, err error) error {
		if info == nil {
			return fmt.Errorf(fmt.Sprintf("path config file pathinfo = nil, %s", path))
		}
		if info.IsDir() {
			return nil
		}
		log.Debug().Msgf("path : %s", path)
		f, err := os.Open(path)
		if err != nil {
			return fmt.Errorf("file open failed, path: %s", path)
		}
		defer f.Close()
		data, err := ioutil.ReadAll(f)
		if err != nil {
			return fmt.Errorf("read data failed, path: %s", path)
		}
		var stage resStage
		xml.Unmarshal(data, &stage)
		nodeMap := make(map[uint32]resNode)
		for i, nd := range stage.Nodes {
			if nd.Connect == "" {
				stage.Nodes[i] = nd
				nodeMap[nd.NodeID] = nd
				continue
			}
			strArr := strings.Split(nd.Connect, ",")
			nextNodes := make([]uint32, len(strArr))
			for i, v := range strArr {
				val, err := strconv.Atoi(v)
				if err != nil {
					return fmt.Errorf("convert next nodes failed, nextNode: %s", nd.Connect)
				}
				nextNodes[i] = uint32(val)
			}
			nd.NextNodes = nextNodes
			stage.Nodes[i] = nd
			nodeMap[nd.NodeID] = nd
		}
		resStageMap[stage.StageSourceID] = stage
		resStageSourceNodeMap[stage.StageSourceID] = nodeMap
		return nil
	})
	if err != nil {
		panic(err.Error())
	}
	log.Debug().Msgf("init map node config success ^_^ ")
}

func initStageSourceIds() {
	for k := range resStageMap {
		resStageSourceIDs = append(resStageSourceIDs, k)
	}
}

func getStageConfig(sourceID uint32) (resStage, bool) {
	stage, ok := resStageMap[sourceID]
	return stage, ok
}

func getStageNode(sourceID, nodeID uint32) (node resNode, ok bool) {
	stage, ok := getStageConfig(sourceID)
	if !ok {
		return
	}
	for _, nd := range stage.Nodes {
		if nd.NodeID == nodeID {
			return nd, true
		}
	}
	return
}

func isNextNode(stageSourceID, parentNode, nextNode uint32) bool {
	stage, ok := getStageConfig(stageSourceID)
	if !ok {
		return false
	}
	log.Debug().Msgf("debug isNextNode stage:%v, parentNode:%v, nextNode:%v",
		stage, parentNode, nextNode)
	for _, nd := range stage.Nodes {
		if nd.NodeID == parentNode {
			for _, next := range nd.NextNodes {
				if next == nextNode {
					return true
				}
			}
		}
	}
	return false
}

func getStageNodeFloor(stageResID uint32, nodeID uint32) (floor uint32, ok bool) {
	nodeMap, ok := resStageSourceNodeMap[stageResID]
	if !ok {
		log.Error().Msgf("stage res id : %d not found", stageResID)
		return
	}
	node, ok := nodeMap[nodeID]
	if !ok {
		log.Error().Msgf("stage res node id: %d not found", nodeID)
		return
	}
	floor = node.Floor
	return
}

func getRandomStageSourceID(stageLevel uint32, stageMode uint32, stageDifficulty uint32) (uint32, bool) {
	stageMapArr, ok := table.GetStageMapSelection(stageMode, stageLevel)
	if !ok || len(stageMapArr) <= 0 {
		log.Warn().Msgf("there is not stage map to selecting, stageMode: %d, stageLevel: %d", stageMode, stageLevel)
		return 0, false
	}
	idMin, idMax := 0, 0
	exist := false
	for _, s := range stageMapArr {
		if s.Difficulty_Min <= int(stageDifficulty) && int(stageDifficulty) <= s.Difficulty_Max {
			idMin = s.Map_ID_Min
			idMax = s.Map_ID_Max
			exist = true
			break
		}
	}
	if !exist {
		log.Warn().Msgf("there is not stage map to selecting, stageMode: %d, stageLevel: %d, difficulty: %d", stageMode, stageLevel, stageDifficulty)
		return 0, false
	}

	var stageIDs []uint32
	for _, id := range resStageSourceIDs {
		if int(id) >= idMin && int(id) <= idMax {
			stageIDs = append(stageIDs, id)
		}
	}
	if len(stageIDs) <= 0 {
		log.Error().Msgf("there is not map.xml with resID [between %d and %d], stageMode: %d, stageLevel: %d, difficulty: %d",
			idMin, idMax, stageMode, stageLevel, stageDifficulty)
		return 0, false
	}
	index := rand.Intn(len(stageIDs))
	return stageIDs[index], true
}
