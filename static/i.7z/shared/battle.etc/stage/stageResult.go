package stage

import (
	"github.com/gogo/protobuf/proto"
	"github.com/rs/zerolog/log"
	"shared/battle.etc/card"
	"shared/battle.etc/stageDef"
	"shared/csv"
	pb "shared/proto/client/battle"
	cmd "shared/proto/share/command"
	"strconv"
)

func stageResultNotice(stg *Stage, overType uint32, inChan chan<- *stageDef.In) error {
	stageUID := stg.UID
	log.Debug().Msgf("stage %v over - result notice down overType:%v",
		stg.UID, overType)
	for _, heroOne := range stg.Heros {
		playerID := heroOne.PlayerID
		stageUIDStr := strconv.FormatUint(stageUID, 10)
		sourceData := pb.BattleStageResultNotice{
			StageUid: &stageUIDStr,
			Type:     &overType,
		}
		rewardGoodsTypeID := getRewardGoodsTypeID(stg, overType, heroOne.GetUID())
		score := uint32(0)
		finishNode := heroOne.FinishNode
		enemyNum := heroOne.EnemyNum
		eliteNum := heroOne.EliteNum
		bossNum := heroOne.BossNum
		relicNum, goldCard := uint32(0), uint32(0)
		for _, r := range heroOne.Relics {
			if r.IsExist {
				relicNum++
			}
		}
		for _, c := range heroOne.AllCards {
			if c.Rarity == card.Gold {
				goldCard++
			}
		}
		gold := heroOne.Gold
		life := heroOne.Life

		countAttr := []uint32{
			finishNode,
			enemyNum,
			eliteNum,
			bossNum,
			relicNum,
			goldCard,
			gold,
			life,
		}
		kv := []*pb.BattleCountKv{}
		for scoreIndex, source := range countAttr {
			scoreLocal, countOne, ok := countScore(int64(scoreIndex+1), source)
			if !ok {
				continue
			}
			score += scoreLocal
			kv = append(kv, countOne)
		}
		sourceData.Count = &pb.BattleStageResultCount{
			Score:             &score,
			RewardGoodsTypeID: &rewardGoodsTypeID,
			Kv:                kv,
		}
		if rewardGoodsTypeID > 0 {
			// send player data operation
			inChan <- &stageDef.In{
				Type: stageDef.OperationDown,
				Param: stageDef.Operation{
					PlayerID: playerID,
					Op: stageDef.PlayerOperation{
						Type:   stageDef.PlayerOperationEnumAddRewardGoods,
						Param2: rewardGoodsTypeID,
					},
				},
			}
		}
		data, err := proto.Marshal(&sourceData)
		if err != nil {
			return err
		}
		stageNotice := stageDef.Notice{
			PlayerID: playerID,
			CmdCode:  cmd.CLIENT_RSP_CMD_BATTLE_STAGE_RESULT_NOTICE,
			Data:     data,
		}
		stageIn := stageDef.In{
			Type:  stageDef.NoticeDown,
			Param: stageNotice,
		}

		go func() {
			inChan <- &stageIn
		}()
	}
	return nil
}

func getRewardGoodsTypeID(stg *Stage, overType uint32, heroUID uint64) uint32 {
	rewardStageLevel := uint32(0)
	switch overType {
	case 1:
		rewardStageLevel = stg.Level
	case 2:
	case 3:
		if stg.Level > 0 {
			rewardStageLevel = stg.Level - 1
		}
	}
	if rewardStageLevel <= 0 {
		return 0
	}
	mode, difficulty := stg.Mode, stg.Difficulty
	for _, config := range csv.StageRewardMap {
		if config.Mode == int(mode) &&
			config.Difficulty == int(difficulty) &&
			config.Level == int(rewardStageLevel) {
			return uint32(config.RewardTypeID)
		}
	}
	log.Debug().Msgf("stage over debug mode:%v difficulty:%v level:%v reward not exist",
		mode, difficulty, rewardStageLevel)
	return 0
}

func countScore(scoreType int64, source uint32) (uint32, *pb.BattleCountKv, bool) {
	config, ok := csv.StageCountMap[scoreType]
	if !ok {
		log.Error().Msgf("stage result error count score unknown type %v in StageCountMap", scoreType)
		return 0, nil, false
	}
	addScore := source * uint32(config.Score)
	if addScore > uint32(config.MaxScore) {
		addScore = uint32(config.MaxScore)
	}
	k := uint32(scoreType)
	return addScore, &pb.BattleCountKv{K: &k, V: &source}, true
}
