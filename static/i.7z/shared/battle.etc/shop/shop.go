package shop

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math"
	"math/rand"
	"shared/battle.etc/hero"
	"shared/csv"
	pb "shared/proto/client/battle"
	rds "shared/proto/server/battle"
	"shared/table"
)

// Shop desc shop
type Shop struct {
	Cards              []Item
	Relics             []Item
	Potions            []Item
	DiscardCost        uint32
	DiscardRemainTimes uint32
}

// Item desc shop item
type Item struct {
	ItemID        uint32
	ItemType      uint32
	ItemIndex     uint32
	OriginalPrice uint32
	CurrentPrice  uint32
	State         uint32
}

func (si *Item) toRdsShopItemProto() *rds.RdsShopItem {
	return &rds.RdsShopItem{
		ItemId:        si.ItemID,
		ItemType:      si.ItemType,
		OriginalPrice: si.OriginalPrice,
		CurrentPrice:  si.CurrentPrice,
		State:         si.State,
		ItemIndex:     si.ItemIndex,
	}
}

func fromRdsShopItem(si *rds.RdsShopItem) Item {
	return Item{
		ItemID:        si.ItemId,
		ItemType:      si.ItemType,
		OriginalPrice: si.OriginalPrice,
		CurrentPrice:  si.CurrentPrice,
		State:         si.State,
		ItemIndex:     si.ItemIndex,
	}
}

// ToRdsShopProto proto convert
func (s *Shop) ToRdsShopProto(heroUID uint64) *rds.RdsShopType {
	var cards = make([]*rds.RdsShopItem, len(s.Cards))
	for i, c := range s.Cards {
		cards[i] = c.toRdsShopItemProto()
	}
	var relics = make([]*rds.RdsShopItem, len(s.Relics))
	for i, r := range s.Relics {
		relics[i] = r.toRdsShopItemProto()
	}
	potions := make([]*rds.RdsShopItem, len(s.Potions))
	for i, p := range s.Potions {
		potions[i] = p.toRdsShopItemProto()
	}
	log.Debug().Msgf("to rds shop proto: cards: %v, relics: %v, potions: %v", cards, relics, potions)
	return &rds.RdsShopType{
		HeroUID:            heroUID,
		Cards:              cards,
		Relics:             relics,
		Potions:            potions,
		DiscardCost:        s.DiscardCost,
		DiscardRemainTimes: s.DiscardRemainTimes,
	}
}

// FromRdsShopProto proto convert
func FromRdsShopProto(s *rds.RdsShopType) (shp Shop) {
	cards := make([]Item, len(s.Cards))
	for i, c := range s.Cards {
		cards[i] = fromRdsShopItem(c)
	}
	relics := make([]Item, len(s.Relics))
	for i, r := range s.Relics {
		relics[i] = fromRdsShopItem(r)
	}
	potions := make([]Item, len(s.Potions))
	for i, p := range s.Potions {
		potions[i] = fromRdsShopItem(p)
	}
	return Shop{
		Cards:              cards,
		Relics:             relics,
		Potions:            potions,
		DiscardCost:        s.DiscardCost,
		DiscardRemainTimes: s.DiscardRemainTimes,
	}
}

func (si Item) toClientShopItem() *pb.BattleShopItem {
	itemType := pb.ShopItemType(si.ItemType)
	state := pb.BattleShopItemState(si.State)
	return &pb.BattleShopItem{
		ItemId:        &si.ItemID,
		ItemType:      &itemType,
		OriginalPrice: &si.OriginalPrice,
		CurrentPrice:  &si.CurrentPrice,
		State:         &state,
		ItemIndex:     &si.ItemIndex,
	}
}

// ToClientShopProto proto convert
func (s *Shop) ToClientShopProto() *pb.BattleShop {
	var cards = make([]*pb.BattleShopItem, len(s.Cards))
	for i, c := range s.Cards {
		cards[i] = c.toClientShopItem()
	}
	var relics = make([]*pb.BattleShopItem, len(s.Relics))
	for i, r := range s.Relics {
		relics[i] = r.toClientShopItem()
	}
	var potions = make([]*pb.BattleShopItem, len(s.Potions))
	for i, p := range s.Potions {
		potions[i] = p.toClientShopItem()
	}
	return &pb.BattleShop{
		ShopCards:          cards,
		ShopRelics:         relics,
		ShopPotions:        potions,
		DiscardCost:        &s.DiscardCost,
		DiscardRemainTimes: &s.DiscardRemainTimes,
	}
}

// GetShopItems as name
func GetShopItems(difficulty, stageLevel uint32, h *hero.InStage) (shopItems Shop, err error) {
	shopCards, err := getShopCards(difficulty, stageLevel, 3, 1, 2, h)
	if err != nil {
		return
	}
	shopRelics, err := getShopRelics(difficulty, stageLevel, 3, h)
	if err != nil {
		return
	}
	shopPotions, err := getShopPotions(difficulty, stageLevel, 3, h)
	if err != nil {
		return
	}
	shopItems.Cards = shopCards
	shopItems.Relics = shopRelics
	shopItems.Potions = shopPotions
	shopItems.DiscardRemainTimes = 1
	// TODO
	smileMaskRelic := false
	if smileMaskRelic {
		shopItems.DiscardCost = 50
	} else {
		shopItems.DiscardCost = 75 + 25*h.DiscardTimes
	}
	return
}

func getShopCards(difficulty, stageLevel, numCareer, numHero, numCommon uint32, h *hero.InStage) (shopCards []Item, err error) {
	heroInTable, ok := csv.TableCareerInitialValueMap[int64(h.GetTypeID())]
	if !ok {
		return nil, fmt.Errorf("hero not found in table, typeID: %d", h.GetTypeID())
	}
	//heroCareer := heroInTable.Career
	relation, ok := table.GetDropRelation(difficulty, stageLevel, csv.DROP_FROM_SHOP)
	if !ok {
		log.Error().Msgf("drop relation not found, difficulty: %d, stageLevel: %d, dropFrom: shop", difficulty, stageLevel)
		return nil, fmt.Errorf("drop relation not found, difficulty: %d, stageLevel: %d, dropFrom: shop", difficulty, stageLevel)
	}
	groupCardsMap, ok := table.GetGroupCardsByGroupId(relation.CardGroup)
	if !ok {
		log.Error().Msgf("there is not group cards, group Id: %d", relation.CardGroup)
		return nil, fmt.Errorf("there is not group cards, group Id: %d", relation.CardGroup)
	}
	careerTotalWeight, heroTotalWeight, commonTotalWeight := 0, 0, 0
	careerWeightMap, heroWeightMap, commonWeightMap := make(map[uint32]uint32), make(map[uint32]uint32), make(map[uint32]uint32)
	cardUpgradeMap := make(map[uint32]uint32)

	for _, c := range groupCardsMap {
		unlocked := h.CheckCardUnlocked(uint32(c.Card_Type_ID))
		if !unlocked {
			continue
		}
		count := h.CountFromAllCards(uint32(c.Card_Type_ID))
		newWeight := c.Weight + c.Weight_Revise*int(count)

		if newWeight <= 0 {
			continue
		}

		cardInTable, _ := table.GetTableCard(uint32(c.Card_Type_ID), 1)
		log.Debug().Msgf("rand card, table card, hero: %d, career: %d, heroCareer: %d", cardInTable.Hero, cardInTable.Career, heroInTable.Career)
		// hero special card
		if uint32(cardInTable.Hero) == h.GetTypeID() {
			heroWeightMap[uint32(c.Card_Type_ID)] = uint32(newWeight)
			heroTotalWeight += newWeight
		} else if cardInTable.Hero == 0 && cardInTable.Career == heroInTable.Career {
			careerWeightMap[uint32(c.Card_Type_ID)] = uint32(newWeight)
			careerTotalWeight += newWeight
		} else if cardInTable.Career == csv.CAREER_NONE {
			commonWeightMap[uint32(c.Card_Type_ID)] = uint32(newWeight)
			commonTotalWeight += newWeight
		}
		cardUpgradeMap[uint32(c.Card_Type_ID)] = uint32(c.Upgrade_Probability)
	}
	log.Debug().Msgf("rand shop cards, heroWeight: %d, careerWeight: %d, commonWeight: %d", heroTotalWeight, careerTotalWeight, commonTotalWeight)
	membershipRelic, deliverymanRelic := false, false

	// drop cards
	heroCards := hero.RandDropCards(heroWeightMap, cardUpgradeMap, uint32(heroTotalWeight), numHero)
	careerCards := hero.RandDropCards(careerWeightMap, cardUpgradeMap, uint32(careerTotalWeight), numCareer)
	commonCards := hero.RandDropCards(commonWeightMap, cardUpgradeMap, uint32(commonTotalWeight), numCommon)

	var allRandCardResIds []uint32
	allRandCardResIds = append(allRandCardResIds, heroCards...)
	allRandCardResIds = append(allRandCardResIds, careerCards...)
	allRandCardResIds = append(allRandCardResIds, commonCards...)

	if len(allRandCardResIds) <= 0 {
		return
	}

	shopCards = make([]Item, len(allRandCardResIds))

	for i, resID := range allRandCardResIds {
		cardConf, _ := csv.TableCardsMap[int64(resID)]
		randFloatPrice := float64(rand.Intn(21) - 10)
		floatPrice := float64(cardConf.Price) * (randFloatPrice / 100.0)
		originalPrice := uint32(math.Ceil(float64(cardConf.Price) + floatPrice))
		currentPrice := originalPrice
		// bargain
		randBargain := rand.Intn(101)
		if randBargain <= 10 {
			currentPrice = uint32(math.Ceil(float64(currentPrice) * 0.5))
		}
		if membershipRelic {
			currentPrice = uint32(math.Ceil(float64(currentPrice) * 0.8))
		}
		if deliverymanRelic {
			currentPrice = uint32(math.Ceil(float64(currentPrice) * 0.8))
		}
		currentPrice += uint32(math.Ceil(float64(currentPrice) * (float64(h.ShopPriceSubPercent) / 100)))
		c := Item{
			ItemID:        resID,
			ItemType:      uint32(pb.ShopItemType_SHOP_ITEM_TYPE_CARD),
			State:         uint32(pb.BattleShopItemState_BATTLE_SHOP_ITEM_ON_SAIL),
			ItemIndex:     uint32(i),
			OriginalPrice: originalPrice,
			CurrentPrice:  currentPrice,
		}
		shopCards[i] = c
	}

	return
}

func getShopRelics(difficulty, stageLevel, numRelics uint32, h *hero.InStage) (shopRelics []Item, err error) {
	relicsMap, ok := hero.GetRelicDropGroupMap(h, difficulty, stageLevel, csv.DROP_FROM_SHOP)
	if !ok {
		return
	}

	relicIds := hero.GetDropRelics(h, relicsMap, numRelics)
	if len(relicIds) <= 0 {
		return
	}
	shopRelics = make([]Item, len(relicIds))
	// TODO
	// 遗物：会员卡
	memberShipRelic := false
	// 遗物：送货员
	deliverymanRelic := false
	for i, rlcID := range relicIds {
		rlc, _ := csv.RemainsMap[int64(rlcID)]
		//rand.Seed(time.Now().Unix())
		randFloatPrice := float64(rand.Intn(21) - 10)
		floatPrice := float64(rlc.Price) * (randFloatPrice / 100.0)
		originalPrice := uint32(math.Ceil(float64(rlc.Price) + floatPrice))
		currentPrice := originalPrice
		if memberShipRelic {
			currentPrice = uint32(math.Ceil(float64(currentPrice) * 0.8))
		}
		if deliverymanRelic {
			currentPrice = uint32(math.Ceil(float64(currentPrice) * 0.8))
		}
		currentPrice += uint32(math.Ceil(float64(currentPrice) * (float64(h.ShopPriceSubPercent) / 100)))
		shopRelic := Item{
			ItemID:        rlcID,
			ItemType:      uint32(pb.ShopItemType_SHOP_ITEM_TYPE_RELIC),
			State:         uint32(pb.BattleShopItemState_BATTLE_SHOP_ITEM_ON_SAIL),
			ItemIndex:     uint32(i),
			OriginalPrice: originalPrice,
			CurrentPrice:  currentPrice,
		}
		shopRelics[i] = shopRelic
	}
	return
}

func getShopPotions(difficulty, stageLevel, numPotions uint32, h *hero.InStage) (shopPotions []Item, err error) {

	potionIds := hero.GetDropPotions(h, difficulty, stageLevel, csv.DROP_FROM_SHOP, numPotions)
	if len(potionIds) <= 0 {
		return
	}
	shopPotions = make([]Item, len(potionIds))

	// TODO
	// 遗物：会员卡
	memberShipRelic := false
	// 遗物：送货员
	deliverymanRelic := false

	for i, potionID := range potionIds {
		pnt, _ := csv.TablePotionsMap[int64(potionID)]
		//rand.Seed(time.Now().Unix())
		randFloatPrice := float64(rand.Intn(21) - 10)
		floatPrice := float64(pnt.Price) * (randFloatPrice / 100.0)
		originalPrice := uint32(math.Ceil(float64(pnt.Price) + floatPrice))
		currentPrice := originalPrice
		if memberShipRelic {
			currentPrice = uint32(math.Ceil(float64(currentPrice) * 0.8))
		}
		if deliverymanRelic {
			currentPrice = uint32(math.Ceil(float64(currentPrice) * 0.8))
		}
		currentPrice += uint32(math.Ceil(float64(currentPrice) * (float64(h.ShopPriceSubPercent) / 100)))
		shopPotion := Item{
			ItemID:        potionID,
			ItemType:      uint32(pb.ShopItemType_SHOP_ITEM_TYPE_POTION),
			State:         uint32(pb.BattleShopItemState_BATTLE_SHOP_ITEM_ON_SAIL),
			ItemIndex:     uint32(i),
			OriginalPrice: originalPrice,
			CurrentPrice:  currentPrice,
		}

		shopPotions[i] = shopPotion
	}

	return
}

// FindItem item search
func (s *Shop) FindItem(itemType, itemIndex uint32) (item Item, ok bool) {
	var from []Item
	switch pb.ShopItemType(itemType) {
	case pb.ShopItemType_SHOP_ITEM_TYPE_CARD:
		from = s.Cards
	case pb.ShopItemType_SHOP_ITEM_TYPE_RELIC:
		from = s.Relics
	case pb.ShopItemType_SHOP_ITEM_TYPE_POTION:
		from = s.Potions
	default:
	}
	if int(itemIndex) >= len(from) {
		log.Error().Msgf("shop item index out of range, index: %d", itemIndex)
		return item, false
	}
	return from[itemIndex], true
}

// RefreshItem refresh shop item
func (s *Shop) RefreshItem(h *hero.InStage, difficulty, stageLevel, itemType, oldItemIndex uint32) (item Item, err error) {
	item, ok := s.FindItem(itemType, oldItemIndex)
	if !ok {
		return Item{}, fmt.Errorf("shop item not found")
	}
	switch pb.ShopItemType(itemType) {
	case pb.ShopItemType_SHOP_ITEM_TYPE_CARD:
		heroInTable, _ := csv.TableCareerInitialValueMap[int64(h.GetTypeID())]
		cardInTable, _ := table.GetTableCard(item.ItemID, 1)
		if uint32(cardInTable.Hero) == h.GetTypeID() {
			newCards, err := getShopCards(difficulty, stageLevel, 0, 1, 0, h)
			if err != nil {
				return Item{}, err
			}
			if len(newCards) > 0 {
				item = newCards[0]
			}
		} else if cardInTable.Hero == 0 && cardInTable.Career == heroInTable.Career {
			newCards, err := getShopCards(difficulty, stageLevel, 1, 0, 0, h)
			if err != nil {
				return Item{}, err
			}
			if len(newCards) > 0 {
				item = newCards[0]
			}
		} else if cardInTable.Career == csv.CAREER_NONE {
			newCards, err := getShopCards(difficulty, stageLevel, 0, 0, 1, h)
			if err != nil {
				return Item{}, err
			}
			if len(newCards) > 0 {
				item = newCards[0]
			}
		}
	case pb.ShopItemType_SHOP_ITEM_TYPE_RELIC:
		relics, err := getShopRelics(difficulty, stageLevel, 1, h)
		if err != nil {
			return Item{}, err
		}
		if len(relics) > 0 {
			item = relics[0]
		}
	case pb.ShopItemType_SHOP_ITEM_TYPE_POTION:
		potions, err := getShopPotions(difficulty, stageLevel, 1, h)
		if err != nil {
			return Item{}, err
		}
		if len(potions) > 0 {
			item = potions[0]
		}
	default:
		return Item{}, fmt.Errorf("type error")
	}
	item.ItemIndex = oldItemIndex
	return
}
