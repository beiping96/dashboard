package battle

import (
	"github.com/rs/zerolog/log"
	pb "shared/proto/client/battle"
)

func (i *Battle) buffSpell(uid uint64, buffType uint32, oldParam uint32, newParam uint32, effectGroupID uint32) pb.BattleActionNotice {
	rsp := pb.BattleActionNotice{}
	rsp.SourceUid = &uid
	rsp.SpellId = i.generateSpellID()
	rsp.SpellTypeId = &buffType
	spell := pb.BattleSpell{}
	effect := i.buffEffect(uid, buffType, oldParam, newParam, effectGroupID)
	spell.Effects = append(spell.Effects, effect)
	rsp.Spells = append(rsp.Spells, &spell)
	return rsp
}

func (i *Battle) buffEffect(uid uint64, buffType uint32, oldParam uint32, newParam uint32, effectGroupID uint32) *pb.BattleEffect {
	effectEnum := pb.BattleEffectEnum_BEffect_BUFF
	oldValue, newValue := int32(oldParam), int32(newParam)
	return &pb.BattleEffect{
		GroupId:  &effectGroupID,
		Uid:      &uid,
		E:        &effectEnum,
		Param:    &buffType,
		OldValue: &oldValue,
		NewValue: &newValue,
	}
}

func (i *Battle) buffSpellAddEffect(rsp pb.BattleActionNotice, effectList []*pb.BattleEffect) pb.BattleActionNotice {
	spellLen := len(rsp.Spells)
	if spellLen <= 0 {
		log.Error().Msg("battle buff error buffSpellAddEffect: empty spells list")
		return rsp
	}
	index := spellLen - 1
	spell := rsp.Spells[index]
	spell.Effects = append(spell.Effects, effectList...)
	rsp.Spells[index] = spell
	return rsp
}

func (i *Battle) buffClean(uid uint64, buffType uint32) (oldParam uint32, newParam uint32, ok bool) {
	oldParam = i.battleItems[uid].buff[buffType]
	if oldParam <= 0 {
		ok = false
		return
	}
	i.battleItems[uid].buff[buffType] = 0
	newParam = i.battleItems[uid].buff[buffType]
	ok = true
	return
}

func (i *Battle) buffSub(uid uint64, buffType uint32) (oldParam uint32, newParam uint32, ok bool) {
	oldParam = i.battleItems[uid].buff[buffType]
	if oldParam <= 0 {
		ok = false
		return
	}
	i.battleItems[uid].buff[buffType]--
	newParam = i.battleItems[uid].buff[buffType]
	ok = true
	return
}

func (i *Battle) buffShow(uid uint64, buffType uint32) (oldParam uint32, newParam uint32, ok bool) {
	oldParam = i.battleItems[uid].buff[buffType]
	if oldParam <= 0 {
		ok = false
		return
	}
	newParam = oldParam
	ok = true
	return
}

func (i *Battle) getAllShowBuffs(uid uint64) []uint32 {
	buffs := []uint32{}
	for buffID, param := range i.battleItems[uid].buff {
		if param > 0 {
			buffs = append(buffs, buffID)
		}
	}
	return buffs
}
