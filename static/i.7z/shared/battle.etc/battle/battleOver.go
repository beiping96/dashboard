package battle

import (
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/hero"
	"shared/battle.etc/relic"
	"shared/battle.etc/stageDef"
	"shared/csv"
)

func (i *Battle) findWinnerCamp() uint32 {
	camp0AliveNum := len(i.aliveUIDs(0))
	camp1AliveNum := len(i.aliveUIDs(1))
	if camp0AliveNum > 0 && camp1AliveNum == 0 {
		return 0
	}
	if camp1AliveNum > 0 && camp0AliveNum == 0 {
		return 1
	}
	return 2
}

func (i *Battle) battleOver() {
	winnerCamp := i.findWinnerCamp()
	winnerHeroUIDs := []uint64{}
	loserHeroUIDs := []uint64{}
	for uid, itemOne := range i.battleItems {
		if itemOne.heroTypeID > 0 {
			if itemOne.camp == winnerCamp {
				winnerHeroUIDs = append(winnerHeroUIDs, uid)
			} else {
				loserHeroUIDs = append(loserHeroUIDs, uid)
			}
		}
	}
	log.Debug().Msgf("battle %v:%v Over, the winnerCamp is %v, winnerHeroUIDs is %v, loserHeroUIDs is %v",
		i.battleStageUID, i.battleNodeID, winnerCamp, winnerHeroUIDs, loserHeroUIDs)
	if winnerCamp != 0 && winnerCamp != 1 {
		log.Warn().Msgf("battle %v:%v Over not normal, the winnerCamp is %v, winnerHeroUIDs is %v, loserHeroUIDs is %v",
			i.battleStageUID, i.battleNodeID, winnerCamp, winnerHeroUIDs, loserHeroUIDs)
	}

	// battle normal stopped
	winnerS, loserS := []*hero.InStage{}, []*hero.InStage{}
	for uid, heroB := range i.battleHeros {
		// transfer data from item to heroInBattle
		itemB := i.battleItems[uid]
		camp := i.battleItems[uid].camp
		hpBeforeBattle := heroB.HP
		heroB = itemB.convertToHeroInBattle(heroB)
		// transfer data from heroInBattle to heroInState
		newHeroInStage := heroB.convertToHeroInStage(&heroB.InStage)
		newHeroInStage.ResurgenceHP = hpBeforeBattle
		hpNow := newHeroInStage.HP
		if hpNow == 0 {
			newHeroInStage.RecoverOption = []uint32{}
			// random recover option1
			allWeight := 0
			for _, recoverConfig := range csv.RecoverOptionMap {
				allWeight += recoverConfig.Weight
			}
			recoverIDOne := uint32(0)
			if allWeight > 0 {
				weight := 0
				randWeight := rand.Intn(allWeight)
				for recoverID, recoverConfig := range csv.RecoverOptionMap {
					weight += recoverConfig.Weight
					if randWeight < weight {
						recoverIDOne = uint32(recoverID)
						newHeroInStage.RecoverOption = append(newHeroInStage.RecoverOption, recoverIDOne)
						break
					}
				}
			}
			// random recover option2
			allWeight = 0
			for recoverID, recoverConfig := range csv.RecoverOptionMap {
				if uint32(recoverID) == recoverIDOne {
					continue
				}
				allWeight += recoverConfig.Weight
			}
			if allWeight > 0 {
				weight := 0
				randWeight := rand.Intn(allWeight)
				for recoverID, recoverConfig := range csv.RecoverOptionMap {
					if uint32(recoverID) == recoverIDOne {
						continue
					}
					weight += recoverConfig.Weight
					if randWeight < weight {
						recoverIDOne = uint32(recoverID)
						newHeroInStage.RecoverOption = append(newHeroInStage.RecoverOption, recoverIDOne)
						break
					}
				}
			}
		}
		// do RecoverHpAfterBattlePlus relic
		if param, ok := newHeroInStage.GetRelic(relic.RecoverHpAfterBattlePlus); ok && hpNow > 0 {
			if percent, basic, _, ok := relic.GetRelicBasic(relic.RecoverHpAfterBattlePlus); ok {
				if float64(newHeroInStage.HP)/float64(newHeroInStage.HPLimit) < float64(percent)/float64(100) {
					// notice
					relicAction := i.relicSpell(uid, relic.RecoverHpAfterBattlePlus, param, param, 1)
					effect := i.addHp(uid, uint32(basic), 1)
					relicAction = i.relicSpellAddEffect(relicAction, effect)
					actionDown(i, []uint64{uid}, relicAction)
					// exec
					newHeroInStage.HP += uint32(basic)
					if newHeroInStage.HP > newHeroInStage.HPLimit {
						newHeroInStage.HP = newHeroInStage.HPLimit
					}
				}
			}
		}
		// do RecoverHpAfterBattle relic
		if param, ok := newHeroInStage.GetRelic(relic.RecoverHpAfterBattle); ok && hpNow > 0 {
			basic, _, _, ok := relic.GetRelicBasic(relic.RecoverHpAfterBattle)
			if ok {
				// notice
				relicAction := i.relicSpell(uid, relic.RecoverHpAfterBattle, param, param, 1)
				effect := i.addHp(uid, uint32(basic), 1)
				relicAction = i.relicSpellAddEffect(relicAction, effect)
				actionDown(i, []uint64{uid}, relicAction)
				// exec
				newHeroInStage.HP += uint32(basic)
				if newHeroInStage.HP > newHeroInStage.HPLimit {
					newHeroInStage.HP = newHeroInStage.HPLimit
				}
			}
		}
		// write back
		if winnerCamp == camp {
			winnerS = append(winnerS, newHeroInStage)
			continue
		}
		loserS = append(loserS, newHeroInStage)
	}
	battleOverParam := stageDef.BattleOverParam{
		WinnerS:    winnerS,
		LoserS:     loserS,
		WinnerCamp: winnerCamp,
	}
	i.stageInChan <- &stageDef.In{
		Type:     stageDef.BattleOver,
		Param:    battleOverParam,
		StageUID: i.battleStageUID,
		NodeID:   i.battleNodeID,
	}
}
