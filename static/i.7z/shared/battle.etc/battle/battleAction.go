package battle

import (
	"github.com/gogo/protobuf/proto"
	"github.com/rs/zerolog/log"
	"shared/battle.etc/card"
	"shared/battle.etc/relic"
	"shared/battle.etc/stageDef"
	"shared/csv"
	pb "shared/proto/client/battle"
	cmd "shared/proto/share/command"
)

// action down to player
type action struct {
	cmdCode cmd.CLIENT_RSP_CMD
	data    []byte
}

func aiActionDown(i *Battle, ai monsterAI, resID map[uint64]uint32) {
	rsp := pb.BattleMonsterAiNotice{}
	rsp.AiS = ai.toClientProto(resID)
	successCode := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &successCode
	data, err := proto.Marshal(&rsp)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			i.battleStageUID, i.battleNodeID, err, ai)
	}
	a := action{
		cmdCode: cmd.CLIENT_RSP_CMD_BATTLE_MONSTER_AI_NOTICE,
		data:    data,
	}
	for _, uid := range i.heroIDs() {
		if _, ok := i.battleHeros[uid].GetRelic(relic.MpLimitAndUnShowAI); ok {
			continue
		}
		actionInChan(i, uid, a)
	}
}

func battleDataActionDown(i *Battle, uid uint64) {
	rsp := pb.BattleDataNotice{}
	successCode := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &successCode
	rsp.Data = i.ToClientProto(i.battleHeros[uid].InStage)
	rsp.Uid = &i.turnUID
	data, err := proto.Marshal(&rsp)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			i.battleStageUID, i.battleNodeID, err, rsp)
	}
	a := action{
		cmdCode: cmd.CLIENT_RSP_CMD_BATTLE_DATA_NOTICE,
		data:    data,
	}
	actionInChan(i, uid, a)
}

func potionActionDown(i *Battle, uid uint64) {
	rsp := pb.BattlePotionNotice{}
	for _, p := range i.battleHeros[uid].Potions {
		rsp.Potions = append(rsp.Potions, uint32(p))
	}
	successCode := int32(csv.ERRCODE_SUCCESS)
	rsp.Result = &successCode
	data, err := proto.Marshal(&rsp)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			i.battleStageUID, i.battleNodeID, err, rsp)
	}
	a := action{
		cmdCode: cmd.CLIENT_RSP_CMD_BATTLE_POTION_NOTICE,
		data:    data,
	}
	actionInChan(i, uid, a)
}

func cardActionDown(i *Battle, uid uint64, al []card.MoveDesc) {
	rsp := pb.BattleCardNotice{}
	result := uint32(0)
	rsp.Result = &result
	log.Debug().Msgf("battle %v:%v debug card action info:%v",
		i.battleStageUID, i.battleNodeID, al)
	for _, v := range al {
		rsp.Change = append(rsp.Change, v.ToClientProto())
	}
	data, err := proto.Marshal(&rsp)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			i.battleStageUID, i.battleNodeID, err, rsp)
	}
	a := action{
		cmdCode: cmd.CLIENT_RSP_CMD_BATTLE_CARD_NOTICE,
		data:    data,
	}
	actionInChan(i, uid, a)
}

func allCardsActionDown(i *Battle, uid uint64, pos pb.BattleCardPosEnum) {
	h, ok := i.battleHeros[uid]
	if !ok {
		log.Error().Msgf("hero: %d not found in battle", uid)
		return
	}
	notice := pb.BattleAllCardNotice{}
	notice.Pos = &pos
	switch pos {
	case pb.BattleCardPosEnum_BCardPos_HANDY:
		notice.Cards = make([]*pb.BattleCard, len(h.handyCards))
		for i, c := range h.handyCards {
			notice.Cards[i] = c.ToClientProto()
		}
	case pb.BattleCardPosEnum_BCardPos_DIS:
		notice.Cards = make([]*pb.BattleCard, len(h.disCards))
		for i, c := range h.disCards {
			notice.Cards[i] = c.ToClientProto()
		}
	case pb.BattleCardPosEnum_BCardPos_DRAW:
		notice.Cards = make([]*pb.BattleCard, len(h.drawCards))
		for i, c := range h.drawCards {
			notice.Cards[i] = c.ToClientProto()
		}
	case pb.BattleCardPosEnum_BCardPos_EXHAUSTED:
		notice.Cards = make([]*pb.BattleCard, len(h.exhaustedCards))
		for i, c := range h.exhaustedCards {
			notice.Cards[i] = c.ToClientProto()
		}
	default:
		return
	}
	log.Debug().Msgf("all cards notice debug %v", notice)
	data, err := proto.Marshal(&notice)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			i.battleStageUID, i.battleNodeID, err, notice)
	}
	a := action{
		cmdCode: cmd.CLIENT_RSP_CMD_BATTLE_ALL_CARD_NOTICE,
		data:    data,
	}
	actionInChan(i, uid, a)
}

func progressActionDown(i *Battle, uidS []uint64, rsp pb.BattleProgressNotice) {
	log.Debug().Msgf("battle %v:%v debug progress action info:%v",
		i.battleStageUID, i.battleNodeID, rsp)
	data, err := proto.Marshal(&rsp)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			i.battleStageUID, i.battleNodeID, err, rsp)
	}
	a := action{
		cmdCode: cmd.CLIENT_RSP_CMD_BATTLE_PROGRESS_NOTICE,
		data:    data,
	}
	for _, uid := range uidS {
		actionInChan(i, uid, a)
	}
}

func actionDown(i *Battle, uidS []uint64, rsp pb.BattleActionNotice) {
	log.Debug().Msgf("battle %v:%v debug action info:%v",
		i.battleStageUID, i.battleNodeID, rsp)
	data, err := proto.Marshal(&rsp)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			i.battleStageUID, i.battleNodeID, err, rsp)
	}
	a := action{
		cmdCode: cmd.CLIENT_RSP_CMD_BATTLE_ACTION_NOTICE,
		data:    data,
	}
	for _, uid := range uidS {
		actionInChan(i, uid, a)
	}
}

func chooseCardNoticeDown(i *Battle, uid uint64, notice *pb.BattleChooseCardNotice) {
	if notice == nil {
		log.Debug().Msgf("choose card notice data is nil")
		return
	}
	log.Debug().Msgf("battle %v:%v debug choose card notice: %v", i.battleStageUID, i.battleNodeID, *notice)
	data, err := proto.Marshal(notice)
	if err != nil {
		log.Error().Msgf("battle %v:%v error battleAction Marshal, errinfo:%v, source:%v",
			i.battleStageUID, i.battleNodeID, err, notice)
	}
	a := action{
		cmdCode: cmd.CLIENT_RSP_CMD_BATTLE_CHOOSE_CARD_NOTICE,
		data:    data,
	}
	actionInChan(i, uid, a)
}

func actionInChan(i *Battle, uid uint64, a action) {
	if i.battleItems[uid].online {
		stageNotice := stageDef.Notice{
			PlayerID: i.battleHeros[uid].PlayerID,
			CmdCode:  a.cmdCode,
			Data:     a.data,
		}
		stageIn := stageDef.In{
			Type:  stageDef.NoticeDown,
			Param: stageNotice,
		}
		i.stageInChan <- &stageIn
	}
}
