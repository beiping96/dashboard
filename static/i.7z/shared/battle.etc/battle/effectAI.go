package battle

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/monster"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

type effectNone struct {
	effectCommon
}

func registerEffectNone(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectNone{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectNone) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_SLEEP,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectNone) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (buffTypeID uint32, buffParam uint32) {
	return
}

func (i effectNone) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	return true
}

func (i effectNone) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	return
}

type effectAddBattleItem struct {
	effectCommon
	monsterTypeID uint32

	pos1 uint32
	pos2 uint32
}

func registerEffectAddBattleItem(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectAddBattleItem{
		effectCommon:  newEffectCommon(c),
		monsterTypeID: uint32(c.Param1),
		pos1:          uint32(c.Param2),
		pos2:          uint32(c.Param3),
	}
}

func (i effectAddBattleItem) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ADD_BATTLE_ITEM,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectAddBattleItem) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (buffTypeID uint32, buffParam uint32) {
	return
}

func (i effectAddBattleItem) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if self.battleItems[sourceUID].monsterTypeID == 0 {
		log.Error().Msg("Effect exec error effectAddBattleItem be use by no-monster")
		return false
	}
	if self.battleItems[sourceUID].hp <= 0 {
		return false
	}
	return true
}

func (i effectAddBattleItem) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	log.Debug().Msgf("effect add battle item be exec %v", i)
	pos := uint32(0)
	selfCamp := self.battleItems[sourceUID].camp
	monsterIsExist := func(posLocal uint32) bool {
		for _, uid := range self.aliveUIDs(selfCamp) {
			if self.battleItems[uid].pos == posLocal {
				return true
			}
		}
		return false
	}
	posList := []uint32{i.pos1, i.pos2}
	rand.Shuffle(len(posList), func(i, j int) {
		posList[i], posList[j] = posList[j], posList[i]
	})
	for _, posLocal := range posList {
		if posLocal == 0 {
			continue
		}
		if monsterIsExist(posLocal) {
			continue
		}
		pos = posLocal
		break
	}
	if pos == 0 {
		log.Debug().Msgf("effect add battle item be exec pos is zero %v", i)
		return
	}
	newMonster, err := monster.New(i.monsterTypeID, self.battleStageDifficulty, pos)
	if err != nil {
		log.Error().Msgf("Effect exec error effectAddBattleItem pos:%v self:%v",
			pos, i)
		return
	}
	newBattleItem := monsterToBattleItem(self.generateMonsterID(), newMonster)
	self.battleItems[newBattleItem.uid] = &newBattleItem
	if newBattleItem.hp > 0 {
		self.addOneProgress(newBattleItem.uid)
	}
	timeAfter += i.timeAfter
	enum := pb.BattleEffectEnum_BEffect_Spawn
	effect := &pb.BattleEffect{
		GroupId: &effectGroupID,
		Uid:     &newBattleItem.uid,
		E:       &enum,
		NewItem: newBattleItem.toClientProto(),
	}
	effectS = append(effectS, effect)
	return
}
