package battle

import (
	pb "shared/proto/client/battle"

	"fmt"
	"shared/battle.etc/buff"
	"shared/battle.etc/monster"
)

// item struct - the smallest item in battle
type item struct {
	uid                uint64
	heroTypeID         uint32
	monsterTypeID      uint32
	hp                 uint32
	hpLimit            uint32
	block              uint32
	power              int32
	agility            int32
	buff               map[uint32]uint32
	pos                uint32
	camp               uint32
	speed              uint32
	online             bool
	round              uint32
	phaseRoundBegin    uint32
	oldMonsterAI       uint32
	curMonsterAI       uint32
	curActionMonsterAI uint32
	hadBeHurt          bool
	roundHadBeHurt     uint32
	wriggleBloodLose   uint32
	wriggleStatus      bool
	wriggleTimes       uint32
	multiFacePhase     uint32
	revived            bool
}

func (itemOne *item) convertToHeroInBattle(heroOne *heroInBattle) *heroInBattle {
	heroOne.HP = itemOne.hp
	heroOne.HPLimit = itemOne.hpLimit
	return heroOne
}

// heroInBattleToBattleItem convert InBattle to item
func heroInBattleToBattleItem(basic *heroInBattle) (ans item) {
	ans.online = true
	ans.camp = 0
	ans.uid = basic.GetUID()
	ans.heroTypeID = basic.GetTypeID()
	ans.monsterTypeID = 0
	ans.hp = basic.HP
	ans.hpLimit = basic.HPLimit
	ans.speed = basic.speedLocal
	ans.buff = make(map[uint32]uint32)
	for _, buffOne := range basic.BuffGlobal {
		ans.initBuff(buffOne)
	}
	for _, buffOne := range basic.buffLocal {
		ans.initBuff(buffOne)
	}
	if basic.RecoverPlusMorePower {
		ans.power += 2
		basic.RecoverPlusMorePower = false
	}
	return
}

// monsterToBattleItem convert Monster to Item
func monsterToBattleItem(uid uint64, basic monster.Monster) (ans item) {
	ans.online = true
	ans.camp = 1
	ans.pos = basic.Pos
	ans.uid = uid
	ans.heroTypeID = 0
	ans.monsterTypeID = basic.TypeID
	ans.hp = basic.HP
	ans.hpLimit = basic.HPLimit
	ans.speed = basic.Speed
	ans.buff = make(map[uint32]uint32)
	for _, buffOne := range basic.Buff {
		ans.initBuff(buffOne)
	}
	return
}

func (itemOne *item) initBuff(buffOne buff.Buff) {
	buffTypeID := buffOne.TypeID
	_, ok := itemOne.buff[buffTypeID]
	if !ok {
		itemOne.buff[buffTypeID] = buffOne.Param
		return
	}
	itemOne.buff[buffTypeID] += buffOne.Param
}

// toClientProto convert Item struct to BattleItem
func (itemOne item) toClientProto() *pb.BattleItem {
	ans := pb.BattleItem{
		Uid:           &itemOne.uid,
		HeroTypeId:    &itemOne.heroTypeID,
		MonsterTypeId: &itemOne.monsterTypeID,
		Hp:            &itemOne.hp,
		HpLimit:       &itemOne.hpLimit,
		Pos:           &itemOne.pos,
		Camp:          &itemOne.camp,
		Speed:         &itemOne.speed,
		Block:         &itemOne.block,
		Power:         &itemOne.power,
		Agility:       &itemOne.agility,
	}
	for buffTypeID, buffParam := range itemOne.buff {
		b := buff.Buff{
			TypeID: buffTypeID,
			Param:  buffParam,
		}
		ans.Buff = append(ans.Buff, b.ToClientProto())
	}
	return &ans
}

// String - achieve String interface
func (itemOne item) String() string {
	s := "battleItem: "
	s += fmt.Sprintf("uid:%v", itemOne.uid)
	s += fmt.Sprintf("heroTypeID:%v", itemOne.heroTypeID)
	s += fmt.Sprintf("monsterTypeID:%v", itemOne.monsterTypeID)
	s += fmt.Sprintf("round:%v", itemOne.round)
	return s
}
