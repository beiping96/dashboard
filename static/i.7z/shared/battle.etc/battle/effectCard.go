package battle

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/card"
	"shared/cardDef"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

type effectDuplicateHandAttackCard struct {
	effectCommon
}

func registerEffectDuplicateHandAttackCard(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectDuplicateHandAttackCard{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectDuplicateHandAttackCard) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use %v effect", i)
	return nil
}

func (i effectDuplicateHandAttackCard) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, choiceCardID uint32) {
	basic = i.basic
	if len(arg) > 2 {
		cardID, ok := arg[2].(uint32)
		if ok {
			choiceCardID = cardID
		}
	}
	return
}

func (i effectDuplicateHandAttackCard) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	basic, choiceCardID := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	if basic < 1 {
		return false
	}
	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	for _, c := range h.handyCards {
		if c.ID == choiceCardID && (c.Type == csv.CARD_TYPE_ATTACK || c.Type == csv.CARD_TYPE_POWER) {
			return true
		}
	}
	return false
}

func (i effectDuplicateHandAttackCard) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	basic, choiceCardID := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	timeAfter = i.timeAfter
	h, _ := self.battleHeros[sourceUID]
	var crd card.Card
	for _, c := range h.handyCards {
		if c.ID == choiceCardID {
			crd = c
			break
		}
	}
	var al []card.MoveDesc
	for loop := 0; loop < int(basic); loop++ {
		err := h.addCard2Hand(crd.TypeID, crd.Star, crd.Level)
		if err != nil {
			return
		}
		newCard := &h.handyCards[len(h.handyCards)-1]
		from := pb.BattleCardPosEnum_BCardPos_NIL
		to := pb.BattleCardPosEnum_BCardPos_HANDY
		desc := card.MoveDesc{
			ID:     newCard.ID,
			ResID:  newCard.ResID,
			From:   from,
			To:     to,
			Reason: pb.BattleCardReasonEnum_BCardReason_USE,
			Param:  arg[3].(uint32),
		}
		al = append(al, desc)
	}
	allCardsActionDown(self, sourceUID, pb.BattleCardPosEnum_BCardPos_HANDY)
	cardActionDown(self, sourceUID, al)
	return
}

type effectDrawCardsToHandyCards struct {
	effectCommon
}

func registerEffectDrawCardsToHandyCards(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("registry effect draw cards to hand error, effectTypeID: %d", effectID))
	}
	return effectDrawCardsToHandyCards{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectDrawCardsToHandyCards) getMonsterAI(self *Battle, sourceID uint64, aimID uint64) monsterAI {
	log.Error().Msgf("monster AI use effect : %v", i)
	return nil
}

func (i effectDrawCardsToHandyCards) getEffectBasic(self *Battle, sourceID uint64, aimID uint64, args ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectDrawCardsToHandyCards) effectCheck(self *Battle, sourceID uint64, aimID uint64, args ...interface{}) (executable bool) {
	if !self.isAlive(sourceID) {
		return false
	}
	basic, _ := i.getEffectBasic(self, sourceID, aimID)
	if basic < 1 {
		return false
	}

	return true
}

func (i effectDrawCardsToHandyCards) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	basic, _ := i.getEffectBasic(self, sourceUID, aimUID)
	timeAfter = i.timeAfter
	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return
	}
	cardsMove, err := h.giveCardsN(self, basic, pb.BattleCardReasonEnum_BCardReason_USE, arg[3].(uint32))
	if err != nil {
		return nil, 0
	}
	cardActionDown(self, sourceUID, cardsMove)
	return
}

type effectJoinDisCards struct {
	effectCommon
	cardResID uint32
	copies    uint32
}

func registerEffectJoinDisCards(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectJoinDisCards{
		effectCommon: newEffectCommon(e),
		cardResID:    uint32(e.Param1),
		copies:       uint32(e.Param2),
	}
}

func (i effectJoinDisCards) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var ais monsterAI
	aiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_CARD,
		param1: i.cardResID,
		param2: i.copies,
	}
	ais = append(ais, aiOne)
	return ais
}

func (i effectJoinDisCards) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (cardResID uint32, copies uint32) {
	cardResID = i.cardResID
	copies = i.copies
	return
}

func (i effectJoinDisCards) effectCheck(self *Battle, sourceID uint64, aimUID uint64, args ...interface{}) (executable bool) {
	if !self.isAlive(sourceID) {
		return false
	}
	cardResID, copies := i.getEffectBasic(self, sourceID, aimUID)
	if cardResID == 0 || copies < 1 {
		return false
	}

	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		if _, ok := self.battleHeros[sourceID]; !ok {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
		if _, ok := self.battleHeros[aimUID]; !ok {
			return false
		}
	}

	_, ok := csv.TableCardsMap[int64(cardResID)]
	if !ok {
		return false
	}

	return true
}

func (i effectJoinDisCards) effectExec(self *Battle, sourceID uint64, aimID uint64, effectGroupID uint32, firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter

	cardResID, copies := i.getEffectBasic(self, sourceID, aimID)
	heroUID := aimID
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		heroUID = sourceID
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		heroUID = aimID
	}
	h, ok := self.battleHeros[heroUID]
	if !ok {
		log.Error().Msgf("effect target hero not found, uid: %d", heroUID)
		timeAfter = 0
		return
	}
	c, ok := h.CardPool[cardDef.TypeID(cardResID)]
	starLevel := uint32(1)
	if ok {
		starLevel = c.GetCardStarLevel()
	}
	var moves []card.MoveDesc
	cardConf, _ := csv.TableCardsMap[int64(cardResID)]
	for loop := 0; loop < int(copies); loop++ {
		err := h.addCard2Discard(uint32(cardConf.CardGroupID), starLevel, uint32(cardConf.Level))
		if err != nil {
			log.Error().Msgf("effect join dis cards, new card failed, %v", err.Error())
			continue
		}
		newCard := &h.disCards[len(h.disCards)-1]
		mv := card.MoveDesc{
			ID:     newCard.ID,
			ResID:  newCard.ResID,
			From:   pb.BattleCardPosEnum_BCardPos_NIL,
			To:     pb.BattleCardPosEnum_BCardPos_DIS,
			Reason: pb.BattleCardReasonEnum_BCardReason_USE,
			Param:  args[3].(uint32),
		}
		moves = append(moves, mv)
	}
	allCardsActionDown(self, heroUID, pb.BattleCardPosEnum_BCardPos_DIS)
	cardActionDown(self, heroUID, moves)
	return
}

type effectJoinDrawCards struct {
	effectCommon
	cardResID uint32
	copies    uint32
}

func registerEffectJoinDrawCards(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectJoinDrawCards{
		effectCommon: newEffectCommon(e),
		cardResID:    uint32(e.Param1),
		copies:       uint32(e.Param2),
	}
}

func (i effectJoinDrawCards) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var ais monsterAI
	aiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_CARD,
		param1: i.cardResID,
		param2: i.copies,
	}
	ais = append(ais, aiOne)
	return ais

}

func (i effectJoinDrawCards) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (cardResID uint32, copies uint32) {
	cardResID = i.cardResID
	copies = i.copies
	return
}

func (i effectJoinDrawCards) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	cardResID, copies := i.getEffectBasic(self, sourceUID, aimUID)
	if cardResID == 0 || copies < 1 {
		return false
	}

	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		if _, ok := self.battleHeros[sourceUID]; !ok {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
		if _, ok := self.battleHeros[aimUID]; !ok {
			return false
		}
	}

	_, ok := csv.TableCardsMap[int64(cardResID)]
	if !ok {
		return false
	}

	return true
}

func (i effectJoinDrawCards) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter

	cardResID, copies := i.getEffectBasic(self, sourceUID, aimUID)
	heroUID := aimUID
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		heroUID = sourceUID
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		heroUID = aimUID
	}
	h, ok := self.battleHeros[heroUID]
	if !ok {
		log.Error().Msgf("effect target hero not found, uid: %d", heroUID)
		timeAfter = 0
		return
	}
	c, ok := h.CardPool[cardDef.TypeID(cardResID)]
	starLevel := uint32(1)
	if ok {
		starLevel = c.GetCardStarLevel()
	}
	var moves []card.MoveDesc
	cardConf, _ := csv.TableCardsMap[int64(cardResID)]
	for loop := 0; loop < int(copies); loop++ {
		newCard, err := h.addCard2Draw(uint32(cardConf.CardGroupID), starLevel, uint32(cardConf.Level))
		if err != nil {
			log.Error().Msgf("effect join draw cards, new card failed, %v", err.Error())
			continue
		}
		mv := card.MoveDesc{
			ID:     newCard.ID,
			ResID:  newCard.ResID,
			From:   pb.BattleCardPosEnum_BCardPos_NIL,
			To:     pb.BattleCardPosEnum_BCardPos_DRAW,
			Reason: pb.BattleCardReasonEnum_BCardReason_USE,
			Param:  args[3].(uint32),
		}
		moves = append(moves, mv)
	}
	allCardsActionDown(self, heroUID, pb.BattleCardPosEnum_BCardPos_DRAW)
	cardActionDown(self, heroUID, moves)
	return
}

type effectJoinHandCards struct {
	effectCommon
	cardResID uint32
	copies    uint32
}

func registerEffectJoinHandCards(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectJoinHandCards{
		effectCommon: newEffectCommon(e),
		cardResID:    uint32(e.Param1),
		copies:       uint32(e.Param2),
	}
}

func (i effectJoinHandCards) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var ais monsterAI
	aiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_CARD,
		param1: i.cardResID,
		param2: i.copies,
	}
	ais = append(ais, aiOne)
	return ais

}

func (i effectJoinHandCards) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (cardResID uint32, copies uint32) {
	cardResID = i.cardResID
	copies = i.copies
	return
}

func (i effectJoinHandCards) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	cardResID, copies := i.getEffectBasic(self, sourceUID, aimUID)
	if cardResID == 0 || copies < 1 {
		return false
	}

	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		if _, ok := self.battleHeros[sourceUID]; !ok {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
		if _, ok := self.battleHeros[aimUID]; !ok {
			return false
		}
	}

	_, ok := csv.TableCardsMap[int64(cardResID)]
	if !ok {
		return false
	}

	return true
}

func (i effectJoinHandCards) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter

	cardResID, copies := i.getEffectBasic(self, sourceUID, aimUID)

	heroUID := aimUID
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		heroUID = sourceUID
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		heroUID = aimUID
	}
	h, ok := self.battleHeros[heroUID]
	if !ok {
		log.Error().Msgf("effect target hero not found, uid: %d", heroUID)
		timeAfter = 0
		return
	}
	c, ok := h.CardPool[cardDef.TypeID(cardResID)]
	starLevel := uint32(1)
	if ok {
		starLevel = c.GetCardStarLevel()
	}
	var moves []card.MoveDesc
	cardConf, _ := csv.TableCardsMap[int64(cardResID)]
	for loop := 0; loop < int(copies); loop++ {
		err := h.addCard2Hand(uint32(cardConf.CardGroupID), starLevel, uint32(cardConf.Level))
		if err != nil {
			log.Error().Msgf("effect join hand cards, new card failed, %v", err.Error())
			continue
		}
		newCard := &h.handyCards[len(h.handyCards)-1]
		mv := card.MoveDesc{
			ID:     newCard.ID,
			ResID:  newCard.ResID,
			From:   pb.BattleCardPosEnum_BCardPos_NIL,
			To:     pb.BattleCardPosEnum_BCardPos_HANDY,
			Reason: pb.BattleCardReasonEnum_BCardReason_USE,
			Param:  args[3].(uint32),
		}
		moves = append(moves, mv)
	}
	allCardsActionDown(self, heroUID, pb.BattleCardPosEnum_BCardPos_HANDY)
	cardActionDown(self, heroUID, moves)
	return
}

type effectChoiceCardExhaust struct {
	effectCommon
}

func registerEffectChoiceCardExhaust(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectChoiceCardExhaust{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectChoiceCardExhaust) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use effect: %v", i)
	return nil
}

func (i effectChoiceCardExhaust) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (basic uint32, choiceCardID uint32) {
	basic = i.basic
	if len(args) > 2 {
		cardID, ok := args[2].(uint32)
		if ok {
			choiceCardID = cardID
		}
	}
	return
}

func (i effectChoiceCardExhaust) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}

	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	_, cardID := i.getEffectBasic(self, sourceUID, aimUID, args...)
	exist := false
	for _, c := range h.handyCards {
		if c.ID == cardID {
			exist = true
		}
	}
	if !exist {
		return false
	}

	return true
}

func (i effectChoiceCardExhaust) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter
	h, _ := self.battleHeros[sourceUID]
	_, cardID := i.getEffectBasic(self, sourceUID, aimUID, args...)

	cardMove, ok := h.exhaustedCard(cardID, pb.BattleCardReasonEnum_BCardReason_USE, args[3].(uint32))
	if !ok {
		return
	}
	cardActionDown(self, sourceUID, []card.MoveDesc{cardMove})

	return
}

type effectMoveDiscardToDrawCardTop struct {
	effectCommon
}

func registerEffectMoveDisCardToDrawCardTop(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectMoveDiscardToDrawCardTop{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectMoveDiscardToDrawCardTop) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use effect: %v", i)
	return nil
}

func (i effectMoveDiscardToDrawCardTop) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (sourceCardID uint32, choiceCardID uint32) {
	if len(arg) > 2 {
		cardID, ok := arg[1].(uint32)
		if ok {
			sourceCardID = cardID
		}
		cardID, ok = arg[2].(uint32)
		if ok {
			choiceCardID = cardID
		}
	}
	return
}

func (i effectMoveDiscardToDrawCardTop) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	sourceCardID, choiceCardID := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	if sourceCardID == choiceCardID {
		return false
	}
	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	if len(h.disCards) <= 0 {
		return false
	}

	exist := false
	for _, c := range h.disCards {
		if c.ID == choiceCardID {
			exist = true
		}
	}
	if !exist {
		return false
	}
	return true
}

func (i effectMoveDiscardToDrawCardTop) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter
	h, _ := self.battleHeros[sourceUID]
	_, choiceCardID := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	cardMove, err := h.moveCard(pb.BattleCardPosEnum_BCardPos_DIS, pb.BattleCardPosEnum_BCardPos_DRAW, choiceCardID, pb.BattleCardReasonEnum_BCardReason_USE, arg[3].(uint32))
	if err != nil {
		timeAfter = 0
		return
	}
	cardActionDown(self, sourceUID, []card.MoveDesc{cardMove})
	return
}

type effectDrawCardFromDrawCards struct {
	effectCommon
	cardType uint32
}

func registerEffectDrawCardFromDrawCards(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectDrawCardFromDrawCards{
		effectCommon: newEffectCommon(e),
		cardType:     uint32(e.Param2),
	}
}

func (i effectDrawCardFromDrawCards) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use effect: %v", i)
	return nil
}

func (i effectDrawCardFromDrawCards) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectDrawCardFromDrawCards) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	h, ok := self.battleHeros[sourceUID]
	if !ok || len(h.drawCards) <= 0 {
		return false
	}

	existTypeCard := false
	for _, c := range h.drawCards {
		if c.Type == card.Type(i.cardType) {
			existTypeCard = true
			break
		}
	}
	if !existTypeCard {
		return false
	}
	return true
}

func (i effectDrawCardFromDrawCards) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, arg ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {

	basic, _ := i.getEffectBasic(self, sourceUID, aimUID)
	h, _ := self.battleHeros[sourceUID]
	var allDrawTypeCards []card.Card
	for _, c := range h.drawCards {
		if c.Type == card.Type(i.cardType) {
			allDrawTypeCards = append(allDrawTypeCards, c)
		}
	}
	if len(allDrawTypeCards) <= 0 {
		return
	}
	timeAfter = i.timeAfter
	copies := int(basic)
	if len(allDrawTypeCards) < int(basic) {
		copies = len(allDrawTypeCards)
	}
	var moves []card.MoveDesc
	for loop := 0; loop < copies; loop++ {
		randIndex := rand.Intn(len(allDrawTypeCards))
		c := &allDrawTypeCards[randIndex]
		cardMove, err := h.moveCard(pb.BattleCardPosEnum_BCardPos_DRAW, pb.BattleCardPosEnum_BCardPos_HANDY, c.ID,
			pb.BattleCardReasonEnum_BCardReason_USE, 0)
		if err != nil {
			log.Error().Msgf("effectDrawCardFromDrawCards, move card failed: %v", err)
			return
		}
		moves = append(moves, cardMove)
	}
	cardActionDown(self, sourceUID, moves)
	return
}

type effectChoiceCardDiscard struct {
	effectCommon
}

func registerEffectChoiceCardDiscard(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectChoiceCardDiscard{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectChoiceCardDiscard) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use effect: %v", i)
	return nil
}

func (i effectChoiceCardDiscard) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (basic uint32, choiceCardID uint32) {
	basic = i.basic
	if len(args) > 2 {
		cardID, ok := args[2].(uint32)
		if ok {
			choiceCardID = cardID
		}
	}
	return
}

func (i effectChoiceCardDiscard) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}

	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	_, cardID := i.getEffectBasic(self, sourceUID, aimUID, args...)
	exist := false
	for _, c := range h.handyCards {
		if c.ID == cardID {
			exist = true
		}
	}
	if !exist {
		return false
	}

	return true
}

func (i effectChoiceCardDiscard) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter
	h, _ := self.battleHeros[sourceUID]
	_, cardID := i.getEffectBasic(self, sourceUID, aimUID, args...)

	cardMove, ok := h.disCard(cardID, pb.BattleCardReasonEnum_BCardReason_DIS, args[3].(uint32))
	if !ok {
		return
	}
	cardActionDown(self, sourceUID, []card.MoveDesc{cardMove})

	return
}

type effectMoveDiscardToHand struct {
	effectCommon
}

func registerEffectMoveDisCardToHand(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectMoveDiscardToHand{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectMoveDiscardToHand) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use effect: %v", i)
	return nil
}

func (i effectMoveDiscardToHand) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (sourceCardID uint32, choiceCardID uint32) {
	if len(arg) > 2 {
		cardID, ok := arg[1].(uint32)
		if ok {
			sourceCardID = cardID
		}
		cardID, ok = arg[2].(uint32)
		if ok {
			choiceCardID = cardID
		}
	}
	return
}

func (i effectMoveDiscardToHand) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	sourceCardID, choiceCardID := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	if sourceCardID == choiceCardID {
		return false
	}
	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	if len(h.disCards) <= 0 {
		return false
	}

	exist := false
	for _, c := range h.disCards {
		if c.ID == choiceCardID {
			exist = true
		}
	}
	if !exist {
		return false
	}
	return true
}

func (i effectMoveDiscardToHand) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter
	h, _ := self.battleHeros[sourceUID]
	_, choiceCardID := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	cardMove, err := h.moveCard(pb.BattleCardPosEnum_BCardPos_DIS, pb.BattleCardPosEnum_BCardPos_HANDY, choiceCardID, pb.BattleCardReasonEnum_BCardReason_USE, arg[3].(uint32))
	if err != nil {
		timeAfter = 0
		return
	}
	cardActionDown(self, sourceUID, []card.MoveDesc{cardMove})
	return
}

type effectLevelUpAllHandCards struct {
	effectCommon
}

func registerEffectLevelUpAllHandCards(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return effectLevelUpAllHandCards{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectLevelUpAllHandCards) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use effect: %v", i)
	return nil
}

func (i effectLevelUpAllHandCards) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectLevelUpAllHandCards) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}

	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	ok = false
	for _, c := range h.handyCards {
		if c.Level < c.MaxLevel {
			ok = true
			break
		}
	}
	return ok
}

func (i effectLevelUpAllHandCards) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter
	h, _ := self.battleHeros[sourceUID]

	for index, c := range h.handyCards {
		if c.Level < c.MaxLevel {
			newCard, err := c.LevelUp()
			if err != nil {
				log.Error().Msgf("effect level up hand cards failed, cardID: %d", c.ID)
				continue
			}
			h.handyCards[index] = newCard
		}
	}

	allCardsActionDown(self, sourceUID, pb.BattleCardPosEnum_BCardPos_HANDY)
	return
}

type moveDrawTypeCardToHand struct {
	effectCommon
	cardType uint32
}

func registerEffectMoveDrawTypeCardToHand(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("effect not found, effect id : %d", effectID))
	}
	return moveDrawTypeCardToHand{
		effectCommon: newEffectCommon(e),
		cardType:     uint32(e.Param1),
	}
}

func (i moveDrawTypeCardToHand) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use effect: %v", i)
	return nil
}

func (i moveDrawTypeCardToHand) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (sourceCardID uint32, choiceCardID uint32) {
	if len(arg) > 2 {
		cardID, ok := arg[1].(uint32)
		if ok {
			sourceCardID = cardID
		}
		cardID, ok = arg[2].(uint32)
		if ok {
			choiceCardID = cardID
		}
	}
	return
}

func (i moveDrawTypeCardToHand) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (executable bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	sourceCardID, choiceCardID := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	if sourceCardID == choiceCardID {
		return false
	}
	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	if len(h.disCards) <= 0 {
		return false
	}

	exist := false
	for _, c := range h.drawCards {
		if c.ID == choiceCardID && c.Type == card.Type(i.cardType) {
			exist = true
		}
	}
	if !exist {
		return false
	}
	return true
}

func (i moveDrawTypeCardToHand) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter
	h, _ := self.battleHeros[sourceUID]
	_, choiceCardID := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	cardMove, err := h.moveCard(pb.BattleCardPosEnum_BCardPos_DRAW, pb.BattleCardPosEnum_BCardPos_HANDY, choiceCardID, pb.BattleCardReasonEnum_BCardReason_USE, arg[3].(uint32))
	if err != nil {
		timeAfter = 0
		return
	}
	cardActionDown(self, sourceUID, []card.MoveDesc{cardMove})
	return
}
