package battle

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/buff"
	"shared/battle.etc/card"
	"shared/battle.etc/hero"
	"shared/battle.etc/potion"
	"shared/battle.etc/relic"
	"shared/csv"
	pb "shared/proto/client/battle"
	"shared/table"
	"sort"
)

// heroInBattle struct - hero in battle
type heroInBattle struct {
	hero.InStage
	mp             uint32
	mpLimit        uint32
	buffLocal      []buff.Buff
	drawCards      []card.Card
	disCards       []card.Card
	exhaustedCards []card.Card
	handyCards     []card.Card
	nilCards       []card.Card
	getCardsNum    uint32
	speedLocal     uint32
	//chooseCardUIDMap map[uint32]bool
	chooseCardType   uint32
	chooseCardNum    uint32
	gotStatusCardNum uint32
}

// Len interface for sort
func (heroOne *heroInBattle) Len() int {
	return len(heroOne.drawCards)
}

// Swap interface for sort
func (heroOne *heroInBattle) Swap(i, j int) {
	heroOne.drawCards[i], heroOne.drawCards[j] = heroOne.drawCards[j], heroOne.drawCards[i]
}

// Less interface for sort
func (heroOne *heroInBattle) Less(i, j int) bool {
	card1, card2 := heroOne.drawCards[i], heroOne.drawCards[j]
	relicInCard1, relicInCard2 := false, false
	// do relic SelectPowerCardBeforeBattle
	if cardID, ok := heroOne.GetRelic(relic.SelectPowerCardBeforeBattle); cardID > 0 && ok {
		if cardID == card1.ID {
			relicInCard1 = true
		}
		if cardID == card2.ID {
			relicInCard2 = true
		}
	}
	// do relic SelectAttackCardBeforeBattle
	if cardID, ok := heroOne.GetRelic(relic.SelectAttackCardBeforeBattle); cardID > 0 && ok {
		if cardID == card1.ID {
			relicInCard1 = true
		}
		if cardID == card2.ID {
			relicInCard2 = true
		}
	}
	// do relic SelectSkillCardBeforeBattle
	if cardID, ok := heroOne.GetRelic(relic.SelectSkillCardBeforeBattle); cardID > 0 && ok {
		if cardID == card1.ID {
			relicInCard1 = true
		}
		if cardID == card2.ID {
			relicInCard2 = true
		}
	}
	// sort by relic order
	if relicInCard1 && relicInCard2 {
		switch rand.Intn(2) {
		case 0:
			return true
		case 1:
			return false
		}
	}
	if relicInCard1 || relicInCard2 {
		if relicInCard1 {
			return false
		}
		return true
	}
	// sort by card config
	cardGeneralTrue1, cardGeneralTrue2 := false, false
	tbCard, ok := table.GetTableCard(uint32(card1.TypeID), uint32(card1.Level))
	cardGeneralTrue1 = ok && tbCard.Innate == csv.GENERAL_TRUE
	tbCard, ok = table.GetTableCard(uint32(card2.TypeID), uint32(card2.Level))
	cardGeneralTrue2 = ok && tbCard.Innate == csv.GENERAL_TRUE
	if cardGeneralTrue1 && cardGeneralTrue2 {
		switch rand.Intn(2) {
		case 0:
			return true
		case 1:
			return false
		}
	}
	if cardGeneralTrue1 || cardGeneralTrue2 {
		if cardGeneralTrue1 {
			return false
		}
		return true
	}
	switch rand.Intn(2) {
	case 0:
		return true
	case 1:
		return false
	}
	return true
}

// newHeroInBattle create InBattle struct from Hero
func newHeroInBattle(heroBasic hero.InStage) heroInBattle {
	ans := heroInBattle{}
	ans.InStage = heroBasic
	ans.mpLimit = heroBasic.MPLimit
	ans.mp = ans.mpLimit
	ans.drawCards = make([]card.Card, len(heroBasic.AllCards))
	copy(ans.drawCards, heroBasic.AllCards)
	ans.shuffle()
	// change draw cards order
	log.Debug().Msgf("--------before sort draw card, %v", ans.drawCards)
	sort.Sort(&ans)
	log.Debug().Msgf("--------after sort draw card, %v", ans.drawCards)
	// TODO from config
	ans.getCardsNum = 5
	ans.speedLocal = ans.InStage.SpeedGlobal
	ans.ResurgencePotions = make([]potion.Potion, len(ans.Potions))
	copy(ans.ResurgencePotions, ans.Potions)
	return ans
}

func (heroOne *heroInBattle) convertToHeroInStage(heroInStage *hero.InStage) *hero.InStage {
	return heroInStage
}

// toClientProto convert heroInBattle to StageHeroInfoInside
func (heroOne heroInBattle) toClientProto() *pb.StageHeroInfoInside {
	ans := pb.StageHeroInfoInside{}
	ans.Basic = heroOne.ToClientProtoInfo()
	ans.Mp = &heroOne.mp
	ans.MpLimit = &heroOne.mpLimit
	for _, c := range heroOne.drawCards {
		ans.DrawCards = append(ans.DrawCards, c.ToClientProto())
	}
	for _, c := range heroOne.disCards {
		ans.DisCards = append(ans.DisCards, c.ToClientProto())
	}
	for _, c := range heroOne.exhaustedCards {
		ans.ExhaustedCards = append(ans.ExhaustedCards, c.ToClientProto())
	}
	for _, c := range heroOne.handyCards {
		ans.HandyCards = append(ans.HandyCards, c.ToClientProto())
	}
	return &ans
}

// String - achieve String interface
func (heroOne heroInBattle) String() string {
	s := "Hero InBattle Struct:"
	s += fmt.Sprintf(" BASIC: %v", heroOne.Hero)
	s += fmt.Sprintf("DrawCards: %v", heroOne.drawCards)
	s += fmt.Sprintf("DisCards: %v", heroOne.disCards)
	s += fmt.Sprintf("ExhaustedCards: %v", heroOne.exhaustedCards)
	s += fmt.Sprintf("HandyCards: %v", heroOne.handyCards)
	return s
}
