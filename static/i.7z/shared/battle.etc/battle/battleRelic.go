package battle

import (
	"github.com/rs/zerolog/log"
	pb "shared/proto/client/battle"
)

func (i *Battle) relicSpell(uid uint64, relicTypeID uint32, oldParam uint32, newParam uint32, effectGroupID uint32) pb.BattleActionNotice {
	rsp := pb.BattleActionNotice{}
	rsp.SourceUid = &uid
	rsp.SpellId = i.generateSpellID()
	rsp.SpellTypeId = &relicTypeID
	spell := pb.BattleSpell{}
	effect := i.relicEffect(uid, relicTypeID, oldParam, newParam, effectGroupID)
	spell.Effects = append(spell.Effects, effect)
	rsp.Spells = append(rsp.Spells, &spell)
	return rsp
}

func (i *Battle) relicEffect(uid uint64, relicTypeID uint32, oldParam uint32, newParam uint32, effectGroupID uint32) *pb.BattleEffect {
	effectEnum := pb.BattleEffectEnum_BEffect_RELIC
	oldValue, newValue := int32(oldParam), int32(newParam)
	return &pb.BattleEffect{
		GroupId:  &effectGroupID,
		Uid:      &uid,
		E:        &effectEnum,
		Param:    &relicTypeID,
		OldValue: &oldValue,
		NewValue: &newValue,
	}
}

func (i *Battle) relicSpellAddEffect(rsp pb.BattleActionNotice, effectList []*pb.BattleEffect) pb.BattleActionNotice {
	spellLen := len(rsp.Spells)
	if spellLen <= 0 {
		log.Error().Msg("battle buff error relicSpellAddEffect: empty spells list")
		return rsp
	}
	index := spellLen - 1
	spell := rsp.Spells[index]
	spell.Effects = append(spell.Effects, effectList...)
	rsp.Spells[index] = spell
	return rsp
}
