package battle

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/buff"
	"shared/battle.etc/relic"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

func (i *Battle) addHp(uid uint64, Hp uint32, effectGroupID uint32) []*pb.BattleEffect {
	ans := []*pb.BattleEffect{}
	effect := pb.BattleEffect{}
	oldHp := i.battleItems[uid].hp
	effect.Param = &Hp
	newHp := oldHp + Hp
	if newHp > i.battleItems[uid].hpLimit {
		newHp = i.battleItems[uid].hpLimit
	}
	i.battleItems[uid].hp = newHp
	effect.GroupId = &effectGroupID
	effect.Uid = &uid
	effectEnum := pb.BattleEffectEnum_BEffect_HP
	effect.E = &effectEnum
	param := Hp
	effect.Param = &param
	oldValue, newValue := int32(oldHp), int32(newHp)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	ans = append(ans, &effect)
	return ans
}

type effectHpUp struct {
	effectCommon
}

func registerEffectHpUp(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHpUp{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectHpUp) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_HP,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectHpUp) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectHpUp) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectHpUp) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addHp(sourceUID, basic, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addHp(aimUID, basic, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.addHp(uID, basic, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	}
	return
}

func (i *Battle) deHp(sourceUID uint64, aimUID uint64, Hp uint32, blood bool, effectGroupID uint32, attackType *pb.BattleEffectEnum) []*pb.BattleEffect {
	if attackType == nil {
		effectEnum := pb.BattleEffectEnum_BEffect_HP
		attackType = &effectEnum
		blood = false
	}
	ans := []*pb.BattleEffect{}
	if Hp > 0 {
		// do blockAbsolutely buff
		oldParam, newParam, ok := i.buffSub(aimUID, buff.BlockAbsolutely)
		if ok {
			buffEffect := i.buffEffect(aimUID, buff.BlockAbsolutely, oldParam, newParam, effectGroupID)
			ans = append(ans, buffEffect)
			return ans
		}
	}
	effect := pb.BattleEffect{}
	effect.Param = &Hp
	oldHp := i.battleItems[aimUID].hp
	newHp := uint32(0)
	if oldHp >= Hp {
		newHp = oldHp - Hp
	}
	// do blood
	if blood && *attackType == pb.BattleEffectEnum_BEffect_N_ATTACK_HP {
		recoverHP := oldHp - newHp
		effectList := i.addHp(sourceUID, recoverHP, effectGroupID)
		ans = append(ans, effectList...)
	}
	i.battleItems[aimUID].hp = newHp
	i.battleItems[aimUID].hadBeHurt = true
	i.battleItems[aimUID].roundHadBeHurt++
	effect.GroupId = &effectGroupID
	effect.Uid = &aimUID
	effect.E = attackType
	param := Hp
	effect.Param = &param
	oldValue, newValue := int32(oldHp), int32(newHp)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	ans = append(ans, &effect)

	if newHp == 0 {
		// monster revive
		if i.battleItems[aimUID].monsterTypeID == constMonsterRevive && !i.battleItems[aimUID].revived {
			i.monsterAiHpDown(aimUID)
			reviveEffect := i.revive(aimUID, effectGroupID)
			ans = append(ans, reviveEffect...)
			i.battleItems[aimUID].revived = true
			return ans
		}
		i.dead(aimUID)
		// do relic
		if i.battleItems[sourceUID].heroTypeID > 0 {
			heroOne := i.battleHeros[sourceUID]
			// do RecoverHpAfterKillEnemy relic
			if param, ok := heroOne.GetRelic(relic.RecoverHpAfterKillEnemy); ok {
				basic, _, _, ok := relic.GetRelicBasic(relic.RecoverHpAfterKillEnemy)
				if ok {
					// notice
					relicAction := i.relicSpell(sourceUID, relic.RecoverHpAfterKillEnemy, param, param, effectGroupID)
					// exec
					effectList := i.addHp(sourceUID, uint32(basic), effectGroupID)
					relicAction = i.relicSpellAddEffect(relicAction, effectList)
					actionDown(i, i.heroIDs(), relicAction)
				}
			}
			// do RecoverMpAfterKillEnemy relic
			if param, ok := heroOne.GetRelic(relic.RecoverMpAfterKillEnemy); ok {
				basic, _, _, ok := relic.GetRelicBasic(relic.RecoverMpAfterKillEnemy)
				if ok {
					// notice
					relicAction := i.relicSpell(sourceUID, relic.RecoverMpAfterKillEnemy, param, param, effectGroupID)
					// exec
					effectList := i.addMp(sourceUID, uint32(basic), effectGroupID)
					relicAction = i.relicSpellAddEffect(relicAction, effectList)
					actionDown(i, i.heroIDs(), relicAction)
				}
			}
			// do GiveCardAfterKillEnemy relic
			if param, ok := heroOne.GetRelic(relic.GiveCardAfterKillEnemy); ok {
				basic, _, _, ok := relic.GetRelicBasic(relic.GiveCardAfterKillEnemy)
				if ok {
					// notice
					relicAction := i.relicSpell(sourceUID, relic.GiveCardAfterKillEnemy, param, param, effectGroupID)
					actionDown(i, i.heroIDs(), relicAction)
					// exec
					cardAction, err := heroOne.giveCardsN(i, uint32(basic), pb.BattleCardReasonEnum_BCardReason_RELIC, relic.GiveCardAfterKillEnemy)
					if err == nil {
						cardActionDown(i, sourceUID, cardAction)
					}
				}
			}
			// do AllEasyToHurtAfterKillEnemy relic
			if param, ok := heroOne.GetRelic(relic.AllEasyToHurtAfterKillEnemy); ok {
				buffNum, buffTypeID, _, ok := relic.GetRelicBasic(relic.AllEasyToHurtAfterKillEnemy)
				if ok {
					// notice
					relicAction := i.relicSpell(sourceUID, relic.AllEasyToHurtAfterKillEnemy, param, param, effectGroupID)
					// exec
					selfCamp := i.battleItems[sourceUID].camp
					for _, uid := range i.aliveUIDs(otherCamp(selfCamp)) {
						effectList := i.addBuff(sourceUID, uid, uint32(buffTypeID), uint32(buffNum), effectGroupID)
						relicAction = i.relicSpellAddEffect(relicAction, effectList)
					}
					actionDown(i, i.heroIDs(), relicAction)
				}
			}
			// do AllPowerlessAfterKillEnemy relic
			if param, ok := heroOne.GetRelic(relic.AllPowerlessAfterKillEnemy); ok {
				buffNum, buffTypeID, _, ok := relic.GetRelicBasic(relic.AllPowerlessAfterKillEnemy)
				if ok {
					// notice
					relicAction := i.relicSpell(sourceUID, relic.AllPowerlessAfterKillEnemy, param, param, effectGroupID)
					// exec
					selfCamp := i.battleItems[sourceUID].camp
					for _, uid := range i.aliveUIDs(otherCamp(selfCamp)) {
						effectList := i.addBuff(sourceUID, uid, uint32(buffTypeID), uint32(buffNum), effectGroupID)
						relicAction = i.relicSpellAddEffect(relicAction, effectList)
					}
					actionDown(i, i.heroIDs(), relicAction)
				}
			}
			// do AllElectricityAfterKillEnemy relic
			if param, ok := heroOne.GetRelic(relic.AllElectricityAfterKillEnemy); ok {
				buffNum, buffTypeID, _, ok := relic.GetRelicBasic(relic.AllElectricityAfterKillEnemy)
				if ok {
					// notice
					relicAction := i.relicSpell(sourceUID, relic.AllElectricityAfterKillEnemy, param, param, effectGroupID)
					// exec
					selfCamp := i.battleItems[sourceUID].camp
					for _, uid := range i.aliveUIDs(otherCamp(selfCamp)) {
						effectList := i.addBuff(sourceUID, uid, uint32(buffTypeID), uint32(buffNum), effectGroupID)
						relicAction = i.relicSpellAddEffect(relicAction, effectList)
					}
					actionDown(i, i.heroIDs(), relicAction)
				}
			}
		}
		return ans
	}
	// do angryAfterBeAttacked buff
	oldParam, newParam, ok := i.buffShow(aimUID, buff.AngryAfterBeAttacked)
	if ok {
		buffEffect := i.buffEffect(aimUID, buff.AngryAfterBeAttacked, oldParam, newParam, effectGroupID)
		ans = append(ans, buffEffect)
		// add angry
		basic := oldParam * uint32(buff.GetBasic(buff.AngryAfterBeAttacked))
		execEffectList := i.addBuff(aimUID, aimUID, buff.Angry, basic, effectGroupID)
		ans = append(ans, execEffectList...)
	}
	// do blockAfterRound buff
	if *attackType == pb.BattleEffectEnum_BEffect_N_ATTACK_HP {
		oldParam, newParam, ok = i.buffSub(aimUID, buff.BlockAfterRound)
		if ok {
			buffEffect := i.buffEffect(aimUID, buff.BlockAfterRound, oldParam, newParam, effectGroupID)
			ans = append(ans, buffEffect)
		}
	}
	// do BlockAfterRoundFirstBeHurt buff
	if *attackType == pb.BattleEffectEnum_BEffect_N_ATTACK_HP && i.battleItems[aimUID].roundHadBeHurt == 1 {
		oldParam, newParam, ok = i.buffShow(aimUID, buff.BlockAfterRoundFirstBeHurt)
		if ok {
			buffEffect := i.buffEffect(aimUID, buff.BlockAfterRoundFirstBeHurt, oldParam, newParam, effectGroupID)
			ans = append(ans, buffEffect)
			// add block
			basic := oldParam * uint32(buff.GetBasic(buff.BlockAfterRoundFirstBeHurt))
			execEffectList := i.addBlock(aimUID, basic, effectGroupID)
			ans = append(ans, execEffectList...)
		}
	}
	// do relic
	if i.battleItems[aimUID].heroTypeID > 0 {
		heroOne := i.battleHeros[aimUID]
		// do AddMpAfterHpUnderPercent relic
		if relicParam, ok := heroOne.GetRelic(relic.AddMpAfterHpUnderPercent); ok {
			percent, basic, _, ok := relic.GetRelicBasic(relic.AddMpAfterHpUnderPercent)
			if ok {
				oldPercent := float64(oldHp) / float64(i.battleItems[aimUID].hpLimit)
				newPercent := float64(newHp) / float64(i.battleItems[aimUID].hpLimit)
				if oldPercent >= float64(percent)/float64(100) && newPercent < float64(percent)/float64(100) {
					relicEffect := i.relicEffect(aimUID, relic.AddMpAfterHpUnderPercent, relicParam, relicParam, effectGroupID)
					ans = append(ans, relicEffect)
					// exec
					effectList := i.addMp(aimUID, uint32(basic), effectGroupID)
					ans = append(ans, effectList...)
				}
			}
		}
	}

	// finally check monster AI change
	if i.battleItems[aimUID].monsterTypeID > 0 {
		// shark monster
		if i.battleItems[aimUID].monsterTypeID == constMonsterShark {
			i.battleItems[aimUID].wriggleBloodLose += Hp
		}
		i.monsterAiHpDown(aimUID)
	}
	return ans
}

func (i *Battle) revive(uid uint64, effectGroupID uint32) []*pb.BattleEffect {
	var ans []*pb.BattleEffect
	if i.battleItems[uid].monsterTypeID == 0 {
		return ans
	}
	for _, buffID := range i.getAllShowBuffs(uid) {
		if buff.GetBuffType(buffID) != csv.BUFF_BAD {
			continue
		}
		if oldParam, newParam, ok := i.buffClean(uid, buffID); ok {
			buffEffect := i.buffEffect(uid, buffID, oldParam, newParam, effectGroupID)
			ans = append(ans, buffEffect)
		}
	}
	effect := pb.BattleEffect{}
	monster := i.battleItems[uid]
	monster.hp = monster.hpLimit
	effect.Uid = &uid
	hpOld, hpNew := int32(0), int32(monster.hpLimit)
	effect.OldValue = &hpOld
	effect.NewValue = &hpNew
	effect.GroupId = &effectGroupID
	effectEnum := pb.BattleEffectEnum_BEffect_Revive
	effect.E = &effectEnum
	effect.NewItem = i.battleItems[uid].toClientProto()
	ans = append(ans, &effect)
	return ans
}

type effectHpDown struct {
	effectCommon
}

func registerEffectHpDown(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHpDown{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectHpDown) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_DEHP,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectHpDown) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectHpDown) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectHpDown) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.deHp(sourceUID, sourceUID, basic, false, effectGroupID, nil)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.deHp(sourceUID, aimUID, basic, false, effectGroupID, nil)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				effectLocal := self.deHp(sourceUID, uID, basic, false, effectGroupID, nil)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.deHp(sourceUID, uIDs[rand.Intn(aliveNum)], basic, false, effectGroupID, nil)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

func (i *Battle) addMp(uid uint64, Mp uint32, effectGroupID uint32) []*pb.BattleEffect {
	ans := []*pb.BattleEffect{}
	oldMp := i.battleHeros[uid].mp
	i.battleHeros[uid].mp = oldMp + Mp
	newMp := i.battleHeros[uid].mp
	effect := pb.BattleEffect{}
	effect.GroupId = &effectGroupID
	effect.Uid = &uid
	effectEnum := pb.BattleEffectEnum_BEffect_MP
	effect.E = &effectEnum
	oldValue, newValue := int32(oldMp), int32(newMp)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	ans = append(ans, &effect)
	return ans
}

type effectMp struct {
	effectCommon
}

func registerEffectMp(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectMp{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectMp) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use %v effect", i)
	return nil
}

func (i effectMp) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectMp) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	if self.battleItems[sourceUID].heroTypeID <= 0 {
		log.Error().Msgf("battle error monster can't use MpEffect")
		return false
	}
	return true
}

func (i effectMp) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	for loopI := uint32(0); loopI < times; loopI++ {
		if !self.isAlive(sourceUID) {
			break
		}
		if firstTier {
			timeAfter += i.timeAfter
			effectGroupID++
		}
		effectLocal := self.addMp(sourceUID, basic, effectGroupID)
		effectS = append(effectS, effectLocal...)
	}
	return
}

type effectAddCardCostMp struct {
	effectCommon
}

func registerAddCardCostMp(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectAddCardCostMp{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectAddCardCostMp) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use %v effect", i)
	return nil
}

func (i effectAddCardCostMp) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (basic uint32, times uint32) {
	if len(args) < 3 {
		log.Error().Msgf("args too few, args: %v", args)
		return
	}
	h, ok := self.battleHeros[sourceUID]
	if !ok {
		log.Error().Msgf("hero not found, sourceID: %d", sourceUID)
		return
	}
	cardID, _ := args[2].(uint32)
	c, _, ok := h.findCard(cardID)
	if !ok {
		log.Error().Msgf("effect add card cost mp, hero not exist card, cardID: %d ")
		return
	}
	crd, ok := csv.TableCardsMap[int64(c.ResID)]
	if !ok {
		log.Error().Msgf("effect add card cost mp, card not found, cardResID: %d", c.ResID)
		return
	}
	if crd.Cost == self.ConstCardCostX {
		basic = 0
	} else {
		basic = uint32(crd.Cost)
	}
	times = i.times
	return
}

func (i effectAddCardCostMp) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}

	if len(args) < 3 {
		log.Error().Msgf("args too few, args: %v", args)
		return false
	}
	h, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}

	cardID, _ := args[2].(uint32)
	c, _, ok := h.findCard(cardID)
	if !ok {
		log.Error().Msgf("effect add card cost mp, card not found, cardID: %d", cardID)
		return false
	}
	crd, ok := csv.TableCardsMap[int64(c.ResID)]
	if !ok {
		log.Error().Msgf("effect add card cost mp, card not found, cardResID: %d", c.ResID)
		return false
	}
	if crd.Cost == self.ConstCardCostX {
		return false
	}
	return true
}

func (i effectAddCardCostMp) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	basic, _ := i.getEffectBasic(self, sourceUID, aimUID, args...)
	switch i.aim {
	case csv.EFFECT_TARGET_SELF:
		if firstTier {
			effectGroupID++
			timeAfter += i.timeAfter
		}
		localEffect := self.addMp(sourceUID, basic, effectGroupID)
		effects = append(effects, localEffect...)
		return
	}
	return
}
