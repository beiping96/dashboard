package battle

import (
	"github.com/rs/zerolog/log"
	"shared/battle.etc/potion"
	"shared/csv"
	"shared/table"
	"time"
)

func getPotionConfig(potionID potion.Potion) (spellTypeID uint32, effectIDs []typeEffectID, forcedAim bool, ok bool) {
	pt, ok := table.GetPotionsFromTable(uint32(potionID))
	if !ok {
		log.Error().Msgf("table potion not found, potionId: %d", potionID)
		return
	}
	spellTypeID = uint32(pt.ID)
	effectIDs = make([]typeEffectID, len(pt.Effect_IDs))
	for i, e := range pt.Effect_IDs {
		effectIDs[i] = typeEffectID(e)
	}
	if pt.Potions_Target == csv.CARD_TARGET_SINGLE {
		forcedAim = true
	}
	return
}

func getCardConfig(cardTypeID uint32, cardLevel uint32) (spellTypeID uint32, sleepBefore time.Duration, checkList []cardUseCheck, effectIDs []typeEffectID, interactivePriority uint32, interactiveType uint32, forcedAim bool, ok bool) {
	card, ok := table.GetTableCard(cardTypeID, cardLevel)
	if !ok {
		log.Error().Msgf("table card not found, cardGroupId: %d, cardLevel: %d", cardTypeID, cardLevel)
		return
	}
	spellTypeID = uint32(card.ID)
	sleepBefore = time.Duration(card.Forward_Time) * time.Millisecond
	effectIDs = make([]typeEffectID, len(card.EffectIDs))
	for i, effectID := range card.EffectIDs {
		effectIDs[i] = typeEffectID(effectID)
	}
	if card.Card_Target == csv.CARD_TARGET_SINGLE {
		forcedAim = true
	} else {
		forcedAim = false
	}
	interactivePriority = uint32(card.Interactive_Priority)
	interactiveType = uint32(card.Interactive_Type)
	return
}

func otherCamp(camp uint32) uint32 {
	if camp == 0 {
		return 1
	}
	return 0
}

func (i Battle) aliveUIDs(camp uint32) (uIDs []uint64) {
	for uID, v := range i.battleItems {
		if v.camp == camp && v.hp > 0 {
			uIDs = append(uIDs, uID)
		}
	}
	return
}

func (i Battle) isAnyAlive(camp uint32) (alive bool) {
	for _, v := range i.battleItems {
		if v.camp == camp && v.hp > 0 {
			alive = true
			return
		}
	}
	return
}

func (i Battle) isAlive(uid uint64) (alive bool) {
	v, ok := i.battleItems[uid]
	if ok && v.hp > 0 {
		alive = true
		return
	}
	return
}

func (i *Battle) generateSpellID() *uint32 {
	i.spellID++
	spellID := i.spellID
	return &spellID
}

func (i *Battle) generateMonsterID() uint64 {
	i.monsterUID++
	return i.monsterUID
}

func (i *Battle) runAway(uid uint64) {
	i.delOneProgress(uid)
	i.battleItems[uid].online = false
	i.battleItems[uid].hp = 0
}

func (i *Battle) dead(uid uint64) {
	i.delOneProgress(uid)
}

func (i *Battle) offline(uid uint64) {
	i.battleItems[uid].online = false
}

func (i *Battle) online(uid uint64) {
	i.battleItems[uid].online = true
	battleDataActionDown(i, uid)
	log.Debug().Msgf("battle %v reconnection down %v", i, uid)
}
