package battle

var (
	workChan chan *Battle
)

func init() {
	workChan = make(chan *Battle)
	go pop()
}

func pop() {
	// ERROR
	// all work will use the same memory
	// for work := range workChan {
	// 	go Start(&work)
	// }

	for {
		work := <-workChan
		go Start(work)
	}
}

func push(b *Battle) {
	workChan <- b
}
