package battle

import (
	"github.com/rs/zerolog/log"
	"reflect"
	"shared/battle.etc/stageDef"
	"shared/csv"
	pb "shared/proto/client/battle"
	"strconv"
	"time"
)

// OperationReply reply from battle-process
type OperationReply struct {
	Result         int32
	CardRoundTimes uint32
}

// operation UP to battle-process
type operation struct {
	isChooseCard bool
	cardUIDs     []uint32
	enum         pb.BattleOperationEnum
	param1       uint64
	param2       uint64
	param3       uint64
	replyChan    chan<- OperationReply
}

// NewOperationUP - make player operation to battle-process
func NewOperationUP(o *pb.BattleOperation) (interface{}, <-chan OperationReply) {
	param1Str, param2Str, param3Str := o.GetParam1(), o.GetParam2(), o.GetParam3()
	param1, err := strconv.ParseUint(param1Str, 0, 64)
	if err != nil {
		param1 = 0
	}
	param2, err := strconv.ParseUint(param2Str, 0, 64)
	if err != nil {
		param2 = 0
	}
	param3, err := strconv.ParseUint(param3Str, 0, 64)
	if err != nil {
		param3 = 0
	}
	replyChan := make(chan OperationReply, 1)
	return operation{
		enum:      o.GetType(),
		param1:    param1,
		param2:    param2,
		param3:    param3,
		replyChan: replyChan,
	}, replyChan
}

// NewChooseCardOperationUP - make player choose card operation to battle-process
func NewChooseCardOperationUP(cardUIDs []uint32) (interface{}, <-chan OperationReply) {
	replyChan := make(chan OperationReply, 1)
	return operation{
		isChooseCard: true,
		cardUIDs:     cardUIDs,
		replyChan:    replyChan,
	}, replyChan
}

// FinishRoundOperation - make player finish round operation
func FinishRoundOperation() interface{} {
	return operation{
		enum: pb.BattleOperationEnum_BOperation_FINISH_ROUND,
	}
}

// wait all player is ready start battle
func (i *Battle) listenAllReady() bool {
	uIDs := i.heroIDs()
	uIDsState := make(map[uint64]bool)
	log.Debug().Msgf("battle %v:%v wait all player is ready battle start uIDs:%v",
		i.battleStageUID, i.battleNodeID, uIDs)
	if len(uIDs) == 0 {
		return false
	}

	defer func() {
		i.stateDelete()
	}()
	i.stateSave(uIDs)

	timerIndex := len(uIDs)
	controlIndex := timerIndex + 1
	chanLen := timerIndex + 2
	cases := make([]reflect.SelectCase, chanLen)
	for index, uid := range uIDs {
		chanOperation := i.operationChanS[uid]
		cases[index] = reflect.SelectCase{
			Dir:  reflect.SelectRecv,
			Chan: reflect.ValueOf(chanOperation),
		}
	}
	timer := time.After(i.ConstWaitAllPlayerReady)
	cases[timerIndex] = reflect.SelectCase{
		Dir:  reflect.SelectRecv,
		Chan: reflect.ValueOf(timer),
	}
	cases[controlIndex] = reflect.SelectCase{
		Dir:  reflect.SelectRecv,
		Chan: reflect.ValueOf(i.battleInChan),
	}
	for {
		index, value, ok := reflect.Select(cases)
		if index == timerIndex {
			// timeout
			break
		}
		if !ok {
			continue
		}
		if index == controlIndex {
			control, _ := value.Interface().(*stageDef.BattleOperationParam)
			controlSingal, _ := control.Control.(Control)
			stopNow, _ := i.controlSingal(controlSingal)
			if stopNow {
				return false
			}
			continue
		}
		uid := uIDs[index]
		o, ok := value.Interface().(operation)
		if !ok {
			continue
		}
		if o.enum == pb.BattleOperationEnum_BOperation_START_BATTLE {
			uIDsState[uid] = true
			log.Debug().Msgf("battle %v:%v wait all player is ready battle start get uid:%v",
				i.battleStageUID, i.battleNodeID, uid)
			select {
			case o.replyChan <- OperationReply{Result: csv.ERRCODE_SUCCESS}:
				close(o.replyChan)
			default:
			}
		}
		allIsReady := true
		for uid := range i.operationChanS {
			if false == uIDsState[uid] {
				allIsReady = false
				break
			}
		}
		if allIsReady {
			break
		}
	}

	playerIDs := make(map[uint64]bool)
	for heroUID := range uIDsState {
		playerIDs[i.battleHeros[heroUID].PlayerID] = true
	}
	i.stageInChan <- &stageDef.In{
		Type:     stageDef.BattleStart,
		StageUID: i.battleStageUID,
		NodeID:   i.battleNodeID,
		Param:    playerIDs,
	}

	isSomeoneReady := false
	for _, uid := range uIDs {
		if uIDsState[uid] == true {
			isSomeoneReady = true
			continue
		}
		i.delOneProgress(uid)
		i.battleItems[uid].online = false
	}
	if isSomeoneReady {
		return true
	}
	log.Debug().Msgf("battle %v:%v wait all player is ready battle start TIMEOUT uIDs:%v",
		i.battleStageUID, i.battleNodeID, uIDs)
	return false
}

// deal with player round start
func (i *Battle) beforeHeroRoundBegin() {
	// just save it
	// let battleWorker.go make it empty
	i.stateSave([]uint64{i.turnUID})

	log.Debug().Msgf("battle %v:%v wait player start round uid:%v",
		i.battleStageUID, i.battleNodeID, i.turnUID)
}
