package battle

import (
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/buff"
	"shared/battle.etc/card"
	"shared/battle.etc/relic"
	"shared/csv"
	pb "shared/proto/client/battle"
)

// this file is used to count battle items's attributes changed
// will be triggered in some time point
// should include:
// - recover MP
// - count buff or effect
// - down action to player
// - check dead or stopped?
// - call dead-function
// - return stop battle process flag

func (i *Battle) countBeforeStart() (stopNow bool) {
	for uid, hero := range i.battleHeros {
		stopNow = i.countEachHeroBeforeStart(uid, hero)
	}
	return stopNow
}

func (i *Battle) countEachHeroBeforeStart(uid uint64, hero *heroInBattle) (stopNow bool) {
	// do relic MoreCardsBeforeBattle
	if param, ok := hero.GetRelic(relic.MoreCardsBeforeBattle); ok {
		basic, _, _, ok := relic.GetRelicBasic(relic.MoreCardsBeforeBattle)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.MoreCardsBeforeBattle, param, param, 1)
			actionDown(i, []uint64{uid}, relicAction)
			// exec
			cardAction, err := hero.giveCardsN(i, uint32(basic), pb.BattleCardReasonEnum_BCardReason_RELIC, relic.MoreCardsBeforeBattle)
			if err == nil {
				cardActionDown(i, uid, cardAction)
			}
		}
	}
	// do relic RecoverHpBeforeBattle
	if param, ok := hero.GetRelic(relic.RecoverHpBeforeBattle); ok {
		basic, _, _, ok := relic.GetRelicBasic(relic.RecoverHpBeforeBattle)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.RecoverHpBeforeBattle, param, param, 1)
			// exec
			effectList := i.addHp(uid, uint32(basic), 1)
			relicAction = i.relicSpellAddEffect(relicAction, effectList)
			actionDown(i, i.heroIDs(), relicAction)
		}
	}
	// do relic EasyToHurtAllBeforeBattle
	if param, ok := hero.GetRelic(relic.EasyToHurtAllBeforeBattle); ok {
		buffParam, buffTypeID, _, ok := relic.GetRelicBasic(relic.EasyToHurtAllBeforeBattle)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.EasyToHurtAllBeforeBattle, param, param, 1)
			// exec
			selfCamp := i.battleItems[uid].camp
			for _, enemyUID := range i.aliveUIDs(otherCamp(selfCamp)) {
				effectList := i.addBuff(uid, enemyUID, uint32(buffTypeID), uint32(buffParam), 1)
				relicAction = i.relicSpellAddEffect(relicAction, effectList)
			}
			actionDown(i, i.heroIDs(), relicAction)
		}
	}
	// do relic AttackPowerlessAllBeforeBattle
	if param, ok := hero.GetRelic(relic.AttackPowerlessAllBeforeBattle); ok {
		buffParam, buffTypeID, _, ok := relic.GetRelicBasic(relic.AttackPowerlessAllBeforeBattle)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.AttackPowerlessAllBeforeBattle, param, param, 1)
			// exec
			selfCamp := i.battleItems[uid].camp
			for _, enemyUID := range i.aliveUIDs(otherCamp(selfCamp)) {
				effectList := i.addBuff(uid, enemyUID, uint32(buffTypeID), uint32(buffParam), 1)
				relicAction = i.relicSpellAddEffect(relicAction, effectList)
			}
			actionDown(i, i.heroIDs(), relicAction)
		}
	}
	// do relic AgilityBeforeBattle
	if param, ok := hero.GetRelic(relic.AgilityBeforeBattle); ok {
		basic, _, _, ok := relic.GetRelicBasic(relic.AgilityBeforeBattle)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.AgilityBeforeBattle, param, param, 1)
			// exec
			effectList := i.agilityChange(uid, int32(basic), 1)
			relicAction = i.relicSpellAddEffect(relicAction, effectList)
			actionDown(i, i.heroIDs(), relicAction)
		}
	}
	// do relic PowerBeforeBattle
	if param, ok := hero.GetRelic(relic.PowerBeforeBattle); ok {
		basic, _, _, ok := relic.GetRelicBasic(relic.PowerBeforeBattle)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.PowerBeforeBattle, param, param, 1)
			// exec
			effectList := i.powerChange(uid, int32(basic), 1)
			relicAction = i.relicSpellAddEffect(relicAction, effectList)
			actionDown(i, i.heroIDs(), relicAction)
		}
	}
	// do relic ReflectBeforeBattle
	if param, ok := hero.GetRelic(relic.ReflectBeforeBattle); ok {
		buffParam, buffTypeID, _, ok := relic.GetRelicBasic(relic.ReflectBeforeBattle)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.ReflectBeforeBattle, param, param, 1)
			// exec
			effectList := i.addBuff(uid, uid, uint32(buffTypeID), uint32(buffParam), 1)
			relicAction = i.relicSpellAddEffect(relicAction, effectList)
			actionDown(i, i.heroIDs(), relicAction)
		}
	}
	// do relic MpLimitAndMoreCardsBeforeBattle
	if param, ok := hero.GetRelic(relic.MpLimitAndMoreCardsBeforeBattle); ok {
		_, cardNum, cardResID, ok := relic.GetRelicBasic(relic.MpLimitAndMoreCardsBeforeBattle)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.MpLimitAndMoreCardsBeforeBattle, param, param, 1)
			actionDown(i, []uint64{uid}, relicAction)
			// exec
			cardConf, ok := csv.TableCardsMap[int64(cardResID)]
			if ok {
				var moves []card.MoveDesc
				for loopI := 0; loopI < cardNum; loopI++ {
					newCard, err := hero.addCard2Draw(uint32(cardConf.CardGroupID), 1, uint32(cardConf.Level))
					if err != nil {
						log.Error().Msgf("battle error, relic.MpLimitAndMoreCardsBeforeBattle,add card %v ", err)
						continue
					}
					mv := card.MoveDesc{
						ID:     newCard.ID,
						ResID:  newCard.ResID,
						From:   pb.BattleCardPosEnum_BCardPos_NIL,
						To:     pb.BattleCardPosEnum_BCardPos_DRAW,
						Reason: pb.BattleCardReasonEnum_BCardReason_RELIC,
						Param:  relic.MpLimitAndMoreCardsBeforeBattle,
					}
					moves = append(moves, mv)
				}
				allCardsActionDown(i, uid, pb.BattleCardPosEnum_BCardPos_DRAW)
				cardActionDown(i, uid, moves)
			}
		}
	}
	// do relic MpLimitAndEnemyPower
	if param, ok := hero.GetRelic(relic.MpLimitAndEnemyPower); ok {
		_, basic, _, ok := relic.GetRelicBasic(relic.MpLimitAndEnemyPower)
		if ok {
			// notice
			relicAction := i.relicSpell(uid, relic.MpLimitAndEnemyPower, param, param, 1)
			// exec
			selfCamp := i.battleItems[uid].camp
			for _, enemyUID := range i.aliveUIDs(otherCamp(selfCamp)) {
				effectList := i.powerChange(enemyUID, int32(basic), 1)
				relicAction = i.relicSpellAddEffect(relicAction, effectList)
			}
			actionDown(i, i.heroIDs(), relicAction)
		}
	}
	return stopNow
}

func (i *Battle) countBeforeRound() (stopNow bool) {
	turnUID := i.turnUID
	if i.battleItems[turnUID].heroTypeID > 0 {
		// recover MP to MPLimit
		oldMP := i.battleHeros[turnUID].mp
		newMP := i.battleHeros[turnUID].mpLimit
		if i.battleItems[turnUID].round == 1 && i.battleHeros[turnUID].RecoverPlusMoreMPAndCard {
			newMP += 2
			i.battleHeros[turnUID].RecoverPlusMoreMPAndCard = false
		}
		// do keepMP buff
		oldParam, newParam, ok := i.buffSub(turnUID, buff.KeepMP)
		if ok {
			newMP = oldMP + i.battleHeros[turnUID].mpLimit
			buffNotice := i.buffSpell(turnUID, buff.KeepMP, oldParam, newParam, 1)
			actionDown(i, i.heroIDs(), buffNotice)
		}

		// do clean turn reflect buff
		oldParam, newParam, ok = i.buffClean(turnUID, buff.TurnReflect)
		if ok {
			buffAction := i.buffSpell(turnUID, buff.TurnReflect, oldParam, newParam, 1)
			actionDown(i, i.heroIDs(), buffAction)
		}

		i.battleHeros[turnUID].mp = newMP
		rsp := pb.BattleActionNotice{}
		rsp.SourceUid = &turnUID
		rsp.SpellId = i.generateSpellID()
		spellTypeID := uint32(1)
		rsp.SpellTypeId = &spellTypeID
		spell := pb.BattleSpell{}
		effect := pb.BattleEffect{}
		effectGroupID := uint32(1)
		effect.GroupId = &effectGroupID
		effect.Uid = &turnUID
		effectEnum := pb.BattleEffectEnum_BEffect_MP
		effect.E = &effectEnum
		oldValue, newValue := int32(oldMP), int32(newMP)
		effect.OldValue = &oldValue
		effect.NewValue = &newValue
		spell.Effects = append(spell.Effects, &effect)
		rsp.Spells = append(rsp.Spells, &spell)
		actionDown(i, []uint64{turnUID}, rsp)
	}

	// do keepBlock buff notice
	oldParam, newParam, ok := i.buffShow(turnUID, buff.KeepBlock)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.KeepBlock, oldParam, newParam, 1)
		actionDown(i, i.heroIDs(), buffAction)
	}
	if i.battleItems[turnUID].block > 0 && !ok {
		// DeBlock
		oldBlock := i.battleItems[turnUID].block
		i.battleItems[turnUID].block = 0
		newBlock := i.battleItems[turnUID].block
		rsp := pb.BattleActionNotice{}
		rsp.SourceUid = &turnUID
		rsp.SpellId = i.generateSpellID()
		spellTypeID := uint32(2)
		rsp.SpellTypeId = &spellTypeID
		spell := pb.BattleSpell{}
		effect := pb.BattleEffect{}
		effectGroupID := uint32(1)
		effect.GroupId = &effectGroupID
		effect.Uid = &turnUID
		effectEnum := pb.BattleEffectEnum_BEffect_BLOCK
		effect.E = &effectEnum
		oldValue, newValue := int32(oldBlock), int32(newBlock)
		effect.OldValue = &oldValue
		effect.NewValue = &newValue
		spell.Effects = append(spell.Effects, &effect)
		rsp.Spells = append(rsp.Spells, &spell)
		actionDown(i, i.heroIDs(), rsp)
	}

	// do relic first round
	if i.battleItems[turnUID].round == 1 && i.battleItems[turnUID].heroTypeID > 0 {
		// do relic MpBeforeFirstRound
		if param, ok := i.battleHeros[turnUID].GetRelic(relic.MpBeforeFirstRound); ok {
			basic, _, _, ok := relic.GetRelicBasic(relic.MpBeforeFirstRound)
			if ok {
				relicAction := i.relicSpell(turnUID, relic.MpBeforeFirstRound, param, param, 1)
				effectList := i.addMp(turnUID, uint32(basic), 1)
				relicAction = i.relicSpellAddEffect(relicAction, effectList)
				actionDown(i, []uint64{turnUID}, relicAction)
			}
		}
		// do relic BlockBeforeFirstRound
		if param, ok := i.battleHeros[turnUID].GetRelic(relic.BlockBeforeFirstRound); ok {
			basic, _, _, ok := relic.GetRelicBasic(relic.BlockBeforeFirstRound)
			if ok {
				relicAction := i.relicSpell(turnUID, relic.BlockBeforeFirstRound, param, param, 1)
				effectList := i.addBlock(turnUID, uint32(basic), 1)
				relicAction = i.relicSpellAddEffect(relicAction, effectList)
				actionDown(i, []uint64{turnUID}, relicAction)
			}
		}
	}

	// do burn buff
	oldParam, newParam, ok = i.buffSub(turnUID, buff.Burn)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.Burn, oldParam, newParam, 1)
		// de hp
		execEffectList := i.deHp(turnUID, turnUID, oldParam, false, 1, nil)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		actionDown(i, i.heroIDs(), buffAction)
		// is battle stopped?
		if stopped := i.isBattleStopped(); stopped {
			stopNow = true
			return
		}
	}

	// do angryBeforeRound buff
	oldParam, newParam, ok = i.buffShow(turnUID, buff.AngryBeforeRound)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.AngryBeforeRound, oldParam, newParam, 1)
		// add angry buff
		execEffectList := i.addBuff(turnUID, turnUID, buff.Angry, oldParam*uint32(buff.GetBasic(buff.AngryBeforeRound)), 1)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do burnAllBeforeRound buff
	oldParam, newParam, ok = i.buffShow(turnUID, buff.BurnAllBeforeRound)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.BurnAllBeforeRound, oldParam, newParam, 1)
		// add burn buff
		selfCamp := i.battleItems[turnUID].camp
		allAlive := i.aliveUIDs(otherCamp(selfCamp))
		buffParam := oldParam * uint32(buff.GetBasic(buff.BurnAllBeforeRound))
		for _, uID := range allAlive {
			execEffectList := i.addBuff(turnUID, uID, buff.Burn, buffParam, 1)
			buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		}
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do electricityAllBeforeRound buff
	oldParam, newParam, ok = i.buffShow(turnUID, buff.ElectricityAllBeforeRound)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.ElectricityAllBeforeRound, oldParam, newParam, 1)
		// add electricity buff
		selfCamp := i.battleItems[turnUID].camp
		allAlive := i.aliveUIDs(otherCamp(selfCamp))
		buffParam := oldParam * uint32(buff.GetBasic(buff.ElectricityAllBeforeRound))
		for _, uID := range allAlive {
			execEffectList := i.addBuff(turnUID, uID, buff.Electricity, buffParam, 1)
			buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		}
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do frozenAllBeforeRound buff
	oldParam, newParam, ok = i.buffShow(turnUID, buff.FrozenAllBeforeRound)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.FrozenAllBeforeRound, oldParam, newParam, 1)
		// add frozen buff
		selfCamp := i.battleItems[turnUID].camp
		allAlive := i.aliveUIDs(otherCamp(selfCamp))
		buffParam := oldParam * uint32(buff.GetBasic(buff.FrozenAllBeforeRound))
		for _, uID := range allAlive {
			execEffectList := i.addBuff(turnUID, uID, buff.Frozen, buffParam, 1)
			buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		}
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do relic
	if i.battleItems[turnUID].heroTypeID > 0 {
		// do RandomHurtBeforeRound relic
		if param, ok := i.battleHeros[turnUID].GetRelic(relic.RandomHurtBeforeRound); ok {
			basic, _, _, ok := relic.GetRelicBasic(relic.RandomHurtBeforeRound)
			if ok {
				relicAction := i.relicSpell(turnUID, relic.RandomHurtBeforeRound, param, param, 1)
				selfCamp := i.battleItems[turnUID].camp
				aliveUIDs := i.aliveUIDs(otherCamp(selfCamp))
				effectList := i.trueAttack(turnUID, aliveUIDs[rand.Intn(len(aliveUIDs))], uint32(basic),
					false, 1, nil)
				relicAction = i.relicSpellAddEffect(relicAction, effectList)
				actionDown(i, i.heroIDs(), relicAction)
				// is battle stopped?
				if stopped := i.isBattleStopped(); stopped {
					stopNow = true
					return
				}
			}
		}
		// do AllHurtBeforeRound relic
		if param, ok := i.battleHeros[turnUID].GetRelic(relic.AllHurtBeforeRound); ok {
			basic, _, _, ok := relic.GetRelicBasic(relic.AllHurtBeforeRound)
			if ok {
				relicAction := i.relicSpell(turnUID, relic.AllHurtBeforeRound, param, param, 1)
				selfCamp := i.battleItems[turnUID].camp
				for _, uid := range i.aliveUIDs(otherCamp(selfCamp)) {
					effectList := i.trueAttack(turnUID, uid, uint32(basic),
						false, 1, nil)
					relicAction = i.relicSpellAddEffect(relicAction, effectList)
				}
				actionDown(i, i.heroIDs(), relicAction)
				// is battle stopped?
				if stopped := i.isBattleStopped(); stopped {
					stopNow = true
					return
				}
			}
		}
		// do RandomElectricityBeforeRound relic
		if param, ok := i.battleHeros[turnUID].GetRelic(relic.RandomElectricityBeforeRound); ok {
			buffNum, buffTypeID, _, ok := relic.GetRelicBasic(relic.RandomElectricityBeforeRound)
			if ok {
				relicAction := i.relicSpell(turnUID, relic.RandomElectricityBeforeRound, param, param, 1)
				selfCamp := i.battleItems[turnUID].camp
				aliveUIDs := i.aliveUIDs(otherCamp(selfCamp))
				effectList := i.addBuff(turnUID, aliveUIDs[rand.Intn(len(aliveUIDs))], uint32(buffTypeID), uint32(buffNum), 1)
				relicAction = i.relicSpellAddEffect(relicAction, effectList)
				actionDown(i, i.heroIDs(), relicAction)
			}
		}
	}
	return false
}

func (i *Battle) countAfterGiveCards() (stopNow bool) {
	turnUID := i.turnUID

	// do moreCardsBeforeRound buff
	oldParam, newParam, ok := i.buffShow(turnUID, buff.MoreCardsBeforeRound)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.MoreCardsBeforeRound, oldParam, newParam, 1)
		// notice firstly
		actionDown(i, i.heroIDs(), buffAction)
		// add cards
		param := oldParam
		cardActionList, err := i.battleHeros[turnUID].giveCardsN(i, param, pb.BattleCardReasonEnum_BCardReason_BUFF, buff.MoreCardsBeforeRound)
		if err != nil {
			log.Error().Msgf("Battle %v:%v Error give card by buff Error info:%v",
				i.battleStageUID, i.battleNodeID, i.battleHeros[turnUID])
		}
		cardActionDown(i, turnUID, cardActionList)
	}

	return false
}

func (i *Battle) countAfterRound(disCardS []card.Card) (stopNow bool) {
	turnUID := i.turnUID

	// sub buff
	subBuffList := []uint32{
		buff.Electricity,
		buff.Frozen,
		buff.AttackPowerless,
		buff.EasyToHurt,
		buff.BlockLess,
	}
	for _, buffTypeID := range subBuffList {
		oldParam, newParam, ok := i.buffSub(turnUID, buffTypeID)
		if !ok {
			continue
		}
		buffAction := i.buffSpell(turnUID, buffTypeID, oldParam, newParam, 1)
		actionDown(i, i.heroIDs(), buffAction)
	}

	// clean buff
	cleanBuffList := []uint32{
		buff.TwiceAttack,
		buff.TwiceSkill,
		buff.BlockAfterAttack,
		buff.AngryAfterAttack,
		buff.HandCardCostChange,
	}
	for _, buffTypeID := range cleanBuffList {
		oldParam, newParam, ok := i.buffClean(turnUID, buffTypeID)
		if !ok {
			continue
		}
		buffAction := i.buffSpell(turnUID, buffTypeID, oldParam, newParam, 1)
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do autoBlock buff
	oldParam, newParam, ok := i.buffShow(turnUID, buff.AutoBlock)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.AutoBlock, oldParam, newParam, 1)
		// add block
		basic := oldParam * uint32(buff.GetBasic(buff.AutoBlock))
		execEffectList := i.addBlock(turnUID, basic, 1)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		// notice
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do recoverHpAfterRound buff
	oldParam, newParam, ok = i.buffShow(turnUID, buff.RecoverHpAfterRound)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.RecoverHpAfterRound, oldParam, newParam, 1)
		// add block
		basic := oldParam * uint32(buff.GetBasic(buff.RecoverHpAfterRound))
		execEffectList := i.addHp(turnUID, basic, 1)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		// notice
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do powerfulAfterRound buff
	oldParam, newParam, ok = i.buffShow(turnUID, buff.PowerfulAfterRound)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.PowerfulAfterRound, oldParam, newParam, 1)
		// add block
		basic := oldParam * uint32(buff.GetBasic(buff.PowerfulAfterRound))
		execEffectList := i.powerChange(turnUID, int32(basic), 1)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		// notice
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do BlockAfterRound buff
	oldParam, newParam, ok = i.buffShow(turnUID, buff.BlockAfterRound)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.BlockAfterRound, oldParam, newParam, 1)
		// add block
		basic := oldParam * uint32(buff.GetBasic(buff.BlockAfterRound))
		execEffectList := i.addBlock(turnUID, basic, 1)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		// notice
		actionDown(i, i.heroIDs(), buffAction)
	}

	// do relic
	if i.battleItems[turnUID].heroTypeID > 0 {
		// do relic RecoverHpByMpAfterRound
		if param, ok := i.battleHeros[turnUID].GetRelic(relic.RecoverHpByMpAfterRound); ok {
			basic, _, _, ok := relic.GetRelicBasic(relic.RecoverHpByMpAfterRound)
			if ok {
				relicAction := i.relicSpell(turnUID, relic.RecoverHpByMpAfterRound, param, param, 1)
				leftMp := i.battleHeros[turnUID].mp
				effectList := i.addHp(turnUID, leftMp*uint32(basic), 1)
				i.relicSpellAddEffect(relicAction, effectList)
				actionDown(i, i.heroIDs(), relicAction)
			}
		}
		// do relic BlockByCardsAfterRound
		if param, ok := i.battleHeros[turnUID].GetRelic(relic.BlockByCardsAfterRound); ok {
			basic, _, _, ok := relic.GetRelicBasic(relic.BlockByCardsAfterRound)
			if ok {
				relicAction := i.relicSpell(turnUID, relic.BlockByCardsAfterRound, param, param, 1)
				effectList := i.addBlock(turnUID, uint32(len(disCardS))*uint32(basic), 1)
				i.relicSpellAddEffect(relicAction, effectList)
				actionDown(i, i.heroIDs(), relicAction)
			}
		}
		// do relic BlockAfterRound
		if param, ok := i.battleHeros[turnUID].GetRelic(relic.BlockAfterRound); ok {
			param1, param2, _, ok := relic.GetRelicBasic(relic.BlockAfterRound)
			if ok {
				basic := param1
				if i.battleItems[turnUID].block == 0 {
					basic = param2
				}
				relicAction := i.relicSpell(turnUID, relic.BlockAfterRound, param, param, 1)
				effectList := i.addBlock(turnUID, uint32(basic), 1)
				i.relicSpellAddEffect(relicAction, effectList)
				actionDown(i, i.heroIDs(), relicAction)
			}
		}
	}
	// card dis effect
	for _, cardOne := range disCardS {
		switch cardOne.TypeID {
		case 5002, 5003, 5004, 5104: // 诅咒牌, 状态牌-烧伤
			spellTypeID, _, _, effectIDs, _, _, _, ok := getCardConfig(cardOne.TypeID, cardOne.Level)
			if !ok || len(effectIDs) == 0 {
				log.Error().Msgf("Battle %v:%v Error hero count after round, try count status card effect, card config not found or effectIDs is empty cardTypeID:%v, cardLevel:%v",
					i.battleStageUID, i.battleNodeID, cardOne.TypeID, cardOne.Level)
				break
			}
			execEffectIDs(i, turnUID, turnUID, spellTypeID, effectIDs, cardOne, 0)
			// is battle stopped?
			if stopped := i.isBattleStopped(); stopped {
				stopNow = true
				return
			}
		default:
		}
	}
	return false
}

func (i *Battle) countAfterUseCard(cardID uint32) (stopNow bool) {
	turnUID := i.turnUID
	cardOne, _, ok := i.battleHeros[turnUID].findCard(cardID)
	if !ok {
		return
	}
	switch cardOne.Type {
	case card.Attack:
		stopNow = i.countAfterUseAttackCard(cardOne)
	case card.Skill:
		stopNow = i.countAfterUseSkillCard(cardOne)
	case card.Power:
		stopNow = i.countAfterUsePowerCard(cardOne)
	default:
	}
	return
}

func (i *Battle) countAfterUseAttackCard(cardOne card.Card) (stopNow bool) {
	turnUID := i.turnUID

	// do blockAfterAttack buff
	oldParam, newParam, ok := i.buffShow(turnUID, buff.BlockAfterAttack)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.BlockAfterAttack, oldParam, newParam, 1)
		// add block
		basic := oldParam * uint32(buff.GetBasic(buff.BlockAfterAttack))
		execEffectList := i.addBlock(turnUID, basic, 1)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		// notice
		actionDown(i, i.heroIDs(), buffAction)
	}

	// sub angry buff
	_, _, angryOk := i.buffShow(turnUID, buff.Angry)
	if angryOk {
		// if has angry buff
		angryControlOldParam, angryControlNewParam, angryControlOk := i.buffShow(turnUID, buff.AngryControl)
		if angryControlOk {
			// if has angryControl buff
			// Down buff exec flag
			buffAction := i.buffSpell(turnUID, buff.AngryControl, angryControlOldParam, angryControlNewParam, 1)
			actionDown(i, i.heroIDs(), buffAction)
		} else {
			// if no angry control
			// sub angry
			angryOldParam, angryNewParam, angryOk := i.buffSub(turnUID, buff.Angry)
			if angryOk {
				buffAction := i.buffSpell(turnUID, buff.Angry, angryOldParam, angryNewParam, 1)
				actionDown(i, i.heroIDs(), buffAction)
			}
		}
	}

	// do angryAfterAttack buff
	oldParam, newParam, ok = i.buffShow(turnUID, buff.AngryAfterAttack)
	if ok {
		buffAction := i.buffSpell(turnUID, buff.AngryAfterAttack, oldParam, newParam, 1)
		// add angry buff
		basic := oldParam * uint32(buff.GetBasic(buff.AngryAfterAttack))
		execEffectList := i.addBuff(turnUID, turnUID, buff.Angry, basic, 1)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		// notice
		actionDown(i, i.heroIDs(), buffAction)
	}

	return
}

func (i *Battle) countAfterUseSkillCard(cardOne card.Card) (stopNow bool) {
	turnUID := i.turnUID
	// do PowerfulAfterSkillCard buff
	for monsterUID, monsterItem := range i.battleItems {
		if monsterItem.monsterTypeID <= 0 {
			continue
		}
		if monsterItem.hp <= 0 {
			continue
		}
		oldParam, newParam, ok := i.buffShow(monsterUID, buff.PowerfulAfterSkillCard)
		if !ok {
			continue
		}
		buffAction := i.buffSpell(monsterUID, buff.PowerfulAfterSkillCard, oldParam, newParam, 1)
		basic := oldParam * uint32(buff.GetBasic(buff.PowerfulAfterSkillCard))
		execEffectList := i.powerChange(monsterUID, int32(basic), 1)
		buffAction = i.buffSpellAddEffect(buffAction, execEffectList)
		// notice
		actionDown(i, i.heroIDs(), buffAction)
	}
	// do CardToDisAfterSkillAndPowerCard buff
	if oldParam, newParam, ok := i.buffShow(turnUID, buff.CardToDisAfterSkillAndPowerCard); ok {
		buffAction := i.buffSpell(turnUID, buff.CardToDisAfterSkillAndPowerCard, oldParam, newParam, 1)
		// notice
		actionDown(i, []uint64{turnUID}, buffAction)
		// add card
		cardConf, ok := csv.TableCardsMap[int64(buff.GetBasic(buff.CardToDisAfterSkillAndPowerCard))]
		if ok {
			moves := []card.MoveDesc{}
			for loop := 0; loop < int(oldParam); loop++ {
				err := i.battleHeros[turnUID].addCard2Discard(uint32(cardConf.CardGroupID), 1, uint32(cardConf.Level))
				if err != nil {
					log.Error().Msgf("buff join dis cards, new card failed, %v", err.Error())
					continue
				}
				newCard := &i.battleHeros[turnUID].disCards[len(i.battleHeros[turnUID].disCards)-1]
				mv := card.MoveDesc{
					ID:     newCard.ID,
					ResID:  newCard.ResID,
					From:   pb.BattleCardPosEnum_BCardPos_NIL,
					To:     pb.BattleCardPosEnum_BCardPos_DIS,
					Reason: pb.BattleCardReasonEnum_BCardReason_BUFF,
					Param:  buff.CardToDisAfterSkillAndPowerCard,
				}
				moves = append(moves, mv)
			}
			allCardsActionDown(i, turnUID, pb.BattleCardPosEnum_BCardPos_DIS)
			cardActionDown(i, turnUID, moves)
		}
	}
	// do CardToDisAndDrawAfterSkillAndPowerCard buff
	if oldParam, newParam, ok := i.buffShow(turnUID, buff.CardToDrawAfterSkillAndPowerCard); ok {
		buffAction := i.buffSpell(turnUID, buff.CardToDrawAfterSkillAndPowerCard, oldParam, newParam, 1)
		// notice
		actionDown(i, []uint64{turnUID}, buffAction)
		// add card
		cardConf, ok := csv.TableCardsMap[int64(buff.GetBasic(buff.CardToDrawAfterSkillAndPowerCard))]
		if ok {
			moves := []card.MoveDesc{}
			for loop := 0; loop < int(oldParam); loop++ {
				newCardDraw, err := i.battleHeros[turnUID].addCard2Draw(uint32(cardConf.CardGroupID), 1, uint32(cardConf.Level))
				if err != nil {
					log.Error().Msgf("buff join dis cards, new card failed, %v", err.Error())
					continue
				}
				newCard := &newCardDraw
				mv := card.MoveDesc{
					ID:     newCard.ID,
					ResID:  newCard.ResID,
					From:   pb.BattleCardPosEnum_BCardPos_NIL,
					To:     pb.BattleCardPosEnum_BCardPos_DRAW,
					Reason: pb.BattleCardReasonEnum_BCardReason_BUFF,
					Param:  buff.CardToDrawAfterSkillAndPowerCard,
				}
				moves = append(moves, mv)
			}
			//allCardsActionDown(i, turnUID, pb.BattleCardPosEnum_BCardPos_DIS)
			allCardsActionDown(i, turnUID, pb.BattleCardPosEnum_BCardPos_DRAW)
			cardActionDown(i, turnUID, moves)
		}
	}
	return false
}

func (i *Battle) countAfterUsePowerCard(cardOne card.Card) (stopNow bool) {
	turnUID := i.turnUID
	// do CardToDisAfterSkillAndPowerCard buff
	if oldParam, newParam, ok := i.buffShow(turnUID, buff.CardToDisAfterSkillAndPowerCard); ok {
		buffAction := i.buffSpell(turnUID, buff.CardToDisAfterSkillAndPowerCard, oldParam, newParam, 1)
		// notice
		actionDown(i, []uint64{turnUID}, buffAction)
		// add card
		cardConf, ok := csv.TableCardsMap[int64(buff.GetBasic(buff.CardToDisAfterSkillAndPowerCard))]
		if ok {
			moves := []card.MoveDesc{}
			for loop := 0; loop < int(oldParam); loop++ {
				err := i.battleHeros[turnUID].addCard2Discard(uint32(cardConf.CardGroupID), 1, uint32(cardConf.Level))
				if err != nil {
					log.Error().Msgf("buff join dis cards, new card failed, %v", err.Error())
					continue
				}
				newCard := &i.battleHeros[turnUID].disCards[len(i.battleHeros[turnUID].disCards)-1]
				mv := card.MoveDesc{
					ID:     newCard.ID,
					ResID:  newCard.ResID,
					From:   pb.BattleCardPosEnum_BCardPos_NIL,
					To:     pb.BattleCardPosEnum_BCardPos_DIS,
					Reason: pb.BattleCardReasonEnum_BCardReason_BUFF,
					Param:  buff.CardToDisAfterSkillAndPowerCard,
				}
				moves = append(moves, mv)
			}
			allCardsActionDown(i, turnUID, pb.BattleCardPosEnum_BCardPos_DIS)
			cardActionDown(i, turnUID, moves)
		}
	}
	// do CardToDisAndDrawAfterSkillAndPowerCard buff
	if oldParam, newParam, ok := i.buffShow(turnUID, buff.CardToDrawAfterSkillAndPowerCard); ok {
		buffAction := i.buffSpell(turnUID, buff.CardToDrawAfterSkillAndPowerCard, oldParam, newParam, 1)
		// notice
		actionDown(i, []uint64{turnUID}, buffAction)
		// add card
		cardConf, ok := csv.TableCardsMap[int64(buff.GetBasic(buff.CardToDrawAfterSkillAndPowerCard))]
		if ok {
			moves := []card.MoveDesc{}
			for loop := 0; loop < int(oldParam); loop++ {
				newCardDraw, err := i.battleHeros[turnUID].addCard2Draw(uint32(cardConf.CardGroupID), 1, uint32(cardConf.Level))
				if err != nil {
					log.Error().Msgf("buff join dis cards, new card failed, %v", err.Error())
					continue
				}
				newCard := &newCardDraw
				mv := card.MoveDesc{
					ID:     newCard.ID,
					ResID:  newCard.ResID,
					From:   pb.BattleCardPosEnum_BCardPos_NIL,
					To:     pb.BattleCardPosEnum_BCardPos_DRAW,
					Reason: pb.BattleCardReasonEnum_BCardReason_BUFF,
					Param:  buff.CardToDrawAfterSkillAndPowerCard,
				}
				moves = append(moves, mv)
			}
			//allCardsActionDown(i, turnUID, pb.BattleCardPosEnum_BCardPos_DIS)
			allCardsActionDown(i, turnUID, pb.BattleCardPosEnum_BCardPos_DRAW)
			cardActionDown(i, turnUID, moves)
		}
	}
	return false
}

func (i *Battle) countAfterUsePotion(o operation) (stopNow bool) {
	return false
}
