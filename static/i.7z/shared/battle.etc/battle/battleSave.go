package battle

import (
	"shared/battle.etc/stageDef"
)

// save BattleState into memory
func (battleOne Battle) stateSave(heroUIDs []uint64) {
	playerIDs := make(map[uint64]chan interface{})
	for _, heroUID := range heroUIDs {
		playerID := battleOne.battleHeros[heroUID].PlayerID
		playerIDs[playerID] = battleOne.operationChanS[heroUID]
	}
	stageIn := stageDef.In{
		Type:     stageDef.BattleStatus,
		Param:    playerIDs,
		StageUID: battleOne.battleStageUID,
		NodeID:   battleOne.battleNodeID,
	}
	battleOne.stageInChan <- &stageIn
}

func (battleOne Battle) stateDelete() {
	stageIn := stageDef.In{
		Type:     stageDef.BattleStatus,
		Param:    make(map[uint64]chan interface{}),
		StageUID: battleOne.battleStageUID,
		NodeID:   battleOne.battleNodeID,
	}
	battleOne.stageInChan <- &stageIn
}
