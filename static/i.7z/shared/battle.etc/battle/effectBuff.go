package battle

import (
	"fmt"
	"math/rand"
	"shared/battle.etc/buff"
	"shared/battle.etc/relic"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

func (i *Battle) addBuff(sourceUID uint64, uid uint64, buffTypeID uint32, buffParam uint32, effectGroupID uint32) []*pb.BattleEffect {
	// skip param == 0
	if buffParam <= 0 {
		return nil
	}
	ans := i.addBuffTrue(uid, buffTypeID, buffParam, effectGroupID)
	// trigger after add buff
	if buffTypeID == buff.Burn {
		oldParam, newParam, ok := i.buffShow(sourceUID, buff.BurnAfterBurn)
		if ok {
			buffEffect := i.buffEffect(sourceUID, buff.BurnAfterBurn, oldParam, newParam, effectGroupID)
			ans = append(ans, buffEffect)
			// add burn buff
			basic := oldParam * uint32(buff.GetBasic(buff.BurnAfterBurn))
			effectLocal := i.addBuffTrue(uid, buff.Burn, basic, effectGroupID)
			ans = append(ans, effectLocal...)
		}
	}
	return ans
}

func (i *Battle) addBuffTrue(uid uint64, buffTypeID uint32, buffParam uint32, effectGroupID uint32) []*pb.BattleEffect {
	ans := []*pb.BattleEffect{}
	// skip param == 0
	if buffParam <= 0 {
		return ans
	}
	// do FixSelfAttackPowerLess relic
	if i.battleItems[uid].heroTypeID > 0 && buffTypeID == buff.AttackPowerless {
		if relicParam, ok := i.battleHeros[uid].GetRelic(relic.FixSelfAttackPowerLess); ok {
			relicEffect := i.relicEffect(uid, relic.FixSelfAttackPowerLess, relicParam, relicParam, effectGroupID)
			ans = append(ans, relicEffect)
			buffParam = 0
			//return ans
		}
	}
	_, _, ok := i.buffShow(uid, buff.ResistDeBuff)
	if ok && buff.GetBuffType(buffTypeID) == csv.BUFF_BAD {
		oldParam, newParam, ok := i.buffSub(uid, buff.ResistDeBuff)
		if ok {
			buffEffect := i.buffEffect(uid, buff.ResistDeBuff, oldParam, newParam, effectGroupID)
			ans = append(ans, buffEffect)
			buffParam = 0
		}
		//return ans
	}
	// exec
	oldParam := i.battleItems[uid].buff[buffTypeID]
	i.battleItems[uid].buff[buffTypeID] += buffParam
	newParam := i.battleItems[uid].buff[buffTypeID]
	effect := i.buffEffect(uid, buffTypeID, oldParam, newParam, effectGroupID)
	ans = append(ans, effect)
	return ans
}

type effectBuffGiver struct {
	effectCommon
	buffTypeID uint32
	buffParam  uint32
}

func registerEffectBuffGiver(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectBuffGiver{
		effectCommon: newEffectCommon(c),
		buffTypeID:   uint32(c.Param1),
		buffParam:    uint32(c.Param2),
	}
}

func (i effectBuffGiver) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_BUFF,
		param1: buffTypeID,
		param2: buffParam,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectBuffGiver) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (buffTypeID uint32, buffParam uint32) {
	buffTypeID = i.buffTypeID
	buffParam = i.buffParam
	return
}

func (i effectBuffGiver) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectBuffGiver) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
	times := i.times
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBuff(sourceUID, sourceUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBuff(sourceUID, aimUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.addBuff(sourceUID, uID, buffTypeID, buffParam, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBuff(sourceUID, aimUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				effectLocal := self.addBuff(sourceUID, uID, buffTypeID, buffParam, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBuff(sourceUID, uIDs[rand.Intn(aliveNum)], buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectBuffTimes struct {
	effectCommon
	buffTypeID uint32
	buffTimes  uint32
}

func registerEffectBuffTimes(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectBuffTimes{
		effectCommon: newEffectCommon(c),
		buffTypeID:   uint32(c.Param1),
		buffTimes:    uint32(c.Param2),
	}
}

func (i effectBuffTimes) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_BUFF,
		param1: buffTypeID,
		param2: buffParam,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectBuffTimes) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (buffTypeID uint32, buffParam uint32) {
	buffTypeID = i.buffTypeID
	if i.buffTimes-1 <= 0 {
		return
	}
	item, ok := self.battleItems[aimUID]
	if !ok {
		return
	}
	if item.buff[buffTypeID] <= 0 {
		return
	}
	buffParam = item.buff[buffTypeID] * (i.buffTimes - 1)
	return
}

func (i effectBuffTimes) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectBuffTimes) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	times := i.times
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, sourceUID)
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBuff(sourceUID, sourceUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
			effectLocal := self.addBuff(sourceUID, aimUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.addBuff(sourceUID, uID, buffTypeID, buffParam, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
			effectLocal := self.addBuff(sourceUID, aimUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.addBuff(sourceUID, uID, buffTypeID, buffParam, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.addBuff(sourceUID, uID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectBuffByEnemyNum struct {
	effectCommon
	buffTypeID uint32
	buffParam  uint32
}

func registerEffectBuffByEnemyNum(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectBuffByEnemyNum{
		effectCommon: newEffectCommon(c),
		buffTypeID:   uint32(c.Param1),
		buffParam:    uint32(c.Param2),
	}
}

func (i effectBuffByEnemyNum) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_BUFF,
		param1: buffTypeID,
		param2: buffParam,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectBuffByEnemyNum) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (buffTypeID uint32, buffParam uint32) {
	buffTypeID = i.buffTypeID
	selfCamp := self.battleItems[sourceUID].camp
	allEnemy := self.aliveUIDs(otherCamp(selfCamp))
	buffParam = uint32(len(allEnemy)) * i.buffParam
	return
}

func (i effectBuffByEnemyNum) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectBuffByEnemyNum) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	times := i.times
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, sourceUID)
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBuff(sourceUID, sourceUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
			effectLocal := self.addBuff(sourceUID, aimUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.addBuff(sourceUID, uID, buffTypeID, buffParam, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
			effectLocal := self.addBuff(sourceUID, aimUID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.addBuff(sourceUID, uID, buffTypeID, buffParam, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.addBuff(sourceUID, uID, buffTypeID, buffParam, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectBuffByEnemyBuff struct {
	effectCommon
	baseBuff uint32
	newBuff  uint32
}

func registerEffectBuffByEnemyBuff(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectBuffByEnemyBuff{
		effectCommon: newEffectCommon(e),
		baseBuff:     uint32(e.Param1),
		newBuff:      uint32(e.Param2),
	}
}

func (i effectBuffByEnemyBuff) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	buffTypeID, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_BUFF,
		param1: buffTypeID,
		param2: buffParam,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectBuffByEnemyBuff) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (buffTypeID uint32, buffParam uint32) {
	oldParam, _, ok := self.buffShow(aimUID, i.baseBuff)
	if ok {
		buffTypeID = i.newBuff
		buffParam = oldParam
	}
	return
}

func (i effectBuffByEnemyBuff) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		if !self.isAlive(aimUID) {
			return false
		}
		if oldParam, _, ok := self.buffShow(aimUID, i.baseBuff); !ok || oldParam == 0 {
			return false
		}
	}
	return true
}

func (i effectBuffByEnemyBuff) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	times := i.times
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		for loop := 0; loop < int(times); loop++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				effectGroupID++
				timeAfter += i.timeAfter
			}
			newBuff, buffParam := i.getEffectBasic(self, sourceUID, aimUID)
			battleEffect := self.addBuff(sourceUID, aimUID, newBuff, buffParam, effectGroupID)
			effects = append(effects, battleEffect...)
		}
		return
	}
	return
}

type effectClearBadBuffs struct {
	effectCommon
}

func registerEffectClearBadBuffs(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectClearBadBuffs{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectClearBadBuffs) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_CLEAR_BAD_BUFFS,
		param1: 0,
		param2: 0,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectClearBadBuffs) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (buffTypeID uint32, buffParam uint32) {

	return
}

func (i effectClearBadBuffs) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	switch i.aim {
	case csv.EFFECT_TARGET_SELF:
		buffs := self.getAllShowBuffs(sourceUID)
		for _, buffID := range buffs {
			if buff.GetBuffType(buffID) != csv.BUFF_BAD {
				continue
			}
			return true
		}
		return false
	}
	return false
}

func (i effectClearBadBuffs) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter
	switch i.aim {
	case csv.EFFECT_TARGET_SELF:
		buffs := self.getAllShowBuffs(sourceUID)
		for _, buffID := range buffs {
			if buff.GetBuffType(buffID) != csv.BUFF_BAD {
				continue
			}
			oldParam, newParam, ok := self.buffClean(sourceUID, buffID)
			if !ok {
				continue
			}
			localEffects := self.buffEffect(sourceUID, buffID, oldParam, newParam, effectGroupID)
			effects = append(effects, localEffects)
		}
		return
	}
	return
}
