package battle

import (
	"github.com/rs/zerolog/log"
	"shared/battle.etc/buff"
	"shared/battle.etc/card"
	"shared/battle.etc/potion"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

func useCardReply(o operation, errCode int32, cardRoundTimes *uint32) {
	re := OperationReply{
		Result: errCode,
	}
	if cardRoundTimes != nil {
		re.CardRoundTimes = *cardRoundTimes
	}
	select {
	case o.replyChan <- re:
		close(o.replyChan)
	default:
	}
}

func execEffectIDs(i *Battle, turnUID uint64, aimUID uint64, spellTypeID uint32, effectIDs []typeEffectID, cardOne card.Card, choiceCardID uint32) {
	rsp := pb.BattleActionNotice{}
	rsp.SourceUid = &turnUID
	rsp.ClientAimUid = &aimUID
	rsp.SpellId = i.generateSpellID()
	rsp.SpellTypeId = &spellTypeID
	spell := pb.BattleSpell{}
	for _, effectID := range effectIDs {
		effectPb, _ := effectID.exec(i, turnUID, aimUID, cardOne.RoundTimes, cardOne.ID, choiceCardID, cardOne.ResID)
		spell.Effects = append(spell.Effects, effectPb...)
	}
	switch cardOne.Type {
	case card.Attack:
		oldParam, newParam, ok := i.buffSub(turnUID, buff.TwiceAttack)
		if ok {
			buffEffect := i.buffEffect(turnUID, buff.TwiceAttack, oldParam, newParam, 1)
			spell.Effects = append(spell.Effects, buffEffect)
			for _, effectID := range effectIDs {
				effectPb, _ := effectID.exec(i, turnUID, aimUID, cardOne.RoundTimes, cardOne.ID, 0, cardOne.ResID)
				spell.Effects = append(spell.Effects, effectPb...)
			}
		}
	case card.Skill:
		oldParam, newParam, ok := i.buffSub(turnUID, buff.TwiceSkill)
		if ok {
			buffEffect := i.buffEffect(turnUID, buff.TwiceSkill, oldParam, newParam, 1)
			spell.Effects = append(spell.Effects, buffEffect)
			for _, effectID := range effectIDs {
				effectPb, _ := effectID.exec(i, turnUID, aimUID, cardOne.RoundTimes, cardOne.ID, 0, cardOne.ResID)
				spell.Effects = append(spell.Effects, effectPb...)
			}
		}
	default:
	}
	rsp.Spells = append(rsp.Spells, &spell)

	actionDown(i, i.heroIDs(), rsp)
}

// execute the operation in battle process
func (i *Battle) execUseCard(o operation, roundTimer <-chan time.Time) (errCode int32, checkStop bool, stopRound bool) {
	errCode = csv.ERRCODE_SUCCESS
	cardID := uint32(o.param1)
	aimUID := o.param2
	choiceCardID := uint32(o.param3)
	turnUID := i.turnUID
	log.Debug().Msgf("battle %v:%v debug use card cardID:%v, aimID:%v",
		i.battleStageUID, i.battleNodeID, cardID, aimUID)
	// hero is alive
	if i.battleItems[turnUID].hp <= 0 {
		errCode = csv.ERRCODE_BATTLE_HERO_DEAD
		useCardReply(o, errCode, nil)
		return
	}
	// card is exist
	cardOne, ok := i.battleHeros[turnUID].isExist(cardID)
	if !ok {
		errCode = csv.ERRCODE_BATTLE_CARD_NOT_EXIST
		useCardReply(o, errCode, nil)
		return
	}
	// confing is exist
	spellTypeID, _, checkList, effectIDs, interactivePriority, interactiveType, forcedAim, ok := getCardConfig(cardOne.TypeID, cardOne.Level)
	if !ok {
		errCode = csv.ERRCODE_FAILED
		useCardReply(o, errCode, nil)
		return
	}

	// check config before using card
	for _, check := range checkList {
		errCode = check.check(i)
		if errCode != csv.ERRCODE_SUCCESS {
			useCardReply(o, errCode, nil)
			return
		}
	}
	cardRoundTimes := cardOne.RoundTimes
	switch interactivePriority {
	case csv.PRIORITY_EFFECT_FIRST:
		errCode = i.effectFirst(o)
		useCardReply(o, errCode, &cardRoundTimes)
		stopRound = i.waitForChoosingDiscard(turnUID, roundTimer, cardOne)
		checkStop = true
		return
	case csv.PRIORITY_INTERACTIVE_FIRST:
		changedCard := cardOne
		errCode, stopRound, changedCard = i.interactiveFirst(o, interactiveType)
		useCardReply(o, errCode, &cardRoundTimes)
		stopRound = i.waitForChoosingCardAndExecEffects(turnUID, spellTypeID, effectIDs, aimUID, forcedAim, changedCard, roundTimer)
		checkStop = true
		return
	default:
		defer useCardReply(o, errCode, &cardRoundTimes)
	}

	// aim is alive
	if forcedAim {
		if !i.isAlive(aimUID) {
			errCode = csv.ERRCODE_BATTLE_AIM_HERO_DEAD
			return
		}
	}

	cardCost := cardOne.Cost
	_, _, handChangeCostBuffOk := i.buffShow(turnUID, buff.HandCardCostChange)
	if handChangeCostBuffOk {
		basic := uint32(buff.GetBasic(buff.HandCardCostChange))
		if cardCost != uint32(i.ConstCardCostX) && cardCost > basic {
			cardCost = basic
		}
	}
	// has enough mp
	if i.battleHeros[turnUID].mp < cardCost && cardCost != uint32(i.ConstCardCostX) {
		errCode = csv.ERRCODE_BATTLE_NO_MP
		return
	}
	// change card
	cardNotice, changedCard, ok := i.battleHeros[turnUID].useCard(cardID)
	if !ok {
		errCode = csv.ERRCODE_BATTLE_CARD_NOT_EXIST
		return
	}
	cardRoundTimes = changedCard.RoundTimes
	cardActionDown(i, turnUID, []card.MoveDesc{cardNotice})
	// cost MP
	if cardCost != uint32(i.ConstCardCostX) {
		oldMP := i.battleHeros[turnUID].mp
		newMP := i.battleHeros[turnUID].mp - cardCost
		i.battleHeros[turnUID].mp = newMP
		rsp := pb.BattleActionNotice{}
		rsp.SourceUid = &turnUID
		rsp.SpellId = i.generateSpellID()
		mpSpellTypeID := uint32(1)
		rsp.SpellTypeId = &mpSpellTypeID
		spell := pb.BattleSpell{}
		effect := pb.BattleEffect{}
		effectGroupID := uint32(1)
		effect.GroupId = &effectGroupID
		effect.Uid = &turnUID
		effectEnum := pb.BattleEffectEnum_BEffect_MP
		effect.E = &effectEnum
		oldValue, newValue := int32(oldMP), int32(newMP)
		effect.OldValue = &oldValue
		effect.NewValue = &newValue
		spell.Effects = append(spell.Effects, &effect)
		rsp.Spells = append(rsp.Spells, &spell)
		actionDown(i, []uint64{turnUID}, rsp)
	}
	// exec effect
	execEffectIDs(i, turnUID, aimUID, spellTypeID, effectIDs, changedCard, choiceCardID)

	errCode = csv.ERRCODE_SUCCESS
	checkStop = true
	return
}

// execute the operation in battle process
func (i *Battle) execUsePotion(o operation) (errCode int32, checkStop bool) {
	errCode = csv.ERRCODE_SUCCESS
	potionID := potion.Potion(o.param1)
	aimUID := o.param2
	turnID := i.turnUID
	log.Debug().Msgf("battle %v:%v debug use potion potionID:%v, aimID:%v",
		i.battleStageUID, i.battleNodeID, potionID, aimUID)
	// hero is alive
	if i.battleItems[turnID].hp <= 0 {
		errCode = csv.ERRCODE_BATTLE_HERO_DEAD
		return
	}
	// potion is exist
	allPotions := i.battleHeros[turnID].Potions
	index := -1
	for indexLocal, potion := range allPotions {
		if potionID == potion {
			index = indexLocal
			break
		}
	}
	if index < 0 {
		errCode = csv.ERRCODE_BATTLE_POTION_NOT_EXIST
		return
	}

	// confing is exist
	spellTypeID, effectIDs, forcedAim, ok := getPotionConfig(potionID)
	if !ok {
		errCode = csv.ERRCODE_FAILED
		return
	}
	// aim is alive
	if forcedAim {
		if !i.isAlive(aimUID) {
			errCode = csv.ERRCODE_BATTLE_AIM_HERO_DEAD
			return
		}
	}
	// delete potion
	newPotions := append(allPotions[:index], allPotions[index+1:]...)
	i.battleHeros[turnID].Potions = newPotions
	potionActionDown(i, turnID)
	// exec effect
	rsp := pb.BattleActionNotice{}
	rsp.SourceUid = &turnID
	rsp.SpellId = i.generateSpellID()
	rsp.SpellTypeId = &spellTypeID
	for _, effectID := range effectIDs {
		spell := pb.BattleSpell{}
		effectPb, _ := effectID.exec(i, turnID, aimUID, 0, 0, 0, spellTypeID)
		spell.Effects = effectPb
		rsp.Spells = append(rsp.Spells, &spell)
	}
	actionDown(i, i.heroIDs(), rsp)

	errCode = csv.ERRCODE_SUCCESS
	checkStop = true

	return
}

func (i *Battle) effectFirst(op operation) (errCode int32) {
	errCode = csv.ERRCODE_SUCCESS

	cardID := uint32(op.param1)
	aimUID := op.param2
	turnID := i.turnUID
	log.Debug().Msgf("battle %v:%v debug use card cardID:%v, aimID:%v",
		i.battleStageUID, i.battleNodeID, cardID, aimUID)
	// hero is alive
	if i.battleItems[turnID].hp <= 0 {
		errCode = csv.ERRCODE_BATTLE_HERO_DEAD
		return
	}
	// card is exist
	cardOne, ok := i.battleHeros[turnID].isExist(cardID)
	if !ok {
		errCode = csv.ERRCODE_BATTLE_CARD_NOT_EXIST
		return
	}
	// config is exist
	spellTypeID, _, checkList, effectIDs, _, interactiveType, forcedAim, ok := getCardConfig(cardOne.TypeID, cardOne.Level)
	if !ok {
		errCode = csv.ERRCODE_FAILED
		return
	}

	// check config before using card
	for _, check := range checkList {
		errCode = check.check(i)
		if errCode != csv.ERRCODE_SUCCESS {
			return
		}
	}

	// aim is alive
	if forcedAim {
		if !i.isAlive(aimUID) {
			errCode = csv.ERRCODE_BATTLE_AIM_HERO_DEAD
			return
		}
	}
	// has enough mp
	if i.battleHeros[turnID].mp < cardOne.Cost && cardOne.Cost == uint32(i.ConstCardCostX) {
		errCode = csv.ERRCODE_BATTLE_NO_MP
		return
	}

	if interactiveType != csv.INTERACTIVE_DEAW_3_DIS_1 && interactiveType != csv.INTERACTIVE_DEAW_1_DIS_1 {
		errCode = csv.ERRCODE_CARD_INTERACTIVE_TYPE_NOT_EXIST
		return
	}

	// change card
	cardNotice, changedCard, ok := i.battleHeros[turnID].useCard(cardID)
	if !ok {
		errCode = csv.ERRCODE_BATTLE_CARD_NOT_EXIST
		return
	}
	cardActionDown(i, turnID, []card.MoveDesc{cardNotice})
	// cost MP
	if cardOne.Cost != uint32(i.ConstCardCostX) {
		oldMP := i.battleHeros[turnID].mp
		newMP := i.battleHeros[turnID].mp - cardOne.Cost
		i.battleHeros[turnID].mp = newMP
		rsp := pb.BattleActionNotice{}
		rsp.SourceUid = &turnID
		rsp.SpellId = i.generateSpellID()
		mpSpellTypeID := uint32(1)
		rsp.SpellTypeId = &mpSpellTypeID
		spell := pb.BattleSpell{}
		effect := pb.BattleEffect{}
		effectGroupID := uint32(1)
		effect.GroupId = &effectGroupID
		effect.Uid = &turnID
		effectEnum := pb.BattleEffectEnum_BEffect_MP
		effect.E = &effectEnum
		oldValue, newValue := int32(oldMP), int32(newMP)
		effect.OldValue = &oldValue
		effect.NewValue = &newValue
		spell.Effects = append(spell.Effects, &effect)
		rsp.Spells = append(rsp.Spells, &spell)
		actionDown(i, []uint64{turnID}, rsp)
	}

	h, _ := i.battleHeros[turnID]
	chooseCardEnum := pb.ChooseCardEnum_DISCARD_FROM_HAND
	num := uint32(1)
	var cardMove []card.MoveDesc
	var err error
	switch interactiveType {
	case csv.INTERACTIVE_DEAW_1_DIS_1:
		cardMove, err = h.giveCardsN(i, 1, pb.BattleCardReasonEnum_BCardReason_USE, cardOne.ResID)
		//b.giveCard()
	case csv.INTERACTIVE_DEAW_3_DIS_1:
		cardMove, err = h.giveCardsN(i, 3, pb.BattleCardReasonEnum_BCardReason_USE, cardOne.ResID)
	default:
	}
	if err != nil {
		log.Error().Msgf("effect first give cards failed, err: %v", err)
		errCode = csv.ERRCODE_FAILED
		return
	}
	cardActionDown(i, turnID, cardMove)
	var cards = make([]*pb.BattleCard, len(h.handyCards))

	for i, c := range h.handyCards {
		cards[i] = c.ToClientProto()
	}
	h.chooseCardType = uint32(chooseCardEnum)
	h.chooseCardNum = num
	notice := &pb.BattleChooseCardNotice{
		Type:  &chooseCardEnum,
		Num:   &num,
		Cards: cards,
	}
	chooseCardNoticeDown(i, turnID, notice)

	// exec effect
	execEffectIDs(i, turnID, aimUID, spellTypeID, effectIDs, changedCard, 0)

	errCode = csv.ERRCODE_SUCCESS

	return
}

func (i *Battle) waitForChoosingDiscard(heroUID uint64, roundTimer <-chan time.Time, cardOne card.Card) (stopRound bool) {
	stop := false
	for {
		if stop {
			break
		}
		select {
		case control := <-i.battleInChan:
			controlSingal, _ := control.Control.(Control)
			stopRound, _ = i.controlSingal(controlSingal)
			if stopRound {
				stop = true
			}
		case <-roundTimer:
			stopRound = true
			stop = true
		case opInterface := <-i.operationChanS[heroUID]:
			op2, ok := opInterface.(operation)
			if !ok || !op2.isChooseCard {
				log.Error().Msgf("need choosing card")
				select {
				case op2.replyChan <- OperationReply{Result: csv.ERRCODE_BATTLE_CHOOSE_CARD_NECESSARY}:
					close(op2.replyChan)
				default:
				}
				continue
			}
			errCode2 := i.chooseDisCard(op2, cardOne)
			// reply
			select {
			case op2.replyChan <- OperationReply{Result: errCode2}:
				close(op2.replyChan)
			default:
			}
			if errCode2 != csv.ERRCODE_SUCCESS {
				continue
			}
			stop = true
		}
	}
	return
}

func (i *Battle) chooseDisCard(op operation, cardOne card.Card) (errCode int32) {
	errCode = csv.ERRCODE_SUCCESS
	turnUID := i.turnUID
	h, ok := i.battleHeros[turnUID]
	if !ok {
		errCode = csv.ERRCODE_NOT_IN_TURN
		return
	}
	if h.HP <= 0 {
		errCode = csv.ERRCODE_BATTLE_HERO_DEAD
		return
	}

	cardUIDs := op.cardUIDs
	if len(cardUIDs) != int(h.chooseCardNum) {
		errCode = csv.ERRCODE_CHOOSE_CARD_NUM_NOT_MATCH
		return
	}
	var cardMoves []card.MoveDesc
	switch pb.ChooseCardEnum(h.chooseCardType) {
	case pb.ChooseCardEnum_DISCARD_FROM_HAND:
		for _, uid := range cardUIDs {
			if _, ok := h.isExist(uid); !ok {
				errCode = csv.ERRCODE_BATTLE_CARD_NOT_EXIST
				return
			}
			mv, ok := h.disCard(uid, pb.BattleCardReasonEnum_BCardReason_USE, cardOne.ResID)
			if !ok {
				errCode = csv.ERRCODE_SYS_INTERNAL_ERROR
				return
			}
			cardMoves = append(cardMoves, mv)
		}
	default:
		return
	}
	cardActionDown(i, turnUID, cardMoves)
	return
}

func (i *Battle) interactiveFirst(op operation, interactiveType uint32) (errCode int32, stopRound bool, changedCard card.Card) {

	turnUID := i.turnUID
	cardUID := uint32(op.param1)
	//aimUID := uint64(op.param2)
	errCode = csv.ERRCODE_SUCCESS
	h, _ := i.battleHeros[turnUID]

	cardOne, _ := h.isExist(cardUID)

	//_, _, _, effectIDs, _, interactiveType, forceAim, _ := getCardConfig(cardOne.TypeID, cardOne.Level)
	// has enough mp
	if i.battleHeros[turnUID].mp < cardOne.Cost && cardOne.Cost == uint32(i.ConstCardCostX) {
		errCode = csv.ERRCODE_BATTLE_NO_MP
		return
	}

	if interactiveType != csv.INTERACTIVE_DEAW_3_DIS_1 && interactiveType != csv.INTERACTIVE_DEAW_1_DIS_1 {
		errCode = csv.ERRCODE_CARD_INTERACTIVE_TYPE_NOT_EXIST
		return
	}

	// change card
	cardNotice, changedCard, ok := i.battleHeros[turnUID].useCard(cardUID)
	if !ok {
		errCode = csv.ERRCODE_BATTLE_CARD_NOT_EXIST
		return
	}
	cardActionDown(i, turnUID, []card.MoveDesc{cardNotice})
	// cost MP
	if cardOne.Cost != uint32(i.ConstCardCostX) {
		oldMP := i.battleHeros[turnUID].mp
		newMP := i.battleHeros[turnUID].mp - cardOne.Cost
		i.battleHeros[turnUID].mp = newMP
		rsp := pb.BattleActionNotice{}
		rsp.SourceUid = &turnUID
		rsp.SpellId = i.generateSpellID()
		mpSpellTypeID := uint32(1)
		rsp.SpellTypeId = &mpSpellTypeID
		spell := pb.BattleSpell{}
		effect := pb.BattleEffect{}
		effectGroupID := uint32(1)
		effect.GroupId = &effectGroupID
		effect.Uid = &turnUID
		effectEnum := pb.BattleEffectEnum_BEffect_MP
		effect.E = &effectEnum
		oldValue, newValue := int32(oldMP), int32(newMP)
		effect.OldValue = &oldValue
		effect.NewValue = &newValue
		spell.Effects = append(spell.Effects, &effect)
		rsp.Spells = append(rsp.Spells, &spell)
		actionDown(i, []uint64{turnUID}, rsp)
	}

	chooseCardType := pb.ChooseCardEnum_DISCARD_FROM_HAND
	num := uint32(1)
	var cardMoves []card.MoveDesc
	var err error
	switch interactiveType {
	case csv.INTERACTIVE_DEAW_1_DIS_1:
		cardMoves, err = h.giveCardsN(i, 1, pb.BattleCardReasonEnum_BCardReason_USE, changedCard.ResID)
	case csv.INTERACTIVE_DEAW_3_DIS_1:
		cardMoves, err = h.giveCardsN(i, 3, pb.BattleCardReasonEnum_BCardReason_USE, changedCard.ResID)
	default:
	}
	if err != nil {
		errCode = csv.ERRCODE_SYS_INTERNAL_ERROR
		log.Debug().Msgf("interactive first give cards failed")
		return
	}
	cardActionDown(i, turnUID, cardMoves)
	var cards = make([]*pb.BattleCard, len(h.handyCards))

	for i, c := range h.handyCards {
		cards[i] = c.ToClientProto()
	}
	h.chooseCardType = uint32(chooseCardType)
	h.chooseCardNum = num
	notice := &pb.BattleChooseCardNotice{
		Type:  &chooseCardType,
		Num:   &num,
		Cards: cards,
	}
	chooseCardNoticeDown(i, turnUID, notice)

	errCode = csv.ERRCODE_SUCCESS
	return
}

func (i *Battle) waitForChoosingCardAndExecEffects(heroUID uint64, spellTypeID uint32, effectIDs []typeEffectID, aimUID uint64, forceAim bool, cardOne card.Card, roundTimer <-chan time.Time) (stopRound bool) {
	stop := false
	for {
		if stop {
			break
		}
		select {
		case control := <-i.battleInChan:
			controlSingal, _ := control.Control.(Control)
			stopRound, _ = i.controlSingal(controlSingal)
			if stopRound {
				stop = true
			}
		case <-roundTimer:
			stopRound = true
			stop = true
		case opInterface := <-i.operationChanS[heroUID]:
			op2, ok := opInterface.(operation)
			if !ok || !op2.isChooseCard {
				select {
				case op2.replyChan <- OperationReply{Result: csv.ERRCODE_BATTLE_CHOOSE_CARD_NECESSARY}:
					close(op2.replyChan)
				default:
				}
				continue
			}
			errCode2 := i.chooseCardAndExecEffects(spellTypeID, effectIDs, aimUID, forceAim, cardOne, op2)

			// reply
			select {
			case op2.replyChan <- OperationReply{Result: errCode2}:
				close(op2.replyChan)
			default:
			}
			if errCode2 != csv.ERRCODE_SUCCESS {
				continue
			}
			stop = true
		}
	}
	return
}

func (i *Battle) chooseCardAndExecEffects(spellTypeID uint32, effectIDs []typeEffectID, aimUID uint64, forceAim bool, cardOne card.Card, newOp operation) (errCode int32) {
	errCode = csv.ERRCODE_SUCCESS
	turnUID := i.turnUID
	cardUIDs := newOp.cardUIDs

	h, ok := i.battleHeros[turnUID]
	if !ok {
		errCode = csv.ERRCODE_NOT_IN_TURN
		return
	}
	if h.HP <= 0 {
		errCode = csv.ERRCODE_BATTLE_HERO_DEAD
		return
	}

	if len(cardUIDs) != int(h.chooseCardNum) {
		errCode = csv.ERRCODE_CHOOSE_CARD_NUM_NOT_MATCH
		return
	}

	var cardMoves []card.MoveDesc
	switch pb.ChooseCardEnum(h.chooseCardType) {
	case pb.ChooseCardEnum_DISCARD_FROM_HAND:
		for _, id := range cardUIDs {
			mv, ok := h.disCard(id, pb.BattleCardReasonEnum_BCardReason_USE, cardOne.ResID)
			if !ok {
				errCode = csv.ERRCODE_SYS_INTERNAL_ERROR
				return
			}
			cardMoves = append(cardMoves, mv)
		}
	default:
		return
	}
	cardActionDown(i, turnUID, cardMoves)

	if forceAim && aimUID != 0 {
		if !i.isAlive(aimUID) {
			errCode = csv.ERRCODE_BATTLE_AIM_HERO_DEAD
			return
		}
	}

	// exec effect
	if len(effectIDs) > 0 {
		execEffectIDs(i, turnUID, aimUID, spellTypeID, effectIDs, cardOne, 0)
	}
	return
}
