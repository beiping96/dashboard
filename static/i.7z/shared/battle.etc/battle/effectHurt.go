package battle

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math"
	"math/rand"
	"shared/battle.etc/buff"
	"shared/battle.etc/card"
	"shared/battle.etc/relic"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

func (i *Battle) normalAttack(sourUID uint64, aimUID uint64, hpD uint32, blood bool, effectGroupID uint32) []*pb.BattleEffect {
	hadBeHurt := i.battleItems[aimUID].hadBeHurt
	attackType := pb.BattleEffectEnum_BEffect_N_ATTACK_HP
	aimOldHP := i.battleItems[aimUID].hp
	ans := i.trueAttack(sourUID, aimUID, hpD, blood, effectGroupID, &attackType)
	aimNewHP := i.battleItems[aimUID].hp

	// try trigger electricity buff
	oldParam, newParam, ok := i.buffShow(aimUID, buff.Electricity)
	if ok && i.isAlive(aimUID) {
		buffEffect := i.buffEffect(aimUID, buff.Electricity, oldParam, newParam, effectGroupID)
		ans = append(ans, buffEffect)
		deHP := oldParam * uint32(buff.GetBasic(buff.Electricity))
		effectList := i.trueAttack(sourUID, aimUID, deHP, false, effectGroupID, nil)
		ans = append(ans, effectList...)

		localOldParam, localNewParam, ok := i.buffShow(sourUID, buff.AttackAfterElectricity)
		if ok {
			buffEffect := i.buffEffect(sourUID, buff.AttackAfterElectricity, localOldParam, localNewParam, effectGroupID)
			ans = append(ans, buffEffect)
			aimCamp := i.battleItems[aimUID].camp
			for _, aimTeammateID := range i.aliveUIDs(aimCamp) {
				if aimTeammateID == aimUID {
					continue
				}
				if i.isAlive(aimTeammateID) {
					effects := i.trueAttack(sourUID, aimTeammateID, deHP, false, effectGroupID, nil)
					ans = append(ans, effects...)
				}
			}
		}
	}

	// try trigger attackAfterFrozen buff
	oldParam, newParam, ok = i.buffShow(sourUID, buff.AttackAfterFrozen)
	aimOldParam, aimNewParam, aimOk := i.buffShow(aimUID, buff.Frozen)
	if ok && aimOk && i.isAlive(aimUID) {
		aimBuffEffect := i.buffEffect(aimUID, buff.Frozen, aimOldParam, aimNewParam, effectGroupID)
		ans = append(ans, aimBuffEffect)
		buffEffect := i.buffEffect(sourUID, buff.AttackAfterFrozen, oldParam, newParam, effectGroupID)
		ans = append(ans, buffEffect)
		// exec buff
		deHP := aimOldParam * uint32(buff.GetBasic(buff.AttackAfterFrozen)) * 1
		effectList := i.trueAttack(sourUID, aimUID, deHP, false, effectGroupID, nil)
		ans = append(ans, effectList...)
	}
	// try trigger reflect buff
	oldParam, newParam, ok = i.buffShow(aimUID, buff.Reflect)
	if ok && i.isAlive(sourUID) && i.isAlive(aimUID) {
		buffEffect := i.buffEffect(aimUID, buff.Reflect, oldParam, newParam, effectGroupID)
		ans = append(ans, buffEffect)
		// exec buff
		deHP := uint32(buff.GetBasic(buff.Reflect)) * oldParam
		effectList := i.trueAttack(aimUID, sourUID, deHP, false, effectGroupID, nil)
		ans = append(ans, effectList...)
	}
	// try trigger turn reflect buff
	oldParam, newParam, ok = i.buffShow(aimUID, buff.TurnReflect)
	if ok && i.isAlive(sourUID) && i.isAlive(aimUID) {
		buffEffect := i.buffEffect(aimUID, buff.TurnReflect, oldParam, newParam, effectGroupID)
		ans = append(ans, buffEffect)
		// exec buff
		deHP := uint32(buff.GetBasic(buff.TurnReflect)) * oldParam
		effectList := i.trueAttack(aimUID, sourUID, deHP, false, effectGroupID, nil)
		ans = append(ans, effectList...)
	}

	// try trigger powerfulAfterBeHurt buff
	oldParam, newParam, ok = i.buffShow(aimUID, buff.PowerfulAfterBeHurt)
	if ok && i.isAlive(aimUID) {
		buffEffect := i.buffEffect(aimUID, buff.PowerfulAfterBeHurt, oldParam, newParam, effectGroupID)
		ans = append(ans, buffEffect)
		// exec buff
		basic := uint32(buff.GetBasic(buff.PowerfulAfterBeHurt)) * oldParam
		effectList := i.powerChange(aimUID, int32(basic), effectGroupID)
		ans = append(ans, effectList...)
	}

	// in first be hurt
	if !hadBeHurt && aimNewHP < aimOldHP {
		// try trigger blockAfterFirstBeHurt buff
		oldParam, newParam, ok = i.buffShow(aimUID, buff.BlockAfterFirstBeHurt)
		if ok && i.isAlive(aimUID) {
			oldParam, newParam, ok = i.buffClean(aimUID, buff.BlockAfterFirstBeHurt)
			buffEffect := i.buffEffect(aimUID, buff.BlockAfterFirstBeHurt, oldParam, newParam, effectGroupID)
			ans = append(ans, buffEffect)
			// exec buff
			basic := uint32(buff.GetBasic(buff.BlockAfterFirstBeHurt)) * oldParam
			effectList := i.addBlock(aimUID, basic, effectGroupID)
			ans = append(ans, effectList...)
		}
		// do relic
		if i.battleItems[aimUID].heroTypeID > 0 && i.isAlive(aimUID) {
			heroOne := i.battleHeros[aimUID]
			// do AddMpAfterFirstBeHurt relic
			if relicParam, ok := heroOne.GetRelic(relic.AddMpAfterFirstBeHurt); ok {
				basic, _, _, ok := relic.GetRelicBasic(relic.AddMpAfterFirstBeHurt)
				if ok {
					relicEffect := i.relicEffect(aimUID, relic.AddMpAfterFirstBeHurt, relicParam, relicParam, effectGroupID)
					ans = append(ans, relicEffect)
					// exec
					effectList := i.addMp(aimUID, uint32(basic), effectGroupID)
					ans = append(ans, effectList...)
				}
			}
			// do HurtAllAfterFirstBeHurt relic
			if relicParam, ok := heroOne.GetRelic(relic.HurtAllAfterFirstBeHurt); ok {
				basic, _, _, ok := relic.GetRelicBasic(relic.HurtAllAfterFirstBeHurt)
				if ok {
					relicEffect := i.relicEffect(aimUID, relic.HurtAllAfterFirstBeHurt, relicParam, relicParam, effectGroupID)
					ans = append(ans, relicEffect)
					// exec
					selfCamp := i.battleItems[aimUID].camp
					for _, uid := range i.aliveUIDs(otherCamp(selfCamp)) {
						effectList := i.trueAttack(aimUID, uid, uint32(basic), false, effectGroupID, nil)
						ans = append(ans, effectList...)
					}
				}
			}
			// do GiveCardAfterFirstBeHurt relic
			if relicParam, ok := heroOne.GetRelic(relic.GiveCardAfterFirstBeHurt); ok {
				basic, _, _, ok := relic.GetRelicBasic(relic.GiveCardAfterFirstBeHurt)
				if ok {
					relicEffect := i.relicEffect(aimUID, relic.GiveCardAfterFirstBeHurt, relicParam, relicParam, effectGroupID)
					// exec
					cardMove, err := heroOne.giveCardsN(i, uint32(basic), pb.BattleCardReasonEnum_BCardReason_RELIC, relic.GiveCardAfterFirstBeHurt)
					if err == nil {
						ans = append(ans, relicEffect)
						cardActionDown(i, aimUID, cardMove)
					}
				}
			}
			// do AddAgilityAfterFirstBeHurt relic
			if relicParam, ok := heroOne.GetRelic(relic.AddAgilityAfterFirstBeHurt); ok {
				basic, _, _, ok := relic.GetRelicBasic(relic.AddAgilityAfterFirstBeHurt)
				if ok {
					relicEffect := i.relicEffect(aimUID, relic.AddAgilityAfterFirstBeHurt, relicParam, relicParam, effectGroupID)
					ans = append(ans, relicEffect)
					// exec
					effectList := i.agilityChange(aimUID, int32(basic), effectGroupID)
					ans = append(ans, effectList...)
				}
			}
			// do AddPowerAfterFirstBuHurt relic
			if relicParam, ok := heroOne.GetRelic(relic.AddPowerAfterFirstBuHurt); ok {
				basic, _, _, ok := relic.GetRelicBasic(relic.AddPowerAfterFirstBuHurt)
				if ok {
					relicEffect := i.relicEffect(aimUID, relic.AddPowerAfterFirstBuHurt, relicParam, relicParam, effectGroupID)
					ans = append(ans, relicEffect)
					// exec
					effectList := i.powerChange(aimUID, int32(basic), effectGroupID)
					ans = append(ans, effectList...)
				}
			}
			// do AllEasyToHurtAfterFirstBeHurt relic
			if relicParam, ok := heroOne.GetRelic(relic.AllEasyToHurtAfterFirstBeHurt); ok {
				buffNum, buffTypeID, _, ok := relic.GetRelicBasic(relic.AllEasyToHurtAfterFirstBeHurt)
				if ok {
					relicEffect := i.relicEffect(aimUID, relic.AllEasyToHurtAfterFirstBeHurt, relicParam, relicParam, effectGroupID)
					ans = append(ans, relicEffect)
					// exec
					selfCamp := i.battleItems[aimUID].camp
					for _, uid := range i.aliveUIDs(otherCamp(selfCamp)) {
						effectList := i.addBuff(aimUID, uid, uint32(buffTypeID), uint32(buffNum), effectGroupID)
						ans = append(ans, effectList...)
					}
				}
			}
			// do AllAttackPowerlessAfterFirstBeHurt relic
			if relicParam, ok := heroOne.GetRelic(relic.AllAttackPowerlessAfterFirstBeHurt); ok {
				buffNum, buffTypeID, _, ok := relic.GetRelicBasic(relic.AllAttackPowerlessAfterFirstBeHurt)
				if ok {
					relicEffect := i.relicEffect(aimUID, relic.AllAttackPowerlessAfterFirstBeHurt, relicParam, relicParam, effectGroupID)
					ans = append(ans, relicEffect)
					// exec
					selfCamp := i.battleItems[aimUID].camp
					for _, uid := range i.aliveUIDs(otherCamp(selfCamp)) {
						effectList := i.addBuff(aimUID, uid, uint32(buffTypeID), uint32(buffNum), effectGroupID)
						ans = append(ans, effectList...)
					}
				}
			}
			// do AllElectricityAfterFirstBeHurt relic
			if relicParam, ok := heroOne.GetRelic(relic.AllElectricityAfterFirstBeHurt); ok {
				buffNum, buffTypeID, _, ok := relic.GetRelicBasic(relic.AllElectricityAfterFirstBeHurt)
				if ok {
					relicEffect := i.relicEffect(aimUID, relic.AllElectricityAfterFirstBeHurt, relicParam, relicParam, effectGroupID)
					ans = append(ans, relicEffect)
					// exec
					selfCamp := i.battleItems[aimUID].camp
					for _, uid := range i.aliveUIDs(otherCamp(selfCamp)) {
						effectList := i.addBuff(aimUID, uid, uint32(buffTypeID), uint32(buffNum), effectGroupID)
						ans = append(ans, effectList...)
					}
				}
			}
		}
	}

	return ans
}

func (i *Battle) countEffectHurtBasic(sourceUID uint64, aimUID uint64, basic uint32, isAngryHurt bool) uint32 {
	// add angry buff
	if angryParam, _, ok := i.buffShow(sourceUID, buff.Angry); ok {
		if isAngryHurt {
			basic += uint32(buff.GetBasic(buff.Angry)) * angryParam * 3
		} else {
			basic += uint32(buff.GetBasic(buff.Angry)) * angryParam
		}
	}
	// sub frozen buff
	if frozenParam, _, ok := i.buffShow(sourceUID, buff.Frozen); ok {
		frozenBasic := uint32(buff.GetBasic(buff.Frozen))
		if basic >= frozenBasic*frozenParam {
			basic -= frozenBasic * frozenParam
		} else {
			basic = 0
		}
	}
	// sub attackPowerless buff
	if _, _, ok := i.buffShow(sourceUID, buff.AttackPowerless); ok {
		attackPowerlessBasic := uint32(buff.GetBasic(buff.AttackPowerless))
		// do FixEnemyAttackPowerless relic
		if i.battleItems[aimUID].heroTypeID > 0 {
			if _, ok := i.battleHeros[aimUID].GetRelic(relic.FixEnemyAttackPowerless); ok {
				attackPowerlessBasicLocal, _, _, ok := relic.GetRelicBasic(relic.FixEnemyAttackPowerless)
				if ok {
					attackPowerlessBasic = uint32(attackPowerlessBasicLocal)
				}
			}
		}
		// exec
		if attackPowerlessBasic <= 100 {
			percent := float64(100-attackPowerlessBasic) / 100
			basic = uint32(math.Trunc(float64(basic) * percent))
		}
	}
	// add easyToHurt buff
	if i.isAlive(aimUID) {
		easyToHurtBasic := uint32(buff.GetBasic(buff.EasyToHurt))
		_, _, ok := i.buffShow(aimUID, buff.EasyToHurt)
		if ok {
			// do FixEnemyEasyToHurt relic
			if i.battleItems[sourceUID].heroTypeID > 0 {
				if _, ok := i.battleHeros[sourceUID].GetRelic(relic.FixEnemyEasyToHurt); ok {
					easyToHurtBasicLocal, _, _, ok := relic.GetRelicBasic(relic.FixEnemyEasyToHurt)
					if ok {
						easyToHurtBasic = uint32(easyToHurtBasicLocal)
					}
				}
			}
			// do FixSelfEasyToHurt relic
			if i.battleItems[aimUID].heroTypeID > 0 {
				if _, ok := i.battleHeros[aimUID].GetRelic(relic.FixSelfEasyToHurt); ok {
					easyToHurtBasicLocal, _, _, ok := relic.GetRelicBasic(relic.FixSelfEasyToHurt)
					if ok {
						easyToHurtBasic = uint32(easyToHurtBasicLocal)
					}
				}
			}
			// exec
			if easyToHurtBasic < 100 {
				percent := float64(100+easyToHurtBasic) / 100
				basic = uint32(math.Trunc(float64(basic) * percent))
			}
		}
	}
	return basic
}

type effectHurt struct {
	effectCommon
	roundTimesPlus uint32
}

func registerEffectHurt(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHurt{
		effectCommon:   newEffectCommon(c),
		roundTimesPlus: uint32(c.Param2),
	}
}

func (i effectHurt) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectHurt) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	if self.battleItems[sourceUID].power > 0 {
		basic += uint32(self.battleItems[sourceUID].power)
	}
	if self.battleItems[sourceUID].power < 0 {
		powerLocal := uint32(0 - self.battleItems[sourceUID].power)
		if powerLocal > basic {
			basic = 0
		} else {
			basic -= powerLocal
		}
	}
	// add roundTimes
	if len(arg) > 0 {
		log.Debug().Msgf("effect exec debug effectHurt:%v source:%v aim:%v arg:%v",
			i, sourceUID, aimUID, arg)
		roundTimesPlus, ok := arg[0].(uint32)
		if ok && roundTimesPlus > 0 {
			basic += (roundTimesPlus - 1) * i.roundTimesPlus
		}
	}
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)

	times = i.times
	return
}

func (i effectHurt) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectHurt) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID, arg...)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.normalAttack(sourceUID, aimUID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				basic, _ = i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			basic, _ = i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectHurtBlock struct {
	effectCommon
}

func registerEffectHurtBlock(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHurtBlock{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectHurtBlock) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectHurtBlock) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic * self.battleItems[sourceUID].block
	if self.battleItems[sourceUID].power > 0 {
		basic += uint32(self.battleItems[sourceUID].power)
	}
	if self.battleItems[sourceUID].power < 0 {
		powerLocal := uint32(0 - self.battleItems[sourceUID].power)
		if powerLocal > basic {
			basic = 0
		} else {
			basic -= powerLocal
		}
	}
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)

	times = i.times
	return
}

func (i effectHurtBlock) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectHurtBlock) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.normalAttack(sourceUID, aimUID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				basic, _ = i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			basic, _ = i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectHurtMp struct {
	effectCommon
}

func registerEffectHurtMp(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHurtMp{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectHurtMp) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use %v effect", i)
	return nil
}

func (i effectHurtMp) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	if self.battleItems[sourceUID].power > 0 {
		basic += uint32(self.battleItems[sourceUID].power)
	}
	if self.battleItems[sourceUID].power < 0 {
		powerLocal := uint32(0 - self.battleItems[sourceUID].power)
		if powerLocal > basic {
			basic = 0
		} else {
			basic -= powerLocal
		}
	}
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)

	heroInBattle, ok := self.battleHeros[sourceUID]
	if !ok {
		log.Error().Msgf("battle error monster can't use hurtMpEffect")
		return
	}
	times = heroInBattle.mp
	return
}

func (i effectHurtMp) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectHurtMp) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	if times == 0 {
		return
	}
	// deMp and notice
	oldMP := times
	newMP := uint32(0)
	self.battleHeros[sourceUID].mp = newMP
	rsp := pb.BattleActionNotice{}
	rsp.SourceUid = &sourceUID
	rsp.SpellId = self.generateSpellID()
	spellTypeID := uint32(1)
	rsp.SpellTypeId = &spellTypeID
	spell := pb.BattleSpell{}
	effect := pb.BattleEffect{}
	mpEffectGroupID := uint32(1)
	effect.GroupId = &mpEffectGroupID
	effect.Uid = &sourceUID
	effectEnum := pb.BattleEffectEnum_BEffect_MP
	effect.E = &effectEnum
	oldValue, newValue := int32(oldMP), int32(newMP)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	spell.Effects = append(spell.Effects, &effect)
	rsp.Spells = append(rsp.Spells, &spell)
	actionDown(self, []uint64{sourceUID}, rsp)
	// exec
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.normalAttack(sourceUID, aimUID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				basic, _ = i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			basic, _ = i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectHurtCard struct {
	effectCommon
}

func registerEffectHurtCard(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHurtCard{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectHurtCard) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use %v effect", i)
	return nil
}

func (i effectHurtCard) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	if self.battleItems[sourceUID].power > 0 {
		basic += uint32(self.battleItems[sourceUID].power)
	}
	if self.battleItems[sourceUID].power < 0 {
		powerLocal := uint32(0 - self.battleItems[sourceUID].power)
		if powerLocal > basic {
			basic = 0
		} else {
			basic -= powerLocal
		}
	}
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)

	heroInBattle, ok := self.battleHeros[sourceUID]
	if !ok {
		log.Error().Msgf("battle error monster can't use hurtCardEffect")
		return
	}
	times = uint32(len(heroInBattle.handyCards))
	return
}

func (i effectHurtCard) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectHurtCard) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	heroInBattle, ok := self.battleHeros[sourceUID]
	if !ok {
		log.Error().Msgf("battle error monster can't use hurtCardEffect")
		return
	}
	var cardIDs []uint32
	for _, c := range heroInBattle.handyCards {
		cardIDs = append(cardIDs, c.ID)
	}
	if times == 0 || times != uint32(len(cardIDs)) {
		return
	}
	// exhaustedCard and notice
	cardActionList := []card.MoveDesc{}
	for _, cardID := range cardIDs {
		cardAction, ok := heroInBattle.exhaustedCard(cardID, pb.BattleCardReasonEnum_BCardReason_USE, arg[3].(uint32))
		if !ok {
			log.Error().Msgf("Battle %v:%v Error exhausted card Error info:%v",
				self.battleStageUID, self.battleNodeID, self)
			continue
		}
		cardActionList = append(cardActionList, cardAction)
	}
	cardActionDown(self, sourceUID, cardActionList)
	// exec
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.normalAttack(sourceUID, aimUID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				basic, _ = i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			basic, _ = i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

func (i *Battle) trueAttack(sourceUID uint64, aimUID uint64, hpD uint32, blood bool, effectGroupID uint32, attackType *pb.BattleEffectEnum) []*pb.BattleEffect {
	if attackType == nil {
		effectEnum := pb.BattleEffectEnum_BEffect_ATTACK_HP
		attackType = &effectEnum
	}
	ans := []*pb.BattleEffect{}
	oldBlock := i.battleItems[aimUID].block
	if oldBlock > 0 {
		effect := pb.BattleEffect{}
		effect.GroupId = &effectGroupID
		if oldBlock > hpD {
			i.battleItems[aimUID].block -= hpD
		} else {
			i.battleItems[aimUID].block = 0
		}
		newBlock := i.battleItems[aimUID].block
		effect.Uid = &aimUID
		effectEnum := pb.BattleEffectEnum_BEffect_BLOCK
		effect.E = &effectEnum
		param := hpD
		effect.Param = &param
		oldValue, newValue := int32(oldBlock), int32(newBlock)
		effect.OldValue = &oldValue
		effect.NewValue = &newValue
		ans = append(ans, &effect)
	}

	if oldBlock >= hpD {
		return ans
	}
	hpD -= oldBlock

	if i.battleItems[sourceUID].heroTypeID > 0 && *attackType == pb.BattleEffectEnum_BEffect_N_ATTACK_HP {
		// do HurtPlusAfterHurt relic
		if param, ok := i.battleHeros[sourceUID].GetRelic(relic.HurtPlusAfterHurt); ok {
			param1, param2, _, ok := relic.GetRelicBasic(relic.HurtPlusAfterHurt)
			if ok && hpD <= uint32(param1) {
				effectRelic := i.relicEffect(sourceUID, relic.HurtPlusAfterHurt, param, param, effectGroupID)
				ans = append(ans, effectRelic)
				hpD = uint32(param2)
			}
		}
	}
	if i.battleItems[aimUID].heroTypeID > 0 && *attackType == pb.BattleEffectEnum_BEffect_N_ATTACK_HP {
		// do HurtSubAfterBeHurt relic
		if param, ok := i.battleHeros[aimUID].GetRelic(relic.HurtSubAfterBeHurt); ok {
			param1, param2, _, ok := relic.GetRelicBasic(relic.HurtSubAfterBeHurt)
			if ok && hpD <= uint32(param1) {
				effectRelic := i.relicEffect(aimUID, relic.HurtSubAfterBeHurt, param, param, effectGroupID)
				ans = append(ans, effectRelic)
				hpD = uint32(param2)
			}
		}
	}

	deHpEffect := i.deHp(sourceUID, aimUID, hpD, blood, effectGroupID, attackType)
	ans = append(ans, deHpEffect...)
	return ans
}

type effectHurtTrue struct {
	effectCommon
}

func registerEffectHurtTrue(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHurtTrue{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectHurtTrue) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectHurtTrue) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectHurtTrue) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	default:
		return false
	}
	return true
}

func (i effectHurtTrue) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.trueAttack(sourceUID, aimUID, basic, false, effectGroupID, nil)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				basic, _ = i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.trueAttack(sourceUID, uID, basic, false, effectGroupID, nil)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			basic, _ = i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.trueAttack(sourceUID, uID, basic, false, effectGroupID, nil)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.trueAttack(sourceUID, sourceUID, basic, false, effectGroupID, nil)
			effectS = append(effectS, effectLocal...)
		}
	}
	return
}

type effectHurtAngry struct {
	effectCommon
	angryTimes uint32
}

func registerEffectHurtAngry(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHurtAngry{
		effectCommon: newEffectCommon(c),
		angryTimes:   uint32(c.Param2),
	}
}

func (i effectHurtAngry) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectHurtAngry) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	if self.battleItems[sourceUID].power > 0 {
		basic += uint32(self.battleItems[sourceUID].power)
	}
	if self.battleItems[sourceUID].power < 0 {
		powerLocal := uint32(0 - self.battleItems[sourceUID].power)
		if powerLocal > basic {
			basic = 0
		} else {
			basic -= powerLocal
		}
	}
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, true)

	times = i.times
	return
}

func (i effectHurtAngry) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectHurtAngry) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.normalAttack(sourceUID, aimUID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				basic, _ = i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			basic, _ = i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.normalAttack(sourceUID, uID, basic, false, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectHurtBlood struct {
	effectCommon
}

func registerEffectHurtBlood(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectHurtBlood{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectHurtBlood) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectHurtBlood) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	if self.battleItems[sourceUID].power > 0 {
		basic += uint32(self.battleItems[sourceUID].power)
	}
	if self.battleItems[sourceUID].power < 0 {
		powerLocal := uint32(0 - self.battleItems[sourceUID].power)
		if powerLocal > basic {
			basic = 0
		} else {
			basic -= powerLocal
		}
	}
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)

	times = i.times
	return
}

func (i effectHurtBlood) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectHurtBlood) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.normalAttack(sourceUID, aimUID, basic, true, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				basic, _ = i.getEffectBasic(self, sourceUID, uID)
				effectLocal := self.normalAttack(sourceUID, uID, basic, true, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			uID := uIDs[rand.Intn(aliveNum)]
			basic, _ = i.getEffectBasic(self, sourceUID, uID)
			effectLocal := self.normalAttack(sourceUID, uID, basic, true, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectTimesEnemyConditionHurt struct {
	effectCommon
	condition uint32 // 状态
	timesHurt uint32 // 几倍伤害
}

func registerEffectConditionTimesHurt(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectTimesEnemyConditionHurt{
		effectCommon: newEffectCommon(e),
		condition:    uint32(e.Param2),
		timesHurt:    uint32(e.Param3),
	}
}

func (i effectTimesEnemyConditionHurt) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectTimesEnemyConditionHurt) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	_, _, ok := self.buffShow(aimUID, uint32(i.condition))
	if ok {
		basic = i.basic * i.timesHurt
	}
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)
	times = i.times
	return
}

func (i effectTimesEnemyConditionHurt) effectCheck(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		if !self.isAlive(aimUID) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectTimesEnemyConditionHurt) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {

	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	oldParam, newParam, ok := self.buffShow(aimUID, uint32(i.condition))
	if ok {
		effectGroupID++
		buffEffect := self.buffEffect(aimUID, uint32(i.condition), oldParam, newParam, effectGroupID)
		effects = append(effects, buffEffect)
	}
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		for loop := 0; loop < int(times); loop++ {
			if !self.isAlive(aimUID) {
				break
			}

			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}

			effectLocal := self.normalAttack(sourceUID, aimUID, basic, false, effectGroupID)
			effects = append(effects, effectLocal...)
		}
	}
	return
}

type effectEnemyConditionHurt struct {
	effectCommon
	condition uint32
	damage    uint32
}

func registerEffectEnemyConditionHurt(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectEnemyConditionHurt{
		effectCommon: newEffectCommon(e),
		condition:    uint32(e.Param1),
		damage:       uint32(e.Param2),
	}
}

func (i effectEnemyConditionHurt) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectEnemyConditionHurt) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (basic uint32, times uint32) {
	times = i.times
	if _, _, ok := self.buffShow(aimUID, i.condition); ok {
		basic = i.damage
	}
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)
	return
}

func (i effectEnemyConditionHurt) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	sourceCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case csv.EFFECT_TARGET_ALL_ENEMY:
		enemyCamp := otherCamp(sourceCamp)
		if !self.isAnyAlive(enemyCamp) {
			return false
		}
		count := 0
		for _, enemyUID := range self.aliveUIDs(enemyCamp) {
			if _, _, ok := self.buffShow(enemyUID, i.condition); ok {
				count++
			}
		}
		if count == 0 {
			return false

		}
	}

	return true
}

func (i effectEnemyConditionHurt) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	times := i.times

	sourceCamp := self.battleItems[sourceUID].camp

	switch i.aim {
	case csv.EFFECT_TARGET_ALL_ENEMY:
		enemyCamp := otherCamp(sourceCamp)
		for loop := 0; loop < int(times); loop++ {
			if !self.isAnyAlive(enemyCamp) {
				break
			}
			if firstTier {
				effectGroupID++
				timeAfter += i.timeAfter
			}
			for _, enemyUID := range self.aliveUIDs(enemyCamp) {
				if _, _, ok := self.buffShow(enemyUID, i.condition); ok {
					basic, _ := i.getEffectBasic(self, sourceUID, enemyUID)
					effect := self.normalAttack(sourceUID, enemyUID, basic, false, effectGroupID)
					effects = append(effects, effect...)
				}
			}
		}
	}
	return
}

// 真实伤害
type removeEnemyConditionAttack struct {
	effectCommon
	condition uint32
	perDamage uint32 // 每层伤害
}

func registerRemoveEnemyConditionAttack(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return removeEnemyConditionAttack{
		effectCommon: newEffectCommon(e),
		condition:    uint32(e.Param1),
		perDamage:    uint32(e.Param2),
	}
}

func (i removeEnemyConditionAttack) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i removeEnemyConditionAttack) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (basic uint32, times uint32) {
	times = i.times
	oldParam, _, ok := self.buffShow(aimUID, i.condition)
	if ok {
		basic = oldParam * i.perDamage
	}
	return
}

func (i removeEnemyConditionAttack) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) || !self.isAlive(aimUID) {
		return false
	}
	_, _, ok := self.buffShow(aimUID, i.condition)
	if !ok {
		return false
	}
	return true
}

func (i removeEnemyConditionAttack) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	oldParam, newParam, ok := self.buffClean(aimUID, i.condition)
	if !ok {
		return
	}
	battleEffect := self.buffEffect(aimUID, i.condition, oldParam, newParam, effectGroupID)
	effects = append(effects, battleEffect)
	sourceCamp := self.battleItems[sourceUID].camp

	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		for loop := 0; loop < int(times); loop++ {
			if !self.isAnyAlive(otherCamp(sourceCamp)) {
				break
			}
			if firstTier {
				effectGroupID++
				timeAfter += i.timeAfter
			}
			for _, enemyUID := range self.aliveUIDs(otherCamp(sourceCamp)) {
				effect := self.trueAttack(sourceUID, enemyUID, basic, false, effectGroupID, nil)
				effects = append(effects, effect...)
			}
		}
	}
	return
}

type effectTypeCardCopiesAttack struct {
	effectCommon
	cardType uint32
}

func registerEffectTypeCardCopiesAttack(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectTypeCardCopiesAttack{
		effectCommon: newEffectCommon(e),
		cardType:     uint32(e.Param2),
	}
}

func (i effectTypeCardCopiesAttack) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use %v effect", i)
	return nil
}

func (i effectTypeCardCopiesAttack) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (basic uint32, copies uint32) {
	h, _ := self.battleHeros[sourceUID]
	count := uint32(0)
	for _, c := range h.handyCards {
		if c.Type == card.Type(i.cardType) {
			count++
		}
	}
	copies = count
	basic = i.basic
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)
	return
}

func (i effectTypeCardCopiesAttack) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	_, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		if !self.isAlive(aimUID) {
			return false
		}
	}

	_, copies := i.getEffectBasic(self, sourceUID, aimUID)
	if copies == 0 {
		return false
	}
	return true
}

func (i effectTypeCardCopiesAttack) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	basic, copies := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		for loop := 0; loop < int(i.times); loop++ {
			for num := 0; num < int(copies); num++ {
				if !self.isAlive(aimUID) {
					break
				}
				if firstTier {
					effectGroupID++
					timeAfter += i.timeAfter
				}
				battleEffect := self.normalAttack(sourceUID, aimUID, basic, false, effectGroupID)
				effects = append(effects, battleEffect...)
			}
		}
	}
	return
}

type effectEnemyElementAddHurt struct {
	effectCommon
	perAddHurt uint32
}

func registerEffectEnemyElementAddHurt(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectEnemyElementAddHurt{
		effectCommon: newEffectCommon(e),
		perAddHurt:   uint32(e.Param2),
	}
}

func (i effectEnemyElementAddHurt) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_ATTACK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectEnemyElementAddHurt) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	elementBuff := []uint32{buff.Burn, buff.Electricity, buff.Frozen}
	buffLevel := uint32(0)
	for _, b := range elementBuff {
		level, _, ok := self.buffShow(aimUID, b)
		if ok {
			buffLevel += level
		}
	}

	basic += buffLevel * i.perAddHurt
	basic = self.countEffectHurtBasic(sourceUID, aimUID, basic, false)
	times = i.times
	return
}

func (i effectEnemyElementAddHurt) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		if !self.isAlive(aimUID) {
			return false
		}
	}
	return true
}

func (i effectEnemyElementAddHurt) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		for loop := 0; loop < int(times); loop++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				effectGroupID++
				timeAfter += i.timeAfter
			}
			localEffect := self.normalAttack(sourceUID, aimUID, basic, false, effectGroupID)
			effects = append(effects, localEffect...)
		}
		return
	}
	return
}
