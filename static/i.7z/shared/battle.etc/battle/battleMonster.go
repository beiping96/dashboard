package battle

import (
	"github.com/rs/zerolog/log"
	"math"
	"math/rand"
	"shared/csv"
	pb "shared/proto/client/battle"
	"shared/table"
	"strconv"
	"strings"
	"time"
)

const (
	// constMonsterShark 鲨鱼怪
	constMonsterShark uint32 = 635
	// constMonsterRevive 复活怪
	constMonsterRevive uint32 = 640
	// constMonsterMultiFace 多面魔
	constMonsterMultiFace uint32 = 641
	// constMonsterSummonFrog1 召怪精英 蛤蟆1
	constMonsterSummonFrog1 uint32 = 625
	// constMonsterFrogSummonFrog1 精英怪召唤的小怪 小蛤蟆1
	constMonsterFrogSummonFrog1 uint32 = 628
	// constSummonFrogAiID1 召怪精英 蛤蟆1 召怪AI
	constSummonFrogAiID1 uint32 = 6250
	// constMonsterSummonFrog2 召怪精英 蛤蟆2
	constMonsterSummonFrog2 uint32 = 627
	// constMonsterFrogSummonFrog2 精英怪召唤的小怪 小蛤蟆2
	constMonsterFrogSummonFrog2 uint32 = 630
	// constSummonFrogAiID2 召怪精英 蛤蟆2 召怪AI
	constSummonFrogAiID2 uint32 = 6270
	// constMonsterSummonMonkey 召怪Boss 猴子
	constMonsterSummonMonkey uint32 = 638
	// constMonsterBossSummonMonster Boss召唤的小怪 浮游炮
	constMonsterMonkeySummonMonster uint32 = 639
	// constMonsterSummonMonkey 召怪Boss 猴子 召怪AI
	constSummonMonkeyAiID uint32 = 6380
)

func (i *Battle) monsterAction() bool {
	selfUID := i.turnUID
	monster, _ := i.battleItems[selfUID]
	monsterTypeID := monster.monsterTypeID
	monsterRound := monster.round
	selfCamp := monster.camp
	log.Debug().Msgf("battle %v:%v monster ai start %v",
		i.battleStageUID, i.battleNodeID, selfUID)
	spellTypeID, sleepCard, effectIDs, forcedAim, _, ok := monster.getMonsterStrategyConfigAndAction(i)
	if !ok {
		log.Error().Msgf("battle %v:%v error, monster AI can't found monsterTypeID:%v monsterRound:%v",
			i.battleStageUID, i.battleNodeID, monsterTypeID, monsterRound)
		return false
	}
	// choice Aim
	aimUID := uint64(0)
	if forcedAim {
		uIDs := i.aliveUIDs(otherCamp(selfCamp))
		if len(uIDs) <= 0 {
			log.Error().Msgf("battle %v:%v error, monster can't found aim, battle-process should stop before",
				i.battleStageUID, i.battleNodeID)
			return false
		}
		aimUID = uIDs[rand.Intn(len(uIDs))]
	}
	// count sleep time
	// make action notice
	rsp := pb.BattleActionNotice{}
	rsp.SourceUid = &selfUID
	rsp.SpellId = i.generateSpellID()
	rsp.SpellTypeId = &spellTypeID
	// exec effectIDs
	for _, effectID := range effectIDs {
		spell := pb.BattleSpell{}
		effectPb, sleepAfter := effectID.exec(i, selfUID, aimUID, 0, 0, 0, spellTypeID)
		spell.Effects = effectPb
		rsp.Spells = append(rsp.Spells, &spell)
		sleepCard += sleepAfter
	}
	actionDown(i, i.heroIDs(), rsp)
	log.Debug().Msgf("battle %v:%v monster ai sleep:%v attack:%v",
		i.battleStageUID, i.battleNodeID, sleepCard, aimUID)
	// monster sleep
	if sleepCard > time.Duration(5)*time.Second {
		log.Error().Msgf("battle %v:%v monster ai sleep:%v attack:%v",
			i.battleStageUID, i.battleNodeID, sleepCard, aimUID)
		sleepCard = time.Duration(5) * time.Second
	}
	if i.needSleep() {
		time.Sleep(sleepCard)
	}
	return true
}

func (i *Battle) monsterAiHpDown(monsterUID uint64) {
	monster, _ := i.battleItems[monsterUID]
	if monster.monsterTypeID == 0 {
		return
	}
	switch monster.monsterTypeID {
	case constMonsterShark, constMonsterMultiFace:
		log.Debug().Msgf("monster type: %d aiHpDown", monster.monsterTypeID)
	default:
		log.Debug().Msgf("monster type: %d aiHpDown return", monster.monsterTypeID)
		return
	}
	spellTypeID, _, effectIDs, _, statusChange, ok := i.battleItems[monsterUID].getNextRoundMonsterStrategyConfig(i)
	if !ok {
		log.Error().Msgf("battle error monster AI getNextRoundMonsterStrategyConfig, monsterItem:%v",
			i.battleItems[monsterUID])
		return
	}
	if !statusChange {
		return
	}
	var monsterAi monsterAI
	for _, effectID := range effectIDs {
		monsterAi = append(monsterAi, effectID.getMonsterAI(i, monsterUID, i.turnUID)...)
	}
	if len(monsterAi) > 0 {
		resID := make(map[uint64]uint32)
		resID[monsterUID] = spellTypeID
		aiActionDown(i, monsterAi, resID)
	}
}

type monsterAI []monsterAIOne

type monsterAIOne struct {
	uid    uint64
	method pb.BattleMonsterAiEnum
	param1 uint32
	param2 uint32
}

func (ai monsterAI) toClientProto(resID map[uint64]uint32) []*pb.BattleMonsterAi {
	var ans []*pb.BattleMonsterAi
	formatAI := make(map[uint64][]monsterAIOne)
	for _, aiOne := range ai {
		formatAI[aiOne.uid] = append(formatAI[aiOne.uid], aiOne)
	}
	for uid, aiS := range formatAI {
		localUID := uid
		aiOne := pb.BattleMonsterAi{}
		aiOne.Uid = &localUID
		cardResID := resID[localUID]
		aiOne.CardResID = &cardResID
		for _, aiMethod := range aiS {
			localAiMethod := aiMethod
			methodOne := pb.BattleMonsterAiMethod{}
			methodOne.Method = &localAiMethod.method
			methodOne.Param1 = &localAiMethod.param1
			methodOne.Param2 = &localAiMethod.param2
			aiOne.Methods = append(aiOne.Methods, &methodOne)
		}
		ans = append(ans, &aiOne)
	}
	return ans
}

func (i *Battle) monsterAiNotice() {
	turnUID := i.turnUID
	turnCamp := i.battleItems[turnUID].camp
	otherCamp := otherCamp(turnCamp)
	var monsterAi monsterAI
	resID := make(map[uint64]uint32)
	for uid, item := range i.battleItems {
		if item.camp != otherCamp {
			continue
		}
		if item.monsterTypeID <= 0 {
			continue
		}
		if item.hp <= 0 {
			continue
		}
		cardResID, _, effectIDs, _, _, ok := item.getNextRoundMonsterStrategyConfig(i)
		if !ok {
			continue
		}
		for _, effectID := range effectIDs {
			monsterAi = append(monsterAi, effectID.getMonsterAI(i, uid, turnUID)...)
		}
		resID[uid] = cardResID
	}
	if len(monsterAi) > 0 {
		aiActionDown(i, monsterAi, resID)
	}
}

func (monster *item) getNextRoundMonsterStrategyConfig(battle *Battle) (spellTypeID uint32, sleepCard time.Duration, effectIDs []typeEffectID, forcedAim bool, phaseChanged bool, ok bool) {
	monsterTypeID := monster.monsterTypeID
	switch monsterTypeID {
	case constMonsterShark:
		return monster.monsterSharkStrategyNextRoundConfig()
	case constMonsterMultiFace:
		return monster.monsterMultiFaceNextRoundConfig()
	case constMonsterSummonFrog1, constMonsterSummonFrog2, constMonsterSummonMonkey:
		return monster.monsterSummonNextRoundConfig(battle)
	}

	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}

	nextRound := monster.round + 1
	phaseRoundBegin := monster.phaseRoundBegin

	monsterAiID := monster.curMonsterAI
	if monsterAiID == 0 {
		monsterAiID = uint32(mstConf.AI_ID)
		phaseRoundBegin = 1
	}
	if mstConf.Phase2_Blood_Per > 0 && mstConf.Phase2_Blood_Per < 100 &&
		monster.hp <= uint32(math.Round(float64(monster.hpLimit)*(float64(mstConf.Phase2_Blood_Per)/100))) {
		monsterAiID = uint32(mstConf.Phase2_AI_ID)
		if monsterAiID != monster.curMonsterAI {
			phaseChanged = true
			phaseRoundBegin = nextRound
		}
	} else if monsterTypeID == constMonsterRevive && monster.hp == 0 && !monster.revived {
		monsterAiID = uint32(mstConf.Phase2_AI_ID)
		phaseChanged = true
		phaseRoundBegin = nextRound
		monster.curMonsterAI = monsterAiID
		monster.phaseRoundBegin = phaseRoundBegin
		monster.curActionMonsterAI = 0
	}

	monsterRound := nextRound - phaseRoundBegin + 1

	if monster.curActionMonsterAI > 0 {
		spellTypeID = monster.curActionMonsterAI
	} else {
		spellTypeID = getMonsterSpellID(monsterAiID, monsterRound)
		monster.curActionMonsterAI = spellTypeID
	}

	sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)
	return
}

func (monster *item) getMonsterStrategyConfigAndAction(battle *Battle) (spellTypeID uint32, sleepCard time.Duration, effectIDs []typeEffectID, forcedAim bool, phaseChanged bool, ok bool) {
	monsterTypeID := monster.monsterTypeID
	switch monsterTypeID {
	case constMonsterShark:
		return monster.monsterSharkStrategyConfigAndAction()
	case constMonsterMultiFace:
		return monster.monsterMultiFaceConfigAndAction()
	case constMonsterSummonFrog1, constMonsterSummonFrog2, constMonsterSummonMonkey:
		return monster.monsterSummonConfigAndAction(battle)
	}

	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}

	monsterAiID := monster.curMonsterAI
	if monsterAiID == 0 {
		monsterAiID = uint32(mstConf.AI_ID)
		monster.curMonsterAI = monsterAiID
		monster.phaseRoundBegin = 1
	}
	if mstConf.Phase2_Blood_Per > 0 && mstConf.Phase2_Blood_Per < 100 &&
		monster.hp <= uint32(math.Round(float64(monster.hpLimit)*(float64(mstConf.Phase2_Blood_Per)/100))) {
		monsterAiID = uint32(mstConf.Phase2_AI_ID)
		if monsterAiID != monster.curMonsterAI {
			phaseChanged = true
			monster.phaseRoundBegin = monster.round
			monster.oldMonsterAI = monster.curMonsterAI
			monster.curMonsterAI = monsterAiID
		}
	}

	monsterRound := monster.round - monster.phaseRoundBegin + 1

	if monster.curActionMonsterAI > 0 {
		spellTypeID = monster.curActionMonsterAI
	} else {
		spellTypeID = getMonsterSpellID(monsterAiID, monsterRound)
	}
	nextRoundSpellID := getMonsterSpellID(monsterAiID, monsterRound+1)
	monster.curActionMonsterAI = nextRoundSpellID

	sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)
	return
}

func getMonsterSpellID(aiID uint32, monsterRound uint32) (spellID uint32) {
	if monsterRound == 0 {
		log.Debug().Msgf("monster ai round is 0")
		return
	}
	monsterAI, ok := csv.MonsterAIMap[int64(aiID)]
	if !ok {
		log.Error().Msgf("monster ai not found at table, aiID: %d", aiID)
		return
	}
	weight, ok := table.GetMonsterAIWeight(uint32(monsterAI.ID))
	if !ok {
		log.Error().Msgf("monster ai weight not exist, aiID: %d", monsterAI.ID)
		return
	}

	orderSequence := weight.OrderSequence
	round := int(monsterRound - 1)
	orderLen := len(orderSequence)
	// order
	if orderLen > 0 && orderSequence[0] != 0 {
		if round < orderLen {
			spellID = uint32(orderSequence[round])
			return
		}
		round -= orderLen
	}

	cycleSequence := weight.CycleSequence
	cycleLen := len(cycleSequence)
	// cycle
	if cycleLen > 0 && cycleSequence[0] != 0 {
		spellID = uint32(cycleSequence[round%cycleLen])
		return
	}

	// random
	totalWeight := weight.TotalWeight
	randomWeight := rand.Intn(int(totalWeight))
	for _, w := range weight.CardWeight {
		if randomWeight <= int(w.CardWeight) {
			spellID = w.CardId
			return
		}
		randomWeight -= int(w.CardWeight)
	}

	return
}

func (monster *item) monsterSharkStrategyNextRoundConfig() (spellTypeID uint32, sleepCard time.Duration, effectIDs []typeEffectID, forcedAim bool,
	phaseChanged bool, ok bool) {
	if monster.monsterTypeID != constMonsterShark {
		return
	}

	monsterTypeID := monster.monsterTypeID
	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}

	monsterAiID := monster.curMonsterAI
	phaseRound := monster.phaseRoundBegin
	if monsterAiID == 0 {
		monsterAiID = uint32(mstConf.AI_ID)
		phaseRound = 1
	}

	if monster.wriggleStatus == false {
		wiggleBloodLose := []uint32{30, 40, 50, 60, 70, 999}
		if monster.wriggleBloodLose >= wiggleBloodLose[monster.wriggleTimes] {
			monsterAiID = uint32(mstConf.Phase2_AI_ID)
			phaseChanged = true
			phaseRound = 1
			monster.phaseRoundBegin = 1
			monster.curMonsterAI = monsterAiID
			monster.wriggleStatus = true
			monster.wriggleTimes++
			monster.wriggleBloodLose = 0
			// add block cardID
		}
	} else if monster.wriggleStatus == true && phaseRound >= 3 { // TODO round config
		monsterAiID = uint32(mstConf.AI_ID)
		phaseChanged = true
		phaseRound = 1
	}
	spellTypeID = getMonsterSpellID(monsterAiID, phaseRound)
	sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)
	return
}

func (monster *item) monsterSharkStrategyConfigAndAction() (spellTypeID uint32, sleepCard time.Duration,
	effectIDs []typeEffectID, forcedAim bool, phaseChanged bool, ok bool) {
	if monster.monsterTypeID != constMonsterShark {
		return
	}

	monsterTypeID := monster.monsterTypeID
	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}
	monsterAiID := monster.curMonsterAI
	phaseRound := monster.phaseRoundBegin
	if monsterAiID == 0 {
		monsterAiID = uint32(mstConf.AI_ID)
		monster.curMonsterAI = monsterAiID
		phaseRound = 1
		monster.phaseRoundBegin = 1
	}

	if monster.wriggleStatus == true && phaseRound >= 3 { // 已经蜷缩三回合
		monster.wriggleStatus = false
		monster.curMonsterAI = uint32(mstConf.AI_ID)
		monsterAiID = monster.curMonsterAI
		monster.phaseRoundBegin = 1
		phaseRound = 1
		phaseChanged = true
	}

	spellTypeID = getMonsterSpellID(monsterAiID, phaseRound)
	sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)
	return
}

func (monster *item) monsterMultiFaceNextRoundConfig() (spellTypeID uint32, sleepCard time.Duration,
	effectIDs []typeEffectID, forcedAim bool, phaseChanged bool, ok bool) {
	if monster.monsterTypeID != constMonsterMultiFace {
		return
	}
	monsterTypeID := monster.monsterTypeID
	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}
	monsterAiID := monster.curMonsterAI
	nextRound := monster.round + 1
	phaseRoundBegin := monster.phaseRoundBegin
	if monsterAiID == 0 {
		monsterAiID = uint32(mstConf.AI_ID)
		phaseRoundBegin = 1
	}
	blood := uint32(math.Ceil(float64(monster.hpLimit-monster.hp) / float64(monster.hpLimit)))
	_, phaseAI := getMultiFaceMonsterPhase(blood)
	if monsterAiID != phaseAI {
		phaseChanged = true
		monsterAiID = phaseAI
		phaseRoundBegin = nextRound
		log.Debug().Msgf("0-------next round multi face changed-----")
	}
	monsterRound := nextRound - phaseRoundBegin + 1

	if monster.curActionMonsterAI > 0 && !phaseChanged {
		spellTypeID = monster.curActionMonsterAI
	} else {
		spellTypeID = getMonsterSpellID(monsterAiID, monsterRound)
		monster.curActionMonsterAI = spellTypeID
	}
	sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)

	return
}

func (monster *item) monsterMultiFaceConfigAndAction() (spellTypeID uint32, sleepCard time.Duration,
	effectIDs []typeEffectID, forcedAim bool, phaseChanged bool, ok bool) {
	if monster.monsterTypeID != constMonsterMultiFace {
		return
	}
	monsterTypeID := monster.monsterTypeID
	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}
	monsterAiID := monster.curMonsterAI
	monsterRound := monster.round

	if monsterAiID == 0 {
		monsterAiID = uint32(mstConf.AI_ID)
		monster.curMonsterAI = monsterAiID
		monster.phaseRoundBegin = 1
		monster.multiFacePhase = 0
	}
	blood := uint32(math.Ceil(float64(monster.hpLimit-monster.hp) / float64(monster.hpLimit)))
	curPhase, phaseAI := getMultiFaceMonsterPhase(blood)
	if phaseAI != monster.curMonsterAI {
		phaseChanged = true
		monster.oldMonsterAI = monster.curMonsterAI
		monster.curMonsterAI = phaseAI
		monster.multiFacePhase = curPhase
		monster.phaseRoundBegin = monster.round
		monsterAiID = phaseAI
		log.Debug().Msgf("3-------next round multi face changed-----")
	}
	monsterRound = monster.round - monster.phaseRoundBegin + 1

	if monster.curActionMonsterAI > 0 && !phaseChanged {
		spellTypeID = monster.curActionMonsterAI
	} else {
		spellTypeID = getMonsterSpellID(monsterAiID, monsterRound)
	}
	// next round monster Ai spell ID
	monster.curActionMonsterAI = getMonsterSpellID(monsterAiID, monsterRound+1)

	sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)
	return
}

func getMultiFaceMonsterPhase(bloodLose uint32) (uint32, uint32) {
	phase := []uint32{0, 10, 40, 70} // 失血百分比
	phaseAI := []uint32{6410, 6411, 6412, 6413}
	for i := len(phase) - 1; i >= 0; i-- {
		if bloodLose >= phase[i] {
			return uint32(i), phaseAI[i]
		}
	}
	return 0, phaseAI[0]
}

func getMonsterSpellInfo(spellTypeID uint32) (sleepCard time.Duration, effectIDs []typeEffectID, forcedAim bool, ok bool) {
	card, ok := csv.TableCardsMap[int64(spellTypeID)]
	if !ok {
		log.Error().Msgf("monster card not found, card id: %d", spellTypeID)
		return
	}

	sleepCard = time.Duration(card.Forward_Time) * time.Millisecond
	sleepCard += time.Duration(card.Back_Time) * time.Millisecond
	sleepCard += time.Duration(card.Action_Trigger_Time) * time.Millisecond
	effects := strings.Split(card.EffectIDs, ",")
	effectIDs = make([]typeEffectID, len(effects))
	for i, e := range effects {
		si, err := strconv.Atoi(e)
		if err != nil {
			ok = false
			return
		}
		effectIDs[i] = typeEffectID(si)
	}
	if card.Card_Target == csv.CARD_TARGET_SINGLE {
		forcedAim = true
	} else {
		forcedAim = false
	}
	return
}

func (monster *item) monsterSummonNextRoundConfig(battle *Battle) (spellTypeID uint32, sleepCard time.Duration,
	effectIDs []typeEffectID, forcedAim bool, phaseChanged bool, ok bool) {
	monsterTypeID := monster.monsterTypeID
	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}

	initAiID := uint32(mstConf.AI_ID)
	summonAiID := constSummonFrogAiID1
	countProb := []int{75, 50, 0}
	summonMonsterTypeID := constMonsterFrogSummonFrog1
	switch monsterTypeID {
	case constMonsterSummonFrog1:
		summonMonsterTypeID = constMonsterFrogSummonFrog1
		summonAiID = constSummonFrogAiID1
	case constMonsterSummonFrog2:
		summonMonsterTypeID = constMonsterFrogSummonFrog2
		summonAiID = constSummonFrogAiID2
	case constMonsterSummonMonkey:
		summonMonsterTypeID = constMonsterMonkeySummonMonster
		summonAiID = constSummonMonkeyAiID
		countProb = []int{75, 0, 0}
		initAiID = summonAiID
	default:
		return
	}
	camp := monster.camp
	count := 0
	for _, id := range battle.aliveUIDs(camp) {
		if battle.isAlive(id) && battle.battleItems[id].monsterTypeID == summonMonsterTypeID {
			count++
		}
	}
	if count > 2 {
		count = 2
	}
	prob := countProb[count]

	monsterAiID := monster.curMonsterAI
	nextRound := monster.round + 1
	phaseRoundBegin := monster.phaseRoundBegin
	if monster.curMonsterAI == 0 {
		monsterAiID = uint32(initAiID)
		phaseRoundBegin = 1
	}
	if mstConf.Phase2_Blood_Per > 0 && mstConf.Phase2_Blood_Per < 100 &&
		monster.hp <= uint32(math.Round(float64(monster.hpLimit)*(float64(mstConf.Phase2_Blood_Per)/100))) {
		monsterAiID = uint32(mstConf.Phase2_AI_ID)
		if monsterAiID != monster.curMonsterAI {
			phaseChanged = true
			phaseRoundBegin = monster.round
		}
	}

	monsterRound := nextRound - phaseRoundBegin + 1
	r := rand.Intn(100) + 1
	if r <= prob && !phaseChanged {
		phaseChanged = true
		monsterAiID = summonAiID
		spellTypeID = getMonsterSpellID(monsterAiID, monsterRound)
		monster.curActionMonsterAI = spellTypeID
		sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)
		return
	}
	if monster.curActionMonsterAI > 0 {
		spellTypeID = monster.curActionMonsterAI
	} else {
		spellTypeID = getMonsterSpellID(monsterAiID, monsterRound)
		monster.curActionMonsterAI = getMonsterSpellID(monsterAiID, nextRound)
	}

	sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)

	return
}

func (monster *item) monsterSummonConfigAndAction(battle *Battle) (spellTypeID uint32, sleepCard time.Duration,
	effectIDs []typeEffectID, forcedAim bool, phaseChanged bool, ok bool) {
	monsterTypeID := monster.monsterTypeID
	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}

	initAiID := uint32(mstConf.AI_ID)
	//summonAiID := constSummonFrogAiID1
	//countProb := []int{75, 50, 0}
	summonMonsterTypeID := constMonsterFrogSummonFrog1
	switch monsterTypeID {
	case constMonsterSummonFrog1:
		summonMonsterTypeID = constMonsterFrogSummonFrog1
		//summonAiID = constSummonFrogAiID1
	case constMonsterSummonFrog2:
		summonMonsterTypeID = constMonsterFrogSummonFrog2
		//summonAiID = constSummonFrogAiID2
	case constMonsterSummonMonkey:
		summonMonsterTypeID = constMonsterMonkeySummonMonster
		//summonAiID = constSummonMonkeyAiID
		//countProb = []int{75, 0, 0}
		//initAiID = summonAiID
	default:
		return
	}
	camp := monster.camp
	count := 0
	for _, id := range battle.aliveUIDs(camp) {
		if battle.isAlive(id) && battle.battleItems[id].monsterTypeID == summonMonsterTypeID {
			count++
		}
	}
	if count > 2 {
		count = 2
	}
	//prob := countProb[count]

	monsterAiID := monster.curMonsterAI
	if monster.curMonsterAI == 0 {
		monsterAiID = initAiID
		monster.curMonsterAI = monsterAiID
		monster.phaseRoundBegin = 1
	}
	if mstConf.Phase2_Blood_Per > 0 && mstConf.Phase2_Blood_Per < 100 &&
		monster.hp <= uint32(math.Round(float64(monster.hpLimit)*(float64(mstConf.Phase2_Blood_Per)/100))) {
		monsterAiID = uint32(mstConf.Phase2_AI_ID)
		if monsterAiID != monster.curMonsterAI {
			phaseChanged = true
			monster.phaseRoundBegin = monster.round
			monster.oldMonsterAI = monster.curMonsterAI
			monster.curMonsterAI = monsterAiID
		}
	}

	//r := rand.Intn(100) + 1
	//if r <= prob && !phaseChanged {
	//	monsterAiID = summonAiID
	//}
	monsterRound := monster.round - monster.phaseRoundBegin + 1
	if monster.curActionMonsterAI > 0 {
		spellTypeID = monster.curActionMonsterAI
	} else {
		spellTypeID = getMonsterSpellID(monsterAiID, monsterRound)
	}

	monster.curActionMonsterAI = getMonsterSpellID(monster.curMonsterAI, monsterRound+1)
	sleepCard, effectIDs, forcedAim, ok = getMonsterSpellInfo(spellTypeID)
	return
}
