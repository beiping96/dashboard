package battle

import (
	"github.com/rs/zerolog/log"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

// effectGenerator
// when add effectEnum should do this things:
// 1.register effectEnum mapping in this file initEffectEnumMapping function
// 2.create a new file "shared/battle.etc/battle/effect*.go"
// 3.create effect-struct
// 4.effect-struct should plug-in effectCommon
// 5.achieve effectGenerator interface "effectCheck" and "effectExec"
type effectGenerator interface {
	// achieve in each effect-struct
	getMonsterAI(*Battle, uint64, uint64) monsterAI
	getEffectBasic(*Battle, uint64, uint64, ...interface{}) (basic uint32, times uint32)
	effectCheck(*Battle, uint64, uint64, ...interface{}) (canExec bool)
	effectExec(*Battle, uint64, uint64, uint32, bool, ...interface{}) ([]*pb.BattleEffect, time.Duration)
}

// register effectEnumMapping
func initEffectEnumMapping() {
	// nil
	effectEnumMapping[uint32(csv.EFFECT_NONE)] = registerEffectNone
	// hurt
	effectEnumMapping[uint32(csv.EFFECT_DEAL_DAMAGE)] = registerEffectHurt
	// hurtBlock
	effectEnumMapping[uint32(csv.EFFECT_DEAL_BLOCK_DAMAGE)] = registerEffectHurtBlock
	// hurtMp
	effectEnumMapping[uint32(csv.EFFECT_DEAL_POWER_DAMAGE)] = registerEffectHurtMp
	// hurtCard
	effectEnumMapping[uint32(csv.EFFECT_DEAL_HAND_CARD_DAMAGE)] = registerEffectHurtCard
	// hurtTrue
	effectEnumMapping[uint32(csv.EFFECT_TRUE_ATTACK)] = registerEffectHurtTrue
	// hurtAngry
	effectEnumMapping[uint32(csv.EFFECT_DEAL_ANGRY_DAMAGE)] = registerEffectHurtAngry
	// hurtBlood
	effectEnumMapping[uint32(csv.EFFECT_DEAL_BLOOD_DAMAGE)] = registerEffectHurtBlood
	// times hurt with enemy condition
	effectEnumMapping[uint32(csv.EFFECT_DEAL_ENEMY_CONDITION_TIMES_DAMAGE)] = registerEffectConditionTimesHurt
	// remove enemies condition and true hurt
	effectEnumMapping[uint32(csv.EFFECT_DEAL_REMOVE_ENEMY_CONDITION_DAMAGE)] = registerRemoveEnemyConditionAttack
	// hand type card copies attack
	effectEnumMapping[uint32(csv.EFFECT_DEAL_HAND_TYPE_CARD_COPIES_DAMAGE)] = registerEffectTypeCardCopiesAttack
	// hurt with enemy condition
	effectEnumMapping[uint32(csv.EFFECT_DEAL_ENEMY_CONDITION_DAMAGE)] = registerEffectEnemyConditionHurt
	// enemy condition add hurt
	effectEnumMapping[uint32(csv.EFFECT_DEAL_ENEMY_CONDITION_ADD_DAMAGE)] = registerEffectEnemyElementAddHurt
	// block
	effectEnumMapping[uint32(csv.EFFECT_GAIN_BLOCK)] = registerEffectBlock
	// blockTrue
	effectEnumMapping[uint32(csv.EFFECT_GAIN_REAL_BLOCK)] = registerEffectBlockTrue
	// blockTimes
	effectEnumMapping[uint32(csv.EFFECT_GAIN_TIMES_BLOCK)] = registerEffectBlockTimes
	// all power block
	effectEnumMapping[uint32(csv.EFFECT_GAIN_ALL_POWER_BLOCK)] = registerEffectAllPowerBlock
	// remove all block
	effectEnumMapping[uint32(csv.EFFECT_REMOVE_ALL_BLOCK)] = registerRemoveAllBlock
	// HpUp
	effectEnumMapping[uint32(csv.EFFECT_CHANGE_HP_UP)] = registerEffectHpUp
	// HpDown
	effectEnumMapping[uint32(csv.EFFECT_CHANGE_HP_DOWN)] = registerEffectHpDown
	// Mp
	effectEnumMapping[uint32(csv.EFFECT_CHANGE_POWER)] = registerEffectMp
	// add card cost Mp
	effectEnumMapping[uint32(csv.EFFECT_ADD_CARD_COST_POWER)] = registerAddCardCostMp
	// PowerUp
	effectEnumMapping[uint32(csv.EFFECT_POWER_ADD)] = registerEffectPowerUp
	// PowerDown
	effectEnumMapping[uint32(csv.EFFECT_POWER_MINUS)] = registerEffectPowerDown
	// AgilityUp
	effectEnumMapping[uint32(csv.EFFECT_AGILITY_ADD)] = registerEffectAgilityUp
	// AgilityDown
	effectEnumMapping[uint32(csv.EFFECT_AGILITY_MINUS)] = registerEffectAgilityDown
	// buffGiver
	effectEnumMapping[uint32(csv.EFFECT_GIVE_BUFF)] = registerEffectBuffGiver
	// buffTimes
	effectEnumMapping[uint32(csv.EFFECT_TIMES_BUFF)] = registerEffectBuffTimes
	// buffByEnemyNum
	effectEnumMapping[uint32(csv.EFFECT_ENEMY_BUFF)] = registerEffectBuffByEnemyNum
	// buff by another buff
	effectEnumMapping[uint32(csv.EFFECT_GIVE_BUFF_BY_ANOTHER_BUFF)] = registerEffectBuffByEnemyBuff
	// clear bad buffs
	effectEnumMapping[uint32(csv.EFFECT_CLEAR_BAD_BUFFS)] = registerEffectClearBadBuffs
	// DrawCardsToHandyCards
	effectEnumMapping[uint32(csv.EFFECT_DRAW_CARD)] = registerEffectDrawCardsToHandyCards
	// JoinDisCards
	effectEnumMapping[uint32(csv.EFFECT_JOIN_DIS_CARD)] = registerEffectJoinDisCards
	// JoinDrawCards
	effectEnumMapping[uint32(csv.EFFECT_JOIN_DRAW_CARD)] = registerEffectJoinDrawCards
	// JoinHandyCards
	effectEnumMapping[uint32(csv.EFFECT_JOIN_HANDY_CARD)] = registerEffectJoinHandCards
	// GetOneCard from drawCard random
	effectEnumMapping[uint32(csv.EFFECT_RANDOM_DRAW_CARD)] = registerEffectDrawCardFromDrawCards
	// level up all hand cards
	effectEnumMapping[uint32(csv.EFFECT_LEVEL_UP_ALL_HAND_CARDS)] = registerEffectLevelUpAllHandCards
	// duplicate hand attack or power card
	effectEnumMapping[uint32(csv.EFFECT_DUPLICATE_HAND_ATTACK_CARD)] = registerEffectDuplicateHandAttackCard
	// choice card exhaust
	effectEnumMapping[uint32(csv.EFFECT_EXHAUST_CARD)] = registerEffectChoiceCardExhaust
	// move disCard to drawCardTop
	effectEnumMapping[uint32(csv.EFFECT_MOVE_DIS_CARD_TO_DRAW_CARD_TOP)] = registerEffectMoveDisCardToDrawCardTop
	// discard one card
	effectEnumMapping[uint32(csv.EFFECT_DIS_CARD)] = registerEffectChoiceCardDiscard
	// move discard to hand
	effectEnumMapping[uint32(csv.EFFECT_MOVE_DIS_CARD_TO_HAND)] = registerEffectMoveDisCardToHand
	// move draw type card to hand
	effectEnumMapping[uint32(csv.EFFECT_MOVE_DRAW_TYPE_CARD_TO_HAND)] = registerEffectMoveDrawTypeCardToHand
	// monster effect add battleItem
	effectEnumMapping[uint32(csv.EFFECT_ADD_BATTLE_ITEM)] = registerEffectAddBattleItem
}

// exec one effectID
func (effectID typeEffectID) exec(i *Battle, sourceID uint64, aimID uint64, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	effectG, ok := effectGeneratorMapping[effectID]
	if !ok {
		log.Error().Msgf("battle error can't found Effect ID %v", effectID)
		return
	}
	effectGroupID := uint32(0)
	firstTier := true
	if canExec := effectG.effectCheck(i, sourceID, aimID, arg...); !canExec {
		return
	}
	effectSOne, timeAfterOne := effectG.effectExec(i, sourceID, aimID, effectGroupID, firstTier, arg...)
	effectS = append(effectS, effectSOne...)
	timeAfter += timeAfterOne
	return
}

// getMonsterAI
func (effectID typeEffectID) getMonsterAI(i *Battle, sourceID uint64, aimID uint64) monsterAI {
	effectG, ok := effectGeneratorMapping[effectID]
	if !ok {
		log.Error().Msgf("battle error can't found Effect ID %v", effectID)
		return nil
	}
	return effectG.getMonsterAI(i, sourceID, aimID)
}

// typeEffectID - unique ID in table-effect
type typeEffectID uint32

// effectGeneratorMapping -  mapping effectID with effectGenerator
var effectGeneratorMapping map[typeEffectID]effectGenerator

// effectEnumNewHandler - a function can create a effectGenerator
type effectEnumNewHandler func(typeEffectID) effectGenerator

// effectEnumMapping - mapping effectEnum with effectEnumNewHandler
var effectEnumMapping map[uint32]effectEnumNewHandler

// register effectGenerator
func init() {
	// first init effectEnumMapping
	effectEnumMapping = make(map[uint32]effectEnumNewHandler)
	initEffectEnumMapping()
	// then init effectGeneratorMapping
	effectGeneratorMapping = make(map[typeEffectID]effectGenerator)
	initEffectGeneratorMapping()
	// clean csv.TableCardEffectMap
	csv.TableCardEffectMap = nil
}

// register effectGeneratorMapping
func initEffectGeneratorMapping() {
	for k, v := range csv.TableCardEffectMap {
		effectID := typeEffectID(k)
		effectNewHandler, ok := effectEnumMapping[uint32(v.EffectType)]
		if ok {
			effectGeneratorMapping[effectID] = effectNewHandler(effectID)
			continue
		}
		log.Error().Msgf("battle effect init fail, can't found mapping effectEnum %v to newHandler",
			v.EffectType)
		// TODO
		// panic(fmt.Sprintf("battle effect init fail, can't found mapping effectEnum %v to newHandler",
		// 	v.EffectType))
	}
}

// effectCommon - inside struct-effect*
type effectCommon struct {
	timeAfter time.Duration
	times     uint32
	aim       uint32
	basic     uint32
	aiEnum    uint32
}

// newEffectCommon - create new effectCommon struct
func newEffectCommon(c *csv.TableCardEffect) effectCommon {
	return effectCommon{
		timeAfter: time.Duration(c.End_Animation_Last) * time.Millisecond,
		times:     uint32(c.Times),
		aim:       uint32(c.TargetType),
		basic:     uint32(c.Param1),
		aiEnum:    uint32(c.AI_Method),
	}
}
