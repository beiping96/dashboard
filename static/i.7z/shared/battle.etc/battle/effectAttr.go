package battle

import (
	"fmt"
	"math/rand"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

func (i *Battle) powerChange(uid uint64, change int32, effectGroupID uint32) []*pb.BattleEffect {
	ans := []*pb.BattleEffect{}
	oldPower := i.battleItems[uid].power
	i.battleItems[uid].power += change
	newPower := i.battleItems[uid].power
	effect := pb.BattleEffect{}
	effect.GroupId = &effectGroupID
	effect.Uid = &uid
	effectEnum := pb.BattleEffectEnum_BEffect_POWER
	effect.E = &effectEnum
	oldValue, newValue := int32(oldPower), int32(newPower)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	ans = append(ans, &effect)
	return ans
}

type effectPowerUp struct {
	effectCommon
}

func registerEffectPowerUp(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectPowerUp{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectPowerUp) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_POWER_UP,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectPowerUp) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectPowerUp) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectPowerUp) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.powerChange(sourceUID, int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.powerChange(aimUID, int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.powerChange(uID, int32(basic), effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.powerChange(aimUID, int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				effectLocal := self.powerChange(uID, int32(basic), effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.powerChange(uIDs[rand.Intn(aliveNum)], int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectPowerDown struct {
	effectCommon
}

func registerEffectPowerDown(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectPowerDown{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectPowerDown) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_POWER_DN,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectPowerDown) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectPowerDown) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectPowerDown) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.powerChange(sourceUID, 0-int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.powerChange(aimUID, 0-int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.powerChange(uID, 0-int32(basic), effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.powerChange(aimUID, 0-int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				effectLocal := self.powerChange(uID, 0-int32(basic), effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.powerChange(uIDs[rand.Intn(aliveNum)], 0-int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

func (i *Battle) agilityChange(uid uint64, change int32, effectGroupID uint32) []*pb.BattleEffect {
	ans := []*pb.BattleEffect{}
	oldAgility := i.battleItems[uid].agility
	i.battleItems[uid].agility += change
	newAgility := i.battleItems[uid].agility
	effect := pb.BattleEffect{}
	effect.GroupId = &effectGroupID
	effect.Uid = &uid
	effectEnum := pb.BattleEffectEnum_BEffect_AGILITY
	effect.E = &effectEnum
	oldValue, newValue := int32(oldAgility), int32(newAgility)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	ans = append(ans, &effect)
	return ans
}

type effectAgilityUp struct {
	effectCommon
}

func registerEffectAgilityUp(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectAgilityUp{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectAgilityUp) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_AGILITY_UP,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectAgilityUp) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectAgilityUp) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectAgilityUp) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.agilityChange(sourceUID, int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.agilityChange(aimUID, int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.agilityChange(uID, int32(basic), effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.agilityChange(aimUID, int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				effectLocal := self.agilityChange(uID, int32(basic), effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.agilityChange(uIDs[rand.Intn(aliveNum)], int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}

type effectAgilityDown struct {
	effectCommon
}

func registerEffectAgilityDown(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectAgilityDown{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectAgilityDown) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_AGILITY_DN,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectAgilityDown) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectAgilityDown) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY), uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		if !self.isAnyAlive(otherCamp(selfCamp)) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectAgilityDown) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.agilityChange(sourceUID, 0-int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.agilityChange(aimUID, 0-int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.agilityChange(uID, 0-int32(basic), effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_SPECIFIED_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.agilityChange(aimUID, 0-int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(otherCamp(selfCamp)) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(otherCamp(selfCamp)) {
				effectLocal := self.agilityChange(uID, 0-int32(basic), effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	case uint32(csv.EFFECT_TARGET_RANDOM_ENEMY):
		for loopI := uint32(0); loopI < times; loopI++ {
			uIDs := self.aliveUIDs(otherCamp(selfCamp))
			aliveNum := len(uIDs)
			if aliveNum <= 0 {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.agilityChange(uIDs[rand.Intn(aliveNum)], 0-int32(basic), effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	}
	return
}
