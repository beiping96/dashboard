package battle

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math"
	"shared/battle.etc/buff"
	"shared/csv"
	pb "shared/proto/client/battle"
	"time"
)

func (i *Battle) addBlock(uid uint64, blockN uint32, effectGroupID uint32) []*pb.BattleEffect {
	ans := []*pb.BattleEffect{}
	oldBlock := i.battleItems[uid].block
	i.battleItems[uid].block = oldBlock + blockN
	newBlock := i.battleItems[uid].block
	effect := pb.BattleEffect{}
	effect.GroupId = &effectGroupID
	effect.Uid = &uid
	effectEnum := pb.BattleEffectEnum_BEffect_BLOCK
	effect.E = &effectEnum
	oldValue, newValue := int32(oldBlock), int32(newBlock)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	ans = append(ans, &effect)
	return ans
}

func (i *Battle) deBlock(uid uint64, blockN uint32, effectGroupID uint32) []*pb.BattleEffect {
	var ans []*pb.BattleEffect
	oldBlock := i.battleItems[uid].block
	newBlock := oldBlock
	if blockN >= oldBlock {
		newBlock = 0
	} else {
		newBlock = oldBlock - blockN
	}
	i.battleItems[uid].block = newBlock
	effect := pb.BattleEffect{}
	effect.GroupId = &effectGroupID
	effect.Uid = &uid
	effectEnum := pb.BattleEffectEnum_BEffect_BLOCK
	effect.E = &effectEnum
	oldValue, newValue := int32(oldBlock), int32(newBlock)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	ans = append(ans, &effect)
	return ans
}

type effectBlock struct {
	effectCommon
}

func registerEffectBlock(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectBlock{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectBlock) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_BLOCK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectBlock) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	if self.battleItems[sourceUID].agility > 0 {
		basic += uint32(self.battleItems[sourceUID].agility)
	}
	if self.battleItems[sourceUID].agility < 0 {
		agilityLocal := uint32(0 - self.battleItems[sourceUID].agility)
		if agilityLocal > basic {
			basic = 0
		} else {
			basic -= agilityLocal
		}
	}
	// sub blockLess buff
	fragilityBasic := uint32(buff.GetBasic(buff.BlockLess))
	_, _, ok := self.buffShow(sourceUID, buff.BlockLess)
	if ok && fragilityBasic <= 100 {
		percent := float64(100-fragilityBasic) / 100
		basic = uint32(math.Trunc(float64(basic) * percent))
	}

	times = i.times
	return
}

func (i effectBlock) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectBlock) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBlock(sourceUID, basic, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBlock(aimUID, basic, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.addBlock(uID, basic, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	}
	return
}

type effectBlockTrue struct {
	effectCommon
}

func registerEffectBlockTrue(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectBlockTrue{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectBlockTrue) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_BLOCK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectBlockTrue) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (basic uint32, times uint32) {
	basic = i.basic
	times = i.times
	return
}

func (i effectBlockTrue) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectBlockTrue) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, args ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBlock(sourceUID, basic, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBlock(aimUID, basic, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.addBlock(uID, basic, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	}
	return
}

type effectBlockTimes struct {
	effectCommon
}

func registerEffectBlockTimes(effectID typeEffectID) effectGenerator {
	c, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectBlockTimes{
		effectCommon: newEffectCommon(c),
	}
}

func (i effectBlockTimes) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_BLOCK,
		param1: basic,
		param2: times,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i effectBlockTimes) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (basic uint32, times uint32) {
	if i.basic-1 > 0 {
		basic = (i.basic - 1) * self.battleItems[sourceUID].block
	}
	times = i.times
	return
}

func (i effectBlockTimes) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, arg ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	selfCamp := self.battleItems[sourceUID].camp
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		return true
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		if !self.isAlive(aimUID) {
			return false
		}
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		if !self.isAnyAlive(selfCamp) {
			return false
		}
	default:
		return false
	}
	return true
}

func (i effectBlockTimes) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32, firstTier bool, arg ...interface{}) (effectS []*pb.BattleEffect, timeAfter time.Duration) {
	selfCamp := self.battleItems[sourceUID].camp
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)
	switch i.aim {
	case uint32(csv.EFFECT_TARGET_SELF):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(sourceUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBlock(sourceUID, basic, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAlive(aimUID) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			effectLocal := self.addBlock(aimUID, basic, effectGroupID)
			effectS = append(effectS, effectLocal...)
		}
		return
	case uint32(csv.EFFECT_TARGET_ALL_TEAMMATE):
		for loopI := uint32(0); loopI < times; loopI++ {
			if !self.isAnyAlive(selfCamp) {
				break
			}
			if firstTier {
				timeAfter += i.timeAfter
				effectGroupID++
			}
			for _, uID := range self.aliveUIDs(selfCamp) {
				effectLocal := self.addBlock(uID, basic, effectGroupID)
				effectS = append(effectS, effectLocal...)
			}
		}
		return
	}
	return
}

type removeAllBlock struct {
	effectCommon
}

func registerRemoveAllBlock(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return removeAllBlock{
		effectCommon: newEffectCommon(e),
	}
}

func (i removeAllBlock) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	var monsterAi monsterAI

	monsterAiOne := monsterAIOne{
		uid:    sourceUID,
		method: pb.BattleMonsterAiEnum_BMonsterAI_REMOVE_OTHER_BLOCK,
		param1: 0,
		param2: 0,
	}
	monsterAi = append(monsterAi, monsterAiOne)
	return monsterAi
}

func (i removeAllBlock) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (block uint32, times uint32) {

	block = self.battleItems[aimUID].block
	return
}

func (i removeAllBlock) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}

	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		if !self.isAlive(aimUID) {
			return false
		}
		block, _ := i.getEffectBasic(self, sourceUID, aimUID)
		if block == 0 {
			return false
		}
	}
	return true
}

func (i removeAllBlock) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	timeAfter = i.timeAfter
	switch i.aim {
	case csv.EFFECT_TARGET_SPECIFIED_ENEMY:
		block, _ := i.getEffectBasic(self, sourceUID, aimUID)
		if block > 0 {
			localEffect := self.deBlock(aimUID, block, effectGroupID)
			effects = append(effects, localEffect...)
		}
		return
	}
	return
}

type effectAllPowerBlock struct {
	effectCommon
}

func registerEffectAllPowerBlock(effectID typeEffectID) effectGenerator {
	e, ok := csv.TableCardEffectMap[int64(effectID)]
	if !ok {
		panic(fmt.Sprintf("battle effect init fail, can't load config effectID:%v", effectID))
	}
	return effectAllPowerBlock{
		effectCommon: newEffectCommon(e),
	}
}

func (i effectAllPowerBlock) getMonsterAI(self *Battle, sourceUID uint64, aimUID uint64) monsterAI {
	log.Error().Msgf("monster AI use %v effect", i)
	return nil
}

func (i effectAllPowerBlock) getEffectBasic(self *Battle, sourceUID uint64, aimUID uint64,
	args ...interface{}) (basic uint32, times uint32) {
	mp := self.battleHeros[sourceUID].mp
	if mp > 0 {
		basic = i.basic * uint32(mp)
	}
	times = i.times
	return
}

func (i effectAllPowerBlock) effectCheck(self *Battle, sourceUID uint64, aimUID uint64, args ...interface{}) (canExec bool) {
	if !self.isAlive(sourceUID) {
		return false
	}
	_, ok := self.battleHeros[sourceUID]
	if !ok {
		return false
	}
	if self.battleHeros[sourceUID].mp <= 0 {
		return false
	}
	return true
}

func (i effectAllPowerBlock) effectExec(self *Battle, sourceUID uint64, aimUID uint64, effectGroupID uint32,
	firstTier bool, args ...interface{}) (effects []*pb.BattleEffect, timeAfter time.Duration) {
	basic, times := i.getEffectBasic(self, sourceUID, aimUID)

	// deMp and notice
	oldMP := self.battleHeros[sourceUID].mp
	newMP := uint32(0)
	self.battleHeros[sourceUID].mp = newMP
	rsp := pb.BattleActionNotice{}
	rsp.SourceUid = &sourceUID
	rsp.SpellId = self.generateSpellID()
	spellTypeID := uint32(1)
	rsp.SpellTypeId = &spellTypeID
	spell := pb.BattleSpell{}
	effect := pb.BattleEffect{}
	mpEffectGroupID := uint32(1)
	effect.GroupId = &mpEffectGroupID
	effect.Uid = &sourceUID
	effectEnum := pb.BattleEffectEnum_BEffect_MP
	effect.E = &effectEnum
	oldValue, newValue := int32(oldMP), int32(newMP)
	effect.OldValue = &oldValue
	effect.NewValue = &newValue
	spell.Effects = append(spell.Effects, &effect)
	rsp.Spells = append(rsp.Spells, &spell)
	actionDown(self, []uint64{sourceUID}, rsp)

	switch i.aim {
	case csv.EFFECT_TARGET_SELF:
		for loop := 0; loop < int(times); loop++ {
			if firstTier {
				effectGroupID++
				timeAfter += i.timeAfter
			}
			localEffect := self.addBlock(sourceUID, basic, effectGroupID)
			effects = append(effects, localEffect...)
		}
		return
	}
	return
}
