package battle

import (
	"errors"
	"fmt"
	"github.com/rs/zerolog/log"
	pb "shared/proto/client/battle"
	"sort"
)

type progress struct {
	uid   uint64
	pos   uint32
	speed uint32
	camp  uint32
}

// ToPb convert progress to BattleProgress
func (p progress) toClientProto(i *Battle) *pb.BattleProgress {
	ans := pb.BattleProgress{}
	ans.Uid = &p.uid
	ans.HeroTypeId = &i.battleItems[p.uid].heroTypeID
	ans.MonsterTypeId = &i.battleItems[p.uid].monsterTypeID
	ans.Pos = &p.pos
	return &ans
}

// newProgressL
func (i *Battle) newProgressL() {
	for _, item := range i.battleItems {
		p := newProgress(*item)
		i.progressL = append(i.progressL, &p)
	}
	i.progressSort()
}

// delOneProgress
func (i *Battle) delOneProgress(uid uint64) {
	index := -1
	for k, v := range i.progressL {
		if v.uid == uid {
			index = k
			break
		}
	}
	if index >= 0 {
		i.progressL = append(i.progressL[:index], i.progressL[index+1:]...)
	}
}

// addOneProgress
func (i *Battle) addOneProgress(uid uint64) {
	checkUID := false
	for k := range i.battleItems {
		if k == uid {
			checkUID = true
			break
		}
	}
	if !checkUID {
		return
	}
	for _, v := range i.progressL {
		if v.uid == uid {
			return
		}
	}
	p := newProgress(*i.battleItems[uid])
	i.progressL = append(i.progressL, &p)
	i.progressSort()
}

// newProgress from item
func newProgress(i item) progress {
	return progress{
		uid:   i.uid,
		pos:   0,
		speed: i.speed,
		camp:  i.camp,
	}
}

// sortProgress interface for sort
type sortProgress []*progress

// Len interface for sort
func (p sortProgress) Len() int { return len(p) }

// Swap interface for sort
func (p sortProgress) Swap(i, j int) { p[i], p[j] = p[j], p[i] }

// Less interface for sort
func (p sortProgress) Less(i, j int) bool {
	if p[i].camp == p[j].camp {
		return p[i].uid < p[j].uid
	}
	return p[i].camp < p[j].camp
}

// progressSort sort camp 0 in front of camp 1
func (i *Battle) progressSort() {
	sort.Sort(sortProgress(i.progressL))
	log.Debug().Msgf("battle %v:%v progress sort %v:",
		i.battleStageUID, i.battleNodeID, i.progressL)
}

// count new turn uid from progress list
func whoSTurn(ps []*progress) (uint64, error) {
	for {
		if len(ps) == 0 {
			return 0, errors.New("Empty progress list in Battle")
		}
		for _, p := range ps {
			if p.pos >= 100 {
				p.pos = 0
				return p.uid, nil
			}
		}

		for _, p := range ps {
			p.pos += p.speed
			if p.pos > 100 {
				p.pos = 100
			}
		}
	}
}

func noticeProgress(i *Battle, UIDs []uint64) {
	log.Debug().Msgf("battle %v:%v notice progress uid:%v",
		i.battleStageUID, i.battleNodeID, i.turnUID)
	proto := pb.BattleProgressNotice{}
	proto.Uid = &i.turnUID
	for _, v := range i.progressL {
		proto.Status = append(proto.Status, v.toClientProto(i))
	}
	progressActionDown(i, UIDs, proto)
}

func (p progress) String() string {
	s := "progress struct : "
	s += fmt.Sprintf("uid:%v, pos:%v, speed:%v, camp:%v",
		p.uid, p.pos, p.speed, p.camp)
	return s
}
