package battle

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"math/rand"
	"shared/battle.etc/buff"
	"shared/battle.etc/card"
	"shared/battle.etc/relic"
	"shared/csv"
	pb "shared/proto/client/battle"
)

// 卡牌前置使用条件
// TODO add card use check
type cardUseCheck struct {
}

// TODO add card use check
func (check cardUseCheck) check(i *Battle) (errCode int32) {
	errCode = csv.ERRCODE_SUCCESS
	return
}

// 洗牌
func (b *heroInBattle) shuffle() {
	rand.Shuffle(len(b.drawCards), func(i, j int) {
		b.drawCards[i], b.drawCards[j] = b.drawCards[j], b.drawCards[i]
	})
}

// card atomic move
func (b *heroInBattle) moveCard(from pb.BattleCardPosEnum, to pb.BattleCardPosEnum, cardID uint32, reason pb.BattleCardReasonEnum, param uint32) (card.MoveDesc, error) {
	ans := card.MoveDesc{
		Reason: reason,
		Param:  param,
	}
	fromShelf := b.cardShelf(from)
	index := -1
	for k, v := range fromShelf {
		if v.ID == cardID {
			index = k
			break
		}
	}
	if index < 0 {
		return ans, fmt.Errorf("cards %v not exist in shelf %v", cardID, fromShelf)
	}
	c := fromShelf[index]

	fromShelf = append(fromShelf[:index], fromShelf[index+1:]...)
	switch pb.BattleCardPosEnum(from) {
	case pb.BattleCardPosEnum_BCardPos_NIL:
		b.nilCards = fromShelf
	case pb.BattleCardPosEnum_BCardPos_DRAW:
		b.drawCards = fromShelf
	case pb.BattleCardPosEnum_BCardPos_DIS:
		b.disCards = fromShelf
	case pb.BattleCardPosEnum_BCardPos_EXHAUSTED:
		b.exhaustedCards = fromShelf
	case pb.BattleCardPosEnum_BCardPos_HANDY:
		b.handyCards = fromShelf
	}

	toShelf := append(b.cardShelf(to), c)
	switch pb.BattleCardPosEnum(to) {
	case pb.BattleCardPosEnum_BCardPos_NIL:
		b.nilCards = toShelf
	case pb.BattleCardPosEnum_BCardPos_DRAW:
		b.drawCards = toShelf
	case pb.BattleCardPosEnum_BCardPos_DIS:
		b.disCards = toShelf
	case pb.BattleCardPosEnum_BCardPos_EXHAUSTED:
		b.exhaustedCards = toShelf
	case pb.BattleCardPosEnum_BCardPos_HANDY:
		if c.Type == card.Status {
			b.gotStatusCardNum++
		}
		b.handyCards = toShelf
	}

	ans.ID = c.ID
	ans.ResID = c.ResID
	ans.From = from
	ans.To = to
	return ans, nil
}

// find card shelf by pb.BattleCardPosEnum
func (b *heroInBattle) cardShelf(d pb.BattleCardPosEnum) (ans []card.Card) {
	switch pb.BattleCardPosEnum(d) {
	case pb.BattleCardPosEnum_BCardPos_NIL:
		ans = b.nilCards
	case pb.BattleCardPosEnum_BCardPos_DRAW:
		ans = b.drawCards
	case pb.BattleCardPosEnum_BCardPos_DIS:
		ans = b.disCards
	case pb.BattleCardPosEnum_BCardPos_EXHAUSTED:
		ans = b.exhaustedCards
	case pb.BattleCardPosEnum_BCardPos_HANDY:
		ans = b.handyCards
	}
	return
}

// giveCardsN 抽n张牌
func (b *heroInBattle) giveCardsN(i *Battle, need uint32, reason pb.BattleCardReasonEnum, param uint32) (ans []card.MoveDesc, err error) {
	defer func() {
		uid := b.GetUID()
		oldParam, newParam, ok := i.buffShow(uid, buff.MoreCardsAfterBadCard)
		if ok && b.gotStatusCardNum > 0 {
			buffAction := i.buffSpell(uid, buff.MoreCardsAfterBadCard, oldParam, newParam, 1)
			actionDown(i, []uint64{uid}, buffAction)
			num := b.gotStatusCardNum * oldParam * uint32(buff.GetBasic(buff.MoreCardsAfterBadCard))
			b.gotStatusCardNum = 0
			ansLocal, err := b.giveCardsN(i, num, pb.BattleCardReasonEnum_BCardReason_BUFF, buff.MoreCardsAfterBadCard)
			if err != nil {
				log.Error().Msgf("Battle %v:%v Error give card Error info:%v",
					i.battleStageUID, i.battleNodeID, b)
			}
			ans = append(ans, ansLocal...)
		}
	}()
	n := int(need)
	nowHandleLen := len(b.handyCards)
	if nowHandleLen >= i.ConstMaxHandleCardNum {
		return
	}

	if nowHandleLen+n > i.ConstMaxHandleCardNum {
		n = i.ConstMaxHandleCardNum - nowHandleLen
	}

	numDraw := len(b.drawCards)

	// DrawEnough
	if n <= numDraw {
		var cIDs []uint32
		// 从尾部取
		for i := numDraw - 1; i >= numDraw-n; i-- {
			cIDs = append(cIDs, b.drawCards[i].ID)
		}
		for _, cID := range cIDs {
			m, err := b.moveCard(pb.BattleCardPosEnum_BCardPos_DRAW, pb.BattleCardPosEnum_BCardPos_HANDY, cID, reason, param)
			if err != nil {
				return ans, err
			}
			ans = append(ans, m)
		}
		return
	}

	// Draw Not Enough
	// 1. move all Draw to Handy
	hasMoved := 0
	var cIDs []uint32
	// 从尾部取
	for i := numDraw - 1; i >= 0; i-- {
		cIDs = append(cIDs, b.drawCards[i].ID)
	}
	for _, cID := range cIDs {
		m, err := b.moveCard(pb.BattleCardPosEnum_BCardPos_DRAW, pb.BattleCardPosEnum_BCardPos_HANDY, cID, reason, param)
		if err != nil {
			return ans, err
		}
		hasMoved++
		ans = append(ans, m)
	}
	leftNum := n - hasMoved
	// 2. move all Dis to Draw
	cIDs = []uint32{}
	for _, c := range b.disCards {
		cIDs = append(cIDs, c.ID)
	}
	for _, cID := range cIDs {
		m, err := b.moveCard(pb.BattleCardPosEnum_BCardPos_DIS, pb.BattleCardPosEnum_BCardPos_DRAW, cID, reason, param)
		if err != nil {
			return ans, err
		}
		ans = append(ans, m)
	}
	b.shuffle()
	// do relic RecoverHpAfterCardsShuffle
	if param, ok := b.GetRelic(relic.RecoverHpAfterCardsShuffle); ok {
		basic, _, _, ok := relic.GetRelicBasic(relic.RecoverHpAfterCardsShuffle)
		if ok {
			relicAction := i.relicSpell(b.GetUID(), relic.RecoverHpAfterCardsShuffle, param, param, 1)
			effectList := i.addHp(b.GetUID(), uint32(basic), 1)
			relicAction = i.relicSpellAddEffect(relicAction, effectList)
			actionDown(i, []uint64{b.GetUID()}, relicAction)
		}
	}
	// 3-1. move left num from Draw to Handy
	numDraw = len(b.drawCards)
	if leftNum < numDraw {
		cIDs = []uint32{}
		// 从尾部取
		for i := numDraw - 1; i >= numDraw-leftNum; i-- {
			cIDs = append(cIDs, b.drawCards[i].ID)
		}
		for _, cID := range cIDs {
			m, err := b.moveCard(pb.BattleCardPosEnum_BCardPos_DRAW, pb.BattleCardPosEnum_BCardPos_HANDY, cID, reason, param)
			if err != nil {
				return ans, err
			}
			ans = append(ans, m)
		}
		return
	}
	// 3-2. move all Draw to Handy
	cIDs = []uint32{}
	// 从尾部取
	for i := numDraw - 1; i >= 0; i-- {
		cIDs = append(cIDs, b.drawCards[i].ID)
	}
	for _, cID := range cIDs {
		m, err := b.moveCard(pb.BattleCardPosEnum_BCardPos_DRAW, pb.BattleCardPosEnum_BCardPos_HANDY, cID, reason, param)
		if err != nil {
			return ans, err
		}
		ans = append(ans, m)
	}
	return
}

// useCard - use one card and move it
func (b *heroInBattle) useCard(cardID uint32) (ans card.MoveDesc, changedCard card.Card, ok bool) {
	for index, c := range b.handyCards {
		if c.ID == cardID {
			// add Round Times
			c.RoundTimes++
			b.handyCards[index] = c
			// found card
			ok = true
			to := pb.BattleCardPosEnum_BCardPos_DIS
			if c.Type == card.Power {
				to = pb.BattleCardPosEnum_BCardPos_NIL
			} else if c.Spec == card.ExhaustedWithUsed || c.Spec == card.Exhausted {
				to = pb.BattleCardPosEnum_BCardPos_EXHAUSTED
			}
			ans, err := b.moveCard(pb.BattleCardPosEnum_BCardPos_HANDY, to, c.ID, pb.BattleCardReasonEnum_BCardReason_USE, c.ResID)
			if err != nil {
				ok = false
			}
			return ans, c, ok
		}
	}
	return
}

// isExist check one cardID is in handy cards
func (b *heroInBattle) isExist(cardID uint32) (c card.Card, ok bool) {
	for _, c := range b.handyCards {
		if c.ID == cardID {
			return c, true
		}
	}
	return c, false
}

// disCard - dis one card and move it
func (b *heroInBattle) disCard(cardID uint32, reason pb.BattleCardReasonEnum, param uint32) (ans card.MoveDesc, ok bool) {
	for _, c := range b.handyCards {
		if c.ID == cardID {
			ok = true
			to := pb.BattleCardPosEnum_BCardPos_DIS
			if c.Spec == card.ExhaustedWithoutUsed || c.Spec == card.Exhausted {
				to = pb.BattleCardPosEnum_BCardPos_EXHAUSTED
			}
			ans, err := b.moveCard(pb.BattleCardPosEnum_BCardPos_HANDY, to, c.ID, reason, param)
			if err != nil {
				log.Debug().Msgf("battle debug dis card move card fail %v", cardID)
				ok = false
			}
			return ans, ok
		}
	}
	log.Debug().Msgf("battle debug dis card didn't found card %v", cardID)
	return
}

// exhaustedCard - exhausted one card and move it
func (b *heroInBattle) exhaustedCard(cardID uint32, reason pb.BattleCardReasonEnum, param uint32) (ans card.MoveDesc, ok bool) {
	for _, c := range b.handyCards {
		if c.ID == cardID {
			ok = true
			to := pb.BattleCardPosEnum_BCardPos_EXHAUSTED
			ans, err := b.moveCard(pb.BattleCardPosEnum_BCardPos_HANDY, to, c.ID, reason, param)
			if err != nil {
				log.Debug().Msgf("battle debug dis card move card fail %v", cardID)
				ok = false
			}
			return ans, ok
		}
	}
	log.Debug().Msgf("battle debug dis card didn't found card %v", cardID)
	return
}

// add one card to handy, not move
func (b *heroInBattle) addCard2Hand(typeID, starLevel, cardLevel uint32) error {
	id := b.GenerateCardID()
	crd, err := card.New(id, typeID, starLevel, cardLevel)
	if err != nil {
		return err
	}
	b.handyCards = append(b.handyCards, crd)
	return nil
}

func (b *heroInBattle) addCard2Discard(typeID, starLevel, cardLevel uint32) error {
	id := b.GenerateCardID()
	crd, err := card.New(id, typeID, starLevel, cardLevel)
	if err != nil {
		return err
	}
	b.disCards = append(b.disCards, crd)
	return nil
}

func (b *heroInBattle) addCard2Draw(typeID, starLevel, cardLevel uint32) (card.Card, error) {
	id := b.GenerateCardID()
	crd, err := card.New(id, typeID, starLevel, cardLevel)
	if err != nil {
		return crd, err
	}
	drawCardsLen := len(b.drawCards)
	if drawCardsLen == 0 {
		b.drawCards = append(b.drawCards, crd)
		return crd, nil
	}
	randIndex := rand.Intn(drawCardsLen + 1)

	result := make([]card.Card, drawCardsLen+1)
	sourceIndex := 0
	for i := 0; i < drawCardsLen+1; i++ {
		if i == randIndex {
			result[i] = crd
			continue
		}
		result[i] = b.drawCards[sourceIndex]
		sourceIndex++
	}
	b.drawCards = result
	return crd, nil
}

// findCard
func (b *heroInBattle) findCard(cardID uint32) (cardOne card.Card, pos pb.BattleCardPosEnum, ok bool) {
	pos = pb.BattleCardPosEnum_BCardPos_DIS
	for _, c := range b.disCards {
		if c.ID == cardID {
			cardOne = c
			ok = true
			return
		}
	}
	pos = pb.BattleCardPosEnum_BCardPos_DRAW
	for _, c := range b.drawCards {
		if c.ID == cardID {
			cardOne = c
			ok = true
			return
		}
	}
	pos = pb.BattleCardPosEnum_BCardPos_EXHAUSTED
	for _, c := range b.exhaustedCards {
		if c.ID == cardID {
			cardOne = c
			ok = true
			return
		}
	}
	pos = pb.BattleCardPosEnum_BCardPos_HANDY
	for _, c := range b.handyCards {
		if c.ID == cardID {
			cardOne = c
			ok = true
			return
		}
	}
	pos = pb.BattleCardPosEnum_BCardPos_NIL
	for _, c := range b.nilCards {
		if c.ID == cardID {
			cardOne = c
			ok = true
			return
		}
	}
	return
}
