package battle

import (
	"github.com/rs/zerolog/log"
	"runtime/debug"
	"shared/battle.etc/card"
	"shared/cardDef"
	"shared/csv"
	pb "shared/proto/client/battle"
	"strconv"
	"time"
)

// Start one battle
func Start(self *Battle) {
	// create channel
	self.operationChanS = make(map[uint64]chan interface{})
	for _, i := range self.battleItems {
		if i.monsterTypeID == 0 {
			self.operationChanS[i.uid] = make(chan interface{})
		}
	}

	// recover - output Battle info
	defer func() {
		if err := recover(); err != nil {
			log.Error().Msgf("battle %v:%v error, errinfo:%v, stack:%v,  battleInfo:%v",
				self.battleStageUID, self.battleNodeID, err, string(debug.Stack()), self)
		}
		log.Debug().Msgf("battle %v:%v defer be called",
			self.battleStageUID, self.battleNodeID)
		self.battleOver()
	}()
	// create progress
	self.newProgressL()

	log.Debug().Msgf("battle %v:%v init success info:%v",
		self.battleStageUID, self.battleNodeID, self)

	// wait all hero is ready
	if !self.listenAllReady() {
		log.Info().Msgf("battle %v:%v info, no player ready, battle cancel",
			self.battleStageUID, self.battleNodeID)
		return
	}
	// count battle-start buff
	if self.countBeforeStart() {
		return
	}
	// Battle Loop
	roundNum := 0
	for {
		roundNum++
		if roundNum > self.ConstMaxRoundNum {
			log.Debug().Msgf("battle %v:%v STOP out of maxRoundNum",
				self.battleStageUID, self.battleNodeID)
			// TODO
			// Force stop
			return
		}
		if startRound(self) {
			// battle over - stop
			return
		}
	}
}

// start one round
func startRound(self *Battle) (stopNow bool) {
	// is battle stopped?
	if stopped := self.isBattleStopped(); stopped {
		return true
	}
	// who's turn?
	turnUID, err := whoSTurn(self.progressL)
	if err != nil {
		panic(err)
	}
	oldTurnUID := self.turnUID
	self.turnUID = turnUID
	// add round
	self.battleItems[turnUID].round++
	// clear roundHadBeHurt
	for itemID := range self.battleItems {
		self.battleItems[itemID].roundHadBeHurt = 0
	}
	// notice progress
	noticeProgress(self, self.heroIDs())
	// control singal in?
	if stopNow := self.handleControlSingal(); stopNow {
		return true
	}
	// sleep during round
	milliseconds, err := strconv.Atoi(csv.CommonConfigMap["SERVER_ROUND_INTERVAL"].Value)
	if err == nil {
		if oldTurnUID != 0 && self.battleItems[oldTurnUID].heroTypeID > 0 && self.battleItems[turnUID].monsterTypeID > 0 {
			plusMilliseconds, err := strconv.Atoi(csv.CommonConfigMap["SERVER_PLAYER_TO_MONSTER_INTERVAL_ADD"].Value)
			if err == nil {
				milliseconds += plusMilliseconds
			}
		}
		sleepTime := time.Duration(int64(milliseconds)) * time.Millisecond

		if sleepTime > time.Duration(5)*time.Second {
			log.Error().Msgf("battle %v:%v round sleep:%v",
				self.battleStageUID, self.battleNodeID, sleepTime)
			sleepTime = time.Duration(5) * time.Second
		}
		if self.needSleep() {
			time.Sleep(sleepTime)
			// control singal in?
			if stopNow := self.handleControlSingal(); stopNow {
				return true
			}
		}
	}
	// count before round
	if self.countBeforeRound() {
		return true
	}
	disCardS := []card.Card{}
	if _, ok := self.battleHeros[self.turnUID]; ok {
		// this function will save uid into battle operation state
		// make it empty when stop listen operation
		self.beforeHeroRoundBegin()
		// hero action
		stopNow, disCardS = startHeroRound(self)
		// make battle operation state empty
		self.stateDelete()
		if stopNow {
			return true
		}
	} else {
		// monster action
		if startMonsterRound(self) {
			return true
		}
	}

	// count after round
	if self.countAfterRound(disCardS) {
		return true
	}
	return false
}

// start one monster round
func startMonsterRound(self *Battle) bool {
	if checkStop := self.monsterAction(); checkStop {
		// is battle stopped?
		if stopped := self.isBattleStopped(); stopped {
			return true
		}
	}
	return false
}

// start one hero round
func startHeroRound(self *Battle) (bool, []card.Card) {
	turnUID := self.turnUID
	// deal with reconnection
	reconnectionIndex := -1
	for index, uid := range self.reconnection {
		if uid == turnUID {
			self.online(uid)
			reconnectionIndex = index
			break
		}
	}
	if reconnectionIndex >= 0 {
		self.reconnection = append(self.reconnection[:reconnectionIndex], self.reconnection[reconnectionIndex+1:]...)
	}
	if self.battleItems[turnUID].round == 1 && self.battleHeros[turnUID].RecoverPlusMoreMPAndCard {
		self.battleHeros[turnUID].getCardsNum += 2
	}
	// give card
	self.giveCard()
	if self.battleItems[turnUID].round == 1 && self.battleHeros[turnUID].RecoverPlusMoreMPAndCard {
		self.battleHeros[turnUID].getCardsNum -= 2
		self.battleHeros[turnUID].RecoverPlusMoreMPAndCard = false
	}
	// count after give cards
	if self.countAfterGiveCards() {
		return true, []card.Card{}
	}
	// monster ai notice
	self.monsterAiNotice()
	// make timer
	roundTimer := time.After(self.ConstMaxRoundTime)
	log.Debug().Msgf("battle %v:%v round start uid:%v",
		self.battleStageUID, self.battleNodeID, turnUID)
	for {
		// is timeout?
		isTimeout := false
		// has operation?
		stopNow, stopRoundNow := false, false
		select {
		case <-roundTimer:
			isTimeout = true
		case o := <-self.operationChanS[turnUID]:
			// execute operation
			op, _ := o.(operation)
			stopNow, stopRoundNow = startHeroOperation(self, op, roundTimer)
		case control := <-self.battleInChan:
			controlSingal, _ := control.Control.(Control)
			stopNow, _ = self.controlSingal(controlSingal)
		}
		// check stop firstly
		if stopNow {
			return true, []card.Card{}
		}
		// then check stop round
		if stopRoundNow {
			break
		}
		// check timeout
		if isTimeout {
			log.Debug().Msgf("battle %v:%v round stop by TIMEOUT uid:%v",
				self.battleStageUID, self.battleNodeID, turnUID)
			break
		}
	}
	// dis card
	disCardS := self.disCard()
	return false, disCardS
}

// execute hero one operation
func startHeroOperation(self *Battle, o operation, roundTimer <-chan time.Time) (stopNow bool, stopRoundNow bool) {
	turnUID := self.turnUID
	switch o.enum {
	case pb.BattleOperationEnum_BOperation_FINISH_ROUND:
		// stop round
		log.Debug().Msgf("battle %v:%v round stop by STOP round operation uid:%v",
			self.battleStageUID, self.battleNodeID, turnUID)
		stopRoundNow = true
		// reply
		select {
		case o.replyChan <- OperationReply{Result: csv.ERRCODE_SUCCESS}:
			close(o.replyChan)
		default:
		}
	case pb.BattleOperationEnum_BOperation_USE_POTION:
		log.Debug().Msgf("battle %v:%v round execute operation uid:%v info:%v",
			self.battleStageUID, self.battleNodeID, turnUID, o)
		errCode, checkStop := self.execUsePotion(o)
		// reply
		select {
		case o.replyChan <- OperationReply{Result: errCode}:
			close(o.replyChan)
		default:
		}
		// if execute fail, break
		if errCode != csv.ERRCODE_SUCCESS {
			break
		}
		// then check is anyone dead?
		if checkStop {
			// is battle stopped?
			if stopped := self.isBattleStopped(); stopped {
				stopNow = true
				// return here
				// if stopped, do not call countAfterUsePotion
				return
			}
		}
		// count after use card
		if self.countAfterUsePotion(o) {
			stopNow = true
		}
	case pb.BattleOperationEnum_BOperation_USE_CARD:
		// use card
		log.Debug().Msgf("battle %v:%v round execute operation uid:%v info:%v",
			self.battleStageUID, self.battleNodeID, turnUID, o)
		errCode, checkStop, stopRound := self.execUseCard(o, roundTimer)

		stopRoundNow = stopRound
		if errCode != csv.ERRCODE_SUCCESS {
			break
		}

		// then check is anyone dead?
		if checkStop {
			// is battle stopped?
			if stopped := self.isBattleStopped(); stopped {
				stopNow = true
				// return here
				// if stopped, do not call countAfterUseCard
				return
			}
		}

		// count after use card
		if self.countAfterUseCard(uint32(o.param1)) {
			stopNow = true
		}
	case pb.BattleOperationEnum_BOperation_GM_ADD_CARD:
		if !self.ConstGmOpen {
			// reply
			select {
			case o.replyChan <- OperationReply{Result: csv.ERRCODE_BATTLE_OPERATION_ERROR}:
				close(o.replyChan)
			default:
			}
			break
		}
		cardC, ok := csv.TableCardsMap[int64(o.param1)]
		if !ok {
			// reply
			select {
			case o.replyChan <- OperationReply{Result: csv.ERRCODE_BATTLE_CARD_NOT_EXIST}:
				close(o.replyChan)
			default:
			}
			break
		}
		cardStar := uint32(1)
		cardP, ok := self.battleHeros[turnUID].CardPool[cardDef.TypeID(cardC.CardGroupID)]
		if ok {
			cardStar = cardP.GetCardStarLevel()
		}
		err := self.battleHeros[turnUID].addCard2Hand(uint32(cardC.CardGroupID), cardStar, uint32(cardC.Level))
		if err != nil {
			// reply
			select {
			case o.replyChan <- OperationReply{Result: csv.ERRCODE_BATTLE_CARD_NOT_EXIST}:
				close(o.replyChan)
			default:
			}
			break
		}
		newCard := &self.battleHeros[turnUID].handyCards[len(self.battleHeros[turnUID].handyCards)-1]
		from := pb.BattleCardPosEnum_BCardPos_NIL
		to := pb.BattleCardPosEnum_BCardPos_HANDY
		desc := card.MoveDesc{ID: newCard.ID, ResID: newCard.ResID, From: from, To: to}
		allCardsActionDown(self, turnUID, pb.BattleCardPosEnum_BCardPos_HANDY)
		cardActionDown(self, turnUID, []card.MoveDesc{desc})
		// reply
		select {
		case o.replyChan <- OperationReply{Result: csv.ERRCODE_SUCCESS}:
			close(o.replyChan)
		default:
		}
	// TODO
	// add other operation
	default:
		log.Debug().Msgf("battle %v:%v debug catch %v in round -notMatch",
			self.battleStageUID, self.battleNodeID, o)
		// Unknown operation - reply
		select {
		case o.replyChan <- OperationReply{Result: csv.ERRCODE_BATTLE_OPERATION_ERROR}:
			close(o.replyChan)
		default:
		}
	}
	return
}

func (i *Battle) isBattleStopped() (stopped bool) {
	// is item-list empty?
	if len(i.battleItems) == 0 {
		log.Debug().Msgf("battle %v:%v stopped item-list is empty",
			i.battleStageUID, i.battleNodeID)
		return true
	}

	var aliveItems []*item
	for _, i := range i.battleItems {
		if i.hp > 0 {
			aliveItems = append(aliveItems, i)
		}
	}
	// all dead?
	if len(aliveItems) == 0 {
		log.Debug().Msgf("battle %v:%v stopped all items is dead or offline",
			i.battleStageUID, i.battleNodeID)
		return true
	}
	// has winner?
	camp := aliveItems[0].camp
	for _, i := range aliveItems[1:] {
		if camp != i.camp {
			return false
		}
	}

	// return
	log.Debug().Msgf("battle %v:%v stopped",
		i.battleStageUID, i.battleNodeID)
	return true
}

func (i *Battle) needSleep() bool {
	for uid := range i.battleHeros {
		if i.battleItems[uid].online {
			return true
		}
	}
	return false
}

func (i *Battle) controlSingal(controlSingal Control) (stopNow, checkStop bool) {
	switch controlSingal.Enum {
	case "stop":
		stopNow = true
	case "leave":
		log.Debug().Msgf("battle %v:%v player leave",
			i.battleStageUID, i.battleNodeID)
		i.runAway(controlSingal.UID)
		checkStop = true
	case "offline":
		log.Debug().Msgf("battle %v:%v player offline",
			i.battleStageUID, i.battleNodeID)
		i.offline(controlSingal.UID)
	case "reconnection":
		log.Debug().Msgf("battle %v:%v player reconnection",
			i.battleStageUID, i.battleNodeID)
		if controlSingal.UID == i.turnUID {
			i.online(controlSingal.UID)
			i.monsterAiNotice()
		} else {
			i.reconnection = append(i.reconnection, controlSingal.UID)
		}
	default:
	}
	return
}

func (i *Battle) handleControlSingal() bool {
	for {
		checkStop := false
		stopNow := false
		breakNow := false
		var controlSingal Control
		select {
		case battleOperation := <-i.battleInChan:
			controlSingal, _ = battleOperation.Control.(Control)
		default:
			breakNow = true
		}
		if breakNow {
			break
		}
		stopNow, checkStop = i.controlSingal(controlSingal)
		if stopNow {
			return stopNow
		}
		if checkStop {
			if i.isBattleStopped() {
				return true
			}
		}
	}
	return false
}

func (i *Battle) giveCard() {
	heroInBattle := i.battleHeros[i.turnUID]
	cardActionList, err := heroInBattle.giveCardsN(i, heroInBattle.getCardsNum, pb.BattleCardReasonEnum_BCardReason_GIVE, 0)
	if err != nil {
		log.Error().Msgf("Battle %v:%v Error give card Error info:%v",
			i.battleStageUID, i.battleNodeID, heroInBattle)
	}
	log.Debug().Msgf("battle %v:%v card give handyLen:%v drawLen:%v disLen:%v",
		i.battleStageUID, i.battleNodeID, len(heroInBattle.handyCards), len(heroInBattle.drawCards), len(heroInBattle.disCards))
	cardActionDown(i, i.turnUID, cardActionList)
}

func (i *Battle) disCard() []card.Card {
	log.Debug().Msgf("battle %v:%v card dis %v",
		i.battleStageUID, i.battleNodeID, i.turnUID)
	heroInBattle := i.battleHeros[i.turnUID]
	cardActionList := []card.MoveDesc{}
	var cardS []card.Card
	var cIDs []uint32
	for _, c := range heroInBattle.handyCards {
		cardS = append(cardS, c)
		cIDs = append(cIDs, c.ID)
	}
	for _, cID := range cIDs {
		cardAction, ok := heroInBattle.disCard(cID, pb.BattleCardReasonEnum_BCardReason_DIS, 0)
		if !ok {
			log.Error().Msgf("Battle %v:%v Error dis card Error info:%v",
				i.battleStageUID, i.battleNodeID, i)
			continue
		}
		cardActionList = append(cardActionList, cardAction)
	}
	log.Debug().Msgf("battle %v:%v card dis handyLen:%v drawLen:%v disLen:%v",
		i.battleStageUID, i.battleNodeID, len(heroInBattle.handyCards), len(heroInBattle.drawCards), len(heroInBattle.disCards))
	cardActionDown(i, i.turnUID, cardActionList)
	return cardS
}
