package battle

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"shared/battle.etc/hero"
	"shared/battle.etc/node"
	"shared/battle.etc/stageDef"
	pb "shared/proto/client/battle"
	"time"
)

// Config battle running rules
type Config struct {
	// 玩家回合超时
	ConstMaxRoundTime time.Duration
	// 最大回合数限制-防止死循环-推荐配置999
	ConstMaxRoundNum int
	// 等候玩家开始战斗-前端卡loading-推荐配置10s
	ConstWaitAllPlayerReady time.Duration
	// 玩家最大手牌数-推荐配置8
	ConstMaxHandleCardNum int
	// 消耗X卡牌配置-255
	ConstCardCostX int
	// GM开关
	ConstGmOpen bool
}

// GetPVEDefaultConfig PVE default config
func GetPVEDefaultConfig(gmOpen bool) Config {
	return Config{
		ConstMaxRoundTime:       time.Duration(5) * time.Minute,
		ConstMaxRoundNum:        999,
		ConstWaitAllPlayerReady: time.Duration(10) * time.Second,
		ConstMaxHandleCardNum:   8,
		ConstCardCostX:          255,
		ConstGmOpen:             gmOpen,
	}
}

func (config Config) check() error {
	if config.ConstMaxRoundTime < time.Duration(10)*time.Second {
		return fmt.Errorf("ConstMaxRoundTime is less than 10 seconds %v", config)
	}
	if config.ConstMaxRoundNum < 5 {
		return fmt.Errorf("ConstMaxRoundNum is less than 5 round %v", config)
	}
	if config.ConstWaitAllPlayerReady < time.Duration(1)*time.Second {
		return fmt.Errorf("ConstWaitAllPlayerReady is less than 1 second %v", config)
	}
	if config.ConstMaxHandleCardNum < 1 {
		return fmt.Errorf("ConstMaxHandleCardNum is less than 1 %v", config)
	}
	if config.ConstCardCostX < 1 {
		return fmt.Errorf("ConstCardCostX is less than 1 %v", config)
	}
	return nil
}

// Battle struct - used by 1-* users
type Battle struct {
	Config
	battleStageUID        uint64
	battleStageDifficulty uint32
	battleNodeID          uint32
	monsterGroupID        uint32
	battleHeros           map[uint64]*heroInBattle
	battleItems           map[uint64]*item
	battleInChan          <-chan *stageDef.BattleOperationParam
	stageInChan           chan<- *stageDef.In
	turnUID               uint64
	progressL             []*progress
	operationChanS        map[uint64]chan interface{}
	spellID               uint32
	monsterUID            uint64
	reconnection          []uint64
}

// Control desc outside control singal into battle process
type Control struct {
	Enum string
	UID  uint64
}

// New create Battle
func New(stageUID uint64, stageDifficulty uint32, stageInChan chan<- *stageDef.In,
	battleNode *node.Node, battleHero hero.InStage, startNow bool, config Config) (*Battle, chan<- *stageDef.BattleOperationParam, error) {
	log.Debug().Msgf("stage debug touch create new battle %v %v", stageUID, config)
	if err := config.check(); err != nil {
		return nil, nil, fmt.Errorf("battle new config check error %v", err)
	}
	battleInChan := make(chan *stageDef.BattleOperationParam, 100)
	b := &Battle{
		Config:                config,
		battleStageUID:        stageUID,
		battleStageDifficulty: stageDifficulty,
		battleNodeID:          battleNode.ID,
		monsterGroupID:        battleNode.MonsterGroupID,
		battleHeros:           make(map[uint64]*heroInBattle),
		battleItems:           make(map[uint64]*item),
		battleInChan:          battleInChan,
		stageInChan:           stageInChan,
	}

	battleHeroInBattle := newHeroInBattle(battleHero)
	b.battleHeros[battleHeroInBattle.GetUID()] = &battleHeroInBattle
	battleHeroItem := heroInBattleToBattleItem(&battleHeroInBattle)
	b.battleItems[battleHeroInBattle.GetUID()] = &battleHeroItem

	// join monster
	for _, m := range battleNode.MonsterS {
		monsterUID := b.generateMonsterID()
		monsterBattleItem := monsterToBattleItem(monsterUID, m)
		b.battleItems[monsterUID] = &monsterBattleItem
	}

	if startNow {
		push(b)
	}
	return b, battleInChan, nil
}

// ToClientProto convert Battle struct to BattleData
func (battleOne Battle) ToClientProto(selfHero hero.InStage) *pb.BattleData {
	ans := pb.BattleData{}
	for _, h := range battleOne.battleHeros {
		if h.GetUID() == selfHero.GetUID() {
			ans.Mine = h.toClientProto()
			break
		}
	}
	for _, i := range battleOne.battleItems {
		ans.Items = append(ans.Items, i.toClientProto())
	}
	ans.MonsterGroupID = &battleOne.monsterGroupID
	return &ans
}

// String - achieve String interface
func (battleOne Battle) String() string {
	s := "Battle Struct: "
	s += fmt.Sprintln(" turnID: ", battleOne.turnUID)
	s += fmt.Sprintf(" BattleHero: %v", battleOne.battleHeros)
	s += fmt.Sprintf(" BattleItems: %v", battleOne.battleItems)
	s += fmt.Sprintf(" BattleprogressL :%v", battleOne.progressL)
	return s
}

// get all hero uid in battle
func (battleOne Battle) heroIDs() (ans []uint64) {
	for _, v := range battleOne.battleHeros {
		ans = append(ans, v.GetUID())
	}
	return
}

func (battleOne *Battle) clearChooseCardFlag(heroUID uint64) {
	h, ok := battleOne.battleHeros[heroUID]
	if ok {
		h.chooseCardNum = 0
		h.chooseCardType = 0
	}
}
