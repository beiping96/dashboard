package stagePlayer

import (
	"github.com/rs/zerolog/log"
	cd "shared/cardDef"
	"shared/csv"
	"shared/heroDef"
	"strconv"
	"strings"
)

// StagePlayer - Desc the temp struct for create stage
type StagePlayer struct {
	PlayerID       uint64
	PlayerName     string
	LobbyID        uint32
	AllCards       map[cd.TypeID]cd.Card
	AllHeroAttrIDs []uint32
}

// New - create new StagePlayer struct
func New(playerID uint64, playerName string, lobbyID uint32,
	playerAllCards map[cd.TypeID]*cd.Card, playerAllHero map[uint64]*heroDef.Hero) *StagePlayer {
	localAllCards := make(map[cd.TypeID]cd.Card)
	for k, c := range playerAllCards {
		localC := cd.FromDbProto(c.ToDbProto())
		localAllCards[k] = *localC
	}
	localHeroAttrIDs := []uint32{}
	for _, heroOne := range playerAllHero {
		attrString := ""
		for _, heroConfig := range csv.TableHeroGrowingMap {
			if uint32(heroConfig.HeroID) == heroOne.GetTypeID() && uint32(heroConfig.HeroStar) == heroOne.GetStarLevel() {
				attrString = heroConfig.GlobalAttr
				break
			}
		}
		if len(attrString) == 0 {
			break
		}
		attrList := []uint32{}
		for _, attrOne := range strings.Split(attrString, ",") {
			attrID, err := strconv.Atoi(attrOne)
			if err != nil {
				log.Error().Msgf("config error heroGrowing heroTypeID:%v heroStar:%v globalAttrString:%v error:%v",
					heroOne.GetTypeID(), heroOne.GetStarLevel(), attrString, err)
				continue
			}
			attrList = append(attrList, uint32(attrID))
		}
		localHeroAttrIDs = append(localHeroAttrIDs, attrList...)
	}
	return &StagePlayer{
		PlayerID:       playerID,
		PlayerName:     playerName,
		LobbyID:        lobbyID,
		AllCards:       localAllCards,
		AllHeroAttrIDs: localHeroAttrIDs,
	}
}
