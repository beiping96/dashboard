package monster

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"shared/battle.etc/buff"
	"shared/csv"
	rds "shared/proto/server/battle"
	"shared/table"
	"strconv"
	"strings"
)

// Monster struct for desc monster config
type Monster struct {
	TypeID  uint32
	HP      uint32
	HPLimit uint32
	Buff    []buff.Buff
	Speed   uint32
	Pos     uint32
}

// New create monster
func New(typeID uint32, challengeLevel uint32, pos uint32) (ans Monster, err error) {
	m, ok := csv.MonsterMap[int64(typeID)]
	if !ok {
		log.Error().Msgf("monster not found, typeId: %d",
			typeID)
		return ans, fmt.Errorf("battle init error, can't found monster type id %v",
			typeID)
	}
	ans.TypeID = typeID
	prop, ok := table.GetMonsterPropertyByGroupAndChallengeLevel(uint32(m.Property_ID), challengeLevel)
	if !ok {
		log.Error().Msgf("monster prop not found, propId: %d, challengeLevel: %d",
			m.Property_ID, challengeLevel)
		return ans, fmt.Errorf("battle init error, can't found monster attributes %v",
			typeID)
	}
	ans.HPLimit = uint32(prop.Init_HP)
	ans.HP = ans.HPLimit

	for _, buffStr := range []string{prop.Buff1, prop.Buff2, prop.Buff3, prop.Buff4, prop.Buff5} {
		if buffStr == "" {
			continue
		}
		buffStrList := strings.Split(buffStr, ",")
		if len(buffStrList) != 2 {
			log.Error().Msgf("monster %v init 1error buffStr struct error str:%v", typeID, buffStr)
			continue
		}
		buffTypeID, err := strconv.Atoi(buffStrList[0])
		if err != nil {
			log.Error().Msgf("monster %v init 2error buffStr struct error str:%v", typeID, buffStr)
			continue
		}
		buffParam, err := strconv.Atoi(buffStrList[1])
		if err != nil {
			log.Error().Msgf("monster %v init 3error buffStr struct error str:%v", typeID, buffStr)
			continue
		}
		buffOne := buff.Buff{
			TypeID: uint32(buffTypeID),
			Param:  uint32(buffParam),
		}
		ans.Buff = append(ans.Buff, buffOne)
	}

	ans.Speed = uint32(prop.Init_Speed)
	ans.Pos = pos
	return
}

// ToRdsMonsterProto convert proto for save
func (mst *Monster) ToRdsMonsterProto() *rds.RdsMonster {
	monsterbuff := make([]*rds.RdsBuff, len(mst.Buff))
	for i, v := range mst.Buff {
		monsterbuff[i] = v.ToRdsProto()
	}
	return &rds.RdsMonster{
		TypeID:  mst.TypeID,
		Hp:      mst.HP,
		HpLimit: mst.HPLimit,
		Buff:    monsterbuff,
		Speed:   mst.Speed,
		Pos:     mst.Pos,
	}
}

// FromRdsMonsterProto convert proto for save
func FromRdsMonsterProto(mst *rds.RdsMonster) Monster {
	monsterBuff := make([]buff.Buff, len(mst.Buff))
	for i, v := range mst.Buff {
		monsterBuff[i] = buff.FromRdsProto(v)
	}
	return Monster{
		TypeID:  mst.TypeID,
		HP:      mst.Hp,
		HPLimit: mst.HpLimit,
		Buff:    monsterBuff,
		Speed:   mst.Speed,
		Pos:     mst.Pos,
	}
}
