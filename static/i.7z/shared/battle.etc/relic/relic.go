package relic

import (
	"fmt"
	"github.com/rs/zerolog/log"
	"shared/battle.etc/card"
	"shared/battle.etc/potion"
	"shared/csv"
	pb "shared/proto/client/battle"
	rds "shared/proto/server/battle"
)

const (
	// RecoverHpAfterBattle - 面包
	RecoverHpAfterBattle uint32 = 1001
	// RecoverHpAfterCardsShuffle - 咖啡杯
	RecoverHpAfterCardsShuffle uint32 = 1002
	// MoreCardsBeforeBattle - 行囊
	MoreCardsBeforeBattle uint32 = 1003
	// RecoverHpBeforeBattle - 针筒
	RecoverHpBeforeBattle uint32 = 1004
	// EasyToHurtAllBeforeBattle - 准星
	EasyToHurtAllBeforeBattle uint32 = 1005
	// AttackPowerlessAllBeforeBattle - 鬼面具
	AttackPowerlessAllBeforeBattle uint32 = 1006
	// AgilityBeforeBattle - 滑板鞋
	AgilityBeforeBattle uint32 = 1007
	// PowerBeforeBattle - 鸡尾酒
	PowerBeforeBattle uint32 = 1008
	// MpBeforeFirstRound - 手电筒
	MpBeforeFirstRound uint32 = 1009
	// BlockBeforeFirstRound - 船锚
	BlockBeforeFirstRound uint32 = 1010
	// ReflectBeforeBattle - 荆棘丛
	ReflectBeforeBattle uint32 = 1011
	// RecoverHpByMpAfterRound - 吊瓶
	RecoverHpByMpAfterRound uint32 = 1012
	// BlockByCardsAfterRound - 手提包
	BlockByCardsAfterRound uint32 = 1013
	// MpLimitAndMoreCardsBeforeBattle - 独轮车
	MpLimitAndMoreCardsBeforeBattle uint32 = 1014
	// MpLimitAndUnShowAI - 眼罩
	MpLimitAndUnShowAI uint32 = 1015
	// MpLimitAndEnemyPower - 十字架
	MpLimitAndEnemyPower uint32 = 1016
	// MpLimitAndNoGold - 竹篮
	MpLimitAndNoGold uint32 = 1017
	// MpLimitAndNoPotion - 漏斗
	MpLimitAndNoPotion uint32 = 1018
	// MpLimitAndRandomCurseWhenOpenTreasure - 钥匙
	MpLimitAndRandomCurseWhenOpenTreasure uint32 = 1019
	// HurtPlusAfterHurt - 餐叉
	HurtPlusAfterHurt uint32 = 1020
	// HurtSubAfterBeHurt - 龟壳
	HurtSubAfterBeHurt uint32 = 1021
	// BlockAfterRound - 金属锭
	BlockAfterRound uint32 = 1022
	// RandomHurtBeforeRound - 苦无
	RandomHurtBeforeRound uint32 = 1023
	// AllHurtBeforeRound - 手里剑
	AllHurtBeforeRound uint32 = 1024
	// RandomElectricityBeforeRound - 磁铁
	RandomElectricityBeforeRound uint32 = 1025
	// AddMpAfterFirstBeHurt - 双螺旋
	AddMpAfterFirstBeHurt uint32 = 1026
	// HurtAllAfterFirstBeHurt - 定时炸弹
	HurtAllAfterFirstBeHurt uint32 = 1027
	// GiveCardAfterFirstBeHurt - 镊子
	GiveCardAfterFirstBeHurt uint32 = 1028
	// AddAgilityAfterFirstBeHurt - 香蕉皮
	AddAgilityAfterFirstBeHurt uint32 = 1029
	// AddPowerAfterFirstBuHurt - 兴奋剂
	AddPowerAfterFirstBuHurt uint32 = 1030
	// AllEasyToHurtAfterFirstBeHurt - 铁蒺藜
	AllEasyToHurtAfterFirstBeHurt uint32 = 1031
	// AllAttackPowerlessAfterFirstBeHurt - 杀虫剂
	AllAttackPowerlessAfterFirstBeHurt uint32 = 1032
	// AllElectricityAfterFirstBeHurt - 电棍
	AllElectricityAfterFirstBeHurt uint32 = 1033
	// RecoverHpAfterKillEnemy - 滴血犬齿
	RecoverHpAfterKillEnemy uint32 = 1034
	// RecoverMpAfterKillEnemy - 提灯
	RecoverMpAfterKillEnemy uint32 = 1035
	// GiveCardAfterKillEnemy - 战旗
	GiveCardAfterKillEnemy uint32 = 1036
	// AllEasyToHurtAfterKillEnemy - 威吓之瞳
	AllEasyToHurtAfterKillEnemy uint32 = 1037
	// AllPowerlessAfterKillEnemy - 威慑之瞳
	AllPowerlessAfterKillEnemy uint32 = 1038
	// AllElectricityAfterKillEnemy - 雷霆之锤
	AllElectricityAfterKillEnemy uint32 = 1039
	// FixEnemyEasyToHurt - 蛙
	FixEnemyEasyToHurt uint32 = 1040
	// FixEnemyAttackPowerless - 蝉
	FixEnemyAttackPowerless uint32 = 1041
	// FixSelfEasyToHurt - 菇
	FixSelfEasyToHurt uint32 = 1042
	// FixSelfAttackPowerLess - 蒜
	FixSelfAttackPowerLess uint32 = 1043
	// AddMpAfterHpUnderPercent - 陀螺
	AddMpAfterHpUnderPercent uint32 = 1044
	// RecoverHpAfterBattlePlus - 烤肉
	RecoverHpAfterBattlePlus uint32 = 1045
	// RandomCardLvUp - 铁砧
	RandomCardLvUp uint32 = 2001
	// GetGold - $符号
	GetGold uint32 = 2002
	// HpLimit1 - 热带鱼
	HpLimit1 uint32 = 2003
	// HpLimit2 - 章鱼仔
	HpLimit2 uint32 = 2004
	// HpLimit3 - 珍珠贝
	HpLimit3 uint32 = 2005
	// HpLimitAndCurse - 神之触手
	HpLimitAndCurse uint32 = 2006
	// EliteDropRelic - 骷髅
	EliteDropRelic uint32 = 2007
	// MoreCardAfterRecoverHpInRest - 渔网
	MoreCardAfterRecoverHpInRest uint32 = 2008
	// SelectPowerCardBeforeBattle - 瓶装闪电
	SelectPowerCardBeforeBattle uint32 = 2009
	// SelectAttackCardBeforeBattle - 瓶装火焰
	SelectAttackCardBeforeBattle uint32 = 2010
	// SelectSkillCardBeforeBattle - 瓶装闪电
	SelectSkillCardBeforeBattle uint32 = 2011
	// SelectPotions - 试管架
	SelectPotions uint32 = 2012
	// SelectCards - 原子模型
	SelectCards uint32 = 2013
	// MoreHpAfterResurgence - 珠串
	MoreHpAfterResurgence uint32 = 2014
	// SelectCardLvUpAfterResurgence - 铁锹
	SelectCardLvUpAfterResurgence uint32 = 2015
	// AddPotionAfterResurgence - 陪葬瓮
	AddPotionAfterResurgence uint32 = 2016
	// AddCardAfterResurgence - 首饰盒
	AddCardAfterResurgence uint32 = 2017
)

// Relic struct - describe one relic status
type Relic struct {
	TypeID       uint32
	IsExist      bool
	Param        uint32
	SelectCard   []card.Card
	SelectPotion []potion.Potion
}

// New - create a new Relic
func New(relicTypeID uint32) (Relic, error) {
	_, ok := csv.RemainsMap[int64(relicTypeID)]
	if !ok {
		return Relic{}, fmt.Errorf("relic config not found, relic type id: %d", relicTypeID)
	}
	return Relic{
		TypeID: relicTypeID,
		Param:  0,
	}, nil
}

// GetRelicBasic - get relic config
func GetRelicBasic(relicTypeID uint32) (configParam1, configParam2, configParam3 int, ok bool) {
	rlc, isExist := csv.RemainsMap[int64(relicTypeID)]
	if !isExist {
		log.Error().Msgf("relic config not found, relic type id: %d", relicTypeID)
		return
	}
	configParam1 = rlc.Param1
	configParam2 = rlc.Param2
	configParam3 = rlc.Param3
	ok = true
	return
}

// ToClientProto convert Relic struct to BattleRelicsInfo
func (relicOne Relic) ToClientProto() *pb.BattleRelicsInfo {
	if relicOne.IsExist == false {
		return nil
	}
	return &pb.BattleRelicsInfo{
		RelicsTypeId: &relicOne.TypeID,
		Param:        &relicOne.Param,
	}
}

// ToRdsRelicProto convert Relic struct to RdsRelic
func (relicOne *Relic) ToRdsRelicProto() *rds.RdsRelic {
	selectCard := []*rds.RdsCard{}
	for _, cardOne := range relicOne.SelectCard {
		selectCard = append(selectCard, cardOne.ToRdsCardProto())
	}
	selectPotion := []uint32{}
	for _, potionID := range relicOne.SelectPotion {
		selectPotion = append(selectPotion, potionID.ToClientProto())
	}
	return &rds.RdsRelic{
		TypeID:       relicOne.TypeID,
		IsExist:      relicOne.IsExist,
		Param:        relicOne.Param,
		SelectCard:   selectCard,
		SelectPotion: selectPotion,
	}
}

// FromRdsRelicProto convert Relic struct from RdsRelic
func FromRdsRelicProto(r *rds.RdsRelic) Relic {
	selectCard := []card.Card{}
	for _, rdsCard := range r.GetSelectCard() {
		selectCard = append(selectCard, card.FromRdsCardProto(rdsCard))
	}
	selectPotion := []potion.Potion{}
	for _, rdsPotion := range r.GetSelectPotion() {
		selectPotion = append(selectPotion, potion.Potion(rdsPotion))
	}
	return Relic{
		TypeID:       r.TypeID,
		IsExist:      r.IsExist,
		Param:        r.Param,
		SelectCard:   selectCard,
		SelectPotion: selectPotion,
	}
}
