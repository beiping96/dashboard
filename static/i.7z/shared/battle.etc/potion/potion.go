package potion

// Potion type id
type Potion uint32

// ToClientProto convert Potion to uint32
func (potionOne Potion) ToClientProto() uint32 {
	return uint32(potionOne)
}
