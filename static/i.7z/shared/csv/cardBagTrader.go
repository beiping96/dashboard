package csv

type TableCardBagTrader struct {
	ID int
	Type int
	ConvertType int
	ConvertNum int
	ShopType int
	ShopPam int
	IsLimit int
	LimitNum int
}
var TableCardBagTraderMap = map[int64] *TableCardBagTrader{
	1:&TableCardBagTrader{1,1,1,250,2,1001,0,0},
	2:&TableCardBagTrader{2,1,1,750,2,1002,0,0},
	3:&TableCardBagTrader{3,1,1,2500,2,1003,0,0},
	4:&TableCardBagTrader{4,2,1,300,2,1004,1,3},
}
