package csv

type MapNodeConfig struct {
	TypeId int
	NodeName string
	Describe string
	Icon string
	FloorIcon string
}
var MapNodeConfigMap = map[int64] *MapNodeConfig{
	1:&MapNodeConfig{1,"最终BOSS","","300005","UIImage/Checkpoint/Checkpoint"},
	2:&MapNodeConfig{2,"精英怪","","300001","UIImage/Checkpoint/Checkpoint"},
	3:&MapNodeConfig{3,"普通怪","","300002","UIImage/Checkpoint/Checkpoint"},
	4:&MapNodeConfig{4,"商店","","300008","UIImage/Checkpoint/Checkpoint"},
	5:&MapNodeConfig{5,"篝火","","300004","UIImage/Checkpoint/Checkpoint"},
	6:&MapNodeConfig{6,"宝箱","","300003","UIImage/Checkpoint/Checkpoint"},
	7:&MapNodeConfig{7,"未知类型","","300007","UIImage/Checkpoint/Checkpoint"},
}
