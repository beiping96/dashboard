package csv

type TableCardBagDrop struct {
	CardBagID int
	DropPercent int
	MinDebrisNum int
	MaxDebrisNum int
	MinPieceNum int
	MaxPieceNum int
	DropGroup int
}
var TableCardBagDropMap = map[int64] *TableCardBagDrop{
	1:&TableCardBagDrop{1,0,1,1,1,1,1},
	2:&TableCardBagDrop{2,100,1,1,1,1,1},
	3:&TableCardBagDrop{3,10000,1,1,1,1,1},
	4:&TableCardBagDrop{4,0,1,1,1,1,1},
	5:&TableCardBagDrop{5,0,1,1,1,1,1},
	6:&TableCardBagDrop{6,100,1,1,1,1,1},
	7:&TableCardBagDrop{7,10000,10,12,1,1,2},
	8:&TableCardBagDrop{8,10000,30,36,1,2,2},
	9:&TableCardBagDrop{9,10000,100,120,2,3,2},
	10:&TableCardBagDrop{10,10000,1,1,1,1,2},
	11:&TableCardBagDrop{11,10000,2,5,1,1,2},
	12:&TableCardBagDrop{12,10000,10,15,1,1,2},
	13:&TableCardBagDrop{13,10000,48,50,1,1,3},
	14:&TableCardBagDrop{14,10000,143,150,2,4,3},
	15:&TableCardBagDrop{15,10000,479,500,1,2,3},
	16:&TableCardBagDrop{16,10000,10,10,1,1,3},
	17:&TableCardBagDrop{17,10000,22,25,1,1,3},
	18:&TableCardBagDrop{18,10000,45,59,1,1,3},
	99:&TableCardBagDrop{99,0,1,1,1,1,3},
}
