﻿package csv

type Monster struct {
	ID int
	Property_ID int
	Monster_Name string
	Head_Icon string
	Head_Bar_Height int
	Death_sound int
	AI_ID int
	Phase2_Blood_Per int
	Phase2_AI_ID int
	Main_Prefab string
	Hurt_fx string
	Scale string
	Buff_Height int
}
var MonsterMap = map[int64] *Monster{
	601:&Monster{601,601,"史莱姆","Mon_SLM_001",250,1,6010,0,0,"Actor/Monster/SLJT_Mon_SLM_001","","1.57",-120},
	602:&Monster{602,602,"史莱姆","Mon_SLM_002",250,1,6020,0,0,"Actor/Monster/SLJT_Mon_SLM_002","","1.57",-120},
	603:&Monster{603,603,"史莱姆","Mon_SLM_008",250,1,6030,0,0,"Actor/Monster/SLJT_Mon_SLM_008","","1.57",-120},
	604:&Monster{604,604,"精英史莱姆","Mon_SLM_005",360,1,6040,0,0,"Actor/Monster/SLJT_Mon_SLM_005","","2.4",-150},
	605:&Monster{605,605,"冰蝠魔","Mon_BF_001",350,1,6050,0,0,"Actor/Monster/SLJT_Mon_BF_001","","1.57",-50},
	606:&Monster{606,606,"电蝠魔","Mon_BF_002",350,1,6060,0,0,"Actor/Monster/SLJT_Mon_BF_002","","1.57",-50},
	607:&Monster{607,607,"火蝠魔","Mon_BF_003",350,1,6070,0,0,"Actor/Monster/SLJT_Mon_BF_003","","1.57",-50},
	608:&Monster{608,608,"紫色甲壳虫","Mon_STG_002",520,1,6080,0,0,"Actor/Monster/SLJT_Mon_STG_002","","1.57",-100},
	609:&Monster{609,609,"蓝色甲壳虫","Mon_STG_001",520,1,6090,0,0,"Actor/Monster/SLJT_Mon_STG_001","","1.57",-100},
	610:&Monster{610,610,"橙色甲壳虫","Mon_STG_003",520,1,6100,0,0,"Actor/Monster/SLJT_Mon_STG_003","","1.57",-100},
	611:&Monster{611,611,"紫色龙虾","Mon_LXG_003",520,1,6110,0,0,"Actor/Monster/SLJT_Mon_LXG_002","","1.57",-100},
	612:&Monster{612,612,"蓝色龙虾","Mon_LXG_003",520,1,6120,0,0,"Actor/Monster/SLJT_Mon_LXG_001","","1.57",-100},
	613:&Monster{613,613,"红色龙虾","Mon_LXG_003",520,1,6130,0,0,"Actor/Monster/SLJT_Mon_LXG_003","","1.57",-100},
	614:&Monster{614,614,"独眼怪紫","Mon_DuYanGuai_001",600,1,6140,0,0,"Actor/Monster/SLJT_Mon_DuYanGuai_001","","1.57",-150},
	615:&Monster{615,615,"独眼怪蓝","Mon_DuYanGuai_003",600,1,6150,0,0,"Actor/Monster/SLJT_Mon_DuYanGuai_003","","1.57",-150},
	616:&Monster{616,616,"独眼怪红","Mon_DuYanGuai_004",600,1,6160,0,0,"Actor/Monster/SLJT_Mon_DuYanGuai_004","","1.57",-150},
	617:&Monster{617,617,"螃蟹炮","Mon_SZPTC_003",400,1,6170,0,0,"Actor/Monster/SLJT_Mon_SZPTC_003","","1.57",-150},
	618:&Monster{618,618,"螃蟹炮","Mon_SZPTC_003",400,1,6180,0,0,"Actor/Monster/SLJT_Mon_SZPTC_003","","1.57",-150},
	619:&Monster{619,619,"重装河豚","Boss_HTYH_002",600,1,6190,0,0,"Actor/Monster/SLJT_Boss_HTYH_001","","0.9",-100},
	620:&Monster{620,620,"蜘蛛女王","Boss_ZZNW_001",750,1,6200,0,0,"Actor/Monster/SLJT_Boss_ZZNW_001","","0.8",-100},
	621:&Monster{621,621,"玛格纳","Boss_Mengma_001",750,1,6210,50,6211,"Actor/Monster/SLJT_Boss_Mengma_001","","0.75",-100},
	622:&Monster{622,622,"火枪手","Mon_HuoQiangShou_003",560,1,6220,0,0,"Actor/Monster/SLJT_Mon_HuoQiangShou_003","","1.57",-100},
	623:&Monster{623,623,"火枪手","Mon_HuoQiangShou_001",560,1,6230,0,0,"Actor/Monster/SLJT_Mon_HuoQiangShou_001","","1.57",-100},
	624:&Monster{624,624,"火枪手","Mon_HuoQiangShou_002",560,1,6240,0,0,"Actor/Monster/SLJT_Mon_HuoQiangShou_002","","1.57",-100},
	625:&Monster{625,625,"绿蛤蟆","Mon_HMG_001",500,1,6251,0,0,"Actor/Monster/SLJT_Mon_HMG_001","","0.8",-120},
	626:&Monster{626,626,"蓝蛤蟆","Mon_HMG_002",500,1,6260,0,0,"Actor/Monster/SLJT_Mon_HMG_002","","0.8",-120},
	627:&Monster{627,627,"红蛤蟆","Mon_HMG_003",500,1,6271,50,6272,"Actor/Monster/SLJT_Mon_HMG_003","","0.8",-120},
	628:&Monster{628,628,"绿蛤蟆","Mon_XHM_001",250,1,6280,0,0,"Actor/Monster/SLJT_Mon_XHM_001","","1",-100},
	629:&Monster{629,629,"蓝蛤蟆","Mon_XHM_002",250,1,6290,0,0,"Actor/Monster/SLJT_Mon_XHM_002","","1",-100},
	630:&Monster{630,630,"红蛤蟆","Mon_XHM_003",250,1,6300,0,0,"Actor/Monster/SLJT_Mon_XHM_003","","1",-100},
	631:&Monster{631,631,"虚空魔眼","noname_01",650,1,6310,0,0,"Actor/Monster/SLJT_Mon_PDFS_001","","1",-120},
	632:&Monster{632,632,"虚空魔眼","noname_01",650,1,6320,0,0,"Actor/Monster/SLJT_Mon_PDFS_002","","1",-120},
	633:&Monster{633,633,"虚空魔眼","noname_01",650,1,6330,0,0,"Actor/Monster/SLJT_Mon_PDFS_003","","1",-120},
	634:&Monster{634,634,"石头脸","noname_01",500,1,6340,0,0,"Actor/Monster/SLJT_Mon_SLM_001","","1.57",-100},
	635:&Monster{635,635,"鲨鱼怪","noname_01",500,1,6350,0,0,"Actor/Monster/SLJT_Mon_SLM_001","","1.57",-100},
	636:&Monster{636,636,"长手怪","noname_01",800,1,6360,50,6361,"Actor/Monster/SLJT_Boss_JM_001","","1",-200},
	637:&Monster{637,637,"鲨鱼","noname_01",700,1,6370,0,0,"Actor/Monster/SLJT_Boss_SYQSS_001_yu","","0.8",0},
	638:&Monster{638,638,"猴子","noname_01",560,1,6381,0,0,"Actor/Monster/SLJT_Boss_SYQSS_001","","1",-100},
	639:&Monster{639,639,"浮游炮","noname_01",350,1,6390,0,0,"Actor/Monster/SLJT_Boss_SYQSS_001_qiu","","1",-50},
	640:&Monster{640,640,"铠魔","noname_01",750,1,6400,0,6401,"Actor/Monster/SLJT_Boss_ZZDS_001","","1",-120},
	641:&Monster{641,641,"多面魔","noname_01",500,1,6410,0,0,"Actor/Monster/SLJT_Mon_SLM_001","","1.57",-100},
	642:&Monster{642,642,"魔石怪","noname_01",500,1,6420,0,0,"Actor/Monster/SLJT_Mon_SSG_001","","1.57",-100},
	643:&Monster{643,643,"螃蟹炮","Mon_SZPTC_001",400,1,6430,0,0,"Actor/Monster/SLJT_Mon_SZPTC_001","","1.57",-150},
	644:&Monster{644,644,"螃蟹炮","Mon_SZPTC_002",400,1,6440,0,0,"Actor/Monster/SLJT_Mon_SZPTC_002","","1.57",-150},
}
