﻿package csv

type TableCardGoods struct {
	ID int
	Type int
	Number int
	ConvertType int
	ConvertNum int
	CommodityType int
}
var TableCardGoodsMap = map[int64] *TableCardGoods{
	1:&TableCardGoods{1,1,20,2,1000,1},
	2:&TableCardGoods{2,1,40,2,2000,1},
	3:&TableCardGoods{3,1,60,2,3000,1},
	4:&TableCardGoods{4,2,5,2,5000,1},
	5:&TableCardGoods{5,2,5,1,300,1},
	6:&TableCardGoods{6,2,10,1,500,1},
	7:&TableCardGoods{7,3,1,2,20000,1},
	8:&TableCardGoods{8,1,200,2,0,2},
	9:&TableCardGoods{9,1,500,2,0,2},
	10:&TableCardGoods{10,1,1,2,0,1},
}
