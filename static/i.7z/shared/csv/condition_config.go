﻿package csv

type ConditionConfig struct {
	ID int
	conditionType int
	defaultDes string
	Param1 string
	Param2 string
	Param3 string
	Param4 string
}
var ConditionConfigMap = map[int64] *ConditionConfig{
	1:&ConditionConfig{1,0,"该卡牌不能被打出","","","",""},
	2:&ConditionConfig{2,1,"该卡牌不能被打出","","","",""},
	3:&ConditionConfig{3,2,"该卡牌不能被打出","","","",""},
	4:&ConditionConfig{4,3,"该卡牌不能被打出","","","",""},
	5:&ConditionConfig{5,4,"该卡牌不能被打出","","","",""},
	6:&ConditionConfig{6,5,"该卡牌不能被打出","","","",""},
	7:&ConditionConfig{7,6,"该卡牌不能被打出","","","",""},
}
