﻿package csv

type TableCardShop struct {
	ID int
	Type int
	TypeSort int
	Product1 int
	Product2 int
	Product3 int
	Product4 int
	Product5 int
	Product6 int
	SubProduct1 int
	SubProduct2 int
	SubProduct3 int
}
var TableCardShopMap = map[int64] *TableCardShop{
	1:&TableCardShop{1,1,1,8,1,1,2,3,4,3,3,3},
	2:&TableCardShop{2,1,1,8,1,2,3,4,5,3,3,3},
	3:&TableCardShop{3,1,1,8,1,2,4,5,6,3,3,3},
	4:&TableCardShop{4,1,1,8,2,2,3,4,5,3,3,3},
	5:&TableCardShop{5,1,1,8,1,2,3,4,6,3,3,3},
	6:&TableCardShop{6,1,1,8,1,2,3,4,7,3,3,3},
	7:&TableCardShop{7,1,1,8,1,2,2,3,5,3,3,3},
	8:&TableCardShop{8,1,1,8,1,2,3,4,6,3,3,3},
	9:&TableCardShop{9,1,1,8,1,2,2,3,4,3,3,3},
	10:&TableCardShop{10,1,1,8,1,1,2,3,5,3,3,3},
	11:&TableCardShop{11,2,3,9,2,3,4,5,7,3,3,3},
	12:&TableCardShop{12,2,3,9,2,3,5,6,7,3,3,3},
	13:&TableCardShop{13,2,3,9,2,3,4,6,7,3,3,3},
	14:&TableCardShop{14,2,3,9,2,3,4,5,7,3,3,3},
	15:&TableCardShop{15,2,3,9,2,3,5,6,7,3,3,3},
	16:&TableCardShop{16,2,3,9,2,3,4,6,7,3,3,3},
}
