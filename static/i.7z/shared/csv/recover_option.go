﻿package csv

type RecoverOption struct {
	ID int
	Weight int
	Cost int
	Desc string
}
var RecoverOptionMap = map[int64] *RecoverOption{
	1:&RecoverOption{1,10,100,"复活后，当前生命恢复至满"},
	2:&RecoverOption{2,10,100,"复活后，随机升级3张牌库内的卡牌"},
	3:&RecoverOption{3,10,100,"复活后，随机获得刻印一个"},
	4:&RecoverOption{4,10,100,"复活后，随机获得3瓶药水"},
	5:&RecoverOption{5,10,100,"复活后，下次战斗获得2点力量加成"},
	6:&RecoverOption{6,10,100,"复活后，下次战斗开始时获得2点能量多抽2张卡"},
}
