package csv

type PotionDropGroup struct {
	ID int
	Group_ID int
	Potion_ID int
	Weight int
}
var PotionDropGroupMap = map[int64] *PotionDropGroup{
	1:&PotionDropGroup{1,1,11,100},
	2:&PotionDropGroup{2,1,12,100},
	3:&PotionDropGroup{3,1,13,100},
	4:&PotionDropGroup{4,1,14,100},
	5:&PotionDropGroup{5,1,15,100},
	6:&PotionDropGroup{6,1,16,100},
	7:&PotionDropGroup{7,1,17,100},
	8:&PotionDropGroup{8,1,18,100},
	9:&PotionDropGroup{9,1,19,100},
	10:&PotionDropGroup{10,1,20,100},
	11:&PotionDropGroup{11,1,21,100},
	12:&PotionDropGroup{12,1,22,100},
	13:&PotionDropGroup{13,1,23,100},
}
