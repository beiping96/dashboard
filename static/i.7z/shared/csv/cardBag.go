package csv

type TableCardBag struct {
	CardBagID int
	ResourceType int
	NeedKey int
	MinResource int
	MaxResource int
	DebrisSum int
	PieceSum int
	GoodsA int
	GoodsB int
	GoodsC int
	GoodsD int
	RareCardMin int
	LegendCardMin int
}
var TableCardBagMap = map[int64] *TableCardBag{
	1001:&TableCardBag{1001,2,0,750,800,60,2,1,7,99,13,10,1},
	1002:&TableCardBag{1002,2,0,2250,2450,180,5,2,8,99,14,30,1},
	1003:&TableCardBag{1003,2,0,7500,8200,600,5,3,9,99,15,100,1},
	1004:&TableCardBag{1004,1,0,100,100,100,2,1,1,1,1,0,0},
	1005:&TableCardBag{1005,2,2,150,160,11,2,4,10,99,16,1,0},
	1006:&TableCardBag{1006,2,3,450,480,27,2,5,11,99,17,2,0},
	1007:&TableCardBag{1007,2,3,900,960,60,2,6,12,99,18,10,1},
}
