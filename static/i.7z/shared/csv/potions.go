package csv

type TablePotions struct {
	ID int
	Name string
	Icon string
	Price int
	Desc string
	Potions_Target int
	Effect_IDs string
	Common_Skill_Script int
	Forward_Time int
	Back_Time int
	Action_Name string
	Play_Effect string
	Play_Effect_Point string
	Play_Effect_Duration int
	Entries string
}
var TablePotionsMap = map[int64] *TablePotions{
	11:&TablePotions{11,"生命药剂","000001",75,"回复10点生命",3,"111",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,""},
	12:&TablePotions{12,"爆炸药剂","000001",75,"对全体敌人造成10点伤害",2,"121",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,""},
	13:&TablePotions{13,"护盾药剂","000002",75,"获得12点格挡",3,"131",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"1"},
	14:&TablePotions{14,"荆棘药剂","000002",75,"获得3点荆棘",3,"141",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"30"},
	15:&TablePotions{15,"闪电药剂","000002",75,"给予3层感电",1,"151",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"25"},
	16:&TablePotions{16,"火焰药剂","000003",75,"给予6层燃烧",1,"161",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"24"},
	17:&TablePotions{17,"冰冻药剂","000003",75,"给予3层冰冻",1,"171",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"26"},
	18:&TablePotions{18,"虚弱药剂","000003",75,"给予3层脆弱",1,"181",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"27"},
	19:&TablePotions{19,"腐蚀药剂","000003",75,"给予3层易伤",1,"191",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"28"},
	20:&TablePotions{20,"愤怒药剂","000004",75,"获得3点愤怒",3,"201",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"23"},
	21:&TablePotions{21,"秘法药剂","000004",75,"抽2张牌",3,"211",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,""},
	22:&TablePotions{22,"强壮药剂","000004",75,"获得2点力量",3,"221",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"21"},
	23:&TablePotions{23,"能量药剂","000004",75,"获得2点能量",3,"231",1,500,500,"attack","FX/skill_Asssasin_atk1","point_ground",800,"2"},
}
