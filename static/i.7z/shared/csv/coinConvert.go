﻿package csv

type TableCoinConvert struct {
	ID int
	Describe string
	NeedGem int
	ConvertCoinNum int
	Icon string
}
var TableCoinConvertMap = map[int64] *TableCoinConvert{
	1:&TableCoinConvert{1,"Pouch of Gold",60,1000,"Icon/PropIcon/Shop_gold_01"},
	2:&TableCoinConvert{2,"Bucket of Gold",500,10000,"Icon/PropIcon/Shop_gold_02"},
	3:&TableCoinConvert{3,"Wagon of Gold",4500,100000,"Icon/PropIcon/Shop_gold_03"},
}
