package csv

type StageEventRandom struct {
	Event_ID int
	Min_Floor int
	Max_Floor int
	Stage_Level int
	Weight int
	Repeat int
}
var StageEventRandomMap = map[int64] *StageEventRandom{
	10001:&StageEventRandom{10001,1,20,1,50,0},
	10101:&StageEventRandom{10101,1,20,1,50,0},
	10201:&StageEventRandom{10201,1,20,1,50,0},
	10301:&StageEventRandom{10301,1,20,1,50,0},
	10401:&StageEventRandom{10401,1,20,1,50,0},
	10501:&StageEventRandom{10501,1,20,1,50,0},
	10601:&StageEventRandom{10601,1,20,1,50,0},
	10801:&StageEventRandom{10801,1,20,1,50,0},
	20001:&StageEventRandom{20001,1,20,2,50,0},
	20101:&StageEventRandom{20101,1,20,2,50,0},
	20201:&StageEventRandom{20201,1,20,2,50,0},
	20301:&StageEventRandom{20301,1,20,2,50,0},
	20401:&StageEventRandom{20401,1,20,2,50,0},
	20501:&StageEventRandom{20501,1,20,2,50,0},
	20601:&StageEventRandom{20601,1,20,2,50,0},
	20701:&StageEventRandom{20701,1,20,2,50,0},
	20801:&StageEventRandom{20801,1,20,2,50,0},
	20901:&StageEventRandom{20901,1,20,2,50,0},
	21001:&StageEventRandom{21001,1,20,2,50,0},
	30001:&StageEventRandom{30001,1,20,0,50,1},
	30101:&StageEventRandom{30101,1,20,3,50,0},
	30201:&StageEventRandom{30201,1,20,3,50,0},
	30301:&StageEventRandom{30301,1,20,3,50,0},
	40001:&StageEventRandom{40001,1,20,0,50,1},
	40101:&StageEventRandom{40101,1,20,0,50,1},
}
