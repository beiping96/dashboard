package csv

type StageInitEvent struct {
	ID int
	Effect_ID int
	Career_Limited int
	Weight int
	Desc string
}
var StageInitEventMap = map[int64] *StageInitEvent{
	1:&StageInitEvent{1,101,0,10,"初始刻印替换为一个boss刻印"},
	2:&StageInitEvent{2,102,0,10,"随机升级2张卡牌"},
	3:&StageInitEvent{3,103,0,10,"获得一张稀有卡牌"},
	4:&StageInitEvent{4,104,0,10,"获得100奥金"},
	5:&StageInitEvent{5,105,0,10,"获得一个随机刻印"},
	6:&StageInitEvent{6,106,0,10,"获得3瓶药水"},
	7:&StageInitEvent{7,107,0,10,"获得2张通用卡牌"},
}
