package csv

type BasicDrop struct {
	Drop_From int
	Drop_1 int
	Drop_2 int
	Drop_3 int
	Drop_4 int
	Drop_5 int
	Drop_6 int
}
var BasicDropMap = map[int64] *BasicDrop{
	3:&BasicDrop{3,1,2,4,0,0,0},
	2:&BasicDrop{2,1,2,3,4,0,0},
	1:&BasicDrop{1,1,2,3,4,0,0},
	6:&BasicDrop{6,1,3,0,0,0,0},
}
