﻿package csv

type StageDifficulty struct {
	ID int
	Mode int
	Difficulty int
	Reward_1 int
	Reward_2 int
	Reward_3 int
	Monster_Desc string
	Elite_Desc string
	Boss_Desc string
	Other_Desc string
}
var StageDifficultyMap = map[int64] *StageDifficulty{
	1:&StageDifficulty{1,1,1,1,2,3,"小怪描述难度1","精英描述难度1","Boss描述难度1",""},
	2:&StageDifficulty{2,1,2,1,2,3,"小怪描述难度2","精英描述难度2","Boss描述难度2",""},
}
