﻿package csv

type TableSound struct {
	EventName string
	Source string
	Volume int
}
var TableSoundMap = map[string] *TableSound{
	"Login":&TableSound{"Login","BGM/login",30},
	"Theme":&TableSound{"Theme","BGM/Theme",30},
	"HeroSelect":&TableSound{"HeroSelect","BGM/select",30},
	"Chapter":&TableSound{"Chapter","BGM/chapter",30},
	"Battle_01":&TableSound{"Battle_01","BGM/Battle_01",30},
	"Battle_02":&TableSound{"Battle_02","BGM/Battle_02",30},
	"Battle_03":&TableSound{"Battle_03","BGM/Battle_03",30},
	"Battle_BOSS_01":&TableSound{"Battle_BOSS_01","BGM/Battle_BOSS_01",30},
	"Battle_BOSS_02":&TableSound{"Battle_BOSS_02","BGM/Battle_BOSS_02",30},
	"Lose":&TableSound{"Lose","BGM/lose",30},
	"Win":&TableSound{"Win","BGM/win",30},
	"CardBagBoom":&TableSound{"CardBagBoom","UI/card_bag_boom",100},
	"Click":&TableSound{"Click","UI/click",100},
	"GameStart":&TableSound{"GameStart","UI/game_start",100},
	"MpFly":&TableSound{"MpFly","UI/mp_fly",100},
	"Block":&TableSound{"Block","Skill/block",100},
	"WarriorTargetLong":&TableSound{"WarriorTargetLong","Skill/target_long",100},
	"WarriorTargetShort":&TableSound{"WarriorTargetShort","Skill/target_short",100},
	"WarriorBlunt":&TableSound{"WarriorBlunt","Skill/blunt",100},
	"WizardThunderAttack":&TableSound{"WizardThunderAttack","Skill/thunder_attack",100},
	"WizardFireAttack":&TableSound{"WizardFireAttack","Skill/fire_attack",100},
	"WizardIceAttack":&TableSound{"WizardIceAttack","Skill/ice_attack",100},
}
