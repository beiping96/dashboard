package csv

type LevelMonster struct {
	ID int
	MonsterGroupType int
	Min_Floor int
	Max_Floor int
	Level_Config int
	Scene_Path string
	Monster1_ID int
	Monster1_Pos int
	Monster2_ID int
	Monster2_Pos int
	Monster3_ID int
	Monster3_Pos int
	Monster4_ID int
	Monster4_Pos int
}
var LevelMonsterMap = map[int64] *LevelMonster{
	1:&LevelMonster{1,3,1,8,1,"Scene_01",601,2,0,0,0,0,0,0},
	2:&LevelMonster{2,3,1,8,1,"Scene_02",602,2,0,0,0,0,0,0},
	3:&LevelMonster{3,3,1,8,1,"Scene_03",607,2,0,0,0,0,0,0},
	4:&LevelMonster{4,3,1,8,1,"Scene_04",608,2,0,0,0,0,0,0},
	5:&LevelMonster{5,3,1,8,1,"Scene_01",611,2,0,0,0,0,0,0},
	6:&LevelMonster{6,3,8,15,1,"Scene_02",622,2,0,0,0,0,0,0},
	7:&LevelMonster{7,3,8,15,1,"Scene_03",623,2,0,0,0,0,0,0},
	8:&LevelMonster{8,3,8,15,1,"Scene_04",601,1,602,3,0,0,0,0},
	9:&LevelMonster{9,3,8,15,1,"Scene_01",608,1,608,3,0,0,0,0},
	10:&LevelMonster{10,3,12,15,1,"Scene_02",601,1,622,3,0,0,0,0},
	11:&LevelMonster{11,3,12,15,1,"Scene_03",602,1,623,3,0,0,0,0},
	12:&LevelMonster{12,3,12,15,1,"Scene_04",601,1,607,3,0,0,0,0},
	13:&LevelMonster{13,3,12,15,1,"Scene_01",602,1,611,3,0,0,0,0},
	14:&LevelMonster{14,2,1,15,1,"Scene_02",604,5,0,0,0,0,0,0},
	15:&LevelMonster{15,2,1,15,1,"Scene_03",618,1,617,2,618,3,0,0},
	16:&LevelMonster{16,2,1,15,1,"Scene_04",614,5,0,0,0,0,0,0},
	17:&LevelMonster{17,1,16,16,1,"Scene_01",619,5,0,0,0,0,0,0},
	18:&LevelMonster{18,1,16,16,1,"Scene_02",620,5,0,0,0,0,0,0},
	19:&LevelMonster{19,1,16,16,1,"Scene_03",621,5,0,0,0,0,0,0},
	20:&LevelMonster{20,3,1,5,2,"Scene_01",609,2,0,0,0,0,0,0},
	21:&LevelMonster{21,3,1,5,2,"Scene_02",612,2,0,0,0,0,0,0},
	22:&LevelMonster{22,3,1,5,2,"Scene_03",631,2,0,0,0,0,0,0},
	23:&LevelMonster{23,3,5,15,2,"Scene_04",605,1,605,2,605,3,0,0},
	24:&LevelMonster{24,3,5,15,2,"Scene_01",607,1,607,2,607,3,0,0},
	25:&LevelMonster{25,3,5,15,2,"Scene_02",610,2,0,0,0,0,0,0},
	26:&LevelMonster{26,3,5,15,2,"Scene_03",631,1,607,3,0,0,0,0},
	27:&LevelMonster{27,3,5,15,2,"Scene_04",631,1,605,3,0,0,0,0},
	28:&LevelMonster{28,3,5,15,2,"Scene_01",609,1,605,3,0,0,0,0},
	29:&LevelMonster{29,3,5,15,2,"Scene_02",610,1,623,3,0,0,0,0},
	30:&LevelMonster{30,2,1,15,2,"Scene_03",622,1,624,2,623,3,0,0},
	31:&LevelMonster{31,2,1,15,2,"Scene_04",615,5,0,0,0,0,0,0},
	32:&LevelMonster{32,2,1,15,2,"Scene_01",628,1,625,2,0,0,0,0},
	33:&LevelMonster{33,1,16,16,2,"Scene_02",636,5,0,0,0,0,0,0},
	34:&LevelMonster{34,1,16,16,2,"Scene_03",637,1,638,2,0,0,0,0},
	35:&LevelMonster{35,3,1,10,3,"Scene_01",632,2,0,0,0,0,0,0},
	36:&LevelMonster{36,3,1,10,3,"Scene_02",644,2,0,0,0,0,0,0},
	37:&LevelMonster{37,3,1,10,3,"Scene_03",613,2,0,0,0,0,0,0},
	38:&LevelMonster{38,3,1,10,3,"Scene_04",609,1,609,3,0,0,0,0},
	39:&LevelMonster{39,3,1,10,3,"Scene_01",630,1,627,2,0,0,0,0},
	40:&LevelMonster{40,3,1,20,3,"Scene_02",606,1,606,2,606,3,0,0},
	41:&LevelMonster{41,3,10,20,3,"Scene_03",630,1,627,2,630,3,0,0},
	42:&LevelMonster{42,3,10,20,3,"Scene_04",611,1,613,3,0,0,0,0},
	43:&LevelMonster{43,3,10,20,3,"Scene_01",612,1,613,3,0,0,0,0},
	44:&LevelMonster{44,3,10,20,3,"Scene_02",604,1,644,3,0,0,0,0},
	45:&LevelMonster{45,3,10,20,3,"Scene_03",604,1,644,3,0,0,0,0},
	46:&LevelMonster{46,2,1,20,3,"Scene_01",616,5,0,0,0,0,0,0},
	47:&LevelMonster{47,2,1,20,3,"Scene_02",644,1,644,3,0,0,0,0},
	48:&LevelMonster{48,1,21,21,3,"Scene_03",640,5,0,0,0,0,0,0},
}
