﻿package csv

type TableCareerInitialValue struct {
	HeroId int
	Name string
	Icon string
	Career int
	Blood_Height int
	InitMaxBlood int
	InitPower int
	InitGold int
	InitSpeed int
	InitCards string
	InitUnlockCards string
	InitRelic int
	Main_Prefab string
	Scale int
	Attack_fx string
	Hurt_Fx string
	HeroDesc string
	HeroImg string
	HeroIcon string
	BattleHeroIcon string
	MapElementIcon string
}
var TableCareerInitialValueMap = map[int64] *TableCareerInitialValue{
	1:&TableCareerInitialValue{1,"Tina","Icon/HeadIcon/HeadIcon1",1,300,80,3,99,1,"1001,1001,1001,1001,1001,1011,1011,1011,1011,1004","1001,1002,1003,1004,1005,1006,1007,1009,1010,1011,1012,1013,1014,1015,1016,1017,1018,1019,1020,1021,1023,1024,1025,1027,1028,1029,1030,1031,1033,1035,1036,1038,1039,1041,1042,1043,4001,4002,4003,4004,4005,4006,4007,4008,4009,4010,4011,4012,4013",1001,"Actor/Avatar/SLJT_Char_Asssasin_001",147,"FX/skill_Asssasin_atk1","FX/skill_Asssasin_hit","英雄描述1","UIImage/Hero/HeroImg1","Icon/HeadIcon/110001","Icon/HeadIcon/000001","Icon/HeadIcon/00001"},
	2:&TableCareerInitialValue{2,"Ace","Icon/HeadIcon/HeadIcon2",2,300,70,3,120,1,"2001,2001,2001,2001,2001,2002,2002,2002,2002,2015","2001,2002,2003,2004,2005,2007,2009,2010,2011,2012,2013,2014,2015,2017,2018,2019,2020,2022,2023,2024,2025,2026,2027,2028,2029,2030,2031,2033,2034,2036,2037,2039,2041,2042,2043,2045,4001,4002,4003,4004,4005,4006,4007,4008,4009,4010,4011,4012,4013",1002,"Actor/Avatar/SLJT_Char_Caster_001",120,"FX/skill_Asssasin_atk1","FX/skill_Asssasin_hit","英雄描述2","UIImage/Hero/HeroImg2","Icon/HeadIcon/110002","Icon/HeadIcon/000002","Icon/HeadIcon/00002"},
}
