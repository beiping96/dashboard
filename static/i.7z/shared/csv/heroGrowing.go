package csv

type TableHeroGrowing struct {
	ID int
	HeroID int
	HeroStar int
	MaxStar int
	HeroPropID int
	HeroPropNum int
	HeroUpgradeCoin int
	Describe string
	GlobalAttr string
	LocalAttr string
}
var TableHeroGrowingMap = map[int64] *TableHeroGrowing{
	101:&TableHeroGrowing{101,1,1,5,5001,5,500,"","",""},
	102:&TableHeroGrowing{102,1,2,5,5001,30,500,"[自身]初始HP+10","","1"},
	103:&TableHeroGrowing{103,1,3,5,5001,60,1000,"[全局]怪物掉落金币+10%","2","1"},
	104:&TableHeroGrowing{104,1,4,5,5001,90,4000,"[全局]篝火生命恢复+10点","2,3","1"},
	105:&TableHeroGrowing{105,1,5,5,5051,30,8000,"[全局]迷宫复活次数+1","2,3,4","1"},
	201:&TableHeroGrowing{201,2,1,5,5002,5,500,"","",""},
	202:&TableHeroGrowing{202,2,2,5,5002,30,1000,"[全局]初始获得随机药水×1","5",""},
	203:&TableHeroGrowing{203,2,3,5,5002,60,4000,"[自身]商店货物售价-15%","5","6"},
	204:&TableHeroGrowing{204,2,4,5,5002,90,8000,"[全局]药水栏位+1","5,7","6"},
	205:&TableHeroGrowing{205,2,5,5,5052,30,20000,"[自身]地宫视野范围+1","5,7","6,8"},
	301:&TableHeroGrowing{301,3,1,5,5003,5,1000,"","",""},
	302:&TableHeroGrowing{302,3,2,5,5003,30,4000,"未知","",""},
	303:&TableHeroGrowing{303,3,3,5,5003,60,8000,"未知","",""},
	304:&TableHeroGrowing{304,3,4,5,5003,90,20000,"未知","",""},
	305:&TableHeroGrowing{305,3,5,5,5053,30,50000,"未知","",""},
	401:&TableHeroGrowing{401,4,1,5,5003,5,1000,"","",""},
	402:&TableHeroGrowing{402,4,2,5,5003,30,4000,"未知","",""},
	403:&TableHeroGrowing{403,4,3,5,5003,60,8000,"未知","",""},
	404:&TableHeroGrowing{404,4,4,5,5003,90,20000,"未知","",""},
	405:&TableHeroGrowing{405,4,5,5,5053,30,50000,"未知","",""},
	501:&TableHeroGrowing{501,5,1,5,5003,5,1000,"","",""},
	502:&TableHeroGrowing{502,5,2,5,5003,30,4000,"未知","",""},
	503:&TableHeroGrowing{503,5,3,5,5003,60,8000,"未知","",""},
	504:&TableHeroGrowing{504,5,4,5,5003,90,20000,"未知","",""},
	505:&TableHeroGrowing{505,5,5,5,5053,30,50000,"未知","",""},
	601:&TableHeroGrowing{601,6,1,5,5003,5,1000,"","",""},
	602:&TableHeroGrowing{602,6,2,5,5003,30,4000,"未知","",""},
	603:&TableHeroGrowing{603,6,3,5,5003,60,8000,"未知","",""},
	604:&TableHeroGrowing{604,6,4,5,5003,90,20000,"未知","",""},
	605:&TableHeroGrowing{605,6,5,5,5053,30,50000,"未知","",""},
	701:&TableHeroGrowing{701,7,1,5,5003,5,1000,"","",""},
	702:&TableHeroGrowing{702,7,2,5,5003,30,4000,"未知","",""},
	703:&TableHeroGrowing{703,7,3,5,5003,60,8000,"未知","",""},
	704:&TableHeroGrowing{704,7,4,5,5003,90,20000,"未知","",""},
	705:&TableHeroGrowing{705,7,5,5,5053,30,50000,"未知","",""},
	801:&TableHeroGrowing{801,8,1,5,5003,5,1000,"","",""},
	802:&TableHeroGrowing{802,8,2,5,5003,30,4000,"未知","",""},
	803:&TableHeroGrowing{803,8,3,5,5003,60,8000,"未知","",""},
	804:&TableHeroGrowing{804,8,4,5,5003,90,20000,"未知","",""},
	805:&TableHeroGrowing{805,8,5,5,5053,30,50000,"未知","",""},
	901:&TableHeroGrowing{901,9,1,5,5003,5,1000,"","",""},
	902:&TableHeroGrowing{902,9,2,5,5003,30,4000,"未知","",""},
	903:&TableHeroGrowing{903,9,3,5,5003,60,8000,"未知","",""},
	904:&TableHeroGrowing{904,9,4,5,5003,90,20000,"未知","",""},
	905:&TableHeroGrowing{905,9,5,5,5053,30,50000,"未知","",""},
	1001:&TableHeroGrowing{1001,10,1,5,5003,5,1000,"","",""},
	1002:&TableHeroGrowing{1002,10,2,5,5003,30,4000,"未知","",""},
	1003:&TableHeroGrowing{1003,10,3,5,5003,60,8000,"未知","",""},
	1004:&TableHeroGrowing{1004,10,4,5,5003,90,20000,"未知","",""},
	1005:&TableHeroGrowing{1005,10,5,5,5053,30,50000,"未知","",""},
	1101:&TableHeroGrowing{1101,11,1,5,5003,5,1000,"","",""},
	1102:&TableHeroGrowing{1102,11,2,5,5003,30,4000,"未知","",""},
	1103:&TableHeroGrowing{1103,11,3,5,5003,60,8000,"未知","",""},
	1104:&TableHeroGrowing{1104,11,4,5,5003,90,20000,"未知","",""},
	1105:&TableHeroGrowing{1105,11,5,5,5053,30,50000,"未知","",""},
}
