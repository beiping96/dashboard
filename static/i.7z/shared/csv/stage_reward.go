﻿package csv

type StageReward struct {
	ID int
	Mode int
	Difficulty int
	Level int
	RewardTypeID int
}
var StageRewardMap = map[int64] *StageReward{
	1:&StageReward{1,1,0,1,1005},
	2:&StageReward{2,1,0,2,1006},
	3:&StageReward{3,1,0,3,1007},
	4:&StageReward{4,1,1,1,1005},
	5:&StageReward{5,1,1,2,1006},
	6:&StageReward{6,1,1,3,1007},
}
