﻿package csv

type ActorPos struct {
	ID int
	POS int
	FIT int
	X int
	Y int
	Z int
	EX int
	EY int
	EZ int
}
var ActorPosMap = map[int64] *ActorPos{
	1:&ActorPos{1,1,1,-474,0,427,0,-17417,0},
	2:&ActorPos{2,2,1,-162,0,-43,0,-15967,0},
	3:&ActorPos{3,3,1,252,0,474,0,-15761,0},
	4:&ActorPos{4,4,1,288,0,-238,0,-15500,0},
	5:&ActorPos{5,5,1,60,0,278,0,-16160,0},
	6:&ActorPos{6,6,1,-325,0,158,0,-15915,0},
	7:&ActorPos{7,7,1,235,0,0,0,-15500,0},
	8:&ActorPos{8,0,1,-314,0,-1100,0,2436,0},
	9:&ActorPos{9,0,2,-258,0,-1100,0,2436,0},
}
