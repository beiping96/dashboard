﻿package csv

type StageUIConfig struct {
	ID int
	CheckName string
	BackIcon string
	FloorIcon string
}
var StageUIConfigMap = map[int64] *StageUIConfig{
	1001:&StageUIConfig{1001,"月之海一 ","",""},
	1002:&StageUIConfig{1002,"星之空一","",""},
	1003:&StageUIConfig{1003,"日之塔一","",""},
	1004:&StageUIConfig{1004,"月之海一 ","",""},
	1005:&StageUIConfig{1005,"星之空一","",""},
	2001:&StageUIConfig{2001,"月之海二 ","",""},
	2002:&StageUIConfig{2002,"星之空二","",""},
	2003:&StageUIConfig{2003,"日之塔二","",""},
	2004:&StageUIConfig{2004,"月之海二 ","",""},
	2005:&StageUIConfig{2005,"星之空二","",""},
	3001:&StageUIConfig{3001,"月之海三 ","",""},
	3002:&StageUIConfig{3002,"星之空三","",""},
	3003:&StageUIConfig{3003,"日之塔三","",""},
	9999:&StageUIConfig{9999,"群星之塔","",""},
}
