package csv

type StageMapSelection struct {
	ID int
	Mode int
	Stage_Level int
	Difficulty_Min int
	Difficulty_Max int
	Map_ID_Min int
	Map_ID_Max int
}
var StageMapSelectionMap = map[int64] *StageMapSelection{
	1:&StageMapSelection{1,1,1,1,10,1001,1005},
	2:&StageMapSelection{2,1,2,1,10,2001,2005},
	3:&StageMapSelection{3,1,3,1,10,3001,3003},
}
