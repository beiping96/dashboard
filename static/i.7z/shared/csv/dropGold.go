package csv

type DropGold struct {
	ID int
	Mode int
	Stage_Level int
	Node_Type int
	Drop_Min int
	Drop_Max int
}
var DropGoldMap = map[int64] *DropGold{
	1:&DropGold{1,1,1,3,15,25},
	2:&DropGold{2,1,1,2,30,50},
	3:&DropGold{3,1,1,1,80,80},
	4:&DropGold{4,1,1,6,15,25},
	5:&DropGold{5,1,2,3,25,35},
	6:&DropGold{6,1,2,2,50,70},
	7:&DropGold{7,1,2,1,120,120},
	8:&DropGold{8,1,2,6,25,35},
	9:&DropGold{9,1,3,3,35,45},
	10:&DropGold{10,1,3,2,70,90},
	11:&DropGold{11,1,3,1,120,120},
	12:&DropGold{12,1,3,6,35,45},
}
