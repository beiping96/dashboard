﻿package csv

type StageCount struct {
	ID int
	Type string
	Score int
	MaxScore int
}
var StageCountMap = map[int64] *StageCount{
	1:&StageCount{1,"完成节点数",5,300},
	2:&StageCount{2,"普通怪物",5,300},
	3:&StageCount{3,"精英怪物",10,300},
	4:&StageCount{4,"boss怪物",20,300},
	5:&StageCount{5,"刻印拥有数量",10,300},
	6:&StageCount{6,"传奇卡牌数量",10,300},
	7:&StageCount{7,"奥金持有数量",1,300},
	8:&StageCount{8,"生命数量",25,300},
}
