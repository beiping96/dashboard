package csv

type DropRelation struct {
	ID int
	Difficulty int
	Stage_Level int
	Drop_From int
	Card_Group int
	Relic_Group int
	Potion_Group int
}
var DropRelationMap = map[int64] *DropRelation{
	1:&DropRelation{1,1,1,3,1,1,1},
	2:&DropRelation{2,1,1,2,1,1,1},
	3:&DropRelation{3,1,1,1,12,2,1},
	4:&DropRelation{4,1,1,4,2,1,1},
	5:&DropRelation{5,1,1,6,1,1,1},
	6:&DropRelation{6,1,0,5,1,1,1},
	7:&DropRelation{7,1,2,3,1,1,1},
	8:&DropRelation{8,1,2,2,1,1,1},
	9:&DropRelation{9,1,2,1,12,2,1},
	10:&DropRelation{10,1,2,4,2,1,1},
	11:&DropRelation{11,1,2,6,1,1,1},
	12:&DropRelation{12,1,0,5,1,1,1},
	13:&DropRelation{13,1,3,3,1,1,1},
	14:&DropRelation{14,1,3,2,1,1,1},
	15:&DropRelation{15,1,3,1,12,2,1},
	16:&DropRelation{16,1,3,4,2,1,1},
	17:&DropRelation{17,1,3,6,1,1,1},
	18:&DropRelation{18,1,0,5,1,1,1},
}
