package csv

type EntryExplain struct {
	ID int
	Name string
	Describe string
}
var EntryExplainMap = map[int64] *EntryExplain{
	1:&EntryExplain{1,"格挡","阻挡伤害，回合结束时消失"},
	2:&EntryExplain{2,"能量","打出卡牌时消耗能量"},
	3:&EntryExplain{3,"固有","战斗开始时被抽到手牌中"},
	4:&EntryExplain{4,"消耗","战斗结束前移出牌堆"},
	5:&EntryExplain{5,"虚无","如果回合结束时仍在手中，将被消耗"},
	11:&EntryExplain{11,"疼痛","疼痛是状态牌，且不能被打出"},
	21:&EntryExplain{21,"力量","每点力量影响1点攻击伤害"},
	22:&EntryExplain{22,"敏捷","每点敏捷影响1点从牌中获得的格挡"},
	23:&EntryExplain{23,"愤怒","每有1点愤怒，增加1点攻击伤害"},
	24:&EntryExplain{24,"燃烧","回合开始时损失燃烧层数的生命，燃烧层数减少1层"},
	25:&EntryExplain{25,"感电","被攻击时每有1层感电，额外受到1点伤害"},
	26:&EntryExplain{26,"冰冻","每有1层冰冻，减少1点攻击伤害"},
	27:&EntryExplain{27,"虚弱","造成攻击伤害减少25%"},
	28:&EntryExplain{28,"易伤","受到的攻击伤害增加50%"},
	29:&EntryExplain{29,"脆弱","从牌中获得的格挡减少25%"},
	30:&EntryExplain{30,"荆棘","被攻击时每有1点荆棘反弹1点伤害"},
}
