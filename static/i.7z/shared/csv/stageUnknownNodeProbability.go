package csv

type StageUnknownNodeProbability struct {
	ID int
	Mode int
	Stage_Level int
	Treasure int
	Shop int
	Enemy int
	Event int
}
var StageUnknownNodeProbabilityMap = map[int64] *StageUnknownNodeProbability{
	1:&StageUnknownNodeProbability{1,1,1,50,150,300,800},
	2:&StageUnknownNodeProbability{2,1,2,100,200,200,800},
	3:&StageUnknownNodeProbability{3,1,3,100,300,500,300},
}
