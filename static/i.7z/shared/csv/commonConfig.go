﻿package csv

type CommonConfig struct {
	Key string
	Value string
}
var CommonConfigMap = map[string] *CommonConfig{
	"SERVER_ROUND_INTERVAL":&CommonConfig{"SERVER_ROUND_INTERVAL","1000"},
	"RIGHT_NOW_EXCUTE_SKILL":&CommonConfig{"RIGHT_NOW_EXCUTE_SKILL","1,2"},
	"SERVER_PLAYER_TO_MONSTER_INTERVAL_ADD":&CommonConfig{"SERVER_PLAYER_TO_MONSTER_INTERVAL_ADD","2000"},
	"CARD_FLAY_PARTICLE_MAX_NUM":&CommonConfig{"CARD_FLAY_PARTICLE_MAX_NUM","10"},
	"DESTORY_CARD_MIN_NUM":&CommonConfig{"DESTORY_CARD_MIN_NUM","1"},
	"RELIC_EFFECT_SELECT_CARD":&CommonConfig{"RELIC_EFFECT_SELECT_CARD","2009,2010,2011,2015"},
	"IPHONE_UP_DISTANCE":&CommonConfig{"IPHONE_UP_DISTANCE","68"},
	"IPHONE_DOWN_DISTANCE":&CommonConfig{"IPHONE_DOWN_DISTANCE","-88"},
	"GAME_SET_1":&CommonConfig{"GAME_SET_1","1,0"},
	"GAME_SET_2":&CommonConfig{"GAME_SET_2","1,0"},
	"GAME_SET_3":&CommonConfig{"GAME_SET_3","3,2,1"},
}
