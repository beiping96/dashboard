package csv

type HeroGrowingAttr struct {
	ID int
	Enum int
	Param int
}
var HeroGrowingAttrMap = map[int64] *HeroGrowingAttr{
	1:&HeroGrowingAttr{1,1,10},
	2:&HeroGrowingAttr{2,2,10},
	3:&HeroGrowingAttr{3,3,10},
	4:&HeroGrowingAttr{4,4,1},
	5:&HeroGrowingAttr{5,5,1},
	6:&HeroGrowingAttr{6,6,15},
	7:&HeroGrowingAttr{7,7,1},
	8:&HeroGrowingAttr{8,8,1},
}
