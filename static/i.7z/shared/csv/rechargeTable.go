package csv

type TableRecharge struct {
	ID int
	IAP string
	Name string
	Type int
	BuyParam int
	BuyType int
	BuyPrice string
	Icon string
	Sort int
}
var TableRechargeMap = map[int64] *TableRecharge{
	1:&TableRecharge{1,"com.gaeamobile.us.xx","Fistful of Gems",3,80,1,"0.99","Icon/PropIcon/Shop_gem_01",1},
	2:&TableRecharge{2,"com.gaeamobile.us.xxx","Pounch of Gems",3,500,1,"4.99","Icon/PropIcon/Shop_gem_02",2},
	3:&TableRecharge{3,"com.gaeamobile.us.xxxx","Bucket of Gems",3,1200,1,"9.99","Icon/PropIcon/Shop_gem_03",3},
	4:&TableRecharge{4,"com.gaeamobile.us.xxxxx","Barrel of Gems",3,2500,1,"19.99","Icon/PropIcon/Shop_gem_04",4},
	5:&TableRecharge{5,"com.gaeamobile.us.xxxxxx","Wagon of Gems",3,6500,1,"49.99","Icon/PropIcon/Shop_gem_05",5},
	6:&TableRecharge{6,"com.gaeamobile.us.xxxxxxx","Mountain of Gems",3,14000,1,"99.99","Icon/PropIcon/Shop_gem_06",6},
}
