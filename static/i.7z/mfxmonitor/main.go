package main

import (
	"github.com/rs/zerolog/log"
	"os"
)

func printHelp() {
	log.Info().Msgf("mfxmonitor")
	log.Info().Msgf("    mfxmonitor start mfxmonitor.xml")
}

func main() {
	if len(os.Args) < 2 {
		printHelp()
		return
	}

	switch os.Args[1] {
	case "start":
		if len(os.Args) < 3 {
			printHelp()
			return
		}
		r := start(os.Args[2])
		if !r {
			log.Error().Msgf("start failed, find the error in log")
			return
		}
	default:
		printHelp()
	}
}
