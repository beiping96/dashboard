package main

import (
	"github.com/rs/zerolog/log"
	"golang.org/x/net/context"
	cp "shared/mfxcoredump"
	"shared/proto/server/mfxbase"
)

type myService struct{}

func (my *myService) ReportStatus(ctx context.Context, req *mfxbase.ReportStatusReq) (*mfxbase.ReportStatusRsp, error) {
	defer cp.CoredumpHandler()
	log.Debug().Msgf("report status req=%v", req)
	mon.Report(req)
	rsp := &mfxbase.ReportStatusRsp{Result: 0}
	return rsp, nil
}
