package main

import (
	"encoding/xml"
	"fmt"
	"github.com/rs/zerolog/log"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"io/ioutil"
	"net"
	bd "shared/mfxbasedef"
	lu "shared/mfxlogutil"
	"shared/proto/server/mfxbase"
)

type monitorCfg struct {
	// 使用Mysql来写入所有服务节点的状态
	Mysql bd.MysqlConnection `xml:"mysql"`

	// 提供RPC服务，支持各节点上报自己的状态
	RPC                  bd.EndPoint `xml:"rpc"`
	LogPath              string      `xml:"log_path"`
	LogLevel             string      `xml:"log_level"`
	RegistryLoadInterval uint32      `xml:"registry_load_interval"`
	RegistrySyncInterval uint32      `xml:"registry_sync_interval"`
	ReportTimeout        uint32      `xml:"report_timeout"`
	HostIP               string      `xml:"host_ip"`
}

var (
	cfg monitorCfg
	mon *monitorMgr
)

func start(xmlFile string) bool {
	log.Info().Msgf("start with cfg: %s", xmlFile)

	fileData, err := ioutil.ReadFile(xmlFile)
	if err != nil {
		log.Error().Msgf("%s", err.Error())
		return false
	}

	if err := xml.Unmarshal(fileData, &cfg); err != nil {
		log.Error().Msgf("%s", err.Error())
		return false
	}

	log.Info().Msgf("log path=%s, level=%s", cfg.LogPath, cfg.LogLevel)

	// 设置日志输出与日志级别
	lu.SetupLogPath(cfg.LogPath)
	lu.SetupLogLevel(cfg.LogLevel)

	// 输出基础配置
	log.Info().Msgf("start with cfg: %s", xmlFile)
	log.Debug().Msgf("mysql connection: %s:%s", cfg.Mysql.Ep.Ip, cfg.Mysql.Ep.Port)
	log.Debug().Msgf("mysql database=%s, username=%s, password=%s", cfg.Mysql.Database, cfg.Mysql.Username, cfg.Mysql.Password)
	log.Debug().Msgf("host ip=%s", cfg.HostIP)

	// 创建monitorMgr对象
	dbstr := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8", cfg.Mysql.Username, cfg.Mysql.Password, cfg.Mysql.Ep.Ip, cfg.Mysql.Ep.Port, cfg.Mysql.Database)
	mon = newMonitorMgr(dbstr, cfg.RegistrySyncInterval)

	// 先立即拉取一次监控列表，然后再起一个timer定时拉取数据库里的本机需要监控的节点
	mon.LoadMonList()
	go loadMonListRoutine(cfg.RegistryLoadInterval)

	// 绑定RPC端口，以rpc的形式提供其他节点的状态上报服务
	return startRPC()
}

func startRPC() bool {
	rpcAddr := cfg.RPC.Ip + ":" + cfg.RPC.Port
	ls, err := net.Listen("tcp", rpcAddr)
	if err != nil {
		log.Error().Msgf("rpc listen failed: %s", err.Error())
		return false
	}
	defer ls.Close()

	log.Info().Msgf("rpc listen addr=%s ok", rpcAddr)
	srv := grpc.NewServer()
	mfxbase.RegisterMonitorServiceServer(srv, &myService{})
	reflection.Register(srv)
	srv.Serve(ls)

	log.Info().Msg("rpc exit")
	return true
}
