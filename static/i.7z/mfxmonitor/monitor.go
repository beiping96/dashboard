package main

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/golang/protobuf/proto"
	"github.com/rs/zerolog/log"
	bd "shared/mfxbasedef"
	"shared/proto/server/mfxbase"
	"sync"
	"time"
)

type reportInfo struct {
	*bd.RegistryServerConfig
	LastReportTick uint32
	LastSyncTick   uint32
}

type monitorMgr struct {
	// 监控的列表
	monLock sync.RWMutex
	monList map[string]*bd.RegistryServerConfig

	// 上报的列表
	repList map[string]*reportInfo

	// 与外部通讯的channel
	sigQ  chan string
	recvQ chan string

	// mysql的连接信息
	db *sql.DB
}

func newMonitorMgr(dbStr string, syncInterval uint32) *monitorMgr {
	db, err := sql.Open("mysql", dbStr)
	if err != nil {
		log.Error().Msgf("open mysql failed: %s", err.Error())
		return nil
	}
	db.SetMaxOpenConns(100)
	db.SetMaxIdleConns(10)

	sQ := make(chan string, 10)
	rQ := make(chan string, 10)
	go monitorRoutine(sQ, rQ, syncInterval)
	return &monitorMgr{
		monList: make(map[string]*bd.RegistryServerConfig, 100),
		repList: make(map[string]*reportInfo, 100),
		sigQ:    sQ,
		recvQ:   rQ,
		db:      db,
	}
}

func (mm *monitorMgr) SetList(list map[string]*bd.RegistryServerConfig) {
	mm.monLock.Lock()
	defer mm.monLock.Unlock()
	mm.monList = list
}

func (mm *monitorMgr) GetList() map[string]*bd.RegistryServerConfig {
	mm.monLock.RLock()
	defer mm.monLock.RUnlock()
	return mm.monList
}

func (mm *monitorMgr) LoadMonList() {
	sql := fmt.Sprintf("SELECT app, server, division, node, node_status, service_status FROM t_server WHERE node='%s' AND use_agent=1", cfg.HostIP)
	log.Debug().Msgf("load monitor list sql: %s", sql)
	rows, err := mm.db.Query(sql)
	if err != nil {
		log.Error().Msgf("SELECT t_server failed: %s", err.Error())
		return
	}
	defer rows.Close()

	m := make(map[string]*bd.RegistryServerConfig, 100)
	for rows.Next() {
		var app string
		var server string
		var division string
		var node string
		var nodeStatus uint32
		var serviceStatus uint32
		err := rows.Scan(&app, &server, &division, &node, &nodeStatus, &serviceStatus)
		if err != nil {
			log.Error().Msgf("scan failed: %s", err.Error())
			continue
		}

		log.Debug().Msgf("mon: app=%s, server=%s, division=%s, node=%s", app, server, division, node)
		c := &bd.RegistryServerConfig{
			App:           app,
			Server:        server,
			Division:      division,
			Node:          node,
			UseAgent:      1,
			NodeStatus:    nodeStatus,
			ServiceStatus: serviceStatus,
		}
		key := bd.MakeLookupKey(app, server, division)
		m[key] = c
	}

	mm.SetList(m)
}

func (mm *monitorMgr) Report(req *mfxbase.ReportStatusReq) {
	log.Debug().Msgf("req=%v", req)
	s := proto.MarshalTextString(req)
	select {
	case mm.recvQ <- s:
	default:
	}
}

func (mm *monitorMgr) NotifyExit() {
	mm.sigQ <- "exit"
}

func (mm *monitorMgr) DispatchReport(s string) {
	log.Debug().Msgf("str=%s", s)
	var o mfxbase.ReportStatusReq
	err := proto.UnmarshalText(s, &o)
	if err != nil {
		log.Error().Msgf("unmarshal failed: %s", err.Error())
		return
	}
	log.Debug().Msgf("report=%v", o)

	tick := uint32(time.Now().Unix())
	key := bd.MakeLookupKey(o.App, o.Server, o.Division)
	i, ok := mm.repList[key]
	if ok {
		i.NodeStatus = o.NodeStatus
		i.ServiceStatus = o.ServiceStatus
		i.LastReportTick = tick
		log.Debug().Msgf("app=%s server=%s division=%s report refresh at tick=%d", o.App, o.Server, o.Division, tick)
	} else {
		i = &reportInfo{}
		i.App = o.App
		i.Server = o.Server
		i.Division = o.Division
		i.Node = o.Node
		i.NodeStatus = o.NodeStatus
		i.ServiceStatus = o.ServiceStatus
		i.LastReportTick = tick
		i.LastSyncTick = 0
		mm.repList[key] = i
		log.Debug().Msgf("app=%s server=%s division=%s first report at tick=%d", o.App, o.Server, o.Division, tick)
	}
}

func (mm *monitorMgr) syncNodeStatus(app, server, division, node string, nodeStatus, serviceStatus uint32) {
	sql := fmt.Sprintf("UPDATE t_server SET node_status=%d, service_status=%d WHERE app='%s' AND server='%s' AND division='%s' AND node='%s'", nodeStatus, serviceStatus, app, server, division, node)
	log.Debug().Msgf("sync sql=%s", sql)
	_, err := mm.db.Query(sql)
	if err != nil {
		log.Error().Msgf("UPDATE t_server failed: %s", err.Error())
	}
}

func (mm *monitorMgr) SyncStatus() {
	log.Debug().Msgf("it's time to sync report status to registry")
	now := uint32(time.Now().Unix())
	m := mm.GetList()

	// 遍历监控列表，每一个去上报列表中去取数据
	for key, server := range m {
		info, ok := mm.repList[key]
		if !ok {
			// 没有上报过，则直接给设置成离线状态
			mm.syncNodeStatus(server.App, server.Server, server.Division, server.Node, 1, 1)
			continue
		}

		// 上报过，分析上报的数据
		if (info.LastReportTick + cfg.ReportTimeout) <= now {
			// 超过最大的上报间隔了，判定为离线状态，同步到registry里
			mm.syncNodeStatus(server.App, server.Server, server.Division, server.Node, 1, 1)
			if info.LastSyncTick < info.LastReportTick {
				info.LastSyncTick = now
			}
		} else {
			if info.LastSyncTick < info.LastReportTick {
				// 需要同步到registry
				mm.syncNodeStatus(server.App, server.Server, server.Division, server.Node, info.NodeStatus, info.ServiceStatus)
				info.LastSyncTick = now
			}
		}
	}
}

func monitorRoutine(sigQ, recvQ chan string, syncInterval uint32) {
	log.Debug().Msgf("monitor start...")
	defer func() {
		log.Debug().Msgf("monitor exit...")
	}()

	tick := time.NewTicker(time.Duration(syncInterval) * time.Second)
	for {
		select {
		case s, _ := <-recvQ:
			mon.DispatchReport(s)
		case s, _ := <-sigQ:
			if s == "exit" {
				return
			}
		case <-tick.C:
			mon.SyncStatus()
		}
	}
}

func loadMonListRoutine(t uint32) {
	tick := time.NewTicker(time.Duration(t) * time.Second)
	for {
		select {
		case <-tick.C:
			log.Debug().Msg("load monitor list from mysql active")
			mon.LoadMonList()
		}
	}
}
