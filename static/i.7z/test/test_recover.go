package main

import (
	"fmt"
	"runtime/debug"
)

func CoredumpHandler() {
	if err := recover(); err != nil {
		fmt.Printf("err=%v stack=%s\n", err, string(debug.Stack()))
	}
}

func testCoredump() {
	defer CoredumpHandler()
	var m map[string]int
	m["abc"] = 1
}
