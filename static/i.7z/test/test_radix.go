package main

import (
	"fmt"
	"strings"

	"github.com/mediocregopher/radix.v2/cluster"
	"github.com/mediocregopher/radix.v2/redis"
)

type RedisUtil struct {
	clusterDisabled bool
	cluster         *cluster.Cluster
	standalone      *redis.Client
}

func NewRedisUtil(redisAddr string) (*RedisUtil, error) {
	// 先以单例模式连接上去
	c, err := redis.Dial("tcp", redisAddr)
	if err != nil {
		return nil, err
	}

	// 检测是否开启了集群模式
	s, err := c.Cmd("INFO", "CLUSTER").Str()
	if err != nil {
		c.Close()
		return nil, err
	}

	array := strings.Split(s, "\r")
	if len(array) < 2 {
		c.Close()
		return nil, err
	}

	s = array[1]
	array = strings.Split(s, ":")
	if len(array) == 2 && array[1] == "1" {
		// 集群模式
		c.Close()
		opt := cluster.Opts{
			Addr:             redisAddr,
			PoolSize:         10,
			Dialer:           nil,
			MaxRedirectCount: 5,
		}
		if c, err := cluster.NewWithOpts(opt); err == nil {
			return &RedisUtil{clusterDisabled: false, cluster: c, standalone: nil}, nil
		} else {
			return nil, err
		}
	} else {
		// 单例模式
		return &RedisUtil{clusterDisabled: true, cluster: nil, standalone: c}, nil
	}
}

func (n *RedisUtil) Close() {
	if n.clusterDisabled {
		n.standalone.Close()
	} else {
		n.cluster.Close()
	}
}

func (n *RedisUtil) GetMode() string {
	if n.clusterDisabled {
		return "standalone"
	} else {
		return "cluster"
	}
}

func (n *RedisUtil) GetForKey(key string) (*redis.Client, error) {
	if n.clusterDisabled {
		return n.standalone, nil
	} else {
		return n.cluster.GetForKey(key)
	}
}

func (n *RedisUtil) Put(c *redis.Client) {
	if n.clusterDisabled {
	} else {
		n.cluster.Put(c)
	}
}

func (n *RedisUtil) Cmd(cmd string, args ...interface{}) *redis.Resp {
	if n.clusterDisabled {
		return n.standalone.Cmd(cmd, args)
	} else {
		return n.cluster.Cmd(cmd, args)
	}
}

func testRedis(redisAddr string) {
	c, err := NewRedisUtil(redisAddr)
	if err != nil {
		fmt.Printf("new redis client failed: %s\n", err.Error())
		return
	}

	fmt.Printf("redis %s ok\n", c.GetMode())
	defer func() {
		c.Close()
		fmt.Printf("redis %s closed\n", c.GetMode())
	}()

	key := "aron_test"
	if r, err := c.Cmd("SETNX", key, "123456").Int(); err != nil {
		fmt.Printf("SETNX failed: %s\n", err.Error())
	} else {
		fmt.Printf("result=%d\n", r)
	}

	if v, err := c.Cmd("GET", key).Str(); err != nil {
		fmt.Printf("GET failed: %s\n", err.Error())
	} else {
		fmt.Printf("value=%s\n", v)
	}

	if n, err := c.Cmd("DEL", key).Int(); err != nil {
		fmt.Printf("DEL failed: %s\n", err.Error())
	} else {
		fmt.Printf("del key count=%d\n", n)
	}

	resp := c.Cmd("ZRANGE", "mylists", 0, 0)
	array, err := resp.List()
	if err != nil {
		fmt.Printf("ZRANGE failed: %s", err.Error())
	} else {
		fmt.Printf("array=%v, array length=%d\n", array, len(array))
	}
}

func testRedisCluster(redisAddr string) {
	c, err := NewRedisUtil(redisAddr)
	if err != nil {
		fmt.Printf("new cluster failed: %s\n", err.Error())
		return
	}

	fmt.Printf("%s ok\n", c.GetMode())
	defer func() {
		c.Close()
		fmt.Printf("%s closed\n", c.GetMode())
	}()

	key := "aron_test"

	if r, err := c.Cmd("SETNX", key, "123456").Int(); err != nil {
		fmt.Printf("SETNX failed: %s\n", err.Error())
	} else {
		fmt.Printf("result=%d\n", r)
	}

	if v, err := c.Cmd("GET", key).Str(); err != nil {
		fmt.Printf("GET failed: %s\n", err.Error())
	} else {
		fmt.Printf("value=%s\n", v)
	}

	if n, err := c.Cmd("DEL", key).Int(); err != nil {
		fmt.Printf("DEL failed: %s\n", err.Error())
	} else {
		fmt.Printf("del key count=%d\n", n)
	}
}

func testRedisClusterTrx(redisAddr string) {
	c, err := NewRedisUtil(redisAddr)
	if err != nil {
		fmt.Printf("new redis failed: %s\n", err.Error())
		return
	}

	fmt.Printf("%s trx begin\n", c.GetMode())
	defer func() {
		c.Close()
		fmt.Printf("%s trx end\n", c.GetMode())
	}()

	key := "aron_test_hash"
	if cli, err := c.GetForKey(key); err == nil {
		cli.Cmd("WATCH", key)
		cli.Cmd("MULTI")
		cli.Cmd("HSET", key, "aron", "123456")
		if s, err := cli.Cmd("EXEC").Array(); err != nil {
			fmt.Printf("EXEC failed: %s, rsp length=%d\n", err.Error(), len(s))
		} else {
			fmt.Printf("EXEC ok, rsp length=%d\n", len(s))
		}
		c.Put(cli)
	}
}
