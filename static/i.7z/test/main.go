package main

import (
	"fmt"
	// "os"
	//"github.com/rs/zerolog/log"
	//"math"
	//"math/rand"
	//"shared/csv"
	//"shared/table"
	//"strconv"
	//"strings"
	//"time"
	// "github.com/sony/sonyflake"
	"context"
	"math/rand"
	"shared/mfxgrpcpool"
	"sync"
	"time"
)

type S struct {
	A uint32
	B uint32
	C map[uint32]bool
}

func (s *S) fun1() {
	fmt.Printf("this=%p, c=%p\n", s, s.C)
	s.A = 5
	s.B = 6
}

func (s S) fun2() {
	fmt.Printf("this=%p, c=%p\n", &s, s.C)
	s.A = 3
	s.B = 4
}

/*
type item struct {
	uid             uint64
	monsterTypeID   uint32
	hp              uint32
	hpLimit         uint32
	round           uint32
	phaseRoundBegin uint32
	oldMonsterAI    uint32
	curMonsterAI    uint32
}

func (monster *item) f1() (spellTypeID uint32, sleepCard time.Duration, effectIDs []uint32, forcedAim bool, phaseChanged bool, ok bool) {
	monsterTypeID := monster.monsterTypeID
	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}

	nextRound := monster.round + 1
	phaseRoundBegin := monster.phaseRoundBegin

	monsterAiId := monster.curMonsterAI
	if monsterAiId == 0 {
		monsterAiId = uint32(mstConf.AI_ID)
		phaseRoundBegin = 1
	} else if mstConf.Phase2_Blood_Per > 0 && mstConf.Phase2_Blood_Per < 100 &&
		monster.hp <= uint32(math.Round(float64(monster.hpLimit)*(float64(mstConf.Phase2_Blood_Per)/100))) {
		monsterAiId = uint32(mstConf.Phase2_AI_ID)
		if monsterAiId != monster.curMonsterAI {
			phaseChanged = true
			phaseRoundBegin = nextRound
		}
	}

	monsterAI, ok := csv.MonsterAIMap[int64(monsterAiId)]
	monsterRound := nextRound - phaseRoundBegin + 1
	if !ok {
		log.Error().Msgf("table monster ai not found, ai id: %d", mstConf.AI_ID)
		return
	}
	weight, ok := table.GetMonsterAIWeight(uint32(monsterAI.ID))
	sequenceLen := len(weight.Sequence)
	if monsterAI.Sequence == "" || monsterAI.Sequence == "0" || (weight.Sequence[sequenceLen-1] == 0 && int(monsterRound) >= sequenceLen) {
		if !ok {
			return
		}
		totalWeight := weight.TotalWeight
		randomWeight := rand.Intn(int(totalWeight))

		for _, w := range weight.CardWeight {
			if randomWeight <= int(w.CardWeight) {
				spellTypeID = w.CardId
				break
			}
			randomWeight -= int(w.CardWeight)
		}
	} else if weight.Sequence[sequenceLen-1] != 0 {
		spellTypeID = uint32(weight.Sequence[(int(monsterRound)-1)%sequenceLen])
	} else {
		spellTypeID = uint32(weight.Sequence[monsterRound-1])
	}
	card, ok := csv.TableCardsMap[int64(spellTypeID)]
	if !ok {
		log.Error().Msgf("monster card not found, card id: %d", spellTypeID)
		return
	}
	sleepCard = time.Duration(card.Forward_Time) * time.Millisecond
	sleepCard += time.Duration(card.Back_Time) * time.Millisecond
	effects := strings.Split(card.EffectIDs, ",")
	effectIDs = make([]uint32, len(effects))
	for i, e := range effects {
		si, err := strconv.Atoi(e)
		if err != nil {
			ok = false
			return
		}
		effectIDs[i] = uint32(si)
	}
	if card.Card_Target == csv.CARD_TARGET_SINGLE {
		forcedAim = true
	} else {
		forcedAim = false
	}
	return
}

func (monster *item) f2() (spellTypeID uint32, sleepCard time.Duration, effectIDs []uint32, forcedAim bool, phaseChanged bool, ok bool) {
	monsterTypeID := monster.monsterTypeID
	mstConf, ok := csv.MonsterMap[int64(monsterTypeID)]
	if !ok {
		log.Error().Msgf("table monster not found, monster type id: %d", monsterTypeID)
		return
	}

	monsterAiId := monster.curMonsterAI
	if monsterAiId == 0 {
		monsterAiId = uint32(mstConf.AI_ID)
		monster.curMonsterAI = monsterAiId
		monster.phaseRoundBegin = 1
	} else if mstConf.Phase2_Blood_Per > 0 && mstConf.Phase2_Blood_Per < 100 &&
		monster.hp <= uint32(math.Round(float64(monster.hpLimit)*(float64(mstConf.Phase2_Blood_Per)/100))) {
		monsterAiId = uint32(mstConf.Phase2_AI_ID)
		if monsterAiId != monster.curMonsterAI {
			phaseChanged = true
			monster.phaseRoundBegin = monster.round
			monster.oldMonsterAI = monster.curMonsterAI
			monster.curMonsterAI = monsterAiId
		}
	}

	monsterAI, ok := csv.MonsterAIMap[int64(monsterAiId)]
	monsterRound := monster.round - monster.phaseRoundBegin + 1
	if !ok {
		log.Error().Msgf("table monster ai not found, ai id: %d", mstConf.AI_ID)
		return
	}
	weight, ok := table.GetMonsterAIWeight(uint32(monsterAI.ID))
	sequenceLen := len(weight.Sequence)
	if monsterAI.Sequence == "" || monsterAI.Sequence == "0" || (weight.Sequence[sequenceLen-1] == 0 && int(monsterRound) >= sequenceLen) {
		if !ok {
			return
		}
		totalWeight := weight.TotalWeight
		randomWeight := rand.Intn(int(totalWeight))

		for _, w := range weight.CardWeight {
			if randomWeight <= int(w.CardWeight) {
				spellTypeID = w.CardId
				break
			}
			randomWeight -= int(w.CardWeight)
		}
	} else if weight.Sequence[sequenceLen-1] != 0 {
		spellTypeID = uint32(weight.Sequence[(int(monsterRound)-1)%sequenceLen])
	} else {
		spellTypeID = uint32(weight.Sequence[monsterRound-1])
	}
	card, ok := csv.TableCardsMap[int64(spellTypeID)]
	if !ok {
		log.Error().Msgf("monster card not found, card id: %d", spellTypeID)
		return
	}
	sleepCard = time.Duration(card.Forward_Time) * time.Millisecond
	sleepCard += time.Duration(card.Back_Time) * time.Millisecond
	effects := strings.Split(card.EffectIDs, ",")
	effectIDs = make([]uint32, len(effects))
	for i, e := range effects {
		si, err := strconv.Atoi(e)
		if err != nil {
			ok = false
			return
		}
		effectIDs[i] = uint32(si)
	}
	if card.Card_Target == csv.CARD_TARGET_SINGLE {
		forcedAim = true
	} else {
		forcedAim = false
	}
	return
}*/

func main() {
	pool := mfxgrpcpool.New(2, time.Duration(0), time.Duration(5)*time.Second)
	addrs := []string{"192.168.95.233:17802", "192.168.95.182:17922", "192.168.95.233:17902"}

	num := 1000
	wg := &sync.WaitGroup{}
	wg.Add(num)
	for i := 0; i < num; i++ {
		go func() {
			conn, err := pool.GetConn(context.Background(), addrs[rand.Intn(len(addrs))])
			if err != nil {
				panic(err.Error())
			}
			conn.Close()
			wg.Done()
		}()
	}

	wg.Wait()
	// allID := make(map[uint64]bool)
	// for i := 0; i < 100; i++ {
	// 	time.Sleep(time.Duration(10) * time.Millisecond)
	// 	stageUIDGenerator := sonyflake.NewSonyflake(sonyflake.Settings{MachineID: func() (uint16, error) { return 1, nil }})
	// 	for local := 0; local < 10; local++ {
	// 		uid, err := stageUIDGenerator.NextID()
	// 		if err != nil {
	// 			panic(err.Error())
	// 		}
	// 		if allID[uid] {
	// 			panic("error repeated")
	// 		}
	// 		allID[uid] = true
	// 	}
	// }
	// fmt.Printf("len %v", len(allID))

	//s := &S{A: 1, B: 2, C: make(map[uint32]bool, 100)}
	//fmt.Printf("s=%v\n", s)
	//s.fun1()
	//fmt.Printf("s=%v\n", s)
	//s.fun2()
	//fmt.Printf("s=%v\n", s)
	//
	// if len(os.Args) >= 2 {
	// 	redisAddr := os.Args[1]
	// 	testRedis(redisAddr)
	// 	//testRedisCluster(redisAddr)
	// 	//testRedisClusterTrx(redisAddr)
	// }
	//monster1 := &item{uid: 1, monsterTypeID: 601, hp: 15, hpLimit: 30, round: 0, phaseRoundBegin: 0, oldMonsterAI: 0, curMonsterAI: 601}
	//for i := 0; i < 5; i++ {
	//	spellID, sleep, effects, force, changed, ok := monster1.f1()
	//	fmt.Printf("----%v, %v, %v, %v, %v, %v, %v\n", spellID, sleep, effects, force, changed, ok, *monster1)
	//}

	/*
		monster2 := &item{uid: 1, monsterTypeID: 601, hp: 30, hpLimit: 30, round: 0, phaseRoundBegin: 0, oldMonsterAI: 0, curMonsterAI: 0}
		for i := 0; i < 10; i++ {
			monster2.round++
			if i <= 4 {
				monster2.hp -= 5
			} else if i < 8 {
				monster2.hp += 5
			} else {
				monster2.hp -= 5
			}
			spellID, sleep, effects, force, changed, ok := monster2.f2()
			fmt.Printf("++++%v, %v, %v, %v, %v, %v, %v\n", spellID, sleep, effects, force, changed, ok, *monster2)
		}*/

	//testCoredump()

	/*
		err := testErrno()
		fmt.Printf("%d desc %s\n", err, err.Error())*/

	return
}
