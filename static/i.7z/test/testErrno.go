package main

import (
	"fmt"
)

type mfxerror uint16

func (err mfxerror) Error() string {
	return fmt.Sprintf("%d", err)
}

func testErrno() error {
	return mfxerror(5006)
}
