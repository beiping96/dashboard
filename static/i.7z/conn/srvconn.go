package main

import (
	"github.com/rs/zerolog/log"
	"net"
	cd "shared/mfxconn"
)

func handleServerMsg(conn net.Conn, sig chan<- *innerCmd, hdr, body []byte) {
	header := cd.ParseHeader(hdr)
	ok := cd.IsInnerCmd(header.CmdID)
	if !ok {
		sig <- &innerCmd{
			Cmd:  innerCmdServerBroadcast,
			Conn: conn,
			Hdr:  hdr,
			Body: body,
		}
		return
	}

	switch header.CmdID {
	case cd.CmdMasterSet:
		sig <- &innerCmd{
			Cmd:  innerCmdServerMaster,
			Conn: conn,
			Hdr:  hdr,
			Body: body,
		}
	case cd.CmdSessionRoute:
		sig <- &innerCmd{
			Cmd:  innerCmdServerSetRoute,
			Conn: conn,
			Hdr:  hdr,
			Body: body,
		}
	case cd.CmdSessionKick:
		sig <- &innerCmd{
			Cmd:  innerCmdServerKick,
			Conn: conn,
			Hdr:  hdr,
			Body: body,
		}
	case cd.CmdKickAll:
		sig <- &innerCmd{
			Cmd:  innerCmdServerKickAll,
			Conn: conn,
		}
	}
}

func handleServerConn(conn net.Conn, sig chan<- *innerCmd) {
	defer conn.Close()

	remoteAddr := conn.RemoteAddr().String()
	log.Debug().Msgf("server=%s incoming", remoteAddr)

	err := cd.HandleStream(conn, func(conn net.Conn, hdr, body []byte) {
		dupHdr := make([]byte, len(hdr))
		dupBody := make([]byte, len(body))
		copy(dupHdr, hdr)
		copy(dupBody, body)
		handleServerMsg(conn, sig, dupHdr, dupBody)
	})

	sig <- &innerCmd{
		Cmd:    innerCmdServerLeave,
		Error:  err,
		Server: remoteAddr,
	}

	log.Debug().Msgf("server=%s leave", remoteAddr)
}
