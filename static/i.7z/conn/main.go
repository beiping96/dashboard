package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Printf("conn start conn.xml\n")
		return
	}

	switch os.Args[1] {
	case "start":
		c, err := newConfig(os.Args[2])
		if err != nil {
			fmt.Println(err.Error())
			return
		}
		config = c
		fmt.Printf("log path: %s, log level=%s\n", c.LogPath, c.LogLevel)
		startBusiness()

	default:
		fmt.Printf("conn start conn.xml\n")
		return
	}
}
