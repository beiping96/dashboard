package main

import (
	"encoding/json"
	"github.com/rs/zerolog/log"
	"io"
	"net"
	bd "shared/mfxbasedef"
	cd "shared/mfxconn"
	ig "shared/mfxidgen"
	lr "shared/mfxlocalregistry"
	lu "shared/mfxlogutil"
	"strconv"
	"time"
)

type innerCmd struct {
	Cmd       uint8
	Error     error
	SessionID uint64
	Server    string
	Conn      net.Conn
	Hdr       []byte
	Body      []byte
}

type clientSession struct {
	SessionID uint64
	Conn      net.Conn
	Server    string
}

const (
	// 内部的命令定义
	innerCmdClientListenStart = 1
	innerCmdClientListenStop  = 2
	innerCmdClientIncoming    = 3
	innerCmdClientLeave       = 4
	innerCmdClientUp          = 5

	innerCmdServerListenStart = 101
	innerCmdServerListenStop  = 102
	innerCmdServerIncoming    = 103
	innerCmdServerLeave       = 104
	innerCmdServerMaster      = 105
	innerCmdServerBroadcast   = 106
	innerCmdServerKick        = 107
	innerCmdServerKickAll     = 108
	innerCmdServerSetRoute    = 109

	innerCmdAdminListenStart = 201
	innerCmdAdminListenStop  = 202
	innerCmdAdminKick        = 203
	innerCmdAdminKickAll     = 204
)

var (
	// 自己的状态
	config      *connConfig
	masterFrom  map[string]int
	connID      uint16
	sessionSeed uint16

	// 后端服务的列表
	serverMap    map[string]net.Conn
	serverMaster string

	// 客户端的列表
	clientMap map[uint64]*clientSession
)

func startBusiness() {
	// 设置全局日志和流量日志
	lu.SetupLogPath(config.LogPath)
	lu.SetupLogLevel(config.LogLevel)

	// 初始化配置
	if app, server, id, err := bd.ParseDivision(config.Division); err != nil {
		log.Error().Msgf("division error: %s", err.Error())
		log.Debug().Msg("business exit")
		return
	} else {
		log.Debug().Msgf("app=%s, server=%s, id=%s", app, server, id)
		if i, err := strconv.Atoi(id); err != nil {
			log.Error().Msgf("division error: %s", err.Error())
			log.Debug().Msg("business exit")
			return
		} else {
			connID = uint16(i)
		}
	}

	masterFrom = parseMasterFrom(config.MasterFrom)
	log.Debug().Msgf("start business with connID=%d", connID)
	log.Debug().Msgf("locator:%v", config.Loc)
	log.Debug().Msgf("master from %v", masterFrom)
	log.Debug().Msgf("server queue size=%d", config.ServerQueue)
	log.Debug().Msgf("client queue size=%d", config.ClientQueue)
	log.Debug().Msgf("client max conn=%d", config.GetClientMaxConn())
	log.Debug().Msgf("client vip from=%s", config.ClientVipFrom)
	log.Debug().Msgf("pkt body maxlen=%d", cd.LengthOfMaxBody)

	// 先尝试拉取一次registry，如果失败则直接退出
	lr.SetLocator(config.Loc.Ep.Ip, config.Loc.Ep.Port)
	if err := lr.QueryRegistry(); err != nil {
		log.Error().Msgf("query registry from %s:%s failed, %s", config.Loc.Ep.Ip, config.Loc.Ep.Port, err.Error())
		log.Debug().Msg("business exit")
		return
	}
	lr.StartQueryLoop(config.Loc.RefreshInterval)

	// 创建与所有连接进行信令交互的chan
	serverSignal := make(chan *innerCmd, config.ServerQueue)
	clientSignal := make(chan *innerCmd, config.ClientQueue)
	adminSignal := make(chan *innerCmd, 100)

	// 创建server由远程地址到报文通道的映射
	serverMap = make(map[string]net.Conn)
	serverMaster = ""
	clientMap = make(map[uint64]*clientSession)

	// 启动client/server/admin的监听协程
	go startAcceptClient(config, clientSignal)
	go startAcceptServer(config, serverSignal)
	go startAcceptAdmin(config, adminSignal)

	// 启动剖析器的timer，每10秒输出一些重要的运行指标
	tick := time.NewTicker(time.Duration(config.ProfilerInterval) * time.Second)

	// 接收内部命令，并处理
	for {
		select {
		case c := <-clientSignal:
			dispatchClientSignal(c, clientSignal)
		case c := <-serverSignal:
			dispatchServerSignal(c, serverSignal)
		case c := <-adminSignal:
			dispatchAdminSignal(c, adminSignal)
		case <-tick.C:
			dispatchProfiler(clientSignal, serverSignal, adminSignal)
		}
	}

	log.Debug().Msg("business exit")
}

func dispatchClientSignal(c *innerCmd, sig chan<- *innerCmd) {
	switch c.Cmd {
	case innerCmdClientListenStart:
		// 对客户端的监听服务已启动
		if c.Error != nil {
			log.Error().Msgf("start listen client failed: %s", c.Error.Error())
		} else {
			log.Info().Msg("start listen client ok")
		}
	case innerCmdClientIncoming:
		// 有一个客户端连接上来
		remoteAddr := c.Conn.RemoteAddr().String()
		log.Debug().Msgf("client incoming: conn=%v, remote=%s", c.Conn, remoteAddr)
		conn, ok := serverMap[serverMaster]
		if !ok {
			// 还没有master设置上来，所以关闭客户端连接
			log.Error().Msgf("master is nil, so close the connection from client=%s", remoteAddr)
			c.Conn.Close()
		} else {
			if num := uint32(len(clientMap)); num >= config.GetClientMaxConn() {
				// 客户端连接已经超过上限了
				log.Debug().Msgf("conn is full, client num=%d, max=%d", num, config.GetClientMaxConn())
				c.Conn.Close()
			} else {
				// 为这个客户端连接创建一个会话
				sessionID := ig.GenConnSessionID(connID, sessionSeed)
				sessionSeed++

				cs := &clientSession{
					SessionID: sessionID,
					Conn:      c.Conn,
					Server:    serverMaster,
				}
				clientMap[sessionID] = cs
				log.Debug().Msgf("client map size=%d", len(clientMap))

				// 给Master发一个session enter的消息
				sessions := make([]uint64, 1)
				sessions[0] = sessionID
				pkt := cd.MakeSessionPkt(sessions, cd.CmdSessionEnter, 0, 0, nil)
				_, err := conn.Write(pkt)
				if err != nil {
					log.Error().Msgf("send session=%d enter failed: %s", c.SessionID, err.Error())
					c.Conn.Close()
				} else {
					// 创建一个协程去处理这个客户端连接
					go handleClientConn(c.Conn, sessionID, serverMaster, sig)
				}
			}
		}
	case innerCmdClientLeave:
		remoteAddr := c.Server
		log.Debug().Msgf("client leave: remote=%s, session=%d", remoteAddr, c.SessionID)

		// 给Master发一个session leave的消息
		conn, ok := serverMap[serverMaster]
		if ok {
			sessions := make([]uint64, 1)
			sessions[0] = c.SessionID
			pkt := cd.MakeSessionPkt(sessions, cd.CmdSessionLeave, 0, 0, nil)
			_, err := conn.Write(pkt)
			if err != nil {
				log.Error().Msgf("send session=%d leave failed: %s", c.SessionID, err.Error())
			}
		}

		// 删去这个客户端对应的资源
		delete(clientMap, c.SessionID)
		log.Debug().Msgf("client map size=%d", len(clientMap))
	case innerCmdClientUp:
		// 客户端上行数据，依据cs里的Server来做转发
		cs, ok := clientMap[c.SessionID]
		if ok {
			log.Debug().Msgf("client up: server=%s", cs.Server)
			conn, ok := serverMap[cs.Server]
			if ok {
				log.Debug().Msgf("server=%s found, conn=%v", cs.Server, conn)
				forwardToServer(conn, c.SessionID, c.Hdr, c.Body)
			} else {
				log.Error().Msgf("server=%s not found, discard client up", cs.Server)
			}
		} else {
			log.Debug().Msgf("client up, but session=%d not found", c.SessionID)
		}
	}
}

func dispatchServerSignal(c *innerCmd, sig chan<- *innerCmd) {
	switch c.Cmd {
	case innerCmdServerListenStart:
		// 对后端服务的监听服务已启动
		if c.Error != nil {
			log.Error().Msgf("start listen server failed: %s", c.Error.Error())
		} else {
			log.Info().Msg("start listen server ok")
		}
	case innerCmdServerListenStop:
		log.Info().Msg("stop listen server ok")
	case innerCmdServerIncoming:
		// 创建一个协程去处理这个socket连接
		remoteAddr := c.Conn.RemoteAddr().String()
		log.Debug().Msgf("server incoming: conn=%v, remote=%s", c.Conn, remoteAddr)

		serverMap[remoteAddr] = c.Conn
		log.Debug().Msgf("server map size=%d", len(serverMap))

		go handleServerConn(c.Conn, sig)
	case innerCmdServerLeave:
		// 删去这个socket连接对应的映射
		remoteAddr := c.Server
		log.Debug().Msgf("server leave: remote=%s", remoteAddr)

		kickAll := false
		if serverMaster == remoteAddr {
			serverMaster = ""
			log.Debug().Msgf("master=%s leave", remoteAddr)
			kickAll = true
		}
		log.Debug().Msgf("master=%s", serverMaster)

		delete(serverMap, remoteAddr)
		log.Debug().Msgf("server map size=%d", len(serverMap))

		// 如果是master离开，则需要踢掉所有客户端
		if kickAll {
			log.Debug().Msg("master leave, should kick all clients")
			kickAllClients()
		}
	case innerCmdServerMaster:
		remoteAddr := c.Conn.RemoteAddr().String()
		log.Debug().Msgf("server=%s want to be master", remoteAddr)
		if isMasterFromValid(remoteAddr) {
			oldMaster := serverMaster

			// 设置新主
			serverMaster = remoteAddr
			log.Debug().Msgf("master=%s apply", serverMaster)
			if err := cd.SendMasterYou(c.Conn); err != nil {
				log.Error().Msgf("send master you failed: %s", err.Error())
			}

			// 通知旧的主
			oldConn, ok := serverMap[oldMaster]
			if ok {
				log.Debug().Msgf("notify server=%s not master", oldMaster)
				if err := cd.SendMasterNot(oldConn); err != nil {
					log.Error().Msgf("send master not failed: %s", err.Error())
				}
			}
		} else {
			// 告知对方失败
			log.Debug().Msgf("master=%s apply failed, invalid from", remoteAddr)
			if err := cd.SendMasterNot(c.Conn); err != nil {
				log.Error().Msgf("send master not failed: %s", err.Error())
			}
		}
	case innerCmdServerBroadcast:
		remoteAddr := c.Conn.RemoteAddr().String()
		log.Debug().Msgf("server=%s broadcast", remoteAddr)
		broadcastToClients(c.Hdr, c.Body)
	case innerCmdServerKick:
		remoteAddr := c.Conn.RemoteAddr().String()
		log.Debug().Msgf("server=%s request kick", remoteAddr)
		kickClients(c.Hdr, c.Body)
	case innerCmdServerKickAll:
		remoteAddr := c.Conn.RemoteAddr().String()
		log.Info().Msgf("server=%s request kick all clients", remoteAddr)
		kickAllClients()
	case innerCmdServerSetRoute:
		setRouteForClients(c.Hdr, c.Body)
	}
}

func dispatchAdminSignal(c *innerCmd, sig chan<- *innerCmd) {
	switch c.Cmd {
	case innerCmdAdminListenStart:
		log.Debug().Msg("start listen admin ok")
	case innerCmdAdminListenStop:
		log.Debug().Msg("stop listen admin ok")
	case innerCmdAdminKick:
		log.Debug().Msgf("admin kick session=%d", c.SessionID)
		cs, ok := clientMap[c.SessionID]
		if ok {
			log.Debug().Msgf("client session=%d kicked by admin", c.SessionID)
			cs.Conn.Close()
		} else {
			log.Debug().Msgf("admin kick session=%d, but not found", c.SessionID)
		}
	case innerCmdAdminKickAll:
		log.Info().Msg("admin kick all")
		kickAllClients()
	}
}

func dispatchProfiler(client, server, admin chan<- *innerCmd) {
	log.Info().Msgf("client cmd queue size=%d", len(client))
	log.Info().Msgf("server cmd queue size=%d", len(server))
	log.Info().Msgf("admin  cmd queue size=%d", len(admin))
}

// 辅助函数

func forwardToServer(conn io.Writer, sessionID uint64, hdr, body []byte) {
	sessions := make([]uint64, 1)
	sessions[0] = sessionID
	pkt, cmdID := cd.CopySessionPkt(sessions, hdr, body)
	n, err := conn.Write(pkt)
	if config.IsTrafficEnabled() {
		log.Debug().Msgf("UP|session=%d|cmd=%d|hdr=%d|body=%d", sessionID, cmdID, len(hdr), len(body))
		if err != nil {
			log.Debug().Msgf("UPFORWARD|error=%s", err.Error())
		} else {
			log.Debug().Msgf("UPFORWARD|bytes=%d", n)
		}
	}
}

func broadcastToClients(hdr, body []byte) {
	sessionNum, sessions, newBody := cd.ParseSessionBody(body)
	log.Debug().Msgf("broadcast %d client(s)", sessionNum)
	pkt, cmdID := cd.CopyCommonPkt(hdr, newBody)
	for i := 0; i < int(sessionNum); i++ {
		sessionID := sessions[i]
		cs, ok := clientMap[sessionID]
		if ok {
			n, err := cs.Conn.Write(pkt)
			if config.IsTrafficEnabled() {
				log.Debug().Msgf("DN|session=%d|cmd=%d|hdr=%d|body=%d", sessionID, cmdID, len(hdr), len(newBody))
				if err != nil {
					log.Debug().Msgf("DNFORWARD|error=%s", err.Error())
				} else {
					log.Debug().Msgf("DNFORWARD|bytes=%d", n)
				}
			}
		} else {
			log.Debug().Msgf("client dn, but session=%d not found", sessionID)
		}
	}
}

func kickClients(hdr, body []byte) {
	header := cd.ParseHeader(hdr)
	if header.CmdID == cd.CmdSessionKick {
		sessionNum, sessions, _ := cd.ParseSessionBody(body)
		log.Debug().Msgf("kick %d client(s)", sessionNum)
		for i := 0; i < int(sessionNum); i++ {
			sessionID := sessions[i]
			cs, ok := clientMap[sessionID]
			if ok {
				log.Debug().Msgf("client kicked, session=%d", sessionID)
				cs.Conn.Close()
			} else {
				log.Debug().Msgf("client kicked, session=%d not found", sessionID)
			}
		}
	}
}

func kickAllClients() {
	for sessionID, cs := range clientMap {
		log.Debug().Msgf("client kicked, session=%d", sessionID)
		cs.Conn.Close()
	}
}

func setRouteForClients(hdr, body []byte) {
	header := cd.ParseHeader(hdr)
	if header.CmdID == cd.CmdSessionRoute {
		sessionNum, sessions, newBody := cd.ParseSessionBody(body)

		var tc cd.TinyCmd
		err := json.Unmarshal(newBody, &tc)
		if err != nil {
			log.Error().Msgf("set route unmarshal failed: %s", err.Error())
			return
		}
		log.Debug().Msgf("tinycmd=%v", tc)

		_, ok := serverMap[tc.StrParam]
		if ok {
			// 目标地址有效
			for i := 0; i < int(sessionNum); i++ {
				sessionID := sessions[i]
				cs, ok := clientMap[sessionID]
				if ok {
					// session有效
					log.Debug().Msgf("client set route, session=%d from %s to %s", sessionID, cs.Server, tc.StrParam)
					cs.Server = tc.StrParam
				} else {
					log.Debug().Msgf("client set route, session=%d not found", sessionID)
				}
			}
		}
	}
}
