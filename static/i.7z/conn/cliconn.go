package main

import (
	"github.com/rs/zerolog/log"
	"io"
	"net"
	cd "shared/mfxconn"
)

func handleClientMsg(w io.Writer, sessionID uint64, sig chan<- *innerCmd, hdr, body []byte) {
	sig <- &innerCmd{
		Cmd:       innerCmdClientUp,
		SessionID: sessionID,
		Hdr:       hdr,
		Body:      body,
	}
}

func handleClientConn(conn net.Conn, sessionID uint64, serverMaster string, sig chan<- *innerCmd) {
	defer conn.Close()

	server := serverMaster
	remoteAddr := conn.RemoteAddr().String()
	log.Debug().Msgf("client=%s incoming, session=%d, server=%s", remoteAddr, sessionID, server)

	err := cd.HandleStream(conn, func(conn net.Conn, hdr, body []byte) {
		header := cd.ParseHeader(hdr)
		if cd.IsInnerCmd(header.CmdID) {
			return
		}

		dupHdr := make([]byte, len(hdr))
		dupBody := make([]byte, len(body))
		copy(dupHdr, hdr)
		copy(dupBody, body)

		handleClientMsg(conn, sessionID, sig, dupHdr, dupBody)
	})

	sig <- &innerCmd{
		Cmd:       innerCmdClientLeave,
		Error:     err,
		Server:    remoteAddr,
		SessionID: sessionID,
	}
}
