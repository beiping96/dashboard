package main

import (
	"encoding/json"
	"github.com/rs/zerolog/log"
	"net"
	"net/http"
	_ "net/http/pprof"
	lr "shared/mfxlocalregistry"
	lu "shared/mfxlogutil"
	"strconv"
)

type adminRsp struct {
	Result uint   `json:"result"`
	Error  string `json:"error"`
	Msg    string `json:"msg"`
}

func handleAdminMsg(rsp http.ResponseWriter, req *http.Request, sig chan<- *innerCmd) {
	var result adminRsp
	rsp.Header().Add("Access-Control-Allow-Origin", "*")

	// 拿到请求端的ip地址
	rip := req.Header.Get("X-Forwarded-For")
	if rip == "" {
		rip, _, _ = net.SplitHostPort(req.RemoteAddr)
	}

	// 判断这ip是否合法
	if !lr.IsRemoteAdminIPAllowed(rip) {
		result.Result = 1
		result.Error = "not valid admin from"
		body, _ := json.Marshal(result)
		_, err := rsp.Write(body)
		if err != nil {
			log.Error().Msgf("%s", err.Error())
		}
		return
	}

	if req.Method != "POST" {
		log.Debug().Msgf("error Method=%v", req.Method)

		result.Result = 1
		result.Error = "should use POST method"
		body, _ := json.Marshal(result)
		_, err := rsp.Write(body)
		if err != nil {
			log.Error().Msgf("%s", err.Error())
		}
	} else {
		err := req.ParseForm()
		if err != nil {
			log.Error().Msgf("%s", err.Error())
			return
		}
		op := req.FormValue("op")
		switch op {
		case "":
			result.Result = 1
			result.Error = "should contain field 'op'"
		case "kick":
			s := req.FormValue("session")
			var i int64
			i, err = strconv.ParseInt(s, 10, 64)
			if err != nil || i == 0 {
				result.Result = 1
				result.Error = err.Error()
			} else {
				sig <- &innerCmd{
					Cmd:       innerCmdAdminKick,
					SessionID: uint64(i),
				}
				result.Result = 0
				result.Error = ""
				result.Msg = "ok"
			}
		case "kickall":
			sig <- &innerCmd{
				Cmd: innerCmdAdminKickAll,
			}
			result.Result = 0
			result.Msg = "ok"
		case "log":
			level := req.FormValue("level")
			s := lu.SetupLogLevel(level)
			log.Info().Msgf("log level set to %s", s)

			result.Result = 0
			result.Msg = s
		}

		body, _ := json.Marshal(result)
		_, err = rsp.Write(body)
		if err != nil {
			log.Error().Msgf("%s", err.Error())
		}
	}
}

func startAcceptAdmin(config *connConfig, sig chan<- *innerCmd) {
	adminAddr := config.ListenAdmin
	log.Info().Msgf("start listen for admin: %s", adminAddr)

	http.HandleFunc("/admin", func(rsp http.ResponseWriter, req *http.Request) {
		handleAdminMsg(rsp, req, sig)
	})

	sig <- &innerCmd{
		Cmd: innerCmdAdminListenStart,
	}

	admin := &http.Server{Addr: adminAddr, Handler: nil}
	err := admin.ListenAndServe()
	if err != nil {
		log.Error().Msgf("admin ListenAndServe: %s", err.Error())
	}

	sig <- &innerCmd{
		Cmd: innerCmdAdminListenStop,
	}
}
