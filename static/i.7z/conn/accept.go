package main

import (
	"github.com/rs/zerolog/log"
	"net"
)

func startAcceptClient(config *connConfig, ch chan<- *innerCmd) {
	log.Info().Msgf("start listen for client: %s", config.ListenClient)

	clientAddr := config.ListenClient
	ls, err := net.Listen("tcp", clientAddr)
	if err != nil {
		ch <- &innerCmd{
			Cmd:   innerCmdClientListenStart,
			Error: err,
		}
		return
	}
	defer ls.Close()

	ch <- &innerCmd{
		Cmd: innerCmdClientListenStart,
	}

	for {
		conn, err := ls.Accept()
		if err != nil {
			log.Error().Msgf("accept client failed: %s", err.Error())
			continue
		}

		ch <- &innerCmd{
			Cmd:  innerCmdClientIncoming,
			Conn: conn,
		}
	}

	ch <- &innerCmd{
		Cmd: innerCmdClientListenStop,
	}

	log.Info().Msg("listen for client exit")
}

func startAcceptServer(config *connConfig, ch chan<- *innerCmd) {
	log.Info().Msgf("start listen for server: %s", config.ListenServer)

	serverAddr := config.ListenServer
	ls, err := net.Listen("tcp", serverAddr)
	if err != nil {
		ch <- &innerCmd{
			Cmd:   innerCmdServerListenStart,
			Error: err,
		}
		return
	}
	defer ls.Close()

	ch <- &innerCmd{
		Cmd: innerCmdServerListenStart,
	}

	for {
		conn, err := ls.Accept()
		if err != nil {
			log.Error().Msgf("accept server failed: %s", err.Error())
			continue
		}

		ch <- &innerCmd{
			Cmd:  innerCmdServerIncoming,
			Conn: conn,
		}
	}

	ch <- &innerCmd{
		Cmd: innerCmdServerLeave,
	}

	log.Info().Msg("listen for server exit")
}
