package main

import (
	"encoding/xml"
	"io/ioutil"
	bd "shared/mfxbasedef"
	"strings"
)

type connConfig struct {
	Loc              bd.Locator `xml:"locator"`
	ListenClient     string     `xml:"listen_client"`
	ListenServer     string     `xml:"listen_server"`
	ListenAdmin      string     `xml:"listen_admin"`
	MasterFrom       string     `xml:"master_from"`
	Division         string     `xml:"division"`
	ServerQueue      uint32     `xml:"server_queue"`
	ClientQueue      uint32     `xml:"client_queue"`
	ClientMaxConn    uint32     `xml:"client_max_conn"`
	ClientVipFrom    string     `xml:"client_vip_from"`
	ProfilerInterval int32      `xml:"profiler_interval"`
	LogTraffic       uint32     `xml:"log_traffic"`
	LogPath          string     `xml:"log_path"`
	LogLevel         string     `xml:"log_level"`
}

func newConfig(fileName string) (*connConfig, error) {
	fileData, err := ioutil.ReadFile(fileName)
	if err != nil {
		return nil, err
	}

	var config connConfig
	err = xml.Unmarshal(fileData, &config)
	if err != nil {
		return nil, err
	}

	return &config, nil
}

func (c *connConfig) GetClientMaxConn() uint32 {
	return c.ClientMaxConn
}

func (c *connConfig) IsTrafficEnabled() bool {
	return c.LogTraffic != 0
}

func parseMasterFrom(s string) map[string]int {
	m := make(map[string]int)
	array := strings.Split(s, ",")
	for i := 0; i < len(array); i++ {
		ip := strings.TrimSpace(array[i])
		m[ip] = 1
	}
	return m
}

func parseAdminFrom(s string) map[string]int {
	m := make(map[string]int)
	array := strings.Split(s, ",")
	for i := 0; i < len(array); i++ {
		ip := strings.TrimSpace(array[i])
		m[ip] = 1
	}
	return m
}

func parseAddr(s string) (string, string) {
	array := strings.Split(s, ":")
	if len(array) == 2 {
		return array[0], array[1]
	}
	return array[0], ""
}

func isMasterFromValid(remoteAddr string) bool {
	if len(masterFrom) == 0 {
		return true
	}
	ip, _ := parseAddr(remoteAddr)
	_, ok := masterFrom[ip]
	return ok
}
